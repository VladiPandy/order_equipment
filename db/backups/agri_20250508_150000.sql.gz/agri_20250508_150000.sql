--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12 (Debian 15.12-1.pgdg120+1)
-- Dumped by pg_dump version 15.12 (Debian 15.12-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: create_weekly_worker_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.create_weekly_worker_status() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    start_date DATE;
    end_date DATE;
    executor RECORD;
    current_week_period VARCHAR(50);  -- Переименованная переменная
BEGIN
    -- Определяем начало и конец недели через две недели от текущей даты
    start_date := date_trunc('week', CURRENT_DATE + INTERVAL '2 weeks');
    end_date := start_date + INTERVAL '6 days';
    -- Форматируем даты в строку для хранения в week_period
    current_week_period := to_char(start_date, 'DD.MM.YYYY') || '-' || to_char(end_date, 'DD.MM.YYYY');
    -- Проверяем, существуют ли записи на текущую неделю
    IF NOT EXISTS (
        SELECT 1
        FROM public.control_enter_workerweekstatus
        WHERE week_period = current_week_period
    ) THEN
        FOR executor IN SELECT id FROM public.executor LOOP
            INSERT INTO public.control_enter_workerweekstatus (
                id,
                created,
                modified,
                week_period,
                monday,
                tuesday,
                wednesday,
                thursday,
                friday,
                saturday,
                sunday,
                limit_executor,
                executor_id
            ) VALUES (
                uuid_generate_v4(),
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP,
                current_week_period,  -- Используем переименованную переменную
                'Работает',  -- Пример статуса для понедельника
                'Работает',  -- Пример статуса для вторника
                'Работает',  -- Пример статуса для среды
                'Работает',  -- Пример статуса для четверга
                'Выходной',  -- Пример статуса для пятницы
                'Выходной',  -- Пример статуса для субботы
                'Выходной',  -- Пример статуса для воскресенья
                2,  -- Пример лимита исполнителей
                executor.id
            );
        END LOOP;
        RAISE NOTICE 'Созданы записи для недели с % до %', start_date, end_date;
    ELSE
        RAISE NOTICE 'Записи уже существуют для недели с % до %', start_date, end_date;
    END IF;
END;
$$;


ALTER FUNCTION public.create_weekly_worker_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION create_weekly_worker_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.create_weekly_worker_status() IS 'Создает записи в таблице control_enter_workerweekstatus для недели через две недели от текущей даты, если они отсутствуют.';


--
-- Name: create_weekly_working_day_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.create_weekly_working_day_status() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    start_date DATE;
    end_date DATE;
    current_week_period VARCHAR(50);
BEGIN
    -- Определяем начало и конец недели через две недели от текущей даты
    start_date := date_trunc('week', CURRENT_DATE + INTERVAL '2 weeks');
    end_date := start_date + INTERVAL '6 days';
    -- Форматируем даты в строку для хранения в week_period
    current_week_period := to_char(start_date, 'DD.MM.YYYY') || '-' || to_char(end_date, 'DD.MM.YYYY');
    -- Проверяем, существуют ли записи на текущую неделю
    IF NOT EXISTS (
        SELECT 1
        FROM public.control_enter_workingdayofweek
        WHERE week_period = current_week_period
    ) THEN
        -- Если записей нет, создаем новую запись
        INSERT INTO public.control_enter_workingdayofweek (
            id,
            created,
            modified,
            week_period,
            monday,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday
        ) VALUES (
            uuid_generate_v4(),  -- Генерация нового UUID
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP,
            current_week_period,  -- Используем переименованную переменную
            TRUE,  -- Пример статуса для понедельника
            TRUE,  -- Пример статуса для вторника
            TRUE,  -- Пример статуса для среды
            TRUE,  -- Пример статуса для четверга
            FALSE,  -- Пример статуса для пятницы
            FALSE,  -- Пример статуса для субботы
            FALSE   -- Пример статуса для воскресенья
        );
        RAISE NOTICE 'Создана запись для недели с % до %', start_date, end_date;
    ELSE
        RAISE NOTICE 'Запись уже существует для недели с % до %', start_date, end_date;
    END IF;
END;
$$;


ALTER FUNCTION public.create_weekly_working_day_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION create_weekly_working_day_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.create_weekly_working_day_status() IS 'Создает записи в таблице control_enter_workingdayofweek для недели через две недели от текущей даты, если они отсутствуют.';


--
-- Name: update_booking_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.update_booking_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    updated_count integer;
BEGIN
    UPDATE public.projects_booking
    SET status = 'Оценить'
    WHERE status = 'Принято'
    AND is_delete = false
	AND date_booking < now()::date;
    GET DIAGNOSTICS updated_count = ROW_COUNT;
    RAISE NOTICE 'Обновлено % записей', updated_count;
    RETURN updated_count;
END;
$$;


ALTER FUNCTION public.update_booking_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION update_booking_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.update_booking_status() IS 'Обновляет статус бронирования с "Согласовано" на "Оценить" для записей текущего дня';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adminstrator; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.adminstrator (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    admin_nick character varying(255) NOT NULL,
    admin_person character varying(255) NOT NULL,
    admin_password character varying(128) NOT NULL
);


ALTER TABLE public.adminstrator OWNER TO "Admin_agri";

--
-- Name: analyze; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public."analyze" (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    analyze_name character varying(255) NOT NULL,
    analyze_type_id uuid NOT NULL
);


ALTER TABLE public."analyze" OWNER TO "Admin_agri";

--
-- Name: analyze_type; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.analyze_type (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE public.analyze_type OWNER TO "Admin_agri";

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "Admin_agri";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "Admin_agri";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "Admin_agri";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO "Admin_agri";

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO "Admin_agri";

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO "Admin_agri";

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: block_booking; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.block_booking (
    id integer NOT NULL,
    project_id uuid NOT NULL,
    booking_id integer,
    date_booking date,
    analyse_id uuid,
    equipment_id uuid,
    executor_id uuid,
    is_block boolean,
    write_timestamp timestamp without time zone DEFAULT now() NOT NULL,
    cookies_key uuid DEFAULT gen_random_uuid() NOT NULL,
    update_timestamp timestamp without time zone,
    id_delete boolean DEFAULT false
);


ALTER TABLE public.block_booking OWNER TO "Admin_agri";

--
-- Name: block_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.block_booking ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.block_booking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: control_enter_isopenregistration; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_isopenregistration (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    is_open boolean NOT NULL,
    week_period character varying(50) NOT NULL
);


ALTER TABLE public.control_enter_isopenregistration OWNER TO "Admin_agri";

--
-- Name: control_enter_openwindowforordering; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_openwindowforordering (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    start_date character varying(200) NOT NULL,
    start_time character varying(50) NOT NULL,
    end_time character varying(50) NOT NULL,
    for_priority boolean NOT NULL,
    week_period character varying(50) NOT NULL
);


ALTER TABLE public.control_enter_openwindowforordering OWNER TO "Admin_agri";

--
-- Name: control_enter_workerweekstatus; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_workerweekstatus (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    week_period character varying(50) NOT NULL,
    monday character varying NOT NULL,
    tuesday character varying NOT NULL,
    wednesday character varying NOT NULL,
    thursday character varying NOT NULL,
    friday character varying NOT NULL,
    saturday character varying NOT NULL,
    sunday character varying NOT NULL,
    limit_executor integer NOT NULL,
    executor_id uuid NOT NULL
);


ALTER TABLE public.control_enter_workerweekstatus OWNER TO "Admin_agri";

--
-- Name: control_enter_workingdayofweek; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_workingdayofweek (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    week_period character varying(50) NOT NULL,
    monday boolean NOT NULL,
    tuesday boolean NOT NULL,
    wednesday boolean NOT NULL,
    thursday boolean NOT NULL,
    friday boolean NOT NULL,
    saturday boolean NOT NULL,
    sunday boolean NOT NULL
);


ALTER TABLE public.control_enter_workingdayofweek OWNER TO "Admin_agri";

--
-- Name: dependings_analyzeperequipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_analyzeperequipment (
    id uuid NOT NULL,
    count_samples integer NOT NULL,
    analazy_id uuid NOT NULL,
    equipment_name_id uuid NOT NULL
);


ALTER TABLE public.dependings_analyzeperequipment OWNER TO "Admin_agri";

--
-- Name: dependings_operatorperequipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_operatorperequipment (
    id uuid NOT NULL,
    is_priority boolean NOT NULL,
    equipment_id uuid NOT NULL,
    operator_id uuid NOT NULL
);


ALTER TABLE public.dependings_operatorperequipment OWNER TO "Admin_agri";

--
-- Name: dependings_projectperanalyze; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_projectperanalyze (
    id uuid NOT NULL,
    limit_samples integer NOT NULL,
    analazy_n_id uuid NOT NULL,
    project_n_id uuid NOT NULL
);


ALTER TABLE public.dependings_projectperanalyze OWNER TO "Admin_agri";

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "Admin_agri";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "Admin_agri";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "Admin_agri";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "Admin_agri";

--
-- Name: equipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.equipment (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    count_samples int4 NOT NULL
);


ALTER TABLE public.equipment OWNER TO "Admin_agri";

--
-- Name: executor; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.executor (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    patronymic character varying(255)
);


ALTER TABLE public.executor OWNER TO "Admin_agri";

--
-- Name: feedback_task; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.feedback_task (
    booking_id integer NOT NULL,
    question_1 boolean DEFAULT true NOT NULL,
    question_2 boolean DEFAULT true NOT NULL,
    question_3 boolean DEFAULT true NOT NULL
);


ALTER TABLE public.feedback_task OWNER TO "Admin_agri";

--
-- Name: project; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.project (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    project_nick character varying(255) NOT NULL,
    project_name character varying(255) NOT NULL,
    is_priority boolean NOT NULL,
    responsible_person character varying(255) NOT NULL,
    project_password character varying(128) NOT NULL
);


ALTER TABLE public.project OWNER TO "Admin_agri";

--
-- Name: projects_booking; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.projects_booking (
    id integer NOT NULL,
    project_id uuid NOT NULL,
    date_booking date NOT NULL,
    analyse_id uuid NOT NULL,
    equipment_id uuid NOT NULL,
    executor_id uuid NOT NULL,
    count_analyses integer NOT NULL,
    status character varying(254) NOT NULL,
    is_delete boolean,
    comment text
);


ALTER TABLE public.projects_booking OWNER TO "Admin_agri";

--
-- Name: projects_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.projects_booking ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_booking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: Admin_agri
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active, jobname) FROM stdin;
1	5 0 * * *	\r\n    SELECT public.update_booking_status();\r\n	db	5432	agri_db	Admin_agri	t	update_booking_status
2	0 0 * * 1	 SELECT public.create_weekly_worker_status(); 	db	5432	agri_db	Admin_agri	t	create_weekly_worker_status
3	10 0 * * 1	 SELECT public.create_weekly_working_day_status(); 	db	5432	agri_db	Admin_agri	t	create_weekly_working_day_status
\.


--
-- Data for Name: job_run_details; Type: TABLE DATA; Schema: cron; Owner: Admin_agri
--

COPY cron.job_run_details (jobid, runid, job_pid, database, username, command, status, return_message, start_time, end_time) FROM stdin;
1	28	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-03 00:05:00.000434+00	2025-06-03 00:05:00.075143+00
2	1	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-05-05 00:00:00.000583+00	2025-05-05 00:00:00.05478+00
3	18	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-05-26 00:10:00.000603+00	2025-05-26 00:10:00.047557+00
1	2	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-05 00:05:00.000313+00	2025-05-05 00:05:00.042704+00
3	3	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-05-05 00:10:00.0007+00	2025-05-05 00:10:00.044088+00
1	4	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-06 00:05:00.000861+00	2025-05-06 00:05:00.044802+00
1	19	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-27 00:05:00.001106+00	2025-05-27 00:05:00.047812+00
1	5	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-07 00:05:00.000954+00	2025-05-07 00:05:00.045749+00
1	6	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-08 00:05:00.000943+00	2025-05-08 00:05:00.044926+00
1	7	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-09 00:05:00.00093+00	2025-05-09 00:05:00.044152+00
1	20	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-28 00:05:00.000403+00	2025-05-28 00:05:00.046315+00
1	8	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-13 00:05:00.000112+00	2025-05-13 00:05:00.044449+00
1	9	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-14 00:05:00.000668+00	2025-05-14 00:05:00.075571+00
1	29	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-04 00:05:00.000433+00	2025-06-04 00:05:00.043999+00
1	10	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-20 00:05:00.000653+00	2025-05-20 00:05:00.104485+00
1	21	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-29 00:05:00.001282+00	2025-05-29 00:05:00.057013+00
1	11	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-21 00:42:25.685509+00	2025-05-21 00:42:25.69316+00
1	12	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-22 00:05:00.000473+00	2025-05-22 00:05:00.043925+00
1	13	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-23 00:05:00.001203+00	2025-05-23 00:05:00.044578+00
1	22	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-30 00:05:00.000375+00	2025-05-30 00:05:00.044643+00
1	14	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-24 00:05:00.001032+00	2025-05-24 00:05:00.007753+00
1	15	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-25 00:05:00.00111+00	2025-05-25 00:05:00.046281+00
2	16	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-05-26 00:00:00.001011+00	2025-05-26 00:00:00.045698+00
1	23	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-31 00:05:00.001198+00	2025-05-31 00:05:00.044531+00
1	17	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-26 00:05:00.00061+00	2025-05-26 00:05:00.043541+00
1	30	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-05 00:05:00.000928+00	2025-06-05 00:05:00.044634+00
1	24	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-01 00:05:00.000456+00	2025-06-01 00:05:00.04705+00
2	25	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-06-02 00:00:00.000551+00	2025-06-02 00:00:00.037847+00
1	26	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-02 00:05:00.000168+00	2025-06-02 00:05:00.04267+00
1	31	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-06 00:05:00.001356+00	2025-06-06 00:05:00.045299+00
3	27	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-06-02 00:10:00.001077+00	2025-06-02 00:10:00.044287+00
1	32	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-07 00:05:00.000787+00	2025-06-07 00:05:00.043764+00
1	33	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-08 00:05:00.001157+00	2025-06-08 00:05:00.04398+00
\.


--
-- Data for Name: adminstrator; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.adminstrator (id, created, modified, admin_nick, admin_person, admin_password) FROM stdin;
837ada9a-9407-47ef-a0c0-aee56edb6160	2025-05-21 15:07:38.770053+00	2025-05-21 16:16:36.735029+00	Fedorova	Федорова Е.Н.	Admin0108
28aeaae9-88d4-43da-9f5f-663912f3461f	2025-05-21 16:19:00.939208+00	2025-05-21 16:19:00.939222+00	Kivero	Киверо А.Д.	Admin0407
b0e67ba7-ed16-448a-8c60-71768a7972bd	2025-05-04 13:10:26.033926+00	2025-05-21 16:19:42.5831+00	testadm	Admin Majour	wq123456
\.


--
-- Data for Name: analyze; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public."analyze" (id, created, modified, analyze_name, analyze_type_id) FROM stdin;
1b6870c5-c028-4f7d-b3a6-da026ec81032	2025-06-03 14:23:19.691058+00	2025-06-03 14:23:19.691081+00	Lauric acid	b16068e8-0fcf-47af-ba21-86213f92d426
c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	2025-06-03 14:23:33.390755+00	2025-06-03 14:23:33.390769+00	Met	b16068e8-0fcf-47af-ba21-86213f92d426
f3f7fdcc-ca70-4429-8e87-69ce7118b14e	2025-06-03 14:23:47.699173+00	2025-06-03 14:23:47.699188+00	Met (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
601b7b77-ab12-477c-918e-ca3910a3bb96	2025-06-03 14:24:33.395743+00	2025-06-03 14:24:33.395757+00	Met (IA)	6b8c318d-699a-494c-b63f-44156f6a7a1d
f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	2025-06-03 14:27:47.492716+00	2025-06-03 14:27:47.492731+00	Gln	b16068e8-0fcf-47af-ba21-86213f92d426
cf00c1c2-3c4a-4783-bd78-577444bdf9c3	2025-06-03 14:27:59.783606+00	2025-06-03 14:27:59.78362+00	Gln (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
ace768c2-60a5-40f1-b745-63829f6b8d9f	2025-06-03 14:28:38.626011+00	2025-06-03 14:28:38.626026+00	Glu	b16068e8-0fcf-47af-ba21-86213f92d426
62608399-2245-470d-a950-4eec08632518	2025-06-03 13:07:05.617193+00	2025-06-03 13:07:27.525171+00	BCAA(Ile)	b16068e8-0fcf-47af-ba21-86213f92d426
563ae91e-3338-45f7-aead-c5a3c7a57f63	2025-06-03 13:07:47.499473+00	2025-06-03 13:07:54.311366+00	BCAA(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
091e7bb0-f31d-4465-8e6f-130e5f83d454	2025-06-03 13:08:23.466872+00	2025-06-03 13:08:23.466888+00	BCAA(OA,2IPM,3IPM)	c3866711-d6e9-47b6-aa48-f976bb276685
7129f484-2524-4bc2-a857-7a4663b6abbb	2025-06-03 14:28:53.644272+00	2025-06-03 14:28:53.644288+00	Glu (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	2025-05-29 13:28:04.355701+00	2025-06-03 13:08:47.986075+00	Эктоин	b16068e8-0fcf-47af-ba21-86213f92d426
00bc93e0-ef32-471d-aade-da29ce6a1660	2025-06-03 14:29:59.490074+00	2025-06-03 14:29:59.490089+00	Glu (AA)	da3047ce-76fe-4d82-ba86-c121399b066e
c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	2025-05-29 13:29:04.824051+00	2025-06-03 13:09:07.502709+00	Эктоин (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
0b6e2138-4fc5-4404-b584-6707d4890102	2025-06-04 13:33:15.62963+00	2025-06-04 13:33:15.629647+00	Arg	b16068e8-0fcf-47af-ba21-86213f92d426
bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	2025-05-29 13:30:05.723067+00	2025-06-03 13:09:43.842567+00	Эктоин (AA)	da3047ce-76fe-4d82-ba86-c121399b066e
a426aa21-8248-4fad-8ed2-f82aa388d1b5	2025-06-03 13:23:04.139516+00	2025-06-03 13:23:36.126062+00	Asn(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
571cd566-5150-4b80-9221-233cd3d39b87	2025-06-03 13:23:44.867747+00	2025-06-03 13:23:56.847631+00	Asn	b16068e8-0fcf-47af-ba21-86213f92d426
4e1fbb62-07ef-441b-a27b-1956581e9ca8	2025-06-03 13:24:11.144892+00	2025-06-03 13:24:11.144908+00	Asn(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
3893f977-8f70-49be-903b-ed0149e4a505	2025-06-03 13:25:01.066012+00	2025-06-03 13:25:04.592899+00	DAP	b16068e8-0fcf-47af-ba21-86213f92d426
ca0a4632-47de-4590-b84b-5835604a02c6	2025-06-03 13:25:26.783173+00	2025-06-03 13:25:31.725832+00	DAP(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
73129017-ac9d-4a55-9020-7192a2b3150a	2025-06-03 13:30:48.843806+00	2025-06-03 13:30:48.84382+00	Ser	b16068e8-0fcf-47af-ba21-86213f92d426
fdc73d75-74c1-44e9-b276-2b748d35620b	2025-06-03 13:31:03.514559+00	2025-06-03 13:31:11.817631+00	Ser(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
e40964e1-8934-428e-a06e-18379a30ebae	2025-06-03 13:31:28.139989+00	2025-06-03 13:31:28.140003+00	Ser(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
eecdd0f8-7244-4bf6-8f96-65622901a51d	2025-06-03 13:40:20.475451+00	2025-06-03 13:40:20.475464+00	Arg(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	2025-06-03 13:40:04.79744+00	2025-06-03 13:40:42.416149+00	Arg(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
7da0bd39-87ac-4b74-b152-236e519597e1	2025-06-03 13:42:15.409925+00	2025-06-03 13:42:15.409939+00	a-AP	b16068e8-0fcf-47af-ba21-86213f92d426
9056a26d-d6ce-41bf-b1c0-c255f6902d6e	2025-06-03 13:42:34.010068+00	2025-06-03 13:42:34.010082+00	a-AP(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
020da433-e3a3-419c-851f-f52102a5fe00	2025-06-03 13:43:25.357101+00	2025-06-03 13:43:25.357115+00	Cys(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
eeca97d5-0cb8-4567-9ae5-d3e28c052f61	2025-06-03 13:53:26.880452+00	2025-06-03 13:53:49.324037+00	Cys(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
f546d1c3-036a-47dd-8662-9b37a914408f	2025-06-03 13:54:03.307055+00	2025-06-03 13:54:03.307071+00	Cys(sCys)	da3047ce-76fe-4d82-ba86-c121399b066e
13649857-bdb6-4771-8105-8dc1fd503ac9	2025-06-03 14:00:36.946066+00	2025-06-03 14:00:36.946081+00	Ser(IA)	6b8c318d-699a-494c-b63f-44156f6a7a1d
1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	2025-06-03 14:03:10.046839+00	2025-06-03 14:03:10.046854+00	GSH,GC	b16068e8-0fcf-47af-ba21-86213f92d426
1d7b838c-9f35-43e6-9cde-d63c11d9097f	2025-06-03 14:06:45.428883+00	2025-06-03 14:06:45.428897+00	Gr(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
fb54106f-3070-49c0-8a1e-24cdb1fc2d98	2025-06-03 14:07:44.49621+00	2025-06-03 14:08:11.603768+00	HxR	b16068e8-0fcf-47af-ba21-86213f92d426
571c313e-8ec3-4777-bac7-40855117d510	2025-06-03 14:08:33.085988+00	2025-06-03 14:08:33.086016+00	HxR(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	2025-06-03 14:06:05.372765+00	2025-06-03 14:10:27.36553+00	Gr(sugar)	04ffa9b6-2db9-496b-a154-c68bc55fcefd
8cb45323-f121-47ad-969d-0ed9c2336674	2025-06-03 14:10:50.268844+00	2025-06-03 14:10:50.268859+00	HxR(sugar)	04ffa9b6-2db9-496b-a154-c68bc55fcefd
16ea24f6-2468-4895-9715-2edadc26b522	2025-06-03 14:14:21.853179+00	2025-06-03 14:15:12.669641+00	KSS_His (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
6c07ef7d-b39c-4c57-8c2b-0758a52be082	2025-06-03 14:12:29.330981+00	2025-06-03 14:15:31.254939+00	KSS_His	b16068e8-0fcf-47af-ba21-86213f92d426
2f016b91-0b94-4000-bb68-b6fd5be22a0e	2025-06-03 14:13:05.884122+00	2025-06-03 14:18:24.437218+00	KSS_Ala-Gln	b16068e8-0fcf-47af-ba21-86213f92d426
e32c058b-38a7-4a49-a335-548da531c9b0	2025-06-03 14:18:43.060927+00	2025-06-03 14:18:43.060941+00	KSS_Ala-Gln (OA)	c3866711-d6e9-47b6-aa48-f976bb276685
9fe01f07-a489-4eca-8639-403986129de1	2025-06-03 14:19:19.972779+00	2025-06-03 14:19:19.972794+00	KSS_Carnosine	b16068e8-0fcf-47af-ba21-86213f92d426
e5ee5b58-9179-459c-a9b2-b019cc3d11f8	2025-06-03 14:20:29.344501+00	2025-06-03 14:20:29.344516+00	Fatty acid	b16068e8-0fcf-47af-ba21-86213f92d426
1a901c9f-deb2-4451-a71b-4a059e561058	2025-06-03 14:21:50.397925+00	2025-06-03 14:22:09.683928+00	Amisoft	b16068e8-0fcf-47af-ba21-86213f92d426
7b74a6a1-d92b-476a-befc-0783a20e9170	2025-06-03 14:22:35.924699+00	2025-06-03 14:22:35.924715+00	Amisoft(OA)	c3866711-d6e9-47b6-aa48-f976bb276685
\.


--
-- Data for Name: analyze_type; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.analyze_type (id, created, modified, type) FROM stdin;
b16068e8-0fcf-47af-ba21-86213f92d426	2025-05-29 13:19:04.044114+00	2025-05-29 13:30:30.671328+00	основной продукт
c3866711-d6e9-47b6-aa48-f976bb276685	2025-05-20 11:58:33.389137+00	2025-05-29 13:30:55.497565+00	примеси органических кислот
da3047ce-76fe-4d82-ba86-c121399b066e	2025-05-21 15:08:36.658679+00	2025-05-29 13:31:31.499664+00	примеси аминокислот
6b8c318d-699a-494c-b63f-44156f6a7a1d	2025-06-03 14:00:05.819362+00	2025-06-03 14:00:05.819382+00	примеси неорганических анионов
04ffa9b6-2db9-496b-a154-c68bc55fcefd	2025-06-03 14:09:30.919859+00	2025-06-03 14:09:30.919874+00	анализ сахаров
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add Статус открытой регистрации	7	add_isopenregistration
26	Can change Статус открытой регистрации	7	change_isopenregistration
27	Can delete Статус открытой регистрации	7	delete_isopenregistration
28	Can view Статус открытой регистрации	7	view_isopenregistration
29	Can add Окно для заказа	8	add_openwindowforordering
30	Can change Окно для заказа	8	change_openwindowforordering
31	Can delete Окно для заказа	8	delete_openwindowforordering
32	Can view Окно для заказа	8	view_openwindowforordering
33	Can add Рабочий день недели	9	add_workingdayofweek
34	Can change Рабочий день недели	9	change_workingdayofweek
35	Can delete Рабочий день недели	9	delete_workingdayofweek
36	Can view Рабочий день недели	9	view_workingdayofweek
37	Can add Рабочий график сотрудника	10	add_workerweekstatus
38	Can change Рабочий график сотрудника	10	change_workerweekstatus
39	Can delete Рабочий график сотрудника	10	delete_workerweekstatus
40	Can view Рабочий график сотрудника	10	view_workerweekstatus
41	Can add Администратор	11	add_adminstrator
42	Can change Администратор	11	change_adminstrator
43	Can delete Администратор	11	delete_adminstrator
44	Can view Администратор	11	view_adminstrator
45	Can add Тип анализа	12	add_analyzetype
46	Can change Тип анализа	12	change_analyzetype
47	Can delete Тип анализа	12	delete_analyzetype
48	Can view Тип анализа	12	view_analyzetype
49	Can add Прибор	13	add_equipment
50	Can change Прибор	13	change_equipment
51	Can delete Прибор	13	delete_equipment
52	Can view Прибор	13	view_equipment
53	Can add Исполнитель	14	add_executor
54	Can change Исполнитель	14	change_executor
55	Can delete Исполнитель	14	delete_executor
56	Can view Исполнитель	14	view_executor
57	Can add Проект	15	add_project
58	Can change Проект	15	change_project
59	Can delete Проект	15	delete_project
60	Can view Проект	15	view_project
61	Can add Анализ	16	add_analyze
62	Can change Анализ	16	change_analyze
63	Can delete Анализ	16	delete_analyze
64	Can view Анализ	16	view_analyze
65	Can add Проект Анализу	17	add_projectperanalyze
66	Can change Проект Анализу	17	change_projectperanalyze
67	Can delete Проект Анализу	17	delete_projectperanalyze
68	Can view Проект Анализу	17	view_projectperanalyze
69	Can add Оператор по оборудованию	18	add_operatorperequipment
70	Can change Оператор по оборудованию	18	change_operatorperequipment
71	Can delete Оператор по оборудованию	18	delete_operatorperequipment
72	Can view Оператор по оборудованию	18	view_operatorperequipment
73	Can add Анализы по оборудованию	19	add_analyzeperequipment
74	Can change Анализы по оборудованию	19	change_analyzeperequipment
75	Can delete Анализы по оборудованию	19	delete_analyzeperequipment
76	Can view Анализы по оборудованию	19	view_analyzeperequipment
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
8	pbkdf2_sha256$600000$RUKJYvliJXCUrMVyQxzs9r$OYN+gLBiRJbVD0Wbc6wyNY8BdSnHbHPbqDW1UygW8hU=	2025-06-06 11:36:09.960535+00	f	GeraskinaN1				f	t	2025-06-05 10:18:06.143582+00
1	pbkdf2_sha256$600000$t4XNsnvFkAgiKMktcjPtzt$URqxmtFNnfNqUX0NN5Pvado/KCQlwBZ2v/989g9tBKU=	2025-06-02 18:26:23.761003+00	t	Admin_agri			admin@example.com	t	t	2025-05-04 13:09:23.835088+00
5	pbkdf2_sha256$600000$K1K0qicyUwceHa3ebtaFil$zF1M7QqmA6BEi4PScQmE9tQuoyajcl7avmP/tAk8paI=	2025-06-06 12:21:34.131876+00	t	Fedorova				t	t	2025-05-21 15:07:38.773637+00
2	pbkdf2_sha256$600000$YfwE6mVV7NKnCPhtigxY6m$mDU9cPzYklepL1V5hkhvqPDys/KS/XMhT5ZbVNkUzys=	2025-05-04 13:10:42.565374+00	t	testadm				t	t	2025-05-04 13:10:26.034912+00
7	pbkdf2_sha256$600000$pPsmSST3ad65nyAWhdvUnI$U4PSYII+yk2FXxjWTZxVqb59jBxgBQ1oilU80Wsg57o=	2025-05-21 16:30:56.491074+00	t	Kivero				t	t	2025-05-21 16:19:00.939594+00
3	pbkdf2_sha256$600000$fqTjpNkLAoFN0yuUEOQ1EQ$ndvJ/ENuZe2F7U4li+WDOfjvXxd9TIc7juKyhkzMbds=	2025-06-06 11:12:48.281435+00	f	ZiyatdinovM1				f	t	2025-05-04 13:12:51.612559+00
4	pbkdf2_sha256$600000$XnrShS7iMrN4mQXDtaPpFg$8IIVzc7/LWnMWTIcb7SYpD2c+vpH1JmhvdawSpmC8f0=	2025-06-06 11:15:15.540681+00	f	KiryukhinM1				f	t	2025-05-21 14:46:50.712727+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: block_booking; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.block_booking (id, project_id, booking_id, date_booking, analyse_id, equipment_id, executor_id, is_block, write_timestamp, cookies_key, update_timestamp, id_delete) FROM stdin;
1	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-04 13:14:06.95323	5f2310f4-ab7b-4fbb-b49a-8c430107daf8	2025-05-04 13:14:06.971154	f
25	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:30:18.892666	c968be24-27ae-4a28-a877-aab5503df64a	2025-05-21 15:30:27.375981	t
19	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:25:57.988217	201610b7-9092-4dab-b564-06be6473c175	2025-05-21 15:26:17.609305	t
10	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:12:50.884235	3334b879-ebc3-4af8-aa73-bf2ea7ed4ca5	2025-05-19 19:31:13.15582	t
47	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 14:16:51.701067	11e5fe91-10d3-4366-93d6-b722fc2ccf7a	2025-06-05 14:16:51.704833	f
20	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-21 15:26:17.634045	5aba8896-bba4-4419-a2e9-4de90d8b395e	2025-05-21 15:26:31.967818	t
42	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:03:33.800198	8414bde6-6826-4929-afa5-e037a065f3ae	2025-06-05 12:05:03.156732	t
52	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-11	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 10:49:11.341672	ae491da8-71af-4e5c-963b-1b74c4b723dc	2025-06-06 10:50:31.239628	t
12	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:31:23.171169	02c1813f-894f-4cd4-9a8e-385080654d7e	2025-05-19 19:31:23.174549	f
36	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-11	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-05 11:19:52.670671	ea4e995a-10ad-4eb4-87cc-2204767cd890	2025-06-05 11:23:50.989146	t
4	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-04 13:14:58.602607	435297cc-63f9-4799-9a81-8fbc4d61d9ae	2025-05-04 13:14:58.606255	f
3	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-06	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-04 13:14:47.194453	642166a2-ceab-4137-97f2-1af2ee88e8ab	2025-05-09 10:39:00.45763	t
13	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:32:27.545388	12d7ef85-7f49-46b9-bd07-433d142859e7	2025-05-19 19:32:27.548745	f
11	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-22	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:31:13.170334	7da5984b-99a9-4101-9ddb-b3718762ec97	2025-05-19 19:39:57.562606	t
21	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-29	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:26:32.026674	fe770c98-54db-48d8-80b5-e6d367547cb7	2025-05-21 15:26:46.181546	t
5	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-09 10:39:00.473335	c07b3bcb-7aa2-4788-927d-a53df43b40a5	2025-05-09 10:39:53.973015	t
27	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-05-30 14:22:35.039354	e334e799-1595-45d0-8cc0-833b1af11fe8	2025-05-30 14:22:35.094587	f
22	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	\N	\N	\N	\N	2025-05-21 15:26:46.236731	620708a7-427b-41cf-adc6-037ed080281d	2025-05-21 15:26:50.004916	t
14	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:39:57.588819	6651ac6e-bbe9-44b5-a961-7d8996bf9337	2025-05-21 15:24:13.319794	t
6	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-09 10:39:53.9888	e96e0bea-e165-472e-957c-098e3b4f6505	2025-05-09 10:40:05.70163	t
2	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-18	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-04 13:14:29.362611	fdfdffc1-85d7-415a-9bd0-299737ef9e5c	2025-05-04 13:14:47.175137	t
28	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-05-30 14:23:02.531089	a0458d83-71e5-4038-895b-54b599a647ef	2025-05-30 14:23:02.558622	f
15	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	\N	\N	\N	\N	2025-05-21 15:24:13.337065	e1c68fa6-b3e3-4415-bf82-3a4d37aa94b4	2025-05-21 15:24:19.499631	t
7	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 18:43:01.743332	1f322a96-882b-4acb-bf5b-f3413201605c	2025-05-19 19:07:24.992881	t
16	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	\N	\N	\N	\N	2025-05-21 15:24:19.514689	7fd71a2f-8f79-4be9-98f1-b7631e7b738d	2025-05-21 15:24:22.019815	t
29	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:10:50.935371	eb43589d-6f8a-4ae0-8441-c7a92a0afca0	2025-06-02 18:10:50.939425	f
26	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:30:27.429051	7b1320e9-ef5f-4a6e-a04f-805052067fa4	2025-06-02 18:11:32.606259	t
17	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	\N	\N	\N	\N	2025-05-21 15:24:22.072351	2618cdac-04cb-445c-92a4-2142bdef9f8a	2025-05-21 15:24:27.626523	t
8	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:07:25.010992	d2e12478-54f9-409c-84da-d60653e34111	2025-05-19 19:09:26.100552	t
9	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:09:26.154716	7d7e4084-72b1-4515-841c-e0ea3cade3ea	2025-05-19 19:12:50.827766	t
23	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-28	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:26:50.055809	87473cf3-6bbc-4dcb-80e4-b6d09bdc95e3	2025-05-21 15:30:09.913344	t
49	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:35:48.551395	4a196817-6e2b-4870-89ea-ce730f48b8d0	2025-06-06 10:42:33.805538	t
45	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:06:11.030398	b16659aa-8e01-40ce-a204-9aa8a8686c48	2025-06-05 12:08:32.77305	t
43	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-09	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:05:03.185841	70bf42e2-50a6-4e64-9675-fb2b9d4237f1	2025-06-05 12:05:31.041595	t
18	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-21 15:24:27.679668	0db35efc-302b-4a54-a0ac-0ab400c28d05	2025-05-21 15:25:57.973675	t
37	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-05 11:23:51.006153	1297f0ac-60a8-4719-b5ce-f0d116d9d219	2025-06-05 11:24:04.046592	t
24	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-29	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-21 15:30:09.931979	975a0586-24a5-404f-929c-1e0fa1dd4d1c	2025-05-21 15:30:18.863285	t
30	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-02 18:11:32.622565	63e0359a-e41c-4bf5-9d6f-868df030d3c3	2025-06-02 18:25:53.104505	t
31	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:25:53.160743	12a087ef-e2ab-4bda-9cad-711103599bc2	2025-06-02 18:26:54.324683	t
38	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:47:37.69422	0ac7281a-15d7-4eac-b395-e10f9b0f7e60	2025-06-05 11:47:37.711397	f
32	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:26:54.339983	541e4328-31a3-4949-ab60-ab74e76eed7a	2025-06-02 18:27:12.030449	t
39	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:47:42.993564	72cf1b07-1f72-4383-a47f-c3aac7ab30f7	2025-06-05 11:47:43.035851	f
34	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-04 13:30:26.622462	9b198396-a260-41c7-af7f-45fa53fc294a	2025-06-04 13:30:26.675506	f
35	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-04 13:31:07.266863	fb414080-56e1-4d2a-bca1-233bb7d5fcd7	2025-06-04 13:31:07.279895	f
33	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:27:12.047345	a9e82bc1-06b8-45d2-bf71-69b6dca02713	2025-06-05 11:19:52.653073	t
40	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:59:20.889282	87ce4111-ce06-4eee-b1ac-87ba0cdb64b1	2025-06-05 11:59:20.926134	f
41	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 12:02:50.907684	429c4b1d-b07e-49d8-a82f-b1a446625729	2025-06-05 12:03:33.746388	t
48	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:35:09.367434	577584d9-95d2-4f36-a206-79f984bfc295	2025-06-06 10:35:48.499849	t
53	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-06 10:50:31.269533	e52b7e39-74b5-4307-a130-c43e5ecdcb2f	2025-06-06 10:58:13.502566	t
44	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-12	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:05:31.09331	7958704b-8191-4d9c-afe3-739a54fe7c93	2025-06-05 12:06:10.97779	t
54	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-06-06 10:58:13.532321	a62e4289-2854-42e4-8cfc-b79c8805318b	2025-06-06 10:59:58.048688	t
46	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:08:32.824146	10821fc8-8a41-412e-955d-1875d2c9e3e4	2025-06-05 14:16:51.648617	t
50	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	\N	\N	\N	\N	2025-06-06 10:42:33.833372	d1359223-b8c3-4c86-839f-45ba2215142d	2025-06-06 10:48:31.059314	t
51	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 10:48:31.088737	f3770803-519f-4c6d-a9b9-cb348ced9f87	2025-06-06 10:49:11.290609	t
55	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:59:58.099074	13561017-7813-4b30-bc0b-922116223332	2025-06-06 11:00:35.347174	t
56	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-06 11:06:48.140156	b9e5a8ab-fde1-4c53-819a-d01c5c131495	2025-06-06 11:07:21.140894	t
57	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-10	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-06-06 11:07:21.192769	ccc9d83c-e892-494b-9d9e-fdc19cf9876a	2025-06-06 11:08:31.155925	t
58	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-11	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:08:31.209244	5d8e8518-945e-4e1d-9656-0c5d7e978f31	2025-06-06 11:09:09.868484	t
59	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:09:09.918849	cbdd5f01-085f-49ff-a957-04727ef4aa74	2025-06-06 11:10:16.665282	t
60	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-10	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:10:16.720207	7b5d1ce8-6026-4db3-80b9-1ce90469052d	2025-06-06 11:15:18.688808	t
61	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:10:45.162989	6da77d7a-5e58-4518-9ca0-cd49a98f31f8	2025-06-06 11:10:45.16927	f
62	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:10:58.194746	e720fb47-0d8d-4f59-96ec-8fe05fadafeb	2025-06-06 11:10:58.19869	f
63	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:11:19.29854	b98d1e46-1398-4659-8796-2cb82925e6a7	2025-06-06 11:11:19.302003	f
64	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:12:57.704648	7bca48f8-2ffe-4ed3-a7be-b30a70c9a57d	2025-06-06 11:12:57.708317	f
65	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:13:57.555785	660cd3f5-bee3-46d8-b1e3-ceca0326ebc0	2025-06-06 11:13:57.558649	f
66	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:15:18.702216	e75e78a2-212c-440b-bf0f-7ef5a5ab0094	2025-06-06 11:15:54.508122	t
67	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-09	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:15:54.521999	f5607d77-e31f-4ea1-bd51-7e527e9aa036	2025-06-06 11:16:17.352478	t
68	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:16:17.403331	c42dd685-d672-4d03-8ecd-f43524c8b9a5	2025-06-06 11:16:57.504293	t
69	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:16:57.557017	a077ecfa-0acc-49c5-a1ac-0f8a27d0fc5b	2025-06-06 11:16:57.560571	f
70	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:32:15.720919	fd6ca612-6ec6-4ae9-94b7-1bab6083fe55	2025-06-06 11:32:15.774742	f
71	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	\N	\N	2025-06-06 11:32:37.656455	3783a1d4-44c8-49ee-acf5-ebe1bf9212ba	2025-06-06 11:32:55.245171	t
72	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:32:55.266633	fc19e53e-6829-46cf-b23b-8682742f4143	2025-06-06 11:37:29.192039	t
73	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:37:29.244891	1f9a2aee-ebe2-461f-8c92-05043d80c58d	2025-06-06 11:37:50.652354	t
\.


--
-- Data for Name: control_enter_isopenregistration; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_isopenregistration (id, created, modified, is_open, week_period) FROM stdin;
\.


--
-- Data for Name: control_enter_openwindowforordering; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_openwindowforordering (id, created, modified, start_date, start_time, end_time, for_priority, week_period) FROM stdin;
e9f2ece1-0501-4634-bd3c-1623fb54284d	2025-06-02 18:10:26.884495+00	2025-06-06 10:33:58.820069+00	06.06.2025	00:00	24:00	f	09.06.2025-15.06.2025
\.


--
-- Data for Name: control_enter_workerweekstatus; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_workerweekstatus (id, created, modified, week_period, monday, tuesday, wednesday, thursday, friday, saturday, sunday, limit_executor, executor_id) FROM stdin;
5219d651-27b3-4eaf-879d-7885a7dea985	2025-06-06 09:56:16.30784+00	2025-06-06 09:56:25.576063+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
13c9e994-564b-4577-96fb-9856b96e2933	2025-06-06 09:56:38.781765+00	2025-06-06 09:56:38.781781+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
10ff566f-7aa7-4b59-866c-02699cce953c	2025-06-06 09:56:51.966774+00	2025-06-06 09:56:51.966789+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
2ef307d9-4a72-43f0-94d0-32e27af4b41f	2025-06-06 09:57:06.634638+00	2025-06-06 09:57:06.634652+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
386cfcc5-8f81-41b8-901d-4e7933f369cc	2025-06-06 09:57:30.713555+00	2025-06-06 09:57:30.713574+00	09.06.2025-15.06.2025	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
cc74c9b7-7478-4d9c-bfa0-efa19c9d7df0	2025-06-06 09:57:46.917809+00	2025-06-06 09:57:46.917825+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
faf7f1ac-d6d3-4971-9614-079940658474	2025-06-06 09:58:10.361664+00	2025-06-06 09:58:10.361679+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
9c8949f1-b97b-4d7b-aa8e-5f7cfef56f6a	2025-06-06 09:58:21.524683+00	2025-06-06 09:58:21.524697+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
7da16033-9b11-44da-96ca-058675a53e9e	2025-06-06 09:58:34.580708+00	2025-06-06 09:58:34.580724+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
90185b56-b39e-40c7-9798-024213deac70	2025-06-06 09:58:47.321852+00	2025-06-06 09:58:47.321867+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
26a010b1-e1b5-4155-8fd4-36b17ca1ae3b	2025-06-06 09:59:10.587502+00	2025-06-06 09:59:10.587526+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
35a3585e-dd65-4761-8871-54471d4d53cc	2025-06-06 09:59:22.581414+00	2025-06-06 09:59:22.581428+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
8685c020-7469-47aa-9746-fe038ae0c55c	2025-06-06 10:21:28.081478+00	2025-06-06 10:21:28.081492+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
74ca31c7-210d-4f29-8593-f767f2d33969	2025-06-06 10:21:39.153531+00	2025-06-06 10:21:39.153545+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
7d5bca70-ee72-43cf-b4a9-c5416a2137fc	2025-06-06 10:23:13.993976+00	2025-06-06 10:23:13.993991+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
1382ddde-24a5-443a-9af8-133c83477218	2025-06-06 10:23:35.683026+00	2025-06-06 10:23:35.68304+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
75b4833a-4a8a-451d-83d2-9c5f305eef5c	2025-06-06 10:24:04.5925+00	2025-06-06 10:24:04.592515+00	09.06.2025-15.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
6651c987-6301-48ea-a14b-b450ae0548d6	2025-06-06 10:25:28.958037+00	2025-06-06 10:25:28.958053+00	16.06.2025-22.06.2025	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
\.


--
-- Data for Name: control_enter_workingdayofweek; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_workingdayofweek (id, created, modified, week_period, monday, tuesday, wednesday, thursday, friday, saturday, sunday) FROM stdin;
32e6ef03-58f4-4e8f-80c4-bf5537058666	2025-06-04 13:28:07.751838+00	2025-06-04 13:28:07.751856+00	02.06.2025-08.06.2025	t	t	t	t	t	f	f
65986bb1-234e-4c54-b5dd-ccd386a15b10	2025-06-02 18:10:42.698768+00	2025-06-06 10:34:34.539488+00	09.06.2025-15.06.2025	t	t	t	t	t	f	f
b654ea09-0b0d-4b6b-a734-f986016465a5	2025-06-02 17:44:08.060738+00	2025-06-06 10:34:40.860717+00	16.06.2025-22.06.2025	t	t	t	t	t	f	f
\.


--
-- Data for Name: dependings_analyzeperequipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_analyzeperequipment (id, count_samples, analazy_id, equipment_name_id) FROM stdin;
7dd395a4-3652-4450-98a0-80cb8a9b3693	12	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90
f4219c2e-5e50-4b01-b68a-2c42ebb65cbd	12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5
4a8d426e-1a4c-4e7e-b7c7-b23a9bf0bcc1	12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
4ab314fc-7430-480b-a2e4-8209fcf92b19	12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
08dc2b8b-9ef1-43bd-831f-3e43112a125c	8	1b6870c5-c028-4f7d-b3a6-da026ec81032	ef5851f3-9428-411b-a8e0-77086b2e9d90
4e194ce7-ca13-4e35-b5ae-ad7f304dd741	6	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48
e80d95d5-3b67-448f-b8c5-a4dad25485d1	12	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
1d4210d8-b9e3-47cf-9fd2-c138db2b8191	12	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5
47520068-d119-47e0-a9b7-82cf86c41e38	8	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51
0b924349-8b40-4893-826f-1f762571b345	12	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3
f4d86890-3f47-474b-89f2-41f44f2ee4af	12	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	fb09a7e8-8696-45ab-abc4-baa9e1440da5
9e5c8536-1488-4521-abef-5e2162d3e57d	12	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
de22a9eb-3341-4f6e-a7e2-08306aae6cfb	12	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3
151661f6-b9a4-485e-a0b0-79eec9653190	12	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09
ff514302-8ae9-4343-9bb3-53c7e1395fc6	6	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384
65a30651-7236-4933-a05a-e8c774663c5e	12	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
f36c4f83-7cdc-466c-b0c6-f53eee215e52	12	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5
d1bfe6e8-c571-4188-a3f9-185b9954aebe	6	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384
816a15ab-4636-4b60-8c01-5f6a914e66f3	12	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3
c29e42b9-0143-4fb9-aff1-55067ffbf357	12	a426aa21-8248-4fad-8ed2-f82aa388d1b5	fb09a7e8-8696-45ab-abc4-baa9e1440da5
07fa9507-7399-4cdb-ba6f-0fd7ab71feb5	6	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895
2bcddd69-9709-445d-9567-a86b0a947972	6	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895
44c5358c-8aee-4820-83c7-7a568f9d4065	12	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71
71cdf309-436c-41e2-ba9f-00290a6e03ce	12	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5
6ce21107-4e96-4198-8744-f38680e66785	18	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3
9283b3c3-596a-44c4-b907-1c36355e75f6	12	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5
7786e1b5-15f0-4730-b91f-9d2588d7b941	6	e40964e1-8934-428e-a06e-18379a30ebae	1de040d3-f437-4e55-a77c-c71c38fe0384
1d19b9bf-c98e-47d3-9c8e-4221f8e495c6	12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
3b35ac23-0b75-43dc-85ed-76dddd522db2	6	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384
ed0ed014-2191-4b97-af22-9d1ba16ba4c9	20	7da0bd39-87ac-4b74-b152-236e519597e1	e028e32c-581f-4b39-92ae-9a81552b7862
0ca15667-5429-4a44-b009-b1815a7fa312	12	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
007dd4bd-15cf-4911-a4af-80eaf37fa445	12	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
b94cee75-d835-424a-9486-55711407d0db	6	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48
3b2f0fa5-d5ff-4b74-bc28-a0bb4103597a	6	f546d1c3-036a-47dd-8662-9b37a914408f	1de040d3-f437-4e55-a77c-c71c38fe0384
2261a1c8-dd9f-4ba8-9fa1-ec23ddc712d9	8	13649857-bdb6-4771-8105-8dc1fd503ac9	612b7c5b-61b6-4795-8d07-98bc92bc4c51
83635efb-56a4-4bff-a8f2-245739f40fc7	12	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	4b3bb52f-df8d-421c-893e-37052e982bcb
cbce33a1-3c56-4c54-b194-315442818858	12	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5
dccd8d63-fa3a-4047-8909-fd25061670d9	12	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d
9eebac2d-c944-4f98-9ec8-ca65b521dc3a	12	571c313e-8ec3-4777-bac7-40855117d510	fb09a7e8-8696-45ab-abc4-baa9e1440da5
f8d6c899-bbf4-48cd-9457-901947d9a933	12	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	0c0b62b6-c1b4-4828-8c87-b90396e2288d
8d16e8bd-0e67-4612-ba99-bc03b3fea5b9	12	8cb45323-f121-47ad-969d-0ed9c2336674	0c0b62b6-c1b4-4828-8c87-b90396e2288d
b1f3e239-4317-4b5a-a752-e1aab475f793	12	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5
5645adea-fa77-4418-b7e7-2dbc05d4bdbb	6	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384
7ddc3b1d-54af-46fb-b500-14b8c36d398d	6	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384
7bbd84dd-6703-42e0-bfe1-f01da0373b59	12	e32c058b-38a7-4a49-a335-548da531c9b0	fb09a7e8-8696-45ab-abc4-baa9e1440da5
a37304bd-fc47-416e-97b6-f608b67a2f4b	12	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
cd1696ac-e37f-4c0e-99a1-039450bb4ade	8	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	ef5851f3-9428-411b-a8e0-77086b2e9d90
14bb3a20-dc58-4d92-ad61-be551ccad6e4	12	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb
8fe966e3-5285-42a4-b619-ca707c9784e5	12	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5
f68b9664-d014-4676-948d-52498a46ca27	6	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384
37bdfb2c-3a5b-400e-8cfd-86bc61065487	12	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5
\.


--
-- Data for Name: dependings_operatorperequipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_operatorperequipment (id, is_priority, equipment_id, operator_id) FROM stdin;
c37e1b7a-bf5b-427d-ab59-f530c2810d10	f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c
8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	t	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c
ebe0ca91-0214-453a-91f3-925bd53f5606	t	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda
59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	t	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda
3c24341c-235d-4d4b-8561-1f7cf0d108ff	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c
5f9f0bd3-186e-4ee7-9207-8dcbc67c4ea9	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	d36c9e4f-2406-492b-b467-de7884e9a2e6
9fea634d-d28f-4130-928f-ed64f39998c3	f	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6
14cdc62c-f9c2-4043-85a3-99451ebee7fc	t	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6
94189595-1d95-4782-8464-b338640e1b5e	t	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a
eed4b9b6-0e16-4811-ac84-9c8851e8d4ae	t	0c0b62b6-c1b4-4828-8c87-b90396e2288d	58c12ab6-e451-48b5-917e-26fc1855847a
4adae582-a899-4520-9bf1-c4e1411938b9	t	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a
e1dfe070-72f1-4a0f-ae0d-300903a686e2	t	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a
fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	f	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	86bea85e-a62d-4dc0-8c0b-30541fd7782c
3add5154-d941-43d3-a891-28512fd90890	f	0c0b62b6-c1b4-4828-8c87-b90396e2288d	86bea85e-a62d-4dc0-8c0b-30541fd7782c
8e372a71-ce34-4bcd-8d2a-71379b5b2e58	t	27dc31dd-0a11-452e-ac1e-aeb052f18226	8afa309b-cec8-4aaa-9031-06fe2b8267bf
bd3d2f53-fdf4-4ff5-b267-13435039ecde	t	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf
b70cb072-2435-472e-8579-a0e6d5d9e70e	t	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf
e3348e14-7e1d-4f98-b0a7-42cff53daa3a	t	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf
702157a8-9348-41e5-bae7-961a0e3e5940	t	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf
821c378b-aaed-45b3-a007-8b620e34126f	t	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
438c240d-734b-44d9-a17f-7259172dc398	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
54968de3-1f18-4d08-a485-a83a3e89cb3f	f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
a5d446a8-3fa6-47f3-9a84-eb428f14e600	f	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a
7a2e39e0-972a-4e11-aaf7-4091306b4bb4	t	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a
109918bd-fe82-40b4-88a8-7ace7535ab4c	t	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a
3d2dc186-dcb4-4876-9d18-7252d8181131	f	322bde1c-c844-44d7-8846-a773b9f97679	1e4fa050-70ba-4031-9201-31d8cbd60b9a
0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	f	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a
08449636-2537-4ea7-a4e0-78b92ced819b	f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
4ef7cae5-4722-45b1-bc60-d3a241c8d08f	f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc
c47fcc37-09db-4099-aad3-462f24cb56a2	f	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc
\.


--
-- Data for Name: dependings_projectperanalyze; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_projectperanalyze (id, limit_samples, analazy_n_id, project_n_id) FROM stdin;
1c051ae6-a3a0-4637-8011-45d15e7d7590	20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	cdf23166-345a-4084-8437-92c51adbbe78
fc476729-c88c-456d-b1fd-3125b23bc244	12	0b6e2138-4fc5-4404-b584-6707d4890102	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
ed419b7e-46a8-40d0-9b86-7f292f45bfcf	6	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
eccc3238-6a69-450f-a3e2-4785fefe6ed4	12	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
d3b71632-d535-4eae-ad5f-a26e5536f503	12	eecdd0f8-7244-4bf6-8f96-65622901a51d	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
d2307861-ee3b-426a-98fa-259d83ac47d0	12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
cdb3e289-dd41-4e0e-826c-b99270b5eeb2	8	601b7b77-ab12-477c-918e-ca3910a3bb96	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
c0d394f6-e583-4327-9acc-20a826b40cac	12	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	cdf23166-345a-4084-8437-92c51adbbe78
cd93279c-e67a-4059-b8b8-090fa9478f8b	12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	cdf23166-345a-4084-8437-92c51adbbe78
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-05-04 13:10:26.356542+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор admin	1	[{"added": {}}]	11	1
2	2025-05-04 13:11:32.681579+00	c7dba098-3d33-445c-a23b-57c247eee687	тип1	1	[{"added": {}}]	12	1
3	2025-05-04 13:11:35.493498+00	dd7560f9-712c-405d-9c82-190ff14317d2	Анализ1 : тип1	1	[{"added": {}}]	16	1
4	2025-05-04 13:11:51.592492+00	3b62ef9e-48c6-4129-b130-47b56bc69974	Иван  Иванов  Иванович	1	[{"added": {}}]	14	1
5	2025-05-04 13:11:58.69856+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Прибор1	1	[{"added": {}}]	13	1
6	2025-05-04 13:12:09.785285+00	dcd67bb3-44d5-47f1-8264-5b691f5860b7	Анализ1 : тип1 - Прибор1	1	[{"added": {}}]	19	1
7	2025-05-04 13:12:51.930736+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	15	1
8	2025-05-04 13:12:59.57707+00	b3a39687-1f34-4afe-8adf-3d90e539fbcd	Иван  Иванов  Иванович - Прибор1	1	[{"added": {}}]	18	1
9	2025-05-04 13:13:14.593118+00	341aa76d-7d9d-4865-b89c-43dee4771fd4	Окно бронирования на 04.05.2025 с 00:00 до 24:00, период недели: 05.05.2025-11.05.2025	1	[{"added": {}}]	8	1
10	2025-05-04 13:13:25.298694+00	2f9e27ae-f0f8-40e9-8be3-a02e18501804	05.05.2025-11.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
11	2025-05-04 13:13:33.049846+00	2623aef7-c1f0-4f03-b927-d982e763c860	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">05.05.2025-11.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
12	2025-05-04 13:14:24.299961+00	b0bbc07e-59be-4579-a6df-94890c712abd	Анализ1 : тип1 - proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	17	1
13	2025-05-09 10:38:14.86792+00	bc96aaf3-0c60-4837-b95a-0bb644d28774	12.05.2025-18.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
14	2025-05-09 10:38:30.145418+00	7a891ed2-b504-44c6-84d8-61ab1af181e1	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">12.05.2025-18.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
15	2025-05-09 10:38:52.641487+00	46aeb0ce-6415-449c-bde8-daa90370a369	Окно бронирования на 09.05.2025 с 00:00 до 17:00, период недели: 12.05.2025-18.05.2025	1	[{"added": {}}]	8	1
16	2025-05-19 18:42:14.572622+00	46aeb0ce-6415-449c-bde8-daa90370a369	Окно бронирования на 09.05.2025 с 00:00 до 17:00, период недели: 12.05.2025-18.05.2025	3		8	1
17	2025-05-19 18:42:14.581764+00	341aa76d-7d9d-4865-b89c-43dee4771fd4	Окно бронирования на 04.05.2025 с 00:00 до 24:00, период недели: 05.05.2025-11.05.2025	3		8	1
18	2025-05-19 18:42:25.801396+00	3765642b-4174-4a95-814f-cc9f185db017	Окно бронирования на 19.05.2025 с 00:00 до 24:00, период недели: 19.05.2025-25.05.2025	1	[{"added": {}}]	8	1
19	2025-05-19 18:42:32.538128+00	bc96aaf3-0c60-4837-b95a-0bb644d28774	12.05.2025-18.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
20	2025-05-19 18:42:32.541621+00	2f9e27ae-f0f8-40e9-8be3-a02e18501804	05.05.2025-11.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
21	2025-05-19 18:42:32.544282+00	1773bb1d-8d81-4068-a79c-c23c86e71d62	26.05.2025-01.06.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
22	2025-05-19 18:42:42.111868+00	ad217dad-235c-4b8d-84c7-cfbd9b945585	19.05.2025-25.05.2025 - Иван  Иванов  Иванович | Выходной | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
23	2025-05-19 18:42:49.138996+00	dce619e0-b00a-4c2f-be06-4f5959f6fc96	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
24	2025-05-19 18:42:49.141367+00	7a891ed2-b504-44c6-84d8-61ab1af181e1	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">12.05.2025-18.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
25	2025-05-19 18:42:49.143121+00	2623aef7-c1f0-4f03-b927-d982e763c860	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">05.05.2025-11.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
26	2025-05-19 18:42:55.265751+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
27	2025-05-20 11:56:55.090681+00	c7dba098-3d33-445c-a23b-57c247eee687	Основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	1
28	2025-05-20 11:57:33.152481+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met : Основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	1
29	2025-05-20 11:58:33.389719+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примесь	1	[{"added": {}}]	12	1
30	2025-05-20 11:58:41.572403+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	1
31	2025-05-20 11:59:21.996104+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Петрович	1	[{"added": {}}]	14	1
32	2025-05-20 11:59:35.557005+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  None	2	[{"changed": {"fields": ["\\u041e\\u0442\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	14	1
33	2025-05-20 12:04:55.067782+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Иванович	2	[{"changed": {"fields": ["\\u041e\\u0442\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	14	1
34	2025-05-20 12:05:41.822897+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
35	2025-05-20 12:05:59.680195+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Saykam	1	[{"added": {}}]	13	1
36	2025-05-20 12:06:13.704088+00	322bde1c-c844-44d7-8846-a773b9f97679	Waters	1	[{"added": {}}]	13	1
37	2025-05-20 12:06:49.262831+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (project1рук) : Приоритетный 	2	[]	15	1
38	2025-05-20 12:08:20.863078+00	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	Met_2 : Примеси	1	[{"added": {}}]	16	1
39	2025-05-20 12:08:26.869082+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met_1 : Основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	1
40	2025-05-20 12:08:56.763335+00	ba1093f0-eb98-4903-a5c4-46c590689d07	Met_2 : Примеси - Saykam	1	[{"added": {}}]	19	1
41	2025-05-20 12:09:08.850991+00	dcd67bb3-44d5-47f1-8264-5b691f5860b7	Met_1 : Основной продукт - Agilent	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	1
42	2025-05-20 12:09:31.765042+00	b7740e8c-2d86-448a-a2ce-43e245433772	Петр  Петров  Иванович - Saykam	1	[{"added": {}}]	18	1
43	2025-05-20 12:09:54.189214+00	bf2f0c85-d935-4a3f-8f60-5d67902948a9	Met_2 : Примеси - proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	17	1
44	2025-05-20 12:14:19.970049+00	9fe49fe0-d44f-4fa0-a14c-2f42900d5011	26.05.2025-01.06.2025 - Петр  Петров  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
45	2025-05-21 14:11:02.481017+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (Сидоров) : Приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	1
46	2025-05-21 14:11:23.406345+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	1
47	2025-05-21 14:12:29.085338+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	1
48	2025-05-21 14:22:51.751737+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: gray;'>Вт  	2	[{"changed": {"fields": ["\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	9	1
49	2025-05-21 14:46:51.068764+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	15	1
50	2025-05-21 15:07:39.095856+00	837ada9a-9407-47ef-a0c0-aee56edb6160	Администратор Иван	1	[{"added": {}}]	11	1
51	2025-05-21 15:08:36.660232+00	da3047ce-76fe-4d82-ba86-c121399b066e	Ттипа	1	[{"added": {}}]	12	1
52	2025-05-21 15:08:55.74264+00	3b95b72a-5cfb-4a4d-9307-3a382d1e19d7	АнализТестовый : Ттипа	1	[{"added": {}}]	16	1
53	2025-05-21 15:13:17.032622+00	75849d6f-a7a0-4297-b44b-db351e31e5d8	АнализТестовый : Ттипа - Waters	1	[{"added": {}}]	19	1
54	2025-05-21 15:14:23.263894+00	45827d69-eb35-4a5d-bb96-2f86fa5fea27	АнализТестовый : Ттипа - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	1
55	2025-05-21 15:14:51.563069+00	9e42712b-a968-4b81-858f-02b31f9ab85a	Иван  Иванов  Иванович - Waters	1	[{"added": {}}]	18	1
56	2025-05-21 15:17:59.849071+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	8	1
57	2025-05-21 15:20:39.713128+00	55bc1448-28a9-46ec-8a9c-da2cb4d3f069	26.05.2025-01.06.2025 - Иван  Иванов  Иванович | Работает | Занят | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
58	2025-05-21 15:21:06.887206+00	97112c5a-e332-4efe-9b45-b717c45523a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
59	2025-05-21 15:22:17.736919+00	9c956582-d1b6-40d2-8077-879fd07079ed	19.05.2025-25.05.2025 - Петр  Петров  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
60	2025-05-21 15:22:35.977062+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	7	1
61	2025-05-21 15:22:45.535923+00	406d22a2-a71c-4278-9800-c05973e728d2	Закрыта период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	1
62	2025-05-21 15:22:59.175432+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
63	2025-05-21 15:23:22.776632+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	1
64	2025-05-21 15:36:54.114497+00	adf5ec6d-c735-4f8b-a24f-7e314d90b1cd	Окно бронирования на 22.05.2025 с 06:00 до 15:00, период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	8	1
65	2025-05-21 15:45:47.103493+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	1	[{"added": {}}]	11	1
66	2025-05-21 15:46:00.081438+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	2	[{"changed": {"fields": ["\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	11	1
67	2025-05-21 15:46:14.112137+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	3		11	1
68	2025-05-21 16:16:36.736094+00	837ada9a-9407-47ef-a0c0-aee56edb6160	Администратор Федорова Е.Н.	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	11	1
69	2025-05-21 16:19:01.254104+00	28aeaae9-88d4-43da-9f5f-663912f3461f	Администратор Киверо А.Д.	1	[{"added": {}}]	11	1
70	2025-05-21 16:19:26.143288+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор Admin Main	2	[{"changed": {"fields": ["\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e"]}}]	11	1
163	2025-05-29 14:18:55.407037+00	c37e1b7a-bf5b-427d-ab59-f530c2810d10	Борзенко  Татьяна  Сергеевна - Methrohm	1	[{"added": {}}]	18	5
71	2025-05-21 16:19:42.583991+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор Admin Majour	2	[{"changed": {"fields": ["\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e"]}}]	11	1
72	2025-05-22 10:15:44.828597+00	15b8a729-e300-42be-abb3-ba19dc9a2fc9	Эктоин : Основной продукт	1	[{"added": {}}]	16	5
73	2025-05-22 10:17:22.439068+00	15b8a729-e300-42be-abb3-ba19dc9a2fc9	Эктоин : Основной продукт	3		16	5
74	2025-05-28 14:34:09.076204+00	057a1181-d534-453c-8ee5-0b2256347844	Татьяна  Борзенко  None	1	[{"added": {}}]	14	5
75	2025-05-28 14:34:27.42067+00	eaa6f6ee-dc4f-43cb-b776-12cc61a1f2e0	Анна  Новикова  None	1	[{"added": {}}]	14	5
76	2025-05-28 14:34:36.996839+00	eaa6f6ee-dc4f-43cb-b776-12cc61a1f2e0	Анна  Новикова  None	3		14	5
77	2025-05-28 14:34:47.277865+00	057a1181-d534-453c-8ee5-0b2256347844	Татьяна  Борзенко  None	3		14	5
78	2025-05-28 14:35:27.658115+00	6270b586-556e-4539-a76a-514be466f978	Татьяна  Сергеевна  Борзенко	1	[{"added": {}}]	14	5
79	2025-05-28 14:37:23.045666+00	0794bf3d-6d15-4e7c-b077-b250c3b373f7	Егор  Александрович  Сёменов	1	[{"added": {}}]	14	5
80	2025-05-28 14:37:52.770171+00	6270b586-556e-4539-a76a-514be466f978	Татьяна  Сергеевна  Борзенко	3		14	5
81	2025-05-28 14:38:07.442045+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Иванович	3		14	5
82	2025-05-28 14:38:17.350272+00	3b62ef9e-48c6-4129-b130-47b56bc69974	Иван  Иванов  Иванович	3		14	5
83	2025-05-28 14:38:27.359923+00	0794bf3d-6d15-4e7c-b077-b250c3b373f7	Егор  Александрович  Сёменов	3		14	5
84	2025-05-28 14:39:15.362494+00	86bea85e-a62d-4dc0-8c0b-30541fd7782c	Борзенко  Татьяна  Сергеевна	1	[{"added": {}}]	14	5
85	2025-05-28 14:39:51.191336+00	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	Акжигитова  Дарья  Павловна	1	[{"added": {}}]	14	5
86	2025-05-28 14:40:19.39666+00	09d8307c-2256-4f71-94e1-958c21e6f1bc	Новикова  Анна  Евгеньевна	1	[{"added": {}}]	14	5
87	2025-05-28 14:40:59.662991+00	1a5902da-bf12-4f7e-b055-775956f6adda	Санто  Леонид  Павлович	1	[{"added": {}}]	14	5
88	2025-05-28 14:41:27.426425+00	8afa309b-cec8-4aaa-9031-06fe2b8267bf	Киверо  Александр  Дмитриевич	1	[{"added": {}}]	14	5
89	2025-05-28 14:42:32.353652+00	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	Варламова  Дарья  Олеговна	1	[{"added": {}}]	14	5
90	2025-05-28 14:42:59.554736+00	58c12ab6-e451-48b5-917e-26fc1855847a	Федоров  Антон  Сергеевич	1	[{"added": {}}]	14	5
91	2025-05-28 14:43:27.472513+00	1e4fa050-70ba-4031-9201-31d8cbd60b9a	Федорова  Елизавета  Николаевна	1	[{"added": {}}]	14	5
92	2025-05-29 13:11:43.07677+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met_1 : Основной продукт	3		16	5
93	2025-05-29 13:11:52.933928+00	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	Met_2 : Примеси	3		16	5
94	2025-05-29 13:11:58.845098+00	3b95b72a-5cfb-4a4d-9307-3a382d1e19d7	АнализТестовый : Ттипа	3		16	5
95	2025-05-29 13:13:19.146254+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
96	2025-05-29 13:13:48.165263+00	da3047ce-76fe-4d82-ba86-c121399b066e	Примеси аминокислоты	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
97	2025-05-29 13:14:40.836535+00	7469f991-2e03-491d-b168-f7d7f8feef4d	Эктоин : Примеси аминокислоты	1	[{"added": {}}]	16	5
98	2025-05-29 13:15:14.562309+00	7469f991-2e03-491d-b168-f7d7f8feef4d	Эктоин : Основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
99	2025-05-29 13:19:04.044744+00	b16068e8-0fcf-47af-ba21-86213f92d426	Эктоин	1	[{"added": {}}]	12	5
100	2025-05-29 13:19:23.741313+00	b16068e8-0fcf-47af-ba21-86213f92d426	Эктоин основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
101	2025-05-29 13:19:34.159199+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[]	12	5
102	2025-05-29 13:19:41.630174+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[]	12	5
103	2025-05-29 13:20:05.352001+00	c3866711-d6e9-47b6-aa48-f976bb276685	Эктоин примеси органических кислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
104	2025-05-29 13:20:22.699924+00	c7dba098-3d33-445c-a23b-57c247eee687	Основной продукт	3		12	5
105	2025-05-29 13:20:47.016385+00	da3047ce-76fe-4d82-ba86-c121399b066e	Эктоин примеси аминокислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
106	2025-05-29 13:28:04.35654+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин основной продукт : Эктоин основной продукт	1	[{"added": {}}]	16	5
107	2025-05-29 13:28:34.733392+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : Эктоин основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
108	2025-05-29 13:29:04.824583+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : Эктоин примеси органических кислот	1	[{"added": {}}]	16	5
109	2025-05-29 13:30:05.723892+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : Эктоин примеси аминокислот	1	[{"added": {}}]	16	5
110	2025-05-29 13:30:30.67236+00	b16068e8-0fcf-47af-ba21-86213f92d426	основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
111	2025-05-29 13:30:36.923877+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
112	2025-05-29 13:30:55.498286+00	c3866711-d6e9-47b6-aa48-f976bb276685	примеси органических кислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
113	2025-05-29 13:31:16.145889+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : примеси органических кислот	2	[]	16	5
114	2025-05-29 13:31:31.50066+00	da3047ce-76fe-4d82-ba86-c121399b066e	примеси аминокислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
115	2025-05-29 13:31:34.579339+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : примеси аминокислот	2	[]	16	5
116	2025-05-29 13:37:29.220266+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu3 органические кислоты	1	[{"added": {}}]	13	5
117	2025-05-29 13:38:42.978403+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000 аминокислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
118	2025-05-29 13:39:27.290339+00	322bde1c-c844-44d7-8846-a773b9f97679	Waters Alliance New	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430", "\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b"]}}]	13	5
119	2025-05-29 13:40:06.86374+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam433	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
120	2025-05-29 13:40:15.060454+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam 433	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
121	2025-05-29 13:41:01.555266+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260 аминокислоты	1	[{"added": {}}]	13	5
122	2025-05-29 13:41:39.41316+00	e028e32c-581f-4b39-92ae-9a81552b7862	Waters Alliance Old	1	[{"added": {}}]	13	5
123	2025-05-29 13:48:21.788059+00	54e28c12-acd4-4c69-a0a6-815a77c4e895	Hitachi 8900	1	[{"added": {}}]	13	5
124	2025-05-29 13:49:02.220575+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu6 органические кислоты	1	[{"added": {}}]	13	5
125	2025-05-29 13:49:24.644259+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3 органические кислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
126	2025-05-29 13:49:40.206065+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6 органические кислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
127	2025-05-29 13:51:03.592429+00	27dc31dd-0a11-452e-ac1e-aeb052f18226	Agilent 7100 CE	1	[{"added": {}}]	13	5
128	2025-05-29 13:52:14.6906+00	612b7c5b-61b6-4795-8d07-98bc92bc4c51	Methrohm	1	[{"added": {}}]	13	5
129	2025-05-29 13:52:42.207693+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
130	2025-05-29 13:52:52.571696+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
131	2025-05-29 13:53:25.556608+00	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	Dionex ICS 5000	1	[{"added": {}}]	13	5
132	2025-05-29 13:53:45.365327+00	0c0b62b6-c1b4-4828-8c87-b90396e2288d	Dionex ICS 5000 2	1	[{"added": {}}]	13	5
133	2025-05-29 13:57:51.863916+00	370b51e9-685c-4a6d-bcc5-67bed5d29f48	Aracus	1	[{"added": {}}]	13	5
134	2025-05-29 13:59:29.334356+00	555a86cd-0550-42d7-b085-92842c89ee90	Shimadzu 4	1	[{"added": {}}]	13	5
135	2025-05-29 13:59:55.459928+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	1	[{"added": {}}]	13	5
136	2025-05-29 14:00:14.281088+00	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	Shimadzu 7	1	[{"added": {}}]	13	5
137	2025-05-29 14:01:02.408838+00	4b3bb52f-df8d-421c-893e-37052e982bcb	Shimadzu 30	1	[{"added": {}}]	13	5
138	2025-05-29 14:01:24.56301+00	a8222354-63a4-4c12-b4ee-00ff34788fa1	Shimadzu GC 2010	1	[{"added": {}}]	13	5
139	2025-05-29 14:01:51.578352+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	1	[{"added": {}}]	13	5
140	2025-05-29 14:03:05.049898+00	1fb0d24b-975e-4366-b981-ae320ff1265a	Waters  LC-MS/MS Acquity	1	[{"added": {}}]	13	5
141	2025-05-29 14:04:05.786078+00	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	Shimadzu LC-MS 8050	1	[{"added": {}}]	13	5
142	2025-05-29 14:07:16.920949+00	7dd395a4-3652-4450-98a0-80cb8a9b3693	Эктоин 1 : основной продукт - Shimadzu 4	1	[{"added": {}}]	19	5
143	2025-05-29 14:07:45.273566+00	32460d60-bb76-47fc-8668-d651530c08ee	Эктоин 2 : примеси органических кислот - Shimadzu 3 органические кислоты	1	[{"added": {}}]	19	5
144	2025-05-29 14:08:08.471535+00	32460d60-bb76-47fc-8668-d651530c08ee	Эктоин 2 : примеси органических кислот - Shimadzu 3 органические кислоты	3		19	5
145	2025-05-29 14:08:18.937691+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6 органические кислоты	2	[]	13	5
146	2025-05-29 14:08:26.400179+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
147	2025-05-29 14:08:31.88643+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3 органические кислоты	2	[]	13	5
148	2025-05-29 14:08:37.362312+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
149	2025-05-29 14:11:47.684813+00	f4219c2e-5e50-4b01-b68a-2c42ebb65cbd	Эктоин 2 : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
150	2025-05-29 14:12:14.039526+00	4a8d426e-1a4c-4e7e-b7c7-b23a9bf0bcc1	Эктоин 2 : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
151	2025-05-29 14:12:53.677711+00	4ab314fc-7430-480b-a2e4-8209fcf92b19	Эктоин 3 : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
152	2025-05-29 14:13:04.841713+00	f68b9664-d014-4676-948d-52498a46ca27	Эктоин 3 : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
153	2025-05-29 14:14:06.873022+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Эктоин 1 : основной продукт - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
154	2025-05-29 14:16:14.446921+00	8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	Борзенко  Татьяна  Сергеевна - Agilent 1260	1	[{"added": {}}]	18	5
155	2025-05-29 14:16:40.433929+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 11000	1	[{"added": {}}]	18	5
156	2025-05-29 14:16:56.577146+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000	2	[]	13	5
157	2025-05-29 14:17:02.096914+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 1100	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
158	2025-05-29 14:17:32.589828+00	59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	Санто  Леонид  Павлович - Sykam 433	1	[{"added": {}}]	18	5
159	2025-05-29 14:17:56.607826+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	1	[{"added": {}}]	18	5
160	2025-05-29 14:18:09.968488+00	ebe0ca91-0214-453a-91f3-925bd53f5606	Санто  Леонид  Павлович - Hitachi 8900	1	[{"added": {}}]	18	5
161	2025-05-29 14:18:25.631958+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	1	[{"added": {}}]	18	5
162	2025-05-29 14:18:45.380336+00	94189595-1d95-4782-8464-b338640e1b5e	Федоров  Антон  Сергеевич - Methrohm	1	[{"added": {}}]	18	5
164	2025-05-29 14:20:22.927545+00	d36c9e4f-2406-492b-b467-de7884e9a2e6	Сёменов  Егор  Александрович	1	[{"added": {}}]	14	5
165	2025-05-29 14:20:49.214107+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	1	[{"added": {}}]	18	5
166	2025-05-30 14:17:34.283769+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	1	[{"added": {}}]	8	1
167	2025-05-30 14:24:25.212971+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	2	[]	8	1
168	2025-06-02 18:10:26.885797+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 23:00, период недели: 09.06.2025-15.06.2025	1	[{"added": {}}]	8	1
169	2025-06-02 18:10:35.463834+00	558d6fee-fc77-4e01-9876-e48d5f98879b	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
170	2025-06-02 18:10:42.699611+00	65986bb1-234e-4c54-b5dd-ccd386a15b10	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">09.06.2025-15.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
171	2025-06-02 18:11:19.630388+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин 2 : примеси органических кислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	1
172	2025-06-02 18:11:27.097715+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин 3 : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	1
173	2025-06-02 18:26:50.946841+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
174	2025-06-02 18:27:07.413895+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	3		7	1
175	2025-06-02 18:27:20.891718+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
176	2025-06-02 18:27:31.385948+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
177	2025-06-03 12:23:28.646958+00	c37e1b7a-bf5b-427d-ab59-f530c2810d10	Борзенко  Татьяна  Сергеевна - Methrohm	2	[]	18	5
178	2025-06-03 12:24:20.558854+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	1	[{"added": {}}]	18	5
179	2025-06-03 12:24:53.026563+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	2	[]	18	5
180	2025-06-03 12:25:48.851552+00	8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	Борзенко  Татьяна  Сергеевна - Agilent 1260	2	[]	18	5
181	2025-06-03 12:26:10.48317+00	ebe0ca91-0214-453a-91f3-925bd53f5606	Санто  Леонид  Павлович - Hitachi 8900	2	[]	18	5
182	2025-06-03 12:26:15.12582+00	59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	Санто  Леонид  Павлович - Sykam 433	2	[]	18	5
183	2025-06-03 12:26:31.494357+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	2	[]	18	5
184	2025-06-03 12:26:41.128799+00	fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000	1	[{"added": {}}]	18	5
185	2025-06-03 12:27:15.769339+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	2	[]	18	5
186	2025-06-03 12:27:59.518163+00	5f9f0bd3-186e-4ee7-9207-8dcbc67c4ea9	Сёменов  Егор  Александрович - Agilent 1100	1	[{"added": {}}]	18	5
187	2025-06-03 12:29:41.254611+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	2	[]	18	5
188	2025-06-03 12:30:00.215937+00	14cdc62c-f9c2-4043-85a3-99451ebee7fc	Сёменов  Егор  Александрович - Shimadzu 30	1	[{"added": {}}]	18	5
189	2025-06-03 12:30:14.38348+00	94189595-1d95-4782-8464-b338640e1b5e	Федоров  Антон  Сергеевич - Methrohm	2	[]	18	5
190	2025-06-03 12:30:29.202076+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	1	[{"added": {}}]	18	5
191	2025-06-03 12:30:50.356847+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[]	18	5
192	2025-06-03 12:31:07.765117+00	e1dfe070-72f1-4a0f-ae0d-300903a686e2	Федоров  Антон  Сергеевич - Dionex ICS 5000	1	[{"added": {}}]	18	5
193	2025-06-03 12:31:16.805525+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[]	18	5
194	2025-06-03 12:31:26.224615+00	eed4b9b6-0e16-4811-ac84-9c8851e8d4ae	Федоров  Антон  Сергеевич - Dionex ICS 5000 2	1	[{"added": {}}]	18	5
195	2025-06-03 12:31:31.182927+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043b\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0442\\u043e\\u0440 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	18	5
196	2025-06-03 12:45:40.978368+00	e1dfe070-72f1-4a0f-ae0d-300903a686e2	Федоров  Антон  Сергеевич - Dionex ICS 5000	2	[]	18	5
197	2025-06-03 12:45:45.721377+00	fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000	2	[]	18	5
198	2025-06-03 12:46:13.011622+00	3add5154-d941-43d3-a891-28512fd90890	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000 2	1	[{"added": {}}]	18	5
199	2025-06-03 12:47:12.016623+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	2	[]	18	5
200	2025-06-03 12:47:26.957215+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	1	[{"added": {}}]	18	5
201	2025-06-03 12:47:31.616866+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	2	[]	18	5
202	2025-06-03 12:47:47.162344+00	bd3d2f53-fdf4-4ff5-b267-13435039ecde	Киверо  Александр  Дмитриевич - Shimadzu LC-MS 8050	1	[{"added": {}}]	18	5
203	2025-06-03 12:47:53.07458+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	2	[]	18	5
204	2025-06-03 12:48:11.169881+00	b70cb072-2435-472e-8579-a0e6d5d9e70e	Киверо  Александр  Дмитриевич - Shimadzu GC 2010	1	[{"added": {}}]	18	5
205	2025-06-03 12:48:23.985091+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	2	[]	18	5
206	2025-06-03 12:48:38.588846+00	702157a8-9348-41e5-bae7-961a0e3e5940	Киверо  Александр  Дмитриевич - Shimadzu GC 2014	1	[{"added": {}}]	18	5
207	2025-06-03 12:49:30.649207+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 1100	2	[]	18	5
208	2025-06-03 12:50:07.136766+00	821c378b-aaed-45b3-a007-8b620e34126f	Варламова  Дарья  Олеговна - Aracus	1	[{"added": {}}]	18	5
209	2025-06-03 12:50:20.023433+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 1100	2	[]	18	5
210	2025-06-03 12:50:46.197707+00	54968de3-1f18-4d08-a485-a83a3e89cb3f	Варламова  Дарья  Олеговна - Shimadzu 3	1	[{"added": {}}]	18	5
211	2025-06-03 12:51:16.04865+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
212	2025-06-03 12:51:47.599238+00	a5d446a8-3fa6-47f3-9a84-eb428f14e600	Федорова  Елизавета  Николаевна - Shimadzu 4	1	[{"added": {}}]	18	5
213	2025-06-03 12:51:55.140081+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
214	2025-06-03 12:52:13.478217+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	1	[{"added": {}}]	18	5
215	2025-06-03 12:52:20.262299+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	2	[]	18	5
216	2025-06-03 12:52:33.363847+00	7a2e39e0-972a-4e11-aaf7-4091306b4bb4	Федорова  Елизавета  Николаевна - Shimadzu 6	1	[{"added": {}}]	18	5
217	2025-06-03 13:02:27.251361+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	2	[]	18	5
218	2025-06-03 13:02:52.405737+00	3d2dc186-dcb4-4876-9d18-7252d8181131	Федорова  Елизавета  Николаевна - Waters Alliance New	1	[{"added": {}}]	18	5
219	2025-06-03 13:03:01.279781+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
220	2025-06-03 13:03:22.446096+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	1	[{"added": {}}]	18	5
221	2025-06-03 13:03:39.152747+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	2	[]	18	5
222	2025-06-03 13:03:49.047772+00	4ef7cae5-4722-45b1-bc60-d3a241c8d08f	Новикова  Анна  Евгеньевна - Shimadzu 5	1	[{"added": {}}]	18	5
223	2025-06-03 13:04:07.638553+00	4ef7cae5-4722-45b1-bc60-d3a241c8d08f	Новикова  Анна  Евгеньевна - Shimadzu 5	2	[]	18	5
224	2025-06-03 13:04:28.699439+00	c47fcc37-09db-4099-aad3-462f24cb56a2	Новикова  Анна  Евгеньевна - Shimadzu 30	1	[{"added": {}}]	18	5
225	2025-06-03 13:05:39.101358+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
226	2025-06-03 13:07:05.617768+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile) : основной продукт	1	[{"added": {}}]	16	5
227	2025-06-03 13:07:27.527129+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile) : основной продукт	2	[]	16	5
228	2025-06-03 13:07:47.50009+00	563ae91e-3338-45f7-aead-c5a3c7a57f63	BCAA(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
229	2025-06-03 13:07:54.313091+00	563ae91e-3338-45f7-aead-c5a3c7a57f63	BCAA(AA) : примеси аминокислот	2	[]	16	5
230	2025-06-03 13:08:23.467493+00	091e7bb0-f31d-4465-8e6f-130e5f83d454	BCAA(OA,2IPM,3IPM) : примеси органических кислот	1	[{"added": {}}]	16	5
231	2025-06-03 13:08:39.293055+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
232	2025-06-03 13:08:47.987131+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
233	2025-06-03 13:08:52.257312+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : примеси органических кислот	2	[]	16	5
234	2025-06-03 13:09:07.503545+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин (OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
235	2025-06-03 13:09:30.067782+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : примеси аминокислот	2	[]	16	5
236	2025-06-03 13:09:43.844012+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин (AA) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
237	2025-06-03 13:23:04.14012+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn : основной продукт	1	[{"added": {}}]	16	5
238	2025-06-03 13:23:26.327781+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn(OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
239	2025-06-03 13:23:36.127038+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn(OA) : примеси органических кислот	2	[]	16	5
240	2025-06-03 13:23:44.868595+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn : основной продукт	1	[{"added": {}}]	16	5
241	2025-06-03 13:23:56.848477+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn : основной продукт	2	[]	16	5
242	2025-06-03 13:24:11.145502+00	4e1fbb62-07ef-441b-a27b-1956581e9ca8	Asn(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
243	2025-06-03 13:25:01.066649+00	3893f977-8f70-49be-903b-ed0149e4a505	DAP : основной продукт	1	[{"added": {}}]	16	5
244	2025-06-03 13:25:04.593923+00	3893f977-8f70-49be-903b-ed0149e4a505	DAP : основной продукт	2	[]	16	5
245	2025-06-03 13:25:26.783858+00	ca0a4632-47de-4590-b84b-5835604a02c6	DAP(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
246	2025-06-03 13:25:31.727139+00	ca0a4632-47de-4590-b84b-5835604a02c6	DAP(OA) : примеси органических кислот	2	[]	16	5
247	2025-06-03 13:30:48.84451+00	73129017-ac9d-4a55-9020-7192a2b3150a	Ser : основной продукт	1	[{"added": {}}]	16	5
248	2025-06-03 13:31:03.515185+00	fdc73d75-74c1-44e9-b276-2b748d35620b	Ser(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
249	2025-06-03 13:31:11.818608+00	fdc73d75-74c1-44e9-b276-2b748d35620b	Ser(OA) : примеси органических кислот	2	[]	16	5
250	2025-06-03 13:31:28.140659+00	e40964e1-8934-428e-a06e-18379a30ebae	Ser(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
251	2025-06-03 13:40:04.798069+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg : основной продукт	1	[{"added": {}}]	16	5
252	2025-06-03 13:40:09.383601+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg : основной продукт	2	[]	16	5
253	2025-06-03 13:40:20.476288+00	eecdd0f8-7244-4bf6-8f96-65622901a51d	Arg(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
254	2025-06-03 13:40:42.417165+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg(AA) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
255	2025-06-03 13:42:15.410558+00	7da0bd39-87ac-4b74-b152-236e519597e1	a-AP : основной продукт	1	[{"added": {}}]	16	5
256	2025-06-03 13:42:34.010655+00	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	a-AP(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
257	2025-06-03 13:43:25.357688+00	020da433-e3a3-419c-851f-f52102a5fe00	Cys(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
258	2025-06-03 13:53:26.881029+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
259	2025-06-03 13:53:49.325106+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(AA) : примеси аминокислот	2	[]	16	5
260	2025-06-03 13:54:03.307826+00	f546d1c3-036a-47dd-8662-9b37a914408f	Cys(sCys) : примеси аминокислот	1	[{"added": {}}]	16	5
261	2025-06-03 14:00:05.819893+00	6b8c318d-699a-494c-b63f-44156f6a7a1d	примеси неорганических анионов	1	[{"added": {}}]	12	5
262	2025-06-03 14:00:36.946579+00	13649857-bdb6-4771-8105-8dc1fd503ac9	Ser(IA) : примеси неорганических анионов	1	[{"added": {}}]	16	5
263	2025-06-03 14:03:10.047499+00	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	GSH,GC : основной продукт	1	[{"added": {}}]	16	5
264	2025-06-03 14:06:05.373289+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	1	[{"added": {}}]	16	5
265	2025-06-03 14:06:18.202347+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	2	[]	16	5
266	2025-06-03 14:06:45.429394+00	1d7b838c-9f35-43e6-9cde-d63c11d9097f	Gr(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
267	2025-06-03 14:06:51.341344+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	2	[]	16	5
268	2025-06-03 14:07:44.49691+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR : основной продукт	1	[{"added": {}}]	16	5
269	2025-06-03 14:08:11.605514+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR : основной продукт	2	[]	16	5
270	2025-06-03 14:08:33.086643+00	571c313e-8ec3-4777-bac7-40855117d510	HxR(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
271	2025-06-03 14:09:30.920435+00	04ffa9b6-2db9-496b-a154-c68bc55fcefd	анализ сахаров	1	[{"added": {}}]	12	5
272	2025-06-03 14:10:18.333959+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr(sugar) : анализ сахаров	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
273	2025-06-03 14:10:27.366334+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr(sugar) : анализ сахаров	2	[]	16	5
274	2025-06-03 14:10:50.269913+00	8cb45323-f121-47ad-969d-0ed9c2336674	HxR(sugar) : анализ сахаров	1	[{"added": {}}]	16	5
275	2025-06-03 14:12:29.331501+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	1	[{"added": {}}]	16	5
276	2025-06-03 14:12:36.189117+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
277	2025-06-03 14:13:05.884744+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS(Ala-Gln) : основной продукт	1	[{"added": {}}]	16	5
278	2025-06-03 14:13:34.258615+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
279	2025-06-03 14:14:21.853697+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS-His(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
280	2025-06-03 14:14:31.248761+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS(Ala-Gln) : основной продукт	2	[]	16	5
281	2025-06-03 14:14:42.653962+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS_Ala-Gln : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
282	2025-06-03 14:14:57.62561+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS-His(OA) : примеси органических кислот	2	[]	16	5
283	2025-06-03 14:15:09.348656+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS_His (OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
284	2025-06-03 14:15:12.670652+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS_His (OA) : примеси органических кислот	2	[]	16	5
285	2025-06-03 14:15:23.306637+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
286	2025-06-03 14:15:31.255959+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS_His : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
287	2025-06-03 14:18:24.438257+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS_Ala-Gln : основной продукт	2	[]	16	5
288	2025-06-03 14:18:43.061543+00	e32c058b-38a7-4a49-a335-548da531c9b0	KSS_Ala-Gln (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
289	2025-06-03 14:19:19.973302+00	9fe01f07-a489-4eca-8639-403986129de1	KSS_Carnosine : основной продукт	1	[{"added": {}}]	16	5
290	2025-06-03 14:20:29.345022+00	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	Fatty acid : основной продукт	1	[{"added": {}}]	16	5
291	2025-06-03 14:21:50.398446+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	1	[{"added": {}}]	16	5
292	2025-06-03 14:22:05.063468+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	2	[]	16	5
293	2025-06-03 14:22:09.684794+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	2	[]	16	5
294	2025-06-03 14:22:35.92531+00	7b74a6a1-d92b-476a-befc-0783a20e9170	Amisoft(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
295	2025-06-03 14:23:19.691921+00	1b6870c5-c028-4f7d-b3a6-da026ec81032	Lauric acid : основной продукт	1	[{"added": {}}]	16	5
296	2025-06-03 14:23:33.391357+00	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	Met : основной продукт	1	[{"added": {}}]	16	5
297	2025-06-03 14:23:47.700449+00	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	Met (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
298	2025-06-03 14:24:33.396271+00	601b7b77-ab12-477c-918e-ca3910a3bb96	Met (IA) : примеси неорганических анионов	1	[{"added": {}}]	16	5
299	2025-06-03 14:27:47.493544+00	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	Gln : основной продукт	1	[{"added": {}}]	16	5
300	2025-06-03 14:27:59.784137+00	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	Gln (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
301	2025-06-03 14:28:38.626557+00	ace768c2-60a5-40f1-b745-63829f6b8d9f	Glu : основной продукт	1	[{"added": {}}]	16	5
302	2025-06-03 14:28:53.644811+00	7129f484-2524-4bc2-a857-7a4663b6abbb	Glu (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
303	2025-06-03 14:29:59.490608+00	00bc93e0-ef32-471d-aade-da29ce6a1660	Glu (AA) : примеси аминокислот	1	[{"added": {}}]	16	5
304	2025-06-03 14:38:25.411212+00	08dc2b8b-9ef1-43bd-831f-3e43112a125c	Lauric acid : основной продукт - Shimadzu GC 2014	1	[{"added": {}}]	19	5
305	2025-06-03 14:39:07.192493+00	4e194ce7-ca13-4e35-b5ae-ad7f304dd741	Met : основной продукт - Aracus	1	[{"added": {}}]	19	5
306	2025-06-03 14:39:30.806768+00	e80d95d5-3b67-448f-b8c5-a4dad25485d1	Met (OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
307	2025-06-03 14:39:41.219091+00	e80d95d5-3b67-448f-b8c5-a4dad25485d1	Met (OA) : примеси органических кислот - Shimadzu 6	2	[]	19	5
308	2025-06-03 14:39:58.611465+00	1d4210d8-b9e3-47cf-9fd2-c138db2b8191	Met (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
309	2025-06-03 14:40:39.09608+00	47520068-d119-47e0-a9b7-82cf86c41e38	Met (IA) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
310	2025-06-03 14:41:46.278851+00	0b924349-8b40-4893-826f-1f762571b345	Gln : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
311	2025-06-03 14:43:42.970194+00	f4d86890-3f47-474b-89f2-41f44f2ee4af	Gln (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
312	2025-06-03 14:43:53.096529+00	f4d86890-3f47-474b-89f2-41f44f2ee4af	Gln (OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
313	2025-06-03 14:44:08.829169+00	9e5c8536-1488-4521-abef-5e2162d3e57d	Gln (OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
314	2025-06-04 13:19:56.237361+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
315	2025-06-04 13:23:55.862815+00	d3b71632-d535-4eae-ad5f-a26e5536f503	Эктоин (OA) : примеси органических кислот - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
316	2025-06-04 13:24:15.874438+00	d2307861-ee3b-426a-98fa-259d83ac47d0	Эктоин : основной продукт - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
317	2025-06-04 13:27:38.277251+00	536f650e-ae6f-42b0-bf1a-f06eee086923	Окно бронирования на 04.06.2025 с 00:00 до 24:00, период недели: 02.06.2025-08.06.2025	1	[{"added": {}}]	8	5
318	2025-06-04 13:28:07.752618+00	32e6ef03-58f4-4e8f-80c4-bf5537058666	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">02.06.2025-08.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	5
319	2025-06-04 13:33:15.630416+00	0b6e2138-4fc5-4404-b584-6707d4890102	Arg : основной продукт	1	[{"added": {}}]	16	5
320	2025-06-04 13:34:15.971887+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
321	2025-06-04 13:35:07.971314+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[]	15	5
322	2025-06-05 09:56:15.913135+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	2	[]	17	5
323	2025-06-05 10:03:10.403474+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин (OA) : примеси органических кислот - Methionine (Сидоров) : Не приоритетный 	2	[]	17	5
324	2025-06-05 10:03:42.726991+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	2	[]	17	5
325	2025-06-05 10:04:06.053803+00	cdb3e289-dd41-4e0e-826c-b99270b5eeb2	Fatty acid : основной продукт - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
326	2025-06-05 10:05:51.30702+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[]	15	5
327	2025-06-05 10:06:13.007484+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[]	15	5
328	2025-06-05 10:07:01.859647+00	c0d394f6-e583-4327-9acc-20a826b40cac	Cys(AA) : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
329	2025-06-05 10:18:06.505235+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	1	[{"added": {}}]	15	5
330	2025-06-05 10:18:58.791403+00	1c051ae6-a3a0-4637-8011-45d15e7d7590	Эктоин (OA) : примеси органических кислот - Эктоин (Гераскина) : Не приоритетный 	1	[{"added": {}}]	17	5
331	2025-06-05 10:25:19.972909+00	de22a9eb-3341-4f6e-a7e2-08306aae6cfb	Glu : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
332	2025-06-05 10:25:35.535442+00	151661f6-b9a4-485e-a0b0-79eec9653190	BCAA(Ile) : основной продукт - Dionex ICS 5000	1	[{"added": {}}]	19	5
333	2025-06-05 10:25:57.666435+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
334	2025-06-05 10:26:22.128213+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(OA,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
335	2025-06-05 10:26:43.301476+00	f36c4f83-7cdc-466c-b0c6-f53eee215e52	Glu (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
336	2025-06-05 10:27:02.458052+00	d1bfe6e8-c571-4188-a3f9-185b9954aebe	Glu (AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
337	2025-06-05 10:27:44.452808+00	816a15ab-4636-4b60-8c01-5f6a914e66f3	Arg : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
338	2025-06-05 10:28:08.810493+00	c29e42b9-0143-4fb9-aff1-55067ffbf357	Asn(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
339	2025-06-05 10:28:28.919178+00	07fa9507-7399-4cdb-ba6f-0fd7ab71feb5	Asn : основной продукт - Hitachi 8900	1	[{"added": {}}]	19	5
340	2025-06-05 10:28:51.306181+00	2bcddd69-9709-445d-9567-a86b0a947972	Asn(AA) : примеси аминокислот - Hitachi 8900	1	[{"added": {}}]	19	5
341	2025-06-05 10:29:39.917087+00	44c5358c-8aee-4820-83c7-7a568f9d4065	DAP : основной продукт - Agilent 1100	1	[{"added": {}}]	19	5
342	2025-06-05 10:29:58.478527+00	71cdf309-436c-41e2-ba9f-00290a6e03ce	DAP(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
343	2025-06-05 10:31:48.744901+00	6ce21107-4e96-4198-8744-f38680e66785	Ser : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
344	2025-06-05 10:32:09.81416+00	9283b3c3-596a-44c4-b907-1c36355e75f6	Ser(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
345	2025-06-05 10:32:35.083718+00	7786e1b5-15f0-4730-b91f-9d2588d7b941	Ser(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
346	2025-06-05 10:32:58.404074+00	37bdfb2c-3a5b-400e-8cfd-86bc61065487	Arg(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
347	2025-06-05 10:33:42.878964+00	1d19b9bf-c98e-47d3-9c8e-4221f8e495c6	Arg(AA) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
348	2025-06-05 10:34:06.912408+00	3b35ac23-0b75-43dc-85ed-76dddd522db2	Asn(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
349	2025-06-05 10:34:30.027093+00	ed0ed014-2191-4b97-af22-9d1ba16ba4c9	a-AP : основной продукт - Waters Alliance Old	1	[{"added": {}}]	19	5
350	2025-06-05 10:35:02.424767+00	0ca15667-5429-4a44-b009-b1815a7fa312	a-AP(AA) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
351	2025-06-05 10:35:16.231784+00	007dd4bd-15cf-4911-a4af-80eaf37fa445	Cys(OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
352	2025-06-05 10:35:43.141207+00	b94cee75-d835-424a-9486-55711407d0db	Cys(AA) : примеси аминокислот - Aracus	1	[{"added": {}}]	19	5
353	2025-06-05 10:36:00.244056+00	3b2f0fa5-d5ff-4b74-bc28-a0bb4103597a	Cys(sCys) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
354	2025-06-05 10:36:52.317836+00	2261a1c8-dd9f-4ba8-9fa1-ec23ddc712d9	Ser(IA) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
355	2025-06-05 10:37:18.491432+00	83635efb-56a4-4bff-a8f2-245739f40fc7	GSH,GC : основной продукт - Shimadzu 30	1	[{"added": {}}]	19	5
356	2025-06-05 10:37:41.608829+00	cbce33a1-3c56-4c54-b194-315442818858	Gr(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
357	2025-06-05 10:37:57.731099+00	dccd8d63-fa3a-4047-8909-fd25061670d9	HxR : основной продукт - Shimadzu 7	1	[{"added": {}}]	19	5
358	2025-06-05 10:38:19.369462+00	9eebac2d-c944-4f98-9ec8-ca65b521dc3a	HxR(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
359	2025-06-05 10:38:37.891557+00	f8d6c899-bbf4-48cd-9457-901947d9a933	Gr(sugar) : анализ сахаров - Dionex ICS 5000 2	1	[{"added": {}}]	19	5
360	2025-06-05 10:39:03.655056+00	8d16e8bd-0e67-4612-ba99-bc03b3fea5b9	HxR(sugar) : анализ сахаров - Dionex ICS 5000 2	1	[{"added": {}}]	19	5
361	2025-06-05 10:39:21.153518+00	b1f3e239-4317-4b5a-a752-e1aab475f793	KSS_His (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
362	2025-06-05 10:39:41.740202+00	5645adea-fa77-4418-b7e7-2dbc05d4bdbb	KSS_His : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
363	2025-06-05 10:39:54.850472+00	7ddc3b1d-54af-46fb-b500-14b8c36d398d	KSS_Ala-Gln : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
364	2025-06-05 10:41:15.119937+00	7bbd84dd-6703-42e0-bfe1-f01da0373b59	KSS_Ala-Gln (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
365	2025-06-05 10:41:45.428515+00	a37304bd-fc47-416e-97b6-f608b67a2f4b	KSS_Carnosine : основной продукт - Agilent 1260	1	[{"added": {}}]	19	5
366	2025-06-05 10:42:13.479358+00	cd1696ac-e37f-4c0e-99a1-039450bb4ade	Fatty acid : основной продукт - Shimadzu GC 2014	1	[{"added": {}}]	19	5
367	2025-06-05 10:42:26.679959+00	14bb3a20-dc58-4d92-ad61-be551ccad6e4	Amisoft : основной продукт - Shimadzu 30	1	[{"added": {}}]	19	5
368	2025-06-05 10:42:42.281661+00	8fe966e3-5285-42a4-b619-ca707c9784e5	Amisoft(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
369	2025-06-05 10:44:09.733469+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
370	2025-06-05 10:44:37.134305+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[]	15	5
371	2025-06-05 10:44:49.816011+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	2	[]	15	5
372	2025-06-05 11:17:24.929316+00	97112c5a-e332-4efe-9b45-b717c45523a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
373	2025-06-05 11:17:24.938419+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: gray;'>Вт  	3		9	1
374	2025-06-05 11:18:35.873491+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 23:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
375	2025-06-05 11:19:32.994041+00	adf5ec6d-c735-4f8b-a24f-7e314d90b1cd	Окно бронирования на 22.05.2025 с 06:00 до 15:00, период недели: 26.05.2025-01.06.2025	3		8	1
376	2025-06-05 11:19:32.9968+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	3		8	1
377	2025-06-05 11:19:32.999607+00	3765642b-4174-4a95-814f-cc9f185db017	Окно бронирования на 19.05.2025 с 00:00 до 24:00, период недели: 19.05.2025-25.05.2025	3		8	1
378	2025-06-05 11:19:33.00127+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	3		8	1
379	2025-06-05 11:19:41.939747+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
380	2025-06-05 11:59:14.797952+00	fab9df77-6191-4482-acc5-61e247aca6cf	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	1	[{"added": {}}]	10	1
381	2025-06-06 08:37:19.867324+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
382	2025-06-06 08:38:27.113063+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
383	2025-06-06 08:40:20.231614+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
384	2025-06-06 08:51:19.14394+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	2	[]	17	5
385	2025-06-06 09:48:21.811951+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Met : основной продукт - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
386	2025-06-06 09:48:33.062328+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин (OA) : примеси органических кислот - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
387	2025-06-06 09:48:49.633774+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Met (OA) : примеси органических кислот - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
388	2025-06-06 09:49:43.869097+00	d3b71632-d535-4eae-ad5f-a26e5536f503	Arg(OA) : примеси органических кислот - Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
389	2025-06-06 09:50:32.336244+00	d2307861-ee3b-426a-98fa-259d83ac47d0	Arg(AA) : примеси аминокислот - Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
390	2025-06-06 09:50:55.61109+00	cdb3e289-dd41-4e0e-826c-b99270b5eeb2	Met (IA) : примеси неорганических анионов - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
391	2025-06-06 09:51:46.531529+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
392	2025-06-06 09:52:24.856972+00	c0d394f6-e583-4327-9acc-20a826b40cac	Эктоин : основной продукт - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442", "\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
393	2025-06-06 09:54:47.903834+00	fab9df77-6191-4482-acc5-61e247aca6cf	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	3		10	5
394	2025-06-06 09:54:52.416488+00	f3876eca-6fbc-4499-a071-f121b03a1f6d	16.06.2025-22.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
395	2025-06-06 09:54:56.789043+00	e81d5de2-0ee0-4f11-99f9-db6bfd39a19e	16.06.2025-22.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
396	2025-06-06 09:55:01.039826+00	ddf616b6-e88b-4b3e-8b9d-17c94833d9ec	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
397	2025-06-06 09:55:06.122869+00	ddb248fc-54cb-4ef6-a23d-dda0052a6092	16.06.2025-22.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
398	2025-06-06 09:55:11.276794+00	b3109dfd-7f1b-4efd-8a92-c20a50761839	16.06.2025-22.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
399	2025-06-06 09:55:24.030934+00	a5ccc551-db5c-4c71-960d-69c988ae505f	16.06.2025-22.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
400	2025-06-06 09:55:29.591608+00	65c6f9ce-ce2a-41bd-93b5-13673d716e1b	16.06.2025-22.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
401	2025-06-06 09:55:35.231214+00	65360ba8-3bfc-48d2-8272-64a4afa49ad6	16.06.2025-22.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
402	2025-06-06 09:55:40.989704+00	558d6fee-fc77-4e01-9876-e48d5f98879b	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
403	2025-06-06 09:55:46.210419+00	52d6742c-4f75-43d7-bedd-430de3fd61e0	16.06.2025-22.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
404	2025-06-06 09:56:16.308491+00	5219d651-27b3-4eaf-879d-7885a7dea985	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
405	2025-06-06 09:56:25.577132+00	5219d651-27b3-4eaf-879d-7885a7dea985	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u043e\\u0432 \\u043d\\u0430 \\u0441\\u043e\\u0442\\u0440\\u0443\\u0434\\u043d\\u0438\\u043a\\u0430 \\u0432 \\u0434\\u0435\\u043d\\u044c"]}}]	10	5
406	2025-06-06 09:56:38.782519+00	13c9e994-564b-4577-96fb-9856b96e2933	16.06.2025-22.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
407	2025-06-06 09:56:51.968157+00	10ff566f-7aa7-4b59-866c-02699cce953c	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
408	2025-06-06 09:57:06.63526+00	2ef307d9-4a72-43f0-94d0-32e27af4b41f	16.06.2025-22.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
409	2025-06-06 09:57:30.715566+00	386cfcc5-8f81-41b8-901d-4e7933f369cc	09.06.2025-15.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
410	2025-06-06 09:57:46.918589+00	cc74c9b7-7478-4d9c-bfa0-efa19c9d7df0	16.06.2025-22.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
411	2025-06-06 09:58:10.362514+00	faf7f1ac-d6d3-4971-9614-079940658474	09.06.2025-15.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
412	2025-06-06 09:58:21.525402+00	9c8949f1-b97b-4d7b-aa8e-5f7cfef56f6a	16.06.2025-22.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
413	2025-06-06 09:58:34.581509+00	7da16033-9b11-44da-96ca-058675a53e9e	09.06.2025-15.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
414	2025-06-06 09:58:47.322678+00	90185b56-b39e-40c7-9798-024213deac70	16.06.2025-22.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
415	2025-06-06 09:59:10.588556+00	26a010b1-e1b5-4155-8fd4-36b17ca1ae3b	09.06.2025-15.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
416	2025-06-06 09:59:22.582088+00	35a3585e-dd65-4761-8871-54471d4d53cc	16.06.2025-22.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
417	2025-06-06 10:21:28.082147+00	8685c020-7469-47aa-9746-fe038ae0c55c	09.06.2025-15.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
418	2025-06-06 10:21:39.154153+00	74ca31c7-210d-4f29-8593-f767f2d33969	16.06.2025-22.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
419	2025-06-06 10:23:13.994734+00	7d5bca70-ee72-43cf-b4a9-c5416a2137fc	09.06.2025-15.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
420	2025-06-06 10:23:35.683783+00	1382ddde-24a5-443a-9af8-133c83477218	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
421	2025-06-06 10:24:04.593265+00	75b4833a-4a8a-451d-83d2-9c5f305eef5c	09.06.2025-15.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
422	2025-06-06 10:25:28.958805+00	6651c987-6301-48ea-a14b-b450ae0548d6	16.06.2025-22.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
423	2025-06-06 10:32:18.345888+00	536f650e-ae6f-42b0-bf1a-f06eee086923	Окно бронирования на 04.06.2025 с 00:00 до 24:00, период недели: 02.06.2025-08.06.2025	3		8	5
424	2025-06-06 10:32:22.165423+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 06.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
425	2025-06-06 10:33:58.821149+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 06.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[]	8	5
426	2025-06-06 10:34:34.540417+00	65986bb1-234e-4c54-b5dd-ccd386a15b10	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">09.06.2025-15.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0431\\u0431\\u043e\\u0442\\u0430"]}}]	9	5
427	2025-06-06 10:34:40.86158+00	b654ea09-0b0d-4b6b-a734-f986016465a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">16.06.2025-22.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
428	2025-06-06 10:55:12.589328+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
429	2025-06-06 10:58:01.39518+00	f68b9664-d014-4676-948d-52498a46ca27	Эктоин (AA) : примеси аминокислот - Sykam 433	2	[]	19	5
430	2025-06-06 11:26:31.603286+00	37bdfb2c-3a5b-400e-8cfd-86bc61065487	Arg(OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	control_enter	isopenregistration
8	control_enter	openwindowforordering
9	control_enter	workingdayofweek
10	control_enter	workerweekstatus
11	basic_elements	adminstrator
12	basic_elements	analyzetype
13	basic_elements	equipment
14	basic_elements	executor
15	basic_elements	project
16	basic_elements	analyze
17	dependings	projectperanalyze
18	dependings	operatorperequipment
19	dependings	analyzeperequipment
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-05-04 13:09:22.218307+00
2	auth	0001_initial	2025-05-04 13:09:22.294852+00
3	admin	0001_initial	2025-05-04 13:09:22.317887+00
4	admin	0002_logentry_remove_auto_add	2025-05-04 13:09:22.326587+00
5	admin	0003_logentry_add_action_flag_choices	2025-05-04 13:09:22.336136+00
6	contenttypes	0002_remove_content_type_name	2025-05-04 13:09:22.355764+00
7	auth	0002_alter_permission_name_max_length	2025-05-04 13:09:22.365036+00
8	auth	0003_alter_user_email_max_length	2025-05-04 13:09:22.374598+00
9	auth	0004_alter_user_username_opts	2025-05-04 13:09:22.383618+00
10	auth	0005_alter_user_last_login_null	2025-05-04 13:09:22.392945+00
11	auth	0006_require_contenttypes_0002	2025-05-04 13:09:22.396723+00
12	auth	0007_alter_validators_add_error_messages	2025-05-04 13:09:22.405139+00
13	auth	0008_alter_user_username_max_length	2025-05-04 13:09:22.41788+00
14	auth	0009_alter_user_last_name_max_length	2025-05-04 13:09:22.428837+00
15	auth	0010_alter_group_name_max_length	2025-05-04 13:09:22.438618+00
16	auth	0011_update_proxy_permissions	2025-05-04 13:09:22.446236+00
17	auth	0012_alter_user_first_name_max_length	2025-05-04 13:09:22.454814+00
18	basic_elements	0001_initial	2025-05-04 13:09:22.503912+00
19	control_enter	0001_initial	2025-05-04 13:09:22.529558+00
20	dependings	0001_initial	2025-05-04 13:09:22.576243+00
21	sessions	0001_initial	2025-05-04 13:09:22.5918+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
6npeooml8v3ca1l8mo7alziwl30wbqwo	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uNW4k:1iK1GTO3EiOjd_5IR2lm6U4wyv0mWt-wf98ENlImyjM	2025-06-20 12:21:34.203152+00
it4hk3h5rc1fr5d2wpoux5h4zt4qy3cx	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uBZ6W:ioOvhYDSdOCVC0LjGJVZiLhG2qrYZSazdqfbhv7-mkU	2025-05-18 13:10:00.829549+00
xl1oyxnjwi5l68a9hzl6pn2z9dzdly93	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uBZAR:FHliexhUkEdV83AvyAS0HafIUBhKPbAMVhnDu1HFV1Q	2025-05-18 13:14:03.831569+00
oer3eoklsaendoc9pdvyyedz1fpvvrw2	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uH5B0:JqlO1KT7wIsHtTiqzgrQquK1oKXiHMe02wYTz11jQAY	2025-06-02 18:25:26.769676+00
nfm154oqvgr679pujnq1lher73ujou9g	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uN7Xb:5ghAbFyz9DTaX3HVUjx9nNPtTCkbMVs76e7vf0qYXmg	2025-06-19 10:09:43.924189+00
3m7h43sow0by2qfxd2sha9g7buz2qu9m	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uH5Ba:J7Ds3KVo1D_uxvq6uRSy13qk3-gHixdgZs59CtKp13c	2025-06-02 18:26:02.79454+00
c5w5hdydv8kgjsjtpwn2c0v3sa6h1zvn	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uH5F3:l0bh_G_qI6KPC2bLiuD_FINtmmgpeRfUhd_1T380CFI	2025-06-02 18:29:37.445585+00
qudjyfehfsd0ic2cx8v7zcwc3cl2m08w	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uHk7H:oAUKE7ZCYnrhJow9yNVfs8z9SEg8h_kLRJOc3QliELs	2025-06-04 14:08:19.026862+00
u7acvwgpzhn96fe8omepcynxjqrdc2xz	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uN7gx:iDWzuVPU86CqNMiDsxP7U7LnB8UteMt07IiRZXmAFTE	2025-06-19 10:19:23.111221+00
az1jrvhjzsf88yrz9saj8bms3vdcawy3	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uN8cX:ULyZ_xZOVsbdTLwM2ihfRUC3y-9sciBXs1OQGqiu9kg	2025-06-19 11:18:53.738167+00
qh1wb9sxwxkyxphf254y9siqn9cowy2h	.eJxVjEEOwiAQRe_C2hDamQ7g0n3PQIAZpWpoUtqV8e7apAvd_vfef6kQt7WErckSJlZnher0u6WYH1J3wPdYb7POc12XKeld0QdtepxZnpfD_TsosZVv7Xw0QGQsgUVB28Eg8WoTseM-9eLAY5bBezDojaB0xrkEhMSZk4h6fwC63zdd:1uN94I:HfqB1Q7CC4ihA0FpO9yV1JMC76kJAMY_xsLUuwqVFic	2025-06-19 11:47:34.813946+00
6lt0g7f0yiozmz4t87xgixrestrfsxmo	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNUI0:1olbKDpl22W1nZUcO2t0dLhK4linYJmQXgHyrYLPjkM	2025-06-20 10:27:08.775685+00
oenzjsr869bc9g18txl4scnne7d21hm2	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uI5MW:mDV5MBoxJtUT94HVsSHoaU7SN8N58twrNMbKe0_3em4	2025-06-05 12:49:28.015476+00
4a5rdxg3lzoloyzy94iw5wxd73hnjyjw	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNULh:dWWF_YtvMdF_ytvJ4Huc4FrHQFnbzh3Lcd0d4xKzpkY	2025-06-20 10:30:57.818447+00
lkliuwp05s0k8md6hpxz88hbauecxhwv	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0Yh:LMOy1p4ugkOv-iDi7uM6y8I0DgjTtb5--z4LMzuFKgQ	2025-06-13 14:18:07.063964+00
pbntt1ev0mr7mtuuvuzkmmrp12s9oqbc	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0b1:eXPhEadfP5c7V5pHevR4i4ogRi9LhTBlBsQwzQxB9ZI	2025-06-13 14:20:31.871325+00
gx9mk4dtlixf0i54afc4rdhd63ya0cgw	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0ch:iguW7JlQY_QV4Zeu3IgbEEdjII620kcoSqqASw5rP7A	2025-06-13 14:22:15.52872+00
2wx3bf1xi3ha1terfdof3mfmra9mc4qi	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uL0do:9gnaqGIqf3iYjggl5e6JQ5DaYHb6YKfqHC3jprx0AXQ	2025-06-13 14:23:24.132064+00
a1tci9i8zmk8m2e7ljrj3jn6f9owiapc	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uM9rb:1NpzAWZVc-wxWgTUVJRE9PycuppovA6McvRD0jG_1js	2025-06-16 18:26:23.76349+00
s9e8jtfay0uzaze96wrni4se95roufy0	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNUso:2X3ldefd0w-lyNCGfFvirfQ-V5UfNw59WFm7GkxLFJs	2025-06-20 11:05:10.992219+00
x87954npr9pyvvzqm4pubxbf94b2cno0	.eJxVjEEOwiAQRe_C2hDamQ7g0n3PQIAZpWpoUtqV8e7apAvd_vfef6kQt7WErckSJlZnher0u6WYH1J3wPdYb7POc12XKeld0QdtepxZnpfD_TsosZVv7Xw0QGQsgUVB28Eg8WoTseM-9eLAY5bBezDojaB0xrkEhMSZk4h6fwC63zdd:1uMoH5:0vZGxBeP5O_VFF5Ke-n-R2hZkEyBVV9zPNAXdIUVSt8	2025-06-18 13:35:23.730297+00
2239o245g152tneaejjvmxfigo3q6jg8	.eJxVjDEOwyAQBP9CHSHuDAZSpvcb0AHn4CTCkrGrKH-PLblImi12ZvctAm1rCVvjJUxZXIUWl98uUnpyPUB-UL3PMs11XaYoD0WetMlhzvy6ne7fQaFW9nV0jtUewG5M1viEgBhjBE8aFWNnNZhMNoE1mMkDGM_Yj9z1lEhl8fkC3Ik3xw:1uNV2Z:uk0oJYg2MSvx8TDvI9BoUdvgbcpnPO3GHS9HA4Co1mI	2025-06-20 11:15:15.549904+00
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.equipment (id, created, modified, name, status, count_samples) FROM stdin;
322bde1c-c844-44d7-8846-a773b9f97679	2025-05-20 12:06:13.703596+00	2025-05-29 13:39:27.289374+00	Waters Alliance New	active  10
1de040d3-f437-4e55-a77c-c71c38fe0384	2025-05-20 12:05:59.679623+00	2025-05-29 13:40:15.059612+00	Sykam 433	active  10
e028e32c-581f-4b39-92ae-9a81552b7862	2025-05-29 13:41:39.412583+00	2025-05-29 13:41:39.412598+00	Waters Alliance Old	active  10
54e28c12-acd4-4c69-a0a6-815a77c4e895	2025-05-29 13:48:21.787475+00	2025-05-29 13:48:21.78749+00	Hitachi 8900	active  10
27dc31dd-0a11-452e-ac1e-aeb052f18226	2025-05-29 13:51:03.591829+00	2025-05-29 13:51:03.591843+00	Agilent 7100 CE	active  10
612b7c5b-61b6-4795-8d07-98bc92bc4c51	2025-05-29 13:52:14.690109+00	2025-05-29 13:52:14.690123+00	Methrohm	active  10
4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	2025-05-29 13:41:01.554771+00	2025-05-29 13:52:42.206641+00	Agilent 1260	active  10
a9bce02e-43b3-44bd-b9dc-0479fe49bd09	2025-05-29 13:53:25.556093+00	2025-05-29 13:53:25.556108+00	Dionex ICS 5000	active  10
0c0b62b6-c1b4-4828-8c87-b90396e2288d	2025-05-29 13:53:45.364815+00	2025-05-29 13:53:45.36483+00	Dionex ICS 5000 2	active  10
370b51e9-685c-4a6d-bcc5-67bed5d29f48	2025-05-29 13:57:51.863351+00	2025-05-29 13:57:51.863364+00	Aracus	active  10
555a86cd-0550-42d7-b085-92842c89ee90	2025-05-29 13:59:29.333815+00	2025-05-29 13:59:29.333829+00	Shimadzu 4	active  10
5bbfe0ce-1c24-443b-8849-834ef90203d3	2025-05-29 13:59:55.45934+00	2025-05-29 13:59:55.459354+00	Shimadzu 5	active  10
17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	2025-05-29 14:00:14.280359+00	2025-05-29 14:00:14.28038+00	Shimadzu 7	active  10
4b3bb52f-df8d-421c-893e-37052e982bcb	2025-05-29 14:01:02.408082+00	2025-05-29 14:01:02.408098+00	Shimadzu 30	active  10
a8222354-63a4-4c12-b4ee-00ff34788fa1	2025-05-29 14:01:24.562526+00	2025-05-29 14:01:24.56254+00	Shimadzu GC 2010	active  10
ef5851f3-9428-411b-a8e0-77086b2e9d90	2025-05-29 14:01:51.577863+00	2025-05-29 14:01:51.577876+00	Shimadzu GC 2014    active
1fb0d24b-975e-4366-b981-ae320ff1265a	2025-05-29 14:03:05.049354+00	2025-05-29 14:03:05.049368+00	Waters  LC-MS/MS Acquity	active  10
60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	2025-05-29 14:04:05.785524+00	2025-05-29 14:04:05.785562+00	Shimadzu LC-MS 8050	active  10
db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	2025-05-29 13:49:02.220003+00	2025-05-29 14:08:26.399335+00	Shimadzu 6	active  10
fb09a7e8-8696-45ab-abc4-baa9e1440da5	2025-05-29 13:37:29.219566+00	2025-05-29 14:08:37.361347+00	Shimadzu 3	active  10
8bfe7234-ce4a-487c-8728-82b5f1956a71	2025-05-04 13:11:58.697763+00	2025-05-29 14:17:02.096172+00	Agilent 1100	active  10
\.


--
-- Data for Name: executor; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.executor (id, created, modified, first_name, last_name, patronymic) FROM stdin;
86bea85e-a62d-4dc0-8c0b-30541fd7782c	2025-05-28 14:39:15.361961+00	2025-05-28 14:39:15.361975+00	Борзенко	Татьяна	Сергеевна
f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	2025-05-28 14:39:51.190658+00	2025-05-28 14:39:51.190676+00	Акжигитова	Дарья	Павловна
09d8307c-2256-4f71-94e1-958c21e6f1bc	2025-05-28 14:40:19.396053+00	2025-05-28 14:40:19.396067+00	Новикова	Анна	Евгеньевна
1a5902da-bf12-4f7e-b055-775956f6adda	2025-05-28 14:40:59.662473+00	2025-05-28 14:40:59.662487+00	Санто	Леонид	Павлович
8afa309b-cec8-4aaa-9031-06fe2b8267bf	2025-05-28 14:41:27.425895+00	2025-05-28 14:41:27.425909+00	Киверо	Александр	Дмитриевич
ad7a9a32-69c3-46c0-b5b9-80f11dc55797	2025-05-28 14:42:32.353012+00	2025-05-28 14:42:32.353026+00	Варламова	Дарья	Олеговна
58c12ab6-e451-48b5-917e-26fc1855847a	2025-05-28 14:42:59.554037+00	2025-05-28 14:42:59.554067+00	Федоров	Антон	Сергеевич
1e4fa050-70ba-4031-9201-31d8cbd60b9a	2025-05-28 14:43:27.471935+00	2025-05-28 14:43:27.471948+00	Федорова	Елизавета	Николаевна
d36c9e4f-2406-492b-b467-de7884e9a2e6	2025-05-29 14:20:22.926911+00	2025-05-29 14:20:22.926927+00	Сёменов	Егор	Александрович
\.


--
-- Data for Name: feedback_task; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.feedback_task (booking_id, question_1, question_2, question_3) FROM stdin;
5	t	t	t
7	f	f	f
9	t	t	t
6	t	t	t
3	t	f	f
11	f	t	t
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.project (id, created, modified, project_nick, project_name, is_priority, responsible_person, project_password) FROM stdin;
cdf23166-345a-4084-8437-92c51adbbe78	2025-06-05 10:18:06.143127+00	2025-06-06 08:37:19.865587+00	GeraskinaN1	Эктоин	f	Гераскина	GeraskinaN1
1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-05-21 14:46:50.712272+00	2025-06-06 08:38:27.112109+00	KiryukhinM1	Arginine	f	Кирюхин	KiryukhinM1
17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-04 13:12:51.611859+00	2025-06-06 08:40:20.230588+00	ZiyatdinovM1	Methionine	f	Зиятдинов	ZiyatdinovM1
\.


--
-- Data for Name: projects_booking; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.projects_booking (id, project_id, date_booking, analyse_id, equipment_id, executor_id, count_analyses, status, is_delete, comment) FROM stdin;
2	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-06	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	25	На рассмотрении	f	
16	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Оценить	f	
4	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	5	На рассмотрении	t	
15	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-26	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Оценить	f	
10	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-26	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	12	Оценить	f	
1	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-19	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	25	Принято	t	Test
18	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	2	На рассмотрении	t	
19	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	f	
22	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-11	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
7	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	
23	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	8	На рассмотрении	f	
8	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-22	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	На рассмотрении	t	
17	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	10	Принято	t	
25	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	f	
26	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-10	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	f	
27	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-11	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c	2	На рассмотрении	f	
28	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	f	
3	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	комменат
6	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	10	Выполнено	t	
9	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	10	Выполнено	t	Изменено кол-во
5	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	
12	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-29	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	5	На рассмотрении	t	
29	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-10	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	f	
30	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-09	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	f	
31	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
21	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
11	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	3	Выполнено	t	Изменено кол-во образцов
14	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-29	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	12	На рассмотрении	f	
13	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-28	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Отклонено	f	
32	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
24	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
20	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
33	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	f	
\.


--
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: Admin_agri
--

SELECT pg_catalog.setval('cron.jobid_seq', 33, true);


--
-- Name: runid_seq; Type: SEQUENCE SET; Schema: cron; Owner: Admin_agri
--

SELECT pg_catalog.setval('cron.runid_seq', 33, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 8, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: block_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.block_booking_id_seq', 73, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 430, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- Name: projects_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.projects_booking_id_seq', 33, true);


--
-- Name: adminstrator adminstrator_admin_nick_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.adminstrator
    ADD CONSTRAINT adminstrator_admin_nick_key UNIQUE (admin_nick);


--
-- Name: adminstrator adminstrator_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.adminstrator
    ADD CONSTRAINT adminstrator_pkey PRIMARY KEY (id);


--
-- Name: analyze analyze_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public."analyze"
    ADD CONSTRAINT analyze_pkey PRIMARY KEY (id);


--
-- Name: analyze_type analyze_type_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.analyze_type
    ADD CONSTRAINT analyze_type_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: block_booking block_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.block_booking
    ADD CONSTRAINT block_booking_id PRIMARY KEY (id);


--
-- Name: control_enter_isopenregistration control_enter_isopenregistration_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_isopenregistration
    ADD CONSTRAINT control_enter_isopenregistration_pkey PRIMARY KEY (id);


--
-- Name: control_enter_openwindowforordering control_enter_openwindowforordering_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_openwindowforordering
    ADD CONSTRAINT control_enter_openwindowforordering_pkey PRIMARY KEY (id);


--
-- Name: control_enter_workerweekstatus control_enter_workerweekstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workerweekstatus
    ADD CONSTRAINT control_enter_workerweekstatus_pkey PRIMARY KEY (id);


--
-- Name: control_enter_workingdayofweek control_enter_workingdayofweek_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workingdayofweek
    ADD CONSTRAINT control_enter_workingdayofweek_pkey PRIMARY KEY (id);


--
-- Name: dependings_analyzeperequipment dependings_analyzeperequipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzeperequipment_pkey PRIMARY KEY (id);


--
-- Name: dependings_operatorperequipment dependings_operatorperequipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorperequipment_pkey PRIMARY KEY (id);


--
-- Name: dependings_projectperanalyze dependings_projectperanalyze_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectperanalyze_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: executor executor_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.executor
    ADD CONSTRAINT executor_pkey PRIMARY KEY (id);


--
-- Name: feedback_task feedback_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.feedback_task
    ADD CONSTRAINT feedback_booking_id PRIMARY KEY (booking_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project project_project_name_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_name_key UNIQUE (project_name);


--
-- Name: project project_project_nick_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_nick_key UNIQUE (project_nick);


--
-- Name: projects_booking projects_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.projects_booking
    ADD CONSTRAINT projects_booking_id PRIMARY KEY (id);


--
-- Name: adminstrator_admin_nick_50ea001f_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX adminstrator_admin_nick_50ea001f_like ON public.adminstrator USING btree (admin_nick varchar_pattern_ops);


--
-- Name: analyze_analyze_type_id_013e3c35; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX analyze_analyze_type_id_013e3c35 ON public."analyze" USING btree (analyze_type_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: control_enter_workerweekstatus_executor_id_0aece764; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX control_enter_workerweekstatus_executor_id_0aece764 ON public.control_enter_workerweekstatus USING btree (executor_id);


--
-- Name: dependings_analyzeperequipment_analazy_id_3bd0713e; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_analyzeperequipment_analazy_id_3bd0713e ON public.dependings_analyzeperequipment USING btree (analazy_id);


--
-- Name: dependings_analyzeperequipment_equipment_name_id_5149a1e7; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_analyzeperequipment_equipment_name_id_5149a1e7 ON public.dependings_analyzeperequipment USING btree (equipment_name_id);


--
-- Name: dependings_operatorperequipment_equipment_id_94f2408d; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_operatorperequipment_equipment_id_94f2408d ON public.dependings_operatorperequipment USING btree (equipment_id);


--
-- Name: dependings_operatorperequipment_operator_id_6b4f14ed; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_operatorperequipment_operator_id_6b4f14ed ON public.dependings_operatorperequipment USING btree (operator_id);


--
-- Name: dependings_projectperanalyze_analazy_n_id_9d2b088b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_projectperanalyze_analazy_n_id_9d2b088b ON public.dependings_projectperanalyze USING btree (analazy_n_id);


--
-- Name: dependings_projectperanalyze_project_n_id_810d1380; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_projectperanalyze_project_n_id_810d1380 ON public.dependings_projectperanalyze USING btree (project_n_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: project_project_name_b03a06d9_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX project_project_name_b03a06d9_like ON public.project USING btree (project_name varchar_pattern_ops);


--
-- Name: project_project_nick_fd1db1e5_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX project_project_nick_fd1db1e5_like ON public.project USING btree (project_nick varchar_pattern_ops);


--
-- Name: analyze analyze_analyze_type_id_013e3c35_fk_analyze_type_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public."analyze"
    ADD CONSTRAINT analyze_analyze_type_id_013e3c35_fk_analyze_type_id FOREIGN KEY (analyze_type_id) REFERENCES public.analyze_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: control_enter_workerweekstatus control_enter_worker_executor_id_0aece764_fk_executor_; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workerweekstatus
    ADD CONSTRAINT control_enter_worker_executor_id_0aece764_fk_executor_ FOREIGN KEY (executor_id) REFERENCES public.executor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_analyzeperequipment dependings_analyzepe_analazy_id_3bd0713e_fk_analyze_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzepe_analazy_id_3bd0713e_fk_analyze_i FOREIGN KEY (analazy_id) REFERENCES public."analyze"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_analyzeperequipment dependings_analyzepe_equipment_name_id_5149a1e7_fk_equipment; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzepe_equipment_name_id_5149a1e7_fk_equipment FOREIGN KEY (equipment_name_id) REFERENCES public.equipment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_operatorperequipment dependings_operatorp_equipment_id_94f2408d_fk_equipment; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorp_equipment_id_94f2408d_fk_equipment FOREIGN KEY (equipment_id) REFERENCES public.equipment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_operatorperequipment dependings_operatorp_operator_id_6b4f14ed_fk_executor_; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorp_operator_id_6b4f14ed_fk_executor_ FOREIGN KEY (operator_id) REFERENCES public.executor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_projectperanalyze dependings_projectpe_analazy_n_id_9d2b088b_fk_analyze_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectpe_analazy_n_id_9d2b088b_fk_analyze_i FOREIGN KEY (analazy_n_id) REFERENCES public."analyze"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_projectperanalyze dependings_projectpe_project_n_id_810d1380_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectpe_project_n_id_810d1380_fk_project_i FOREIGN KEY (project_n_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

