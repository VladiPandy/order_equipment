--
-- PostgreSQL database dump
--

\restrict H2fzeCoPeGmSZhXi7oR5TSP6DRuM8B3Z7RqWVGebFKENmHupsYm3mzKRiMDGSCZ

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: create_weekly_worker_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.create_weekly_worker_status() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    start_date DATE;
    end_date DATE;
    executor RECORD;
    current_week_period VARCHAR(50);  -- Переименованная переменная
BEGIN
    -- Определяем начало и конец недели через две недели от текущей даты
    start_date := date_trunc('week', CURRENT_DATE + INTERVAL '2 weeks');
    end_date := start_date + INTERVAL '6 days';
    -- Форматируем даты в строку для хранения в week_period
    current_week_period := to_char(start_date, 'DD.MM.YYYY') || '-' || to_char(end_date, 'DD.MM.YYYY');
    -- Проверяем, существуют ли записи на текущую неделю
    IF NOT EXISTS (
        SELECT 1
        FROM public.control_enter_workerweekstatus
        WHERE week_period = current_week_period
    ) THEN
        FOR executor IN SELECT id FROM public.executor LOOP
            INSERT INTO public.control_enter_workerweekstatus (
                id,
                created,
                modified,
                week_period,
                period_start,
                monday,
                tuesday,
                wednesday,
                thursday,
                friday,
                saturday,
                sunday,
                limit_executor,
                executor_id
            ) VALUES (
                uuid_generate_v4(),
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP,
                current_week_period,  -- Используем переименованную переменную
                start_date,
                'Работает',  -- Пример статуса для понедельника
                'Работает',  -- Пример статуса для вторника
                'Работает',  -- Пример статуса для среды
                'Работает',  -- Пример статуса для четверга
                'Выходной',  -- Пример статуса для пятницы
                'Выходной',  -- Пример статуса для субботы
                'Выходной',  -- Пример статуса для воскресенья
                2,  -- Пример лимита исполнителей
                executor.id
            );
        END LOOP;
        RAISE NOTICE 'Созданы записи для недели с % до %', start_date, end_date;
    ELSE
        RAISE NOTICE 'Записи уже существуют для недели с % до %', start_date, end_date;
    END IF;
END;
$$;


ALTER FUNCTION public.create_weekly_worker_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION create_weekly_worker_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.create_weekly_worker_status() IS 'Создает записи в таблице control_enter_workerweekstatus для недели через две недели от текущей даты, если они отсутствуют.';


--
-- Name: create_weekly_working_day_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.create_weekly_working_day_status() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    start_date DATE;
    end_date DATE;
    current_week_period VARCHAR(50);
BEGIN
    -- Определяем начало и конец недели через две недели от текущей даты
    start_date := date_trunc('week', CURRENT_DATE + INTERVAL '2 weeks');
    end_date := start_date + INTERVAL '6 days';
    -- Форматируем даты в строку для хранения в week_period
    current_week_period := to_char(start_date, 'DD.MM.YYYY') || '-' || to_char(end_date, 'DD.MM.YYYY');
    -- Проверяем, существуют ли записи на текущую неделю
    IF NOT EXISTS (
        SELECT 1
        FROM public.control_enter_workingdayofweek
        WHERE week_period = current_week_period
    ) THEN
        -- Если записей нет, создаем новую запись
        INSERT INTO public.control_enter_workingdayofweek (
            id,
            created,
            modified,
            week_period,
            period_start,
            monday,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday
        ) VALUES (
            uuid_generate_v4(),  -- Генерация нового UUID
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP,
            current_week_period,  -- Используем переименованную переменную
            start_date,
            TRUE,  -- Пример статуса для понедельника
            TRUE,  -- Пример статуса для вторника
            TRUE,  -- Пример статуса для среды
            TRUE,  -- Пример статуса для четверга
            FALSE,  -- Пример статуса для пятницы
          FALSE,  -- Пример статуса для субботы
            FALSE   -- Пример статуса для воскресенья
        );
        RAISE NOTICE 'Создана запись для недели с % до %', start_date, end_date;
    ELSE
        RAISE NOTICE 'Запись уже существует для недели с % до %', start_date, end_date;
    END IF;
END;
$$;


ALTER FUNCTION public.create_weekly_working_day_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION create_weekly_working_day_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.create_weekly_working_day_status() IS 'Создает записи в таблице control_enter_workingdayofweek для недели через две недели от текущей даты, если они отсутствуют.';


--
-- Name: update_booking_status(); Type: FUNCTION; Schema: public; Owner: Admin_agri
--

CREATE FUNCTION public.update_booking_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    updated_count integer;
BEGIN
    UPDATE public.projects_booking
    SET status = 'Оценить'
    WHERE status = 'Принято'
    AND is_delete = false
    AND date_booking < (now()::date - interval '24 hours');
    GET DIAGNOSTICS updated_count = ROW_COUNT;
    RAISE NOTICE 'Обновлено % записей', updated_count;
    RETURN updated_count;
END;
$$;


ALTER FUNCTION public.update_booking_status() OWNER TO "Admin_agri";

--
-- Name: FUNCTION update_booking_status(); Type: COMMENT; Schema: public; Owner: Admin_agri
--

COMMENT ON FUNCTION public.update_booking_status() IS 'Обновляет статус бронирования с "Согласовано" на "Оценить" для записей текущего дня';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adminstrator; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.adminstrator (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    admin_nick character varying(255) NOT NULL,
    admin_person character varying(255) NOT NULL,
    admin_password character varying(128) NOT NULL,
    telegram_nick varchar(255) NULL
);


ALTER TABLE public.adminstrator OWNER TO "Admin_agri";

--
-- Name: analyze; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public."analyze" (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    analyze_name character varying(255) NOT NULL,
    analyze_type_id uuid NOT NULL
);


ALTER TABLE public."analyze" OWNER TO "Admin_agri";

--
-- Name: analyze_type; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.analyze_type (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE public.analyze_type OWNER TO "Admin_agri";

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "Admin_agri";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "Admin_agri";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "Admin_agri";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO "Admin_agri";

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO "Admin_agri";

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO "Admin_agri";

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: block_booking; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.block_booking (
    id integer NOT NULL,
    project_id uuid NOT NULL,
    booking_id integer,
    date_booking date,
    analyse_id uuid,
    equipment_id uuid,
    executor_id uuid,
    is_block boolean,
    write_timestamp timestamp without time zone DEFAULT now() NOT NULL,
    cookies_key uuid DEFAULT gen_random_uuid() NOT NULL,
    update_timestamp timestamp without time zone,
    id_delete boolean DEFAULT false
);


ALTER TABLE public.block_booking OWNER TO "Admin_agri";

--
-- Name: block_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.block_booking ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.block_booking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: control_enter_isopenregistration; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_isopenregistration (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    is_open boolean NOT NULL,
    week_period character varying(50) NOT NULL
);


ALTER TABLE public.control_enter_isopenregistration OWNER TO "Admin_agri";

--
-- Name: control_enter_openwindowforordering; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_openwindowforordering (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    start_date character varying(200) NOT NULL,
    start_time character varying(50) NOT NULL,
    end_time character varying(50) NOT NULL,
    for_priority boolean NOT NULL,
    week_period character varying(50) NOT NULL
);


ALTER TABLE public.control_enter_openwindowforordering OWNER TO "Admin_agri";

--
-- Name: control_enter_workerweekstatus; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_workerweekstatus (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    week_period character varying(50) NOT NULL,
    period_start date,
    monday character varying NOT NULL,
    tuesday character varying NOT NULL,
    wednesday character varying NOT NULL,
    thursday character varying NOT NULL,
    friday character varying NOT NULL,
    saturday character varying NOT NULL,
    sunday character varying NOT NULL,
    limit_executor integer NOT NULL,
    executor_id uuid NOT NULL
);


ALTER TABLE public.control_enter_workerweekstatus OWNER TO "Admin_agri";

--
-- Name: control_enter_workingdayofweek; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.control_enter_workingdayofweek (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    week_period character varying(50) NOT NULL,
    period_start date,
    monday boolean NOT NULL,
    tuesday boolean NOT NULL,
    wednesday boolean NOT NULL,
    thursday boolean NOT NULL,
    friday boolean NOT NULL,
    saturday boolean NOT NULL,
    sunday boolean NOT NULL
);


ALTER TABLE public.control_enter_workingdayofweek OWNER TO "Admin_agri";

--
-- Name: dependings_analyzeperequipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_analyzeperequipment (
    id uuid NOT NULL,
    count_samples integer NOT NULL,
    analazy_id uuid NOT NULL,
    equipment_name_id uuid NOT NULL
);


ALTER TABLE public.dependings_analyzeperequipment OWNER TO "Admin_agri";

--
-- Name: dependings_operatorperequipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_operatorperequipment (
    id uuid NOT NULL,
    is_priority boolean NOT NULL,
    equipment_id uuid NOT NULL,
    operator_id uuid NOT NULL
);


ALTER TABLE public.dependings_operatorperequipment OWNER TO "Admin_agri";
--
-- Name: dependings_executorperanalyze; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_executorperanalyze (
    id uuid NOT NULL,
	analazy_nt_id uuid NOT NULL,
	operator_nt_id uuid NOT NULL
);


ALTER TABLE public.dependings_executorperanalyze OWNER TO "Admin_agri";
--
-- Name: dependings_projectperanalyze; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.dependings_projectperanalyze (
    id uuid NOT NULL,
    limit_samples integer NOT NULL,
    analazy_n_id uuid NOT NULL,
    project_n_id uuid NOT NULL
);


ALTER TABLE public.dependings_projectperanalyze OWNER TO "Admin_agri";

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "Admin_agri";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "Admin_agri";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "Admin_agri";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "Admin_agri";

--
-- Name: equipment; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.equipment (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    count_samples integer NOT NULL
);


ALTER TABLE public.equipment OWNER TO "Admin_agri";

--
-- Name: executor; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.executor (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    patronymic character varying(255)
);


ALTER TABLE public.executor OWNER TO "Admin_agri";

--
-- Name: feedback_task; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.feedback_task (
    booking_id integer NOT NULL,
    question_1 boolean DEFAULT true NOT NULL,
    question_2 boolean DEFAULT true NOT NULL,
    question_3 boolean DEFAULT true NOT NULL
);


ALTER TABLE public.feedback_task OWNER TO "Admin_agri";

--
-- Name: project; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.project (
    id uuid NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    project_nick character varying(255) NOT NULL,
    project_name character varying(255) NOT NULL,
    is_priority boolean NOT NULL,
    responsible_person character varying(255) NOT NULL,
    project_password character varying(128) NOT NULL,
    telegram_nick varchar(255) NULL
);


ALTER TABLE public.project OWNER TO "Admin_agri";

--
-- Name: projects_booking; Type: TABLE; Schema: public; Owner: Admin_agri
--

CREATE TABLE public.projects_booking (
    id integer NOT NULL,
    project_id uuid NOT NULL,
    date_booking date NOT NULL,
    analyse_id uuid NOT NULL,
    equipment_id uuid NOT NULL,
    executor_id uuid NOT NULL,
    count_analyses integer NOT NULL,
    status character varying(254) NOT NULL,
    is_delete boolean,
    comment text
);


ALTER TABLE public.projects_booking OWNER TO "Admin_agri";

--
-- Name: projects_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: Admin_agri
--

ALTER TABLE public.projects_booking ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.projects_booking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: Admin_agri
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active, jobname) FROM stdin;
1	5 0 * * *	\r\n    SELECT public.update_booking_status();\r\n	localhost	5432	agri_db	Admin_agri	t	update_booking_status
2	0 0 * * 1	 SELECT public.create_weekly_worker_status(); 	localhost	5432	agri_db	Admin_agri	t	create_weekly_worker_status
3	10 0 * * 1	 SELECT public.create_weekly_working_day_status(); 	localhost	5432	agri_db	Admin_agri	t	create_weekly_working_day_status
\.


--
-- Data for Name: job_run_details; Type: TABLE DATA; Schema: cron; Owner: Admin_agri
--

COPY cron.job_run_details (jobid, runid, job_pid, database, username, command, status, return_message, start_time, end_time) FROM stdin;
1	28	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-03 00:05:00.000434+00	2025-06-03 00:05:00.075143+00
2	1	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-05-05 00:00:00.000583+00	2025-05-05 00:00:00.05478+00
3	18	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-05-26 00:10:00.000603+00	2025-05-26 00:10:00.047557+00
1	2	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-05 00:05:00.000313+00	2025-05-05 00:05:00.042704+00
3	3	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-05-05 00:10:00.0007+00	2025-05-05 00:10:00.044088+00
1	4	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-06 00:05:00.000861+00	2025-05-06 00:05:00.044802+00
1	19	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-27 00:05:00.001106+00	2025-05-27 00:05:00.047812+00
1	5	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-07 00:05:00.000954+00	2025-05-07 00:05:00.045749+00
1	6	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-08 00:05:00.000943+00	2025-05-08 00:05:00.044926+00
1	7	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-09 00:05:00.00093+00	2025-05-09 00:05:00.044152+00
1	20	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-28 00:05:00.000403+00	2025-05-28 00:05:00.046315+00
1	8	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-13 00:05:00.000112+00	2025-05-13 00:05:00.044449+00
1	9	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-14 00:05:00.000668+00	2025-05-14 00:05:00.075571+00
1	29	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-04 00:05:00.000433+00	2025-06-04 00:05:00.043999+00
1	10	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-20 00:05:00.000653+00	2025-05-20 00:05:00.104485+00
1	21	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-29 00:05:00.001282+00	2025-05-29 00:05:00.057013+00
1	11	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-21 00:42:25.685509+00	2025-05-21 00:42:25.69316+00
1	12	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-22 00:05:00.000473+00	2025-05-22 00:05:00.043925+00
1	13	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-23 00:05:00.001203+00	2025-05-23 00:05:00.044578+00
1	22	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-30 00:05:00.000375+00	2025-05-30 00:05:00.044643+00
1	14	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-24 00:05:00.001032+00	2025-05-24 00:05:00.007753+00
1	15	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-25 00:05:00.00111+00	2025-05-25 00:05:00.046281+00
2	16	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-05-26 00:00:00.001011+00	2025-05-26 00:00:00.045698+00
1	23	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-31 00:05:00.001198+00	2025-05-31 00:05:00.044531+00
1	17	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-05-26 00:05:00.00061+00	2025-05-26 00:05:00.043541+00
1	30	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-05 00:05:00.000928+00	2025-06-05 00:05:00.044634+00
1	24	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-01 00:05:00.000456+00	2025-06-01 00:05:00.04705+00
2	25	\N	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	failed	connection failed	2025-06-02 00:00:00.000551+00	2025-06-02 00:00:00.037847+00
1	26	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-02 00:05:00.000168+00	2025-06-02 00:05:00.04267+00
1	31	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-06 00:05:00.001356+00	2025-06-06 00:05:00.045299+00
3	27	\N	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	failed	connection failed	2025-06-02 00:10:00.001077+00	2025-06-02 00:10:00.044287+00
1	32	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-07 00:05:00.000787+00	2025-06-07 00:05:00.043764+00
1	33	\N	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	failed	connection failed	2025-06-08 00:05:00.001157+00	2025-06-08 00:05:00.04398+00
2	40	30157	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-06-16 00:00:00.045265+00	2025-06-16 00:00:00.053913+00
1	44	39137	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-18 00:05:00.049915+00	2025-06-18 00:05:00.053248+00
1	34	3262	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-10 00:05:00.056672+00	2025-06-10 00:05:00.071261+00
1	37	16779	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-13 00:05:00.047291+00	2025-06-13 00:05:00.051077+00
1	39	25703	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-15 00:05:00.030457+00	2025-06-15 00:05:00.052952+00
1	35	7854	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-11 00:05:00.046305+00	2025-06-11 00:05:00.050725+00
1	38	21242	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-14 00:05:00.046111+00	2025-06-14 00:05:00.049832+00
1	36	12316	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-12 00:05:00.046691+00	2025-06-12 00:05:00.050638+00
3	42	30189	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-06-16 00:10:00.043942+00	2025-06-16 00:10:00.04809+00
1	41	30173	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-16 00:05:00.051176+00	2025-06-16 00:05:00.053201+00
1	43	34675	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-17 00:05:00.008676+00	2025-06-17 00:05:00.013219+00
1	45	43601	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-19 00:05:00.044228+00	2025-06-19 00:05:00.05021+00
1	46	48066	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-20 00:05:00.006546+00	2025-06-20 00:05:00.008332+00
1	47	52540	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-21 00:05:00.045052+00	2025-06-21 00:05:00.051225+00
1	48	57002	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-22 00:05:00.044807+00	2025-06-22 00:05:00.046577+00
2	49	61455	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-06-23 00:00:00.005303+00	2025-06-23 00:00:00.012668+00
1	50	61471	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-23 00:05:00.04358+00	2025-06-23 00:05:00.045427+00
3	51	61487	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-06-23 00:10:00.043686+00	2025-06-23 00:10:00.046664+00
1	52	65945	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-24 00:05:00.044742+00	2025-06-24 00:05:00.052979+00
1	53	70692	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-25 00:05:00.046271+00	2025-06-25 00:05:00.056026+00
1	54	75154	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-26 00:05:00.009783+00	2025-06-26 00:05:00.021975+00
1	55	79617	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-27 00:05:00.044704+00	2025-06-27 00:05:00.054379+00
1	56	84081	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-28 00:05:00.045392+00	2025-06-28 00:05:00.048753+00
1	57	88544	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-29 00:05:00.00995+00	2025-06-29 00:05:00.012243+00
2	58	92997	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-06-30 00:00:00.075863+00	2025-06-30 00:00:00.08037+00
1	59	93013	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-06-30 00:05:00.04347+00	2025-06-30 00:05:00.046038+00
3	60	93029	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-06-30 00:10:00.043735+00	2025-06-30 00:10:00.046631+00
3	69	7555	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-07-14 00:10:00.008288+00	2025-07-14 00:10:00.014715+00
1	81	23391	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-24 00:05:00.007439+00	2025-07-24 00:05:00.012648+00
1	61	1418	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-08 00:05:00.0682+00	2025-07-08 00:05:00.073505+00
2	76	18635	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-07-21 00:00:00.045483+00	2025-07-21 00:00:00.05554+00
1	70	9136	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-15 00:05:00.008381+00	2025-07-15 00:05:00.013448+00
1	62	6818	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-09 00:05:00.049419+00	2025-07-09 00:05:00.056355+00
1	97	44616	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-05 00:05:00.044292+00	2025-08-05 00:05:00.051759+00
1	63	1039	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-10 00:05:00.075022+00	2025-07-10 00:05:00.082581+00
1	91	37207	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-01 00:05:00.045159+00	2025-08-01 00:05:00.056648+00
1	71	10719	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-16 00:05:00.050834+00	2025-07-16 00:05:00.057482+00
1	64	2772	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-11 00:05:00.054858+00	2025-07-11 00:05:00.060766+00
1	77	18641	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-21 00:05:00.043397+00	2025-07-21 00:05:00.045167+00
1	65	4376	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-12 00:05:00.047267+00	2025-07-12 00:05:00.052001+00
1	72	12303	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-17 00:05:00.045421+00	2025-07-17 00:05:00.052183+00
1	82	24973	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-25 00:05:00.046701+00	2025-07-25 00:05:00.051218+00
1	66	5959	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-13 00:05:00.046706+00	2025-07-13 00:05:00.051469+00
3	78	18647	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-07-21 00:10:00.044887+00	2025-07-21 00:10:00.048228+00
1	73	13886	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-18 00:05:00.04227+00	2025-07-18 00:05:00.045772+00
2	67	7543	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-07-14 00:00:00.045961+00	2025-07-14 00:00:00.074909+00
1	86	29728	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-28 00:05:00.043307+00	2025-07-28 00:05:00.045056+00
1	68	7549	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-14 00:05:00.010502+00	2025-07-14 00:05:00.015822+00
1	74	15469	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-19 00:05:00.046154+00	2025-07-19 00:05:00.050928+00
1	89	33031	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-30 00:05:00.044645+00	2025-07-30 00:05:00.054773+00
1	79	20225	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-22 00:05:00.044772+00	2025-07-22 00:05:00.049538+00
1	83	26556	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-26 00:05:00.043069+00	2025-07-26 00:05:00.047387+00
1	75	17051	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-20 00:05:00.009333+00	2025-07-20 00:05:00.015461+00
1	93	40538	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-03 00:05:00.045749+00	2025-08-03 00:05:00.051029+00
1	80	21808	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-23 00:05:00.012882+00	2025-07-23 00:05:00.017804+00
3	87	29734	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-07-28 00:10:00.007142+00	2025-07-28 00:10:00.01066+00
1	84	28138	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-27 00:05:00.045008+00	2025-07-27 00:05:00.049719+00
1	90	35242	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-31 00:05:00.044613+00	2025-07-31 00:05:00.054388+00
2	85	29722	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-07-28 00:00:00.007864+00	2025-07-28 00:00:00.02228+00
1	88	31448	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-07-29 00:05:00.043994+00	2025-07-29 00:05:00.055151+00
1	92	38956	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-02 00:05:00.045186+00	2025-08-02 00:05:00.052113+00
1	98	46588	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-06 00:05:00.010701+00	2025-08-06 00:05:00.021963+00
1	95	42128	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-04 00:05:00.044031+00	2025-08-04 00:05:00.046976+00
2	94	42122	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-08-04 00:00:00.045002+00	2025-08-04 00:00:00.066543+00
3	96	42134	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-08-04 00:10:00.006188+00	2025-08-04 00:10:00.010322+00
1	99	48556	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-07 00:05:00.04496+00	2025-08-07 00:05:00.056306+00
1	100	50540	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-08 00:05:00.009654+00	2025-08-08 00:05:00.018466+00
1	101	52232	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-09 00:05:00.045601+00	2025-08-09 00:05:00.059311+00
1	102	53815	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-10 00:05:00.04495+00	2025-08-10 00:05:00.053531+00
2	103	55399	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-08-11 00:00:00.045095+00	2025-08-11 00:00:00.072015+00
1	114	8835	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-19 00:05:00.043263+00	2025-08-19 00:05:00.047909+00
1	104	55405	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-11 00:05:00.044015+00	2025-08-11 00:05:00.046425+00
1	115	10315	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-20 00:05:00.045142+00	2025-08-20 00:05:00.050163+00
3	105	55411	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-08-11 00:10:00.043356+00	2025-08-11 00:10:00.04675+00
1	106	57042	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-12 00:05:00.009097+00	2025-08-12 00:05:00.018733+00
1	107	871	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-14 00:05:00.10006+00	2025-08-14 00:05:00.108852+00
1	108	2318	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-15 00:05:00.042204+00	2025-08-15 00:05:00.046951+00
1	109	4489	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-16 00:05:00.048813+00	2025-08-16 00:05:00.052681+00
1	110	5928	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-17 00:05:00.045586+00	2025-08-17 00:05:00.050279+00
2	111	7363	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-08-18 00:00:00.048427+00	2025-08-18 00:00:00.054137+00
1	112	7369	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-18 00:05:00.007902+00	2025-08-18 00:05:00.011548+00
3	113	7375	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-08-18 00:10:00.046305+00	2025-08-18 00:10:00.048179+00
2	145	5815	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-09-15 00:00:00.051656+00	2025-09-15 00:00:00.061062+00
1	124	27082	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-28 00:05:00.044112+00	2025-08-28 00:05:00.048369+00
1	116	1049	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-22 00:05:00.07353+00	2025-08-22 00:05:00.084893+00
1	136	71433	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-07 00:05:00.010297+00	2025-09-07 00:05:00.013942+00
1	131	49424	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-02 00:05:00.008775+00	2025-09-02 00:05:00.013404+00
1	117	5457	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-23 00:05:00.046306+00	2025-08-23 00:05:00.051197+00
1	125	31403	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-29 00:05:00.047185+00	2025-08-29 00:05:00.053717+00
1	118	9777	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-24 00:05:00.045396+00	2025-08-24 00:05:00.05032+00
1	140	80216	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-09 00:05:00.046157+00	2025-09-09 00:05:00.050824+00
1	126	36385	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-30 00:05:00.03171+00	2025-08-30 00:05:00.035747+00
2	119	14081	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-08-25 00:00:00.043816+00	2025-08-25 00:00:00.051375+00
1	132	54125	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-03 00:05:00.04448+00	2025-09-03 00:05:00.048818+00
1	120	14097	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-25 00:05:00.008308+00	2025-08-25 00:05:00.010524+00
1	127	40704	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-31 00:05:00.030972+00	2025-08-31 00:05:00.036504+00
3	121	14113	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-08-25 00:10:00.04434+00	2025-08-25 00:10:00.04829+00
1	143	2937	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-13 00:05:00.043777+00	2025-09-13 00:05:00.047399+00
2	137	75737	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-09-08 00:00:00.045423+00	2025-09-08 00:00:00.049614+00
1	122	18444	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-26 00:05:00.044258+00	2025-08-26 00:05:00.048832+00
2	128	45008	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-09-01 00:00:00.045276+00	2025-09-01 00:00:00.055034+00
1	133	58445	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-04 00:05:00.087441+00	2025-09-04 00:05:00.092975+00
1	123	22763	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-08-27 00:05:00.085867+00	2025-08-27 00:05:00.091462+00
3	147	5827	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-09-15 00:10:00.00695+00	2025-09-15 00:10:00.009465+00
1	129	45024	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-01 00:05:00.00977+00	2025-09-01 00:05:00.011669+00
1	141	84536	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-10 00:05:00.045972+00	2025-09-10 00:05:00.050826+00
1	134	62764	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-05 00:05:00.045651+00	2025-09-05 00:05:00.049926+00
3	130	45040	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-09-01 00:10:00.044022+00	2025-09-01 00:10:00.046902+00
1	138	75753	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-08 00:05:00.009848+00	2025-09-08 00:05:00.011645+00
1	135	67114	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-06 00:05:00.045603+00	2025-09-06 00:05:00.049712+00
1	144	4377	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-14 00:05:00.04453+00	2025-09-14 00:05:00.048962+00
3	139	75769	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-09-08 00:10:00.04393+00	2025-09-08 00:10:00.045822+00
1	142	1222	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-12 00:05:00.114118+00	2025-09-12 00:05:00.124262+00
1	146	5821	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-15 00:05:00.007286+00	2025-09-15 00:05:00.009047+00
1	151	11598	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-19 00:05:00.045739+00	2025-09-19 00:05:00.050254+00
1	148	7266	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-16 00:05:00.045663+00	2025-09-16 00:05:00.056085+00
1	149	8706	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-17 00:05:00.045198+00	2025-09-17 00:05:00.052134+00
1	150	10146	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-18 00:05:00.047019+00	2025-09-18 00:05:00.056807+00
1	152	13060	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-20 00:05:00.007909+00	2025-09-20 00:05:00.014831+00
1	153	14500	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-21 00:05:00.04099+00	2025-09-21 00:05:00.045476+00
2	154	15935	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-09-22 00:00:00.046767+00	2025-09-22 00:00:00.086068+00
1	155	15941	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-22 00:05:00.044941+00	2025-09-22 00:05:00.067442+00
3	156	15947	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-09-22 00:10:00.044645+00	2025-09-22 00:10:00.054442+00
1	157	17383	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-23 00:05:00.047001+00	2025-09-23 00:05:00.052468+00
1	158	18857	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-24 00:05:00.052196+00	2025-09-24 00:05:00.0679+00
1	159	20301	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-25 00:05:00.07637+00	2025-09-25 00:05:00.085708+00
1	160	21743	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-26 00:05:00.047566+00	2025-09-26 00:05:00.066055+00
1	161	23269	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-27 00:05:00.010066+00	2025-09-27 00:05:00.032411+00
1	162	24709	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-28 00:05:00.044793+00	2025-09-28 00:05:00.055057+00
2	163	26160	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-09-29 00:00:00.044287+00	2025-09-29 00:00:00.065632+00
1	164	26166	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-29 00:05:00.045059+00	2025-09-29 00:05:00.046772+00
3	165	26172	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-09-29 00:10:00.04409+00	2025-09-29 00:10:00.047145+00
1	182	59049	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-13 00:05:00.043828+00	2025-10-13 00:05:00.045902+00
1	175	31995	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-07 00:05:00.044545+00	2025-10-07 00:05:00.050597+00
1	166	387	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-09-30 00:05:00.055357+00	2025-09-30 00:05:00.068812+00
1	203	20582	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-29 00:05:00.046052+00	2025-10-29 00:05:00.069614+00
1	188	3687	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-18 00:05:00.047907+00	2025-10-18 00:05:00.071952+00
1	167	4931	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-01 00:05:00.04465+00	2025-10-01 00:05:00.051011+00
1	176	36595	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-08 00:05:00.044206+00	2025-10-08 00:05:00.052822+00
1	168	9419	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-02 00:05:00.044491+00	2025-10-02 00:05:00.049017+00
3	183	59065	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-10-13 00:10:00.04276+00	2025-10-13 00:10:00.045711+00
1	196	13075	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-24 00:05:00.051831+00	2025-10-24 00:05:00.074797+00
1	169	13907	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-03 00:05:00.010695+00	2025-10-03 00:05:00.01737+00
1	177	41079	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-09 00:05:00.046904+00	2025-10-09 00:05:00.068948+00
1	170	18391	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-04 00:05:00.044008+00	2025-10-04 00:05:00.047959+00
1	193	8036	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-21 00:05:00.046169+00	2025-10-21 00:05:00.066928+00
1	184	63533	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-14 00:05:00.044994+00	2025-10-14 00:05:00.056941+00
1	178	45562	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-10 00:05:00.044963+00	2025-10-10 00:05:00.052551+00
1	171	22874	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-05 00:05:00.044433+00	2025-10-05 00:05:00.048201+00
1	189	5127	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-19 00:05:00.044379+00	2025-10-19 00:05:00.065713+00
2	172	27347	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-10-06 00:00:00.072732+00	2025-10-06 00:00:00.08488+00
1	179	50077	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-11 00:05:00.055266+00	2025-10-11 00:05:00.072367+00
1	173	27363	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-06 00:05:00.044798+00	2025-10-06 00:05:00.050438+00
1	185	68022	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-15 00:05:00.008862+00	2025-10-15 00:05:00.022337+00
3	174	27379	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-10-06 00:10:00.044021+00	2025-10-06 00:10:00.052737+00
1	202	18944	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-28 00:05:00.044243+00	2025-10-28 00:05:00.066272+00
1	180	54561	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-12 00:05:00.009196+00	2025-10-12 00:05:00.018488+00
2	190	6561	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-10-20 00:00:00.015257+00	2025-10-20 00:00:00.05176+00
1	186	727	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-16 00:05:00.112139+00	2025-10-16 00:05:00.138736+00
2	181	59033	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-10-13 00:00:00.046543+00	2025-10-13 00:00:00.070828+00
2	199	17489	agri_db	Admin_agri	 SELECT public.create_weekly_worker_status(); 	succeeded	1 row	2025-10-27 00:00:00.046398+00	2025-10-27 00:00:00.074116+00
1	194	9659	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-22 00:05:00.044946+00	2025-10-22 00:05:00.067197+00
1	187	2167	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-17 00:05:00.045979+00	2025-10-17 00:05:00.070506+00
1	191	6567	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-20 00:05:00.04379+00	2025-10-20 00:05:00.04595+00
1	197	14614	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-25 00:05:00.045303+00	2025-10-25 00:05:00.069083+00
1	195	11595	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-23 00:05:00.045194+00	2025-10-23 00:05:00.067288+00
3	192	6573	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-10-20 00:10:00.044322+00	2025-10-20 00:10:00.049715+00
3	201	17501	agri_db	Admin_agri	 SELECT public.create_weekly_working_day_status(); 	succeeded	1 row	2025-10-27 00:10:00.043388+00	2025-10-27 00:10:00.046586+00
1	198	16054	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-26 00:05:00.009338+00	2025-10-26 00:05:00.023986+00
1	200	17495	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-27 00:05:00.043946+00	2025-10-27 00:05:00.045674+00
1	204	22305	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-30 00:05:00.047353+00	2025-10-30 00:05:00.075238+00
1	205	23827	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-10-31 00:05:00.044157+00	2025-10-31 00:05:00.066831+00
1	206	25404	agri_db	Admin_agri	\r\n    SELECT public.update_booking_status();\r\n	succeeded	1 row	2025-11-01 00:05:00.045514+00	2025-11-01 00:05:00.069137+00
\.


--
-- Data for Name: adminstrator; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.adminstrator (id, created, modified, admin_nick, admin_person, admin_password) FROM stdin;
837ada9a-9407-47ef-a0c0-aee56edb6160	2025-05-21 15:07:38.770053+00	2025-05-21 16:16:36.735029+00	Fedorova	Федорова Е.Н.	Admin0108
28aeaae9-88d4-43da-9f5f-663912f3461f	2025-05-21 16:19:00.939208+00	2025-05-21 16:19:00.939222+00	Kivero	Киверо А.Д.	Admin0407
b0e67ba7-ed16-448a-8c60-71768a7972bd	2025-05-04 13:10:26.033926+00	2025-05-21 16:19:42.5831+00	testadm	Admin Majour	wq123456
\.


--
-- Data for Name: analyze; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public."analyze" (id, created, modified, analyze_name, analyze_type_id) FROM stdin;
1b6870c5-c028-4f7d-b3a6-da026ec81032	2025-06-03 14:23:19.691058+00	2025-06-03 14:23:19.691081+00	Lauric acid	b16068e8-0fcf-47af-ba21-86213f92d426
601b7b77-ab12-477c-918e-ca3910a3bb96	2025-06-03 14:24:33.395743+00	2025-06-03 14:24:33.395757+00	Met (IA)	6b8c318d-699a-494c-b63f-44156f6a7a1d
3893f977-8f70-49be-903b-ed0149e4a505	2025-06-03 13:25:01.066012+00	2025-06-03 13:25:04.592899+00	DAP	b16068e8-0fcf-47af-ba21-86213f92d426
13649857-bdb6-4771-8105-8dc1fd503ac9	2025-06-03 14:00:36.946066+00	2025-06-03 14:00:36.946081+00	Ser(IA)	6b8c318d-699a-494c-b63f-44156f6a7a1d
1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	2025-06-03 14:03:10.046839+00	2025-06-03 14:03:10.046854+00	GSH,GC	b16068e8-0fcf-47af-ba21-86213f92d426
e40964e1-8934-428e-a06e-18379a30ebae	2025-06-03 13:31:28.139989+00	2025-08-06 11:17:00.146771+00	Ser(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
16ea24f6-2468-4895-9715-2edadc26b522	2025-06-03 14:14:21.853179+00	2025-08-07 13:05:39.56581+00	KSS_His (органический кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
00bc93e0-ef32-471d-aade-da29ce6a1660	2025-06-03 14:29:59.490074+00	2025-08-07 13:06:14.927817+00	Glu (примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
5902477d-a765-4934-a832-4fb9a01cf704	2025-07-31 15:56:01.486749+00	2025-07-31 15:56:01.486764+00	Arg(IA)	6b8c318d-699a-494c-b63f-44156f6a7a1d
e32c058b-38a7-4a49-a335-548da531c9b0	2025-06-03 14:18:43.060927+00	2025-08-06 11:17:22.455974+00	KSS_Ala-Gln (органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
fb54106f-3070-49c0-8a1e-24cdb1fc2d98	2025-06-03 14:07:44.49621+00	2025-08-04 10:29:39.815467+00	HxR(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
5dcb5b48-b6d3-44b4-9e49-9f8db410677d	2025-07-08 10:49:56.44757+00	2025-08-04 10:30:11.745654+00	Gr(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
c5484c5f-6ed9-4743-b796-b668e486b652	2025-08-04 10:31:03.418137+00	2025-08-04 10:31:03.418152+00	GAA2(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
cf00c1c2-3c4a-4783-bd78-577444bdf9c3	2025-06-03 14:27:59.783606+00	2025-08-06 11:17:51.472701+00	Gln (органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
8797874d-0abe-4021-89f4-f64cf3582f9f	2025-08-04 10:33:43.605174+00	2025-08-04 10:33:43.605188+00	HxR(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
1d7b838c-9f35-43e6-9cde-d63c11d9097f	2025-06-03 14:06:45.428883+00	2025-08-04 10:34:12.924232+00	Gr(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
b71923ee-67eb-4665-8b04-a71717ab9521	2025-08-04 10:34:44.369933+00	2025-08-04 10:34:44.369947+00	Gr(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
571c313e-8ec3-4777-bac7-40855117d510	2025-06-03 14:08:33.085988+00	2025-08-04 10:48:50.534381+00	HxR(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
b6387178-b0f0-4227-afae-44d21dc68b1e	2025-08-04 10:31:41.338927+00	2025-08-05 11:22:06.976647+00	GAA2(органические кислоты) ферментация	c3866711-d6e9-47b6-aa48-f976bb276685
2ae252e7-ff77-4445-9bba-4f12636a2234	2025-08-05 11:24:05.325159+00	2025-08-05 11:24:05.325173+00	GAA2(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	2025-06-03 14:06:05.372765+00	2025-08-06 11:11:34.825602+00	Gr(анализ сахаров)	04ffa9b6-2db9-496b-a154-c68bc55fcefd
fdc73d75-74c1-44e9-b276-2b748d35620b	2025-06-03 13:31:03.514559+00	2025-08-06 11:11:53.078808+00	Ser(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
f546d1c3-036a-47dd-8662-9b37a914408f	2025-06-03 13:54:03.307055+00	2025-08-06 11:14:24.121739+00	Cys(сульфоцистеин)	da3047ce-76fe-4d82-ba86-c121399b066e
f3f7fdcc-ca70-4429-8e87-69ce7118b14e	2025-06-03 14:23:47.699173+00	2025-08-06 11:14:45.478993+00	Met (органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
eecdd0f8-7244-4bf6-8f96-65622901a51d	2025-06-03 13:40:20.475451+00	2025-08-06 11:15:08.828405+00	Arg(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	2025-05-29 13:28:04.355701+00	2025-08-06 11:15:55.180588+00	Эктоин (основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
ca0a4632-47de-4590-b84b-5835604a02c6	2025-06-03 13:25:26.783173+00	2025-08-06 11:18:16.416325+00	DAP(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	2025-05-29 13:29:04.824051+00	2025-08-06 11:18:34.699357+00	Эктоин (органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	2025-06-03 14:23:33.390755+00	2025-08-06 11:19:00.196083+00	Met(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	2025-05-29 13:30:05.723067+00	2025-08-06 11:19:21.152956+00	Эктоин (примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
ace768c2-60a5-40f1-b745-63829f6b8d9f	2025-06-03 14:28:38.626011+00	2025-08-06 11:19:45.1745+00	Glu(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
a426aa21-8248-4fad-8ed2-f82aa388d1b5	2025-06-03 13:23:04.139516+00	2025-08-06 11:20:23.961894+00	Asn(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	2025-07-08 10:56:06.038791+00	2025-08-06 11:21:17.754689+00	g-EV(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
9056a26d-d6ce-41bf-b1c0-c255f6902d6e	2025-06-03 13:42:34.010068+00	2025-08-06 11:21:35.658073+00	a-AP(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
8cb45323-f121-47ad-969d-0ed9c2336674	2025-06-03 14:10:50.268844+00	2025-08-06 11:21:55.980523+00	HxR(анализ сахаров)	04ffa9b6-2db9-496b-a154-c68bc55fcefd
87e352df-7694-466a-a100-26aa80ff28e9	2025-07-08 10:52:22.327192+00	2025-08-06 11:22:29.137113+00	g-EV(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
7129f484-2524-4bc2-a857-7a4663b6abbb	2025-06-03 14:28:53.644272+00	2025-08-08 12:53:55.473742+00	GAA-3-II (органический кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
7b74a6a1-d92b-476a-befc-0783a20e9170	2025-06-03 14:22:35.924699+00	2025-08-06 11:23:13.964796+00	Amisoft(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
73129017-ac9d-4a55-9020-7192a2b3150a	2025-06-03 13:30:48.843806+00	2025-08-06 11:23:31.92998+00	Ser(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
563ae91e-3338-45f7-aead-c5a3c7a57f63	2025-06-03 13:07:47.499473+00	2025-08-06 11:24:24.38647+00	BCAA(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	2025-06-03 13:40:04.79744+00	2025-08-07 13:04:18.685248+00	Arg(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
020da433-e3a3-419c-851f-f52102a5fe00	2025-06-03 13:43:25.357101+00	2025-08-07 13:05:24.250238+00	Cys(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
7da0bd39-87ac-4b74-b152-236e519597e1	2025-06-03 13:42:15.409925+00	2025-08-07 13:37:30.921081+00	a-AP(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
9990d420-939a-48ce-b6ed-b4d9ef480bc5	2025-08-07 13:46:46.599298+00	2025-08-07 13:46:46.599312+00	EA(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
49334d2e-dc24-4efc-b25a-8054959b1fcb	2025-08-07 13:49:04.048516+00	2025-08-07 13:49:04.048532+00	EA( примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
bcb16827-828e-4e71-b66e-9ed61a8351b9	2025-08-07 13:07:00.073071+00	2025-08-08 12:54:54.061328+00	GAA-3-I (O)глюконат основной продукт	b16068e8-0fcf-47af-ba21-86213f92d426
699509be-9a62-464c-b04f-d42efbd2154d	2025-08-29 08:09:27.623488+00	2025-08-29 08:18:17.088043+00	Lipid ferm ( органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
f76acc0f-710d-4387-8731-dc6d8fd5782c	2025-08-29 08:08:03.455631+00	2025-08-29 08:18:27.54988+00	Lipid ferm (примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	2025-08-29 08:05:25.07192+00	2025-08-29 08:33:22.462899+00	Lipid ferm (основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
9d8f453b-f44b-4065-a5a3-e5566c20a6f6	2025-08-29 12:45:01.095517+00	2025-08-29 12:45:56.911292+00	Plasmid prod (органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
d6d31c42-7b07-4130-b0d0-fa87dde60a8f	2025-08-29 12:59:23.726072+00	2025-08-29 12:59:23.726086+00	Cys(тиосульфат)	6b8c318d-699a-494c-b63f-44156f6a7a1d
261aa121-300a-43d2-bfcf-b4d27630954c	2025-09-08 09:41:25.436192+00	2025-09-08 09:41:25.436205+00	Ser(Glukonic acid)	c3866711-d6e9-47b6-aa48-f976bb276685
488bedde-e9a3-4ab1-a96a-585818dde2d0	2025-09-12 08:29:07.195828+00	2025-09-12 08:29:07.195842+00	Amisoft(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
f2ad7950-00fc-457f-8d6b-aaced7e9e80e	2025-09-12 09:17:42.882919+00	2025-09-12 09:17:42.882933+00	ResearchGSH	ac428bf5-5e4c-417e-bb25-030383d899e9
d7b878e3-64f8-4627-b34c-b9acc1cae09e	2025-09-12 10:28:46.702434+00	2025-09-12 10:28:46.702448+00	TechnicalWork	61975783-69e9-48bd-80a3-a642a0cccf9b
f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	2025-06-03 14:27:47.492716+00	2025-10-21 15:06:49.374728+00	Gln(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
4e1fbb62-07ef-441b-a27b-1956581e9ca8	2025-06-03 13:24:11.144892+00	2025-10-21 15:04:06.10443+00	Asn(примеси аминокислот)	da3047ce-76fe-4d82-ba86-c121399b066e
62608399-2245-470d-a950-4eec08632518	2025-06-03 13:07:05.617193+00	2025-10-22 12:11:47.230416+00	BCAA(Ile основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
091e7bb0-f31d-4465-8e6f-130e5f83d454	2025-06-03 13:08:23.466872+00	2025-10-22 12:48:31.477603+00	BCAA(органические кислоты,2IPM,3IPM)	c3866711-d6e9-47b6-aa48-f976bb276685
1a901c9f-deb2-4451-a71b-4a059e561058	2025-06-03 14:21:50.397925+00	2025-10-28 08:44:08.927058+00	Amisoft(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
f70dda6c-3b1c-4248-bc15-93aefba973bb	2025-07-31 15:48:18.830674+00	2025-10-22 12:11:24.307263+00	BCAA(g-EV)	da3047ce-76fe-4d82-ba86-c121399b066e
0b6e2138-4fc5-4404-b584-6707d4890102	2025-06-04 13:33:15.62963+00	2025-10-28 14:08:29.595741+00	Arg(основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
2f016b91-0b94-4000-bb68-b6fd5be22a0e	2025-06-03 14:13:05.884122+00	2025-10-29 10:40:15.89677+00	KSS_Ala-Gln+AA	b16068e8-0fcf-47af-ba21-86213f92d426
1045bf64-4fb8-4c44-95c2-afe09bffa580	2025-08-04 10:32:14.394712+00	2025-10-31 13:47:58.167438+00	GAA2(цистин)	da3047ce-76fe-4d82-ba86-c121399b066e
6c07ef7d-b39c-4c57-8c2b-0758a52be082	2025-06-03 14:12:29.330981+00	2025-10-29 10:42:34.176717+00	KSS_His+AA	b16068e8-0fcf-47af-ba21-86213f92d426
4333e45c-09aa-4db5-95b7-82e3500c4376	2025-08-13 12:17:25.719141+00	2025-10-29 10:42:04.881675+00	KSS(His+AA)	b16068e8-0fcf-47af-ba21-86213f92d426
9fe01f07-a489-4eca-8639-403986129de1	2025-06-03 14:19:19.972779+00	2025-10-29 10:45:24.878832+00	KSS_Carnosine+AA	b16068e8-0fcf-47af-ba21-86213f92d426
eeca97d5-0cb8-4567-9ae5-d3e28c052f61	2025-06-03 13:53:26.880452+00	2025-10-31 13:49:28.548367+00	Cys(цистин)	da3047ce-76fe-4d82-ba86-c121399b066e
571cd566-5150-4b80-9221-233cd3d39b87	2025-06-03 13:23:44.867747+00	2025-10-21 15:04:23.156167+00	Asn (основной продукт)	b16068e8-0fcf-47af-ba21-86213f92d426
159bcfcd-ecf2-49f9-a33c-8f7f4c551260	2025-10-28 09:11:04.397465+00	2025-10-28 09:11:04.39748+00	RNA(органические кислоты)	c3866711-d6e9-47b6-aa48-f976bb276685
f59ee163-b076-4776-85b3-d0ba4c768838	2025-10-31 12:37:32.26081+00	2025-10-31 12:37:32.260824+00	PFP(AA)	da3047ce-76fe-4d82-ba86-c121399b066e
\.


--
-- Data for Name: analyze_type; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.analyze_type (id, created, modified, type) FROM stdin;
b16068e8-0fcf-47af-ba21-86213f92d426	2025-05-29 13:19:04.044114+00	2025-05-29 13:30:30.671328+00	основной продукт
c3866711-d6e9-47b6-aa48-f976bb276685	2025-05-20 11:58:33.389137+00	2025-05-29 13:30:55.497565+00	примеси органических кислот
da3047ce-76fe-4d82-ba86-c121399b066e	2025-05-21 15:08:36.658679+00	2025-05-29 13:31:31.499664+00	примеси аминокислот
6b8c318d-699a-494c-b63f-44156f6a7a1d	2025-06-03 14:00:05.819362+00	2025-06-03 14:00:05.819382+00	примеси неорганических анионов
04ffa9b6-2db9-496b-a154-c68bc55fcefd	2025-06-03 14:09:30.919859+00	2025-06-03 14:09:30.919874+00	анализ сахаров
ac428bf5-5e4c-417e-bb25-030383d899e9	2025-09-12 09:12:57.374653+00	2025-09-12 09:12:57.374667+00	Reaserch
61975783-69e9-48bd-80a3-a642a0cccf9b	2025-09-12 09:13:13.375494+00	2025-09-12 09:13:13.375507+00	Техн.работы
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add Статус открытой регистрации	7	add_isopenregistration
26	Can change Статус открытой регистрации	7	change_isopenregistration
27	Can delete Статус открытой регистрации	7	delete_isopenregistration
28	Can view Статус открытой регистрации	7	view_isopenregistration
29	Can add Окно для заказа	8	add_openwindowforordering
30	Can change Окно для заказа	8	change_openwindowforordering
31	Can delete Окно для заказа	8	delete_openwindowforordering
32	Can view Окно для заказа	8	view_openwindowforordering
33	Can add Рабочий день недели	9	add_workingdayofweek
34	Can change Рабочий день недели	9	change_workingdayofweek
35	Can delete Рабочий день недели	9	delete_workingdayofweek
36	Can view Рабочий день недели	9	view_workingdayofweek
37	Can add Рабочий график сотрудника	10	add_workerweekstatus
38	Can change Рабочий график сотрудника	10	change_workerweekstatus
39	Can delete Рабочий график сотрудника	10	delete_workerweekstatus
40	Can view Рабочий график сотрудника	10	view_workerweekstatus
41	Can add Администратор	11	add_adminstrator
42	Can change Администратор	11	change_adminstrator
43	Can delete Администратор	11	delete_adminstrator
44	Can view Администратор	11	view_adminstrator
45	Can add Тип анализа	12	add_analyzetype
46	Can change Тип анализа	12	change_analyzetype
47	Can delete Тип анализа	12	delete_analyzetype
48	Can view Тип анализа	12	view_analyzetype
49	Can add Прибор	13	add_equipment
50	Can change Прибор	13	change_equipment
51	Can delete Прибор	13	delete_equipment
52	Can view Прибор	13	view_equipment
53	Can add Исполнитель	14	add_executor
54	Can change Исполнитель	14	change_executor
55	Can delete Исполнитель	14	delete_executor
56	Can view Исполнитель	14	view_executor
57	Can add Проект	15	add_project
58	Can change Проект	15	change_project
59	Can delete Проект	15	delete_project
60	Can view Проект	15	view_project
61	Can add Анализ	16	add_analyze
62	Can change Анализ	16	change_analyze
63	Can delete Анализ	16	delete_analyze
64	Can view Анализ	16	view_analyze
65	Can add Проект Анализу	17	add_projectperanalyze
66	Can change Проект Анализу	17	change_projectperanalyze
67	Can delete Проект Анализу	17	delete_projectperanalyze
68	Can view Проект Анализу	17	view_projectperanalyze
69	Can add Оператор по оборудованию	18	add_operatorperequipment
70	Can change Оператор по оборудованию	18	change_operatorperequipment
71	Can delete Оператор по оборудованию	18	delete_operatorperequipment
72	Can view Оператор по оборудованию	18	view_operatorperequipment
73	Can add Анализы по оборудованию	19	add_analyzeperequipment
74	Can change Анализы по оборудованию	19	change_analyzeperequipment
75	Can delete Анализы по оборудованию	19	delete_analyzeperequipment
76	Can view Анализы по оборудованию	19	view_analyzeperequipment
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
2	pbkdf2_sha256$600000$YfwE6mVV7NKnCPhtigxY6m$mDU9cPzYklepL1V5hkhvqPDys/KS/XMhT5ZbVNkUzys=	2025-05-04 13:10:42.565374+00	t	testadm				t	t	2025-05-04 13:10:26.034912+00
7	pbkdf2_sha256$600000$pPsmSST3ad65nyAWhdvUnI$U4PSYII+yk2FXxjWTZxVqb59jBxgBQ1oilU80Wsg57o=	2025-05-21 16:30:56.491074+00	t	Kivero				t	t	2025-05-21 16:19:00.939594+00
21	pbkdf2_sha256$600000$sn0C0KNEHLytp8Gq310SJt$T623OxL9lBs8nm/3mXrP6T10auOeDd07jtNBCBS0mDc=	2025-09-12 10:23:16.751329+00	f	Research1				f	t	2025-09-12 09:15:09.093887+00
22	pbkdf2_sha256$600000$lIL5qlcNuaj5BShGLqEHvL$zNq9/9PUGOWm4ZBLQAGl/LVWsmb8im/aMxIztyJVczs=	2025-09-12 10:29:48.718835+00	f	TechnicalWork1				f	t	2025-09-12 09:17:12.276255+00
1	pbkdf2_sha256$600000$t4XNsnvFkAgiKMktcjPtzt$URqxmtFNnfNqUX0NN5Pvado/KCQlwBZ2v/989g9tBKU=	2025-09-29 22:44:30.035017+00	t	Admin_agri			admin@example.com	t	t	2025-05-04 13:09:23.835088+00
24	pbkdf2_sha256$600000$1D7YOc2epqyCUFH6zOS2SP$b+F7WWpCqXIrSRBOY1CEL7Bbq/iR2QnhYZIdR1GZhA0=	2025-10-30 12:07:28.201066+00	f	YampolskayaT1				f	t	2025-10-23 13:54:29.818758+00
26	pbkdf2_sha256$600000$l9UdBRHvb8SPnrUdwBXAf3$KZEfKNU7Tz0sWZiC1Yasc9RE4HBdY4hRovxRRfPG4Cg=	2025-10-28 09:17:34.742367+00	f	KrylovA1				f	t	2025-10-23 13:57:47.286316+00
25	pbkdf2_sha256$600000$ilRi4uSkQ7qD1lzxlFT969$8tG5yUuXDAj7LvNxA3OlKwqtGTfuN0u7IVvdHrk9gQQ=	\N	f	KatashkinaJ1				f	t	2025-10-23 13:55:54.921546+00
12	pbkdf2_sha256$600000$p975kRZ6c7xuloyeNDqFaN$vwu3BwZCNRVInnBn9nywgxVOvIMuKlrL2Gal/euZe8Y=	2025-10-30 13:12:42.607724+00	f	SmirnovS1				f	t	2025-07-08 11:00:43.018168+00
3	pbkdf2_sha256$600000$fqTjpNkLAoFN0yuUEOQ1EQ$ndvJ/ENuZe2F7U4li+WDOfjvXxd9TIc7juKyhkzMbds=	2025-10-31 14:02:34.822884+00	f	ZiyatdinovM1				f	t	2025-05-04 13:12:51.612559+00
15	pbkdf2_sha256$600000$C3r4GsnJW5bg2opTgamuOu$97ZlIhHdf6oxub6DmEKQiEW7aWaTScAiRIt233NW/W4=	2025-11-01 07:15:16.252385+00	f	MatrosovaE1				f	t	2025-07-10 18:12:40.7352+00
13	pbkdf2_sha256$600000$IuY4RtX4i8rwgZKUy07OSn$cw3opQ8B4gb/DHP5nkMLW1ZMkXFGvnhp2nmXXYj/qKI=	2025-10-31 12:32:45.94613+00	f	SamsonovViktor1				f	t	2025-07-10 17:45:29.578964+00
11	pbkdf2_sha256$600000$IxOQrw1yHdEYnacEYUWDas$qZTKsHi6RE/HwTjQm3dJ0ZL1bxFuoA2UfOo9PcBwCas=	2025-11-01 07:17:26.787312+00	f	GakEvgeniy1				f	t	2025-07-08 09:39:14.299228+00
8	pbkdf2_sha256$600000$RUKJYvliJXCUrMVyQxzs9r$OYN+gLBiRJbVD0Wbc6wyNY8BdSnHbHPbqDW1UygW8hU=	2025-10-31 12:36:17.370189+00	f	GeraskinaN1				f	t	2025-06-05 10:18:06.143582+00
5	pbkdf2_sha256$600000$K1K0qicyUwceHa3ebtaFil$zF1M7QqmA6BEi4PScQmE9tQuoyajcl7avmP/tAk8paI=	2025-11-01 12:06:23.995413+00	t	Fedorova				t	t	2025-05-21 15:07:38.773637+00
19	pbkdf2_sha256$600000$waDN6eA5iL7OuzesG1WmUz$hKczUd3Htvx0a/xf4vIECItjIkPw8pPHka2oyrdNb30=	2025-10-22 13:34:19.695529+00	f	SavrasovaE1				f	t	2025-07-31 15:27:30.620459+00
23	pbkdf2_sha256$600000$zsgAp6ML7wsW6JvbKAlQjN$XACmOqTeQIpkCpiJCkd5FgL5MxynjHqPKjs23LNq7eM=	2025-10-31 12:40:16.557407+00	f	GronskyS1				f	t	2025-10-23 13:45:45.609463+00
20	pbkdf2_sha256$600000$K1Y1ZJJeS0PJiJ1a51YhYq$MEzuTbIq34qMjjYEs7BHXjjKMMmFLfWS8PbU9DlQfD0=	2025-10-31 12:45:54.635837+00	f	GolubevaL1				f	t	2025-08-29 12:44:27.957294+00
16	pbkdf2_sha256$600000$mMB7OQsIOpQArdTu6Ib5g5$7d6r91BNQhgEtdYz9rucAD2S4kjMMkc/l6d1wRNmR0U=	2025-10-31 12:48:59.378793+00	f	MinaevaN1				f	t	2025-07-10 18:15:33.826035+00
10	pbkdf2_sha256$600000$NVEdeCZDkWfXCXiUZ8Z7sL$FVD2piQxbSJVcPvZAFclQZtPZCMNjEMX8xkTm1hH3Aw=	2025-10-29 13:20:58.072672+00	f	DoroshenkoV1				f	t	2025-07-08 09:24:47.721046+00
17	pbkdf2_sha256$600000$fA4MGAPfsrBXeY1va4wEmC$/K8HSn/1IW7mgtPQDoNAygiEDIPEzy16p60vAu0nu2k=	2025-10-28 15:07:08.826449+00	f	AltmanIrina1				f	t	2025-07-10 18:34:09.120379+00
9	pbkdf2_sha256$600000$Grv8r4K30D03kya3oK0jmf$nEpi591cNSOgOtsTbcQAvGdoTMYewQYbfnmMF3k08Zw=	2025-10-31 13:02:52.477491+00	f	RostovaJ1				f	t	2025-07-08 09:20:20.997698+00
14	pbkdf2_sha256$600000$SEVKJHoUwhAXkanhvIIIq0$mZdDxz1ez6Rmgfi+lh0x6UIdLgqBpQM2edlke/1Ihaw=	2025-10-29 13:22:11.651996+00	f	KazievaE1				f	t	2025-07-10 17:48:57.126194+00
4	pbkdf2_sha256$600000$XnrShS7iMrN4mQXDtaPpFg$8IIVzc7/LWnMWTIcb7SYpD2c+vpH1JmhvdawSpmC8f0=	2025-10-29 10:47:28.692524+00	f	KiryukhinM1				f	t	2025-05-21 14:46:50.712727+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: block_booking; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.block_booking (id, project_id, booking_id, date_booking, analyse_id, equipment_id, executor_id, is_block, write_timestamp, cookies_key, update_timestamp, id_delete) FROM stdin;
1	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-04 13:14:06.95323	5f2310f4-ab7b-4fbb-b49a-8c430107daf8	2025-05-04 13:14:06.971154	f
25	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:30:18.892666	c968be24-27ae-4a28-a877-aab5503df64a	2025-05-21 15:30:27.375981	t
19	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:25:57.988217	201610b7-9092-4dab-b564-06be6473c175	2025-05-21 15:26:17.609305	t
10	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:12:50.884235	3334b879-ebc3-4af8-aa73-bf2ea7ed4ca5	2025-05-19 19:31:13.15582	t
47	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 14:16:51.701067	11e5fe91-10d3-4366-93d6-b722fc2ccf7a	2025-06-05 14:16:51.704833	f
20	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-21 15:26:17.634045	5aba8896-bba4-4419-a2e9-4de90d8b395e	2025-05-21 15:26:31.967818	t
42	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:03:33.800198	8414bde6-6826-4929-afa5-e037a065f3ae	2025-06-05 12:05:03.156732	t
52	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-11	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 10:49:11.341672	ae491da8-71af-4e5c-963b-1b74c4b723dc	2025-06-06 10:50:31.239628	t
12	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:31:23.171169	02c1813f-894f-4cd4-9a8e-385080654d7e	2025-05-19 19:31:23.174549	f
36	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-11	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-05 11:19:52.670671	ea4e995a-10ad-4eb4-87cc-2204767cd890	2025-06-05 11:23:50.989146	t
4	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-04 13:14:58.602607	435297cc-63f9-4799-9a81-8fbc4d61d9ae	2025-05-04 13:14:58.606255	f
3	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-06	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-04 13:14:47.194453	642166a2-ceab-4137-97f2-1af2ee88e8ab	2025-05-09 10:39:00.45763	t
13	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:32:27.545388	12d7ef85-7f49-46b9-bd07-433d142859e7	2025-05-19 19:32:27.548745	f
11	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-22	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:31:13.170334	7da5984b-99a9-4101-9ddb-b3718762ec97	2025-05-19 19:39:57.562606	t
21	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-29	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:26:32.026674	fe770c98-54db-48d8-80b5-e6d367547cb7	2025-05-21 15:26:46.181546	t
5	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-09 10:39:00.473335	c07b3bcb-7aa2-4788-927d-a53df43b40a5	2025-05-09 10:39:53.973015	t
27	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-05-30 14:22:35.039354	e334e799-1595-45d0-8cc0-833b1af11fe8	2025-05-30 14:22:35.094587	f
22	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	\N	\N	\N	\N	2025-05-21 15:26:46.236731	620708a7-427b-41cf-adc6-037ed080281d	2025-05-21 15:26:50.004916	t
14	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:39:57.588819	6651ac6e-bbe9-44b5-a961-7d8996bf9337	2025-05-21 15:24:13.319794	t
6	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-09 10:39:53.9888	e96e0bea-e165-472e-957c-098e3b4f6505	2025-05-09 10:40:05.70163	t
2	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-18	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-04 13:14:29.362611	fdfdffc1-85d7-415a-9bd0-299737ef9e5c	2025-05-04 13:14:47.175137	t
28	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-05-30 14:23:02.531089	a0458d83-71e5-4038-895b-54b599a647ef	2025-05-30 14:23:02.558622	f
15	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	\N	\N	\N	\N	2025-05-21 15:24:13.337065	e1c68fa6-b3e3-4415-bf82-3a4d37aa94b4	2025-05-21 15:24:19.499631	t
7	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 18:43:01.743332	1f322a96-882b-4acb-bf5b-f3413201605c	2025-05-19 19:07:24.992881	t
16	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	\N	\N	\N	\N	2025-05-21 15:24:19.514689	7fd71a2f-8f79-4be9-98f1-b7631e7b738d	2025-05-21 15:24:22.019815	t
29	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:10:50.935371	eb43589d-6f8a-4ae0-8441-c7a92a0afca0	2025-06-02 18:10:50.939425	f
26	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:30:27.429051	7b1320e9-ef5f-4a6e-a04f-805052067fa4	2025-06-02 18:11:32.606259	t
17	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-27	\N	\N	\N	\N	2025-05-21 15:24:22.072351	2618cdac-04cb-445c-92a4-2142bdef9f8a	2025-05-21 15:24:27.626523	t
8	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-19 19:07:25.010992	d2e12478-54f9-409c-84da-d60653e34111	2025-05-19 19:09:26.100552	t
9	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-05-19 19:09:26.154716	7d7e4084-72b1-4515-841c-e0ea3cade3ea	2025-05-19 19:12:50.827766	t
23	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-28	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	\N	2025-05-21 15:26:50.055809	87473cf3-6bbc-4dcb-80e4-b6d09bdc95e3	2025-05-21 15:30:09.913344	t
49	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:35:48.551395	4a196817-6e2b-4870-89ea-ce730f48b8d0	2025-06-06 10:42:33.805538	t
45	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:06:11.030398	b16659aa-8e01-40ce-a204-9aa8a8686c48	2025-06-05 12:08:32.77305	t
43	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-09	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:05:03.185841	70bf42e2-50a6-4e64-9675-fb2b9d4237f1	2025-06-05 12:05:31.041595	t
18	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-26	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-21 15:24:27.679668	0db35efc-302b-4a54-a0ac-0ab400c28d05	2025-05-21 15:25:57.973675	t
37	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-05 11:23:51.006153	1297f0ac-60a8-4719-b5ce-f0d116d9d219	2025-06-05 11:24:04.046592	t
24	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-05-29	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	\N	2025-05-21 15:30:09.931979	975a0586-24a5-404f-929c-1e0fa1dd4d1c	2025-05-21 15:30:18.863285	t
30	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-02 18:11:32.622565	63e0359a-e41c-4bf5-9d6f-868df030d3c3	2025-06-02 18:25:53.104505	t
31	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:25:53.160743	12a087ef-e2ab-4bda-9cad-711103599bc2	2025-06-02 18:26:54.324683	t
38	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:47:37.69422	0ac7281a-15d7-4eac-b395-e10f9b0f7e60	2025-06-05 11:47:37.711397	f
32	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:26:54.339983	541e4328-31a3-4949-ab60-ab74e76eed7a	2025-06-02 18:27:12.030449	t
39	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:47:42.993564	72cf1b07-1f72-4383-a47f-c3aac7ab30f7	2025-06-05 11:47:43.035851	f
34	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-04 13:30:26.622462	9b198396-a260-41c7-af7f-45fa53fc294a	2025-06-04 13:30:26.675506	f
35	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-04 13:31:07.266863	fb414080-56e1-4d2a-bca1-233bb7d5fcd7	2025-06-04 13:31:07.279895	f
33	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-02 18:27:12.047345	a9e82bc1-06b8-45d2-bf71-69b6dca02713	2025-06-05 11:19:52.653073	t
41	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 12:02:50.907684	429c4b1d-b07e-49d8-a82f-b1a446625729	2025-06-05 12:03:33.746388	t
48	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:35:09.367434	577584d9-95d2-4f36-a206-79f984bfc295	2025-06-06 10:35:48.499849	t
53	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-06 10:50:31.269533	e52b7e39-74b5-4307-a130-c43e5ecdcb2f	2025-06-06 10:58:13.502566	t
44	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-12	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:05:31.09331	7958704b-8191-4d9c-afe3-739a54fe7c93	2025-06-05 12:06:10.97779	t
54	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-06-06 10:58:13.532321	a62e4289-2854-42e4-8cfc-b79c8805318b	2025-06-06 10:59:58.048688	t
46	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-05 12:08:32.824146	10821fc8-8a41-412e-955d-1875d2c9e3e4	2025-06-05 14:16:51.648617	t
50	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	\N	\N	\N	\N	2025-06-06 10:42:33.833372	d1359223-b8c3-4c86-839f-45ba2215142d	2025-06-06 10:48:31.059314	t
51	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 10:48:31.088737	f3770803-519f-4c6d-a9b9-cb348ced9f87	2025-06-06 10:49:11.290609	t
55	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-06 10:59:58.099074	13561017-7813-4b30-bc0b-922116223332	2025-06-06 11:00:35.347174	t
56	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-06 11:06:48.140156	b9e5a8ab-fde1-4c53-819a-d01c5c131495	2025-06-06 11:07:21.140894	t
57	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-10	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-06-06 11:07:21.192769	ccc9d83c-e892-494b-9d9e-fdc19cf9876a	2025-06-06 11:08:31.155925	t
58	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-11	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:08:31.209244	5d8e8518-945e-4e1d-9656-0c5d7e978f31	2025-06-06 11:09:09.868484	t
59	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-09	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:09:09.918849	cbdd5f01-085f-49ff-a957-04727ef4aa74	2025-06-06 11:10:16.665282	t
60	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-10	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:10:16.720207	7b5d1ce8-6026-4db3-80b9-1ce90469052d	2025-06-06 11:15:18.688808	t
61	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:10:45.162989	6da77d7a-5e58-4518-9ca0-cd49a98f31f8	2025-06-06 11:10:45.16927	f
62	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:10:58.194746	e720fb47-0d8d-4f59-96ec-8fe05fadafeb	2025-06-06 11:10:58.19869	f
63	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:11:19.29854	b98d1e46-1398-4659-8796-2cb82925e6a7	2025-06-06 11:11:19.302003	f
64	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:12:57.704648	7bca48f8-2ffe-4ed3-a7be-b30a70c9a57d	2025-06-06 11:12:57.708317	f
65	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:13:57.555785	660cd3f5-bee3-46d8-b1e3-ceca0326ebc0	2025-06-06 11:13:57.558649	f
66	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:15:18.702216	e75e78a2-212c-440b-bf0f-7ef5a5ab0094	2025-06-06 11:15:54.508122	t
67	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-09	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:15:54.521999	f5607d77-e31f-4ea1-bd51-7e527e9aa036	2025-06-06 11:16:17.352478	t
68	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:16:17.403331	c42dd685-d672-4d03-8ecd-f43524c8b9a5	2025-06-06 11:16:57.504293	t
69	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:16:57.557017	a077ecfa-0acc-49c5-a1ac-0f8a27d0fc5b	2025-06-06 11:16:57.560571	f
70	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-06-06 11:32:15.720919	fd6ca612-6ec6-4ae9-94b7-1bab6083fe55	2025-06-06 11:32:15.774742	f
71	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	\N	\N	2025-06-06 11:32:37.656455	3783a1d4-44c8-49ee-acf5-ebe1bf9212ba	2025-06-06 11:32:55.245171	t
72	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-06 11:32:55.266633	fc19e53e-6829-46cf-b23b-8682742f4143	2025-06-06 11:37:29.192039	t
73	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-06 11:37:29.244891	1f9a2aee-ebe2-461f-8c92-05043d80c58d	2025-06-06 11:37:50.652354	t
40	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-05 11:59:20.889282	87ce4111-ce06-4eee-b1ac-87ba0cdb64b1	2025-06-09 08:55:58.436282	t
105	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-18	\N	\N	\N	\N	2025-06-09 10:47:31.75685	1641d615-898a-4a00-aceb-a6353cd10c9d	2025-06-09 10:50:49.693079	t
74	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	\N	\N	\N	2025-06-09 08:55:58.455147	1e18f862-94b2-4e19-8784-9ac113795722	2025-06-09 08:56:05.373535	t
88	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 09:00:07.692262	a935e8ea-da08-48e3-9497-345b4ca9df87	2025-06-09 09:00:20.224401	t
107	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-18	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 10:51:09.947447	4222a1d1-ce7c-49bf-afc1-0421be1cc816	2025-06-09 10:51:28.283719	t
80	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-18	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-09 08:57:30.739344	d6d7f760-c66c-40cc-a69f-8bcdf67dfc15	2025-06-09 08:57:56.17395	t
81	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-06-09 08:57:56.232194	e376f275-8f29-45b7-bcf4-9bf4835b07b1	2025-06-09 08:57:56.23968	f
97	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	\N	\N	\N	\N	2025-06-09 10:41:24.150047	b96a58bd-4123-4b31-83ef-d0631f8d67f3	2025-06-09 10:42:10.876991	t
75	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-16	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-06-09 08:56:05.388128	cb841b85-d7bc-46b0-8ea1-2cfbcf2799d9	2025-06-09 08:56:27.42485	t
82	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	\N	\N	\N	\N	2025-06-09 08:58:38.195472	d36a4582-02f1-4586-90da-4f99806b4b8a	2025-06-09 08:59:05.193577	t
93	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 10:35:48.257414	85c4e6d6-85e4-4b95-b077-6c095f3c3049	2025-06-09 10:36:05.608449	t
83	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	\N	\N	\N	\N	2025-06-09 08:59:05.24885	6ef4d287-61c2-4199-b6c8-17efe54901b7	2025-06-09 08:59:13.839914	t
76	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-16	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 08:56:27.449608	342ca23c-328f-47c2-9a1e-fba43a50d444	2025-06-09 08:56:49.81261	t
89	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-06-09 09:00:20.274637	c09ddacb-4d7f-4443-b77c-9fb6b748e5d4	2025-06-09 09:00:34.932437	t
84	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	\N	\N	\N	\N	2025-06-09 08:59:13.857104	a86f816b-c848-45b7-982f-14be9e5236ae	2025-06-09 08:59:24.098222	t
90	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-06-09 09:00:34.989015	872a1cc1-0508-4cf9-9a00-704896a97f67	2025-06-09 09:00:34.992862	f
77	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-17	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-06-09 08:56:49.833669	32d47871-22c5-4064-ac3a-083ed784e734	2025-06-09 08:57:05.598654	t
114	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 11:00:26.442649	dd17fa5a-dfdf-47fa-ae26-36ada2e5c6e7	2025-06-09 11:00:53.228531	t
101	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 10:45:51.673526	15d76e70-1309-49e5-85b5-c0e9e54b7bf3	2025-06-09 10:46:16.908789	t
85	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 08:59:24.152071	3aebb701-6bc1-43dc-9e14-e24e546f373f	2025-06-09 08:59:48.014499	t
78	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-17	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-09 08:57:05.61454	45be85f9-aadf-4542-be05-957211128106	2025-06-09 08:57:18.372918	t
112	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-09 10:59:38.229282	a09f7249-0731-4c1d-81f6-5439b7ef6c62	2025-06-09 11:00:03.439326	t
86	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	\N	\N	\N	2025-06-09 08:59:48.02863	ff447c5f-7693-4eda-9321-09563df271e8	2025-06-09 08:59:52.958973	t
94	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 10:36:05.660681	7a96bd49-4a71-4e4d-8dee-ba40580bc41d	2025-06-09 10:36:46.599196	t
98	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 10:42:10.93071	ad6607c4-d810-4e4b-81c2-9e03dd57263c	2025-06-09 10:44:20.832928	t
79	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-17	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 08:57:18.427964	3d7eb2d4-d485-4471-8147-562d1cc000a1	2025-06-09 08:57:30.72588	t
91	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-16	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-06-09 10:33:15.720456	845480cc-d5bc-4221-bf78-4ff4f42c439c	2025-06-09 10:34:12.502296	t
111	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-09 10:59:21.167191	a7eb4569-f14c-40b1-add0-a73f20b0ca71	2025-06-09 10:59:38.17739	t
87	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 08:59:53.012557	6f11d4a4-bb56-4d4d-9a57-e2c689864b38	2025-06-09 09:00:07.678658	t
102	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	\N	\N	\N	\N	2025-06-09 10:46:16.959596	65a6a951-c24d-488d-8756-749aa7e73eec	2025-06-09 10:46:29.432153	t
99	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	\N	\N	\N	\N	2025-06-09 10:44:20.846374	a5f300df-aa61-447c-a633-5d8da270fa73	2025-06-09 10:45:07.921516	t
95	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-09 10:36:46.648739	28f1c6dc-9df3-4fbe-b2e0-28ebd2672df5	2025-06-09 10:38:55.686361	t
92	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-17	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 10:34:12.554084	1c37a118-8479-4551-ae40-d29fc90df6f5	2025-06-09 10:35:48.193249	t
106	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 10:50:49.722291	3ab8b4e5-f783-4e86-9f40-e247e2e5f8f8	2025-06-09 10:51:09.934568	t
103	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	\N	\N	\N	\N	2025-06-09 10:46:29.462058	b23ff82a-135e-479a-bdcf-7027d1053967	2025-06-09 10:47:21.694337	t
96	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	601b7b77-ab12-477c-918e-ca3910a3bb96	\N	\N	\N	2025-06-09 10:38:55.738716	5c687854-ba6b-40fa-b972-ab541ea9b06b	2025-06-09 10:41:24.097122	t
110	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-09 10:58:46.696673	60eaf76d-c1fc-409f-8284-60dc73dd4af8	2025-06-09 10:59:21.117295	t
100	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 10:45:07.94972	4b5ca408-a269-4b42-9b7e-224059fd8244	2025-06-09 10:45:51.642102	t
104	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	\N	\N	\N	\N	2025-06-09 10:47:21.723391	b3a7a3b9-b3d5-4b23-bc10-7f181b1c8caf	2025-06-09 10:47:31.742966	t
108	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 10:51:28.333998	1e4041b2-17c7-45d3-bead-0517578cc92f	2025-06-09 10:56:34.16407	t
109	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-06-09 10:56:34.192271	607cc974-5ab1-4b3f-9071-b7731ccdcdc6	2025-06-09 10:58:46.645431	t
115	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 11:00:53.279352	d3919d8a-ded8-4a0e-90dd-1cccb1a1a71d	2025-06-09 11:01:24.384271	t
113	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-06-09 11:00:03.541158	30c40957-fb03-4732-bdef-3401e658aac8	2025-06-09 11:00:26.391186	t
116	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 11:01:24.43637	65de6747-7694-4564-8b7b-a4df770db2e1	2025-06-09 11:01:41.641985	t
117	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-19	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 11:01:41.69242	9e326854-98bc-445d-a571-52dc4fd04d34	2025-06-09 11:01:54.466007	t
118	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:42:07.436183	a612bfed-fd20-4ddb-afab-db4add680769	2025-06-09 13:42:40.718071	t
119	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:42:40.770401	8cf5f915-56b3-4dd6-89b5-a130a9abe473	2025-06-09 13:43:13.689226	t
120	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:43:13.741671	14eaeada-f472-4b85-94f0-d16e1ab266bc	2025-06-09 13:43:30.233357	t
122	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:43:41.757265	b2d6a552-dc19-4d43-9725-2fe558a14b89	2025-06-09 13:44:01.981877	t
121	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	\N	\N	2025-06-09 13:43:30.261467	a8de04ef-4942-4dd3-9268-bfd27fa14943	2025-06-09 13:43:41.704324	t
144	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-01	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-24 09:24:12.32408	2b02116c-e752-4603-8f8c-a5df10eeff85	2025-06-24 09:24:39.928857	t
138	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 14:05:30.418137	39436cbc-c104-4763-b0dd-76aee88b9528	2025-06-09 14:06:02.389705	t
123	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:44:02.034927	3dc63d25-e44d-4a2d-aadf-3b52887fd2d7	2025-06-09 13:45:08.660095	t
131	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:52:31.595872	c58de289-9fa1-49c5-af9d-bca49f153279	2025-06-09 13:52:46.575077	t
124	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:45:08.717887	cf953282-520a-44a6-a091-512703d77854	2025-06-09 13:45:21.04704	t
145	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-30	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-24 09:24:39.980234	39da79e2-4555-49ac-94b8-b9b7582fee9c	2025-06-24 09:24:58.244333	t
132	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:52:46.62774	9dfe713e-bb8f-4ccb-8f25-f6fdce3865a8	2025-06-09 13:53:03.041535	t
139	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-30	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-24 09:20:17.135816	3913c06d-fa5c-4285-9a11-6765a1fab790	2025-06-24 09:20:48.902469	t
125	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:45:21.099642	ba235512-f461-42db-ab5d-d4c79778dc91	2025-06-09 13:45:37.338598	t
126	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-18	\N	\N	\N	\N	2025-06-09 13:45:37.352616	b50e3ba6-78ba-4b84-97a2-abc20e053ef3	2025-06-09 13:45:50.450522	t
133	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-16	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 13:54:06.251782	7e13e6b0-be48-48eb-9825-dfbc0052f4fd	2025-06-09 13:54:23.855974	t
127	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-19	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:45:50.502244	b935c9f2-fb40-4dc8-9120-0761fb002510	2025-06-09 13:46:18.857182	t
140	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-01	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-06-24 09:20:48.95331	6289c04b-5e5d-45a8-a3e3-f839dc5e0588	2025-06-24 09:22:31.05255	t
134	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-17	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 13:54:23.907534	6e579b23-3622-4dd7-9882-c4d0a153db9e	2025-06-09 13:55:00.167365	t
128	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:46:18.910435	08340a54-3476-46f1-b8db-8f2b9672f336	2025-06-09 13:51:13.23415	t
141	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-30	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	\N	\N	2025-06-24 09:22:31.116897	cbddc0e6-a2e1-4edb-a613-e609d83fb64e	2025-06-24 09:23:19.421255	t
135	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-18	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 13:55:00.179458	39f301a6-74d7-4407-91c3-4fabe6d3ab81	2025-06-09 13:55:17.385646	t
129	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:51:13.287347	6285ad12-be10-44bd-acf3-a31ef1d539ad	2025-06-09 13:51:54.636514	t
136	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	\N	\N	\N	\N	2025-06-09 13:55:17.436612	fe35afdf-e1d8-4bbe-9877-a295fc132505	2025-06-09 14:01:22.00958	t
130	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-06-09 13:51:54.648492	5a13a6cc-cb53-40dc-95b8-7b07c9facc47	2025-06-09 13:52:31.544401	t
142	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-30	\N	\N	\N	\N	2025-06-24 09:23:19.474764	acf93537-094c-49ca-9f5c-1cbe544188ba	2025-06-24 09:23:45.77785	t
143	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-30	\N	\N	\N	\N	2025-06-24 09:23:45.828786	4782acd6-0e21-4926-b53f-9d4528209bf5	2025-06-24 09:24:12.296157	t
137	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-06-09 14:01:22.060002	d7db9321-0ee3-43bb-b18c-f12fb19b6b33	2025-06-09 14:05:30.403657	t
167	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-14	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-08 12:14:45.141278	6da6ffae-dd04-4203-b6ca-a67757c5578d	2025-07-08 12:17:13.37987	t
161	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-14	\N	\N	\N	\N	2025-07-08 12:03:36.339708	4381991e-8f6c-4aba-ac3f-ece31844e0d9	2025-07-08 12:05:57.106467	t
170	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 12:25:35.626263	891df7c9-e7b0-4a9b-865e-6a572c8f88f4	2025-07-08 12:25:35.629894	f
165	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-14	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-07-08 12:10:48.349065	f8d992ac-3059-4496-8ebe-58572c3eaf3c	2025-07-08 12:11:10.549852	t
156	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-15	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-08 11:53:23.632483	9aea94ec-8842-4def-8e4e-dbdceae1c056	2025-07-08 11:56:45.394415	t
147	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:44:19.465237	cdb59d01-116f-4abd-8c24-fb851fed64f7	2025-07-08 11:44:19.469292	f
148	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:44:27.819335	31db75f6-5a1d-475c-8ed3-6c236a35d74b	2025-07-08 11:44:27.823262	f
149	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:45:04.896595	e01265c9-b8cd-4328-b6ce-becc9d5b0ab4	2025-07-08 11:45:04.900576	f
157	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:56:45.448252	8b52bc95-63fc-4561-8742-575afd9f83aa	2025-07-08 11:57:05.438089	t
150	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:45:27.388938	0acdbbb1-acb6-4fc7-befc-5110cf477be3	2025-07-08 11:45:27.39194	f
151	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:47:36.573948	c7de8742-ed1e-43e1-93ca-932d1f5a88e2	2025-07-08 11:47:36.577787	f
162	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-14	87e352df-7694-466a-a100-26aa80ff28e9	\N	\N	\N	2025-07-08 12:05:57.124641	d6820179-6625-4005-a764-67027142cfbb	2025-07-08 12:07:00.778938	t
152	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:50:41.808444	8611d911-556d-4393-8b1d-2aeaf706f769	2025-07-08 11:50:41.812405	f
153	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:50:54.36711	42c850f6-5220-400e-a875-60481d6e43b4	2025-07-08 11:50:54.37078	f
169	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-07-15	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-07-08 12:17:36.14018	23e7c2f4-089e-415e-905b-3e0dd566677d	2025-07-08 12:27:42.13897	t
154	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:50:58.95102	67fb8b27-9c9f-42a6-82a0-8073682c420d	2025-07-08 11:50:58.954745	f
146	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-06-30	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-08 11:26:12.021014	a55cab8e-0e9e-45fc-b471-7f63bcf750ab	2025-07-08 11:52:28.769097	t
174	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-08	\N	\N	\N	\N	2025-07-09 14:58:05.709065	4d5fb336-1416-4839-b3ca-021329a69a01	2025-07-09 14:59:37.960292	t
168	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-07-15	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-07-08 12:17:13.43279	e0c78a9a-48f0-4ef7-b1ee-a975d96fa0f2	2025-07-08 12:17:36.088764	t
158	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-07-14	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-08 11:57:05.452188	ac9c5939-df38-44e1-b1ca-b31ef7761bd3	2025-07-08 11:57:42.01023	t
155	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-14	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-08 11:52:28.782089	03b04b2d-698c-429f-95c1-2ad557b19e00	2025-07-08 11:53:23.580431	t
166	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-14	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-08 12:11:10.599963	2c29d863-965b-40f5-b2ec-189fce230818	2025-07-08 12:14:45.087553	t
163	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-07-08 12:07:00.830401	200d0047-f8fa-4622-8b60-63e14caeb52b	2025-07-08 12:10:18.201362	t
159	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-07-14	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-07-08 11:57:42.063417	252977a1-be13-4559-a343-3ccac24d1a59	2025-07-08 11:59:44.496516	t
172	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-07	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-08 13:43:16.750087	170a74c6-2820-48bf-9cce-659fdc9c1188	2025-07-08 13:44:36.072498	t
160	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	\N	\N	\N	\N	2025-07-08 11:59:44.525552	9c3cc66e-e088-4c58-aa2e-bd2cbdd29093	2025-07-08 12:03:36.286028	t
164	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-14	1b6870c5-c028-4f7d-b3a6-da026ec81032	\N	\N	\N	2025-07-08 12:10:18.231047	c764486f-6cb3-4b18-806c-edcdc41a2267	2025-07-08 12:10:48.298119	t
180	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-07-10 07:39:21.993786	13d0afba-7a0a-4270-ae03-19061cbfd97b	2025-07-10 07:41:51.349475	t
171	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-07	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-08 12:27:42.207506	a7ccd40d-e3fb-4a96-8405-e49128cb1f54	2025-07-08 12:28:31.034384	t
176	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-07-09 15:03:48.929101	abff8e92-8996-47fd-b335-ee6589145789	2025-07-09 15:03:48.932314	f
173	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-09	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-07-08 13:44:36.12452	57e7ee0e-e0ef-4c32-9746-58396e730092	2025-07-08 13:44:49.270498	f
175	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-09 14:59:38.012098	1c68f720-df6c-4bc1-a08a-78d7826d6b2f	2025-07-09 15:04:51.402773	t
178	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-10 07:38:30.288365	551df718-e8ae-4659-a856-918813082e1e	2025-07-10 07:38:50.849476	t
179	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-10 07:38:50.86288	93bffb54-98f1-4225-abb3-e0a0d8f0e4a1	2025-07-10 07:39:21.979921	t
177	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-07-17	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-07-09 15:04:51.454138	3542f1f0-776e-4dc9-87a3-ceb0ccd79e27	2025-07-09 15:05:04.215849	t
181	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-14	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-10 07:41:51.363299	bd374de4-bee9-49c5-bb9c-de1b77ce500f	2025-07-10 07:42:09.283986	t
182	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-17	\N	\N	\N	\N	2025-07-10 15:42:33.996227	7606b5b2-3c41-4e4e-b8ef-901082794067	2025-07-10 15:45:20.974624	t
183	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-10 15:45:21.004368	e63e766c-16fb-4a99-94bc-f1f26ff1cab4	2025-07-10 15:45:43.99451	t
184	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-14	\N	\N	\N	\N	2025-07-11 07:42:15.219491	ae9e8f32-8269-4c77-83b4-95060a04ee44	2025-07-11 07:42:50.474614	t
185	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-15	\N	\N	\N	\N	2025-07-11 07:42:50.526126	78432d13-79c8-40bf-acc2-6348595b01d6	2025-07-11 07:43:07.601389	t
186	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-17	\N	\N	\N	\N	2025-07-11 07:43:07.654077	2629e596-a0fa-4779-a0c4-e502fc8e59c9	2025-07-11 07:44:02.645287	t
422	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-11	\N	\N	\N	\N	2025-08-07 13:35:23.734552	0a2bea59-529b-47ef-a44e-a3323917a25e	2025-08-07 13:35:29.040723	t
216	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-04	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-30 15:36:05.857809	5946ce52-f084-40f8-b903-2009c8fd509f	2025-07-30 15:36:20.971958	t
187	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-16	\N	\N	\N	\N	2025-07-11 07:44:02.67549	be41e703-656e-417e-b46f-7ac9dac43ee5	2025-07-11 07:44:04.562425	f
221	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-07	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-31 15:10:51.031153	74b622ac-5883-4ee1-a2ff-dc5869befcc2	2025-07-31 15:21:38.046235	t
238	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:44:12.119662	89de22c1-6e09-4597-972a-fd4bb391a66c	2025-07-31 15:46:24.205295	t
234	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-07	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:41:16.557951	87528571-b8dd-4f36-84b3-f8835bf011a6	2025-07-31 15:42:08.772666	t
208	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-04	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-30 15:27:52.741226	757dc18b-3a5e-4b6e-a38b-8dbecdbdfeb0	2025-07-30 15:28:21.239833	t
188	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-14	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-30 09:35:12.807417	8c6ca666-0f15-46f5-8744-160a9319ca34	2025-07-30 09:36:08.127522	t
223	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-05	571cd566-5150-4b80-9221-233cd3d39b87	\N	\N	\N	2025-07-31 15:21:38.098416	33342dcc-1e80-4761-9b17-6568995a58bc	2025-07-31 15:22:05.545231	t
218	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	\N	\N	\N	\N	2025-07-31 15:06:45.127367	cb74969b-5837-44df-a9fb-f8f4842569b4	2025-07-31 15:06:45.131103	f
189	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-07-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-30 09:36:08.147987	f133d19f-ac5f-4058-9587-9107aa6461bf	2025-07-30 09:37:26.122412	t
209	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-05	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-30 15:28:21.296817	b540cbae-6776-40dd-8ea1-66d799362c3b	2025-07-30 15:28:38.751999	t
190	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-07-16	\N	\N	\N	\N	2025-07-30 09:37:26.174975	eabaa4cc-8a9e-473c-b4d0-2dd130ad0275	2025-07-30 09:38:17.512743	t
210	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:31:30.152716	3c692965-cbbb-479e-8ba3-c55c1ae1170b	2025-07-30 15:31:30.229784	f
191	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-16	\N	\N	\N	\N	2025-07-30 09:38:17.52609	b0b98025-9c05-4b30-93ac-f1599d379ed2	2025-07-30 09:38:33.002531	t
211	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:32:23.993497	ac104552-5de5-436e-bf7e-c1c34ec6c0fe	2025-07-30 15:32:24.047567	f
192	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-14	\N	\N	\N	\N	2025-07-30 09:38:33.055122	989eb818-803c-425c-826d-863cd9841f6c	2025-07-30 09:38:47.445312	t
212	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:33:10.860076	47eed038-6de3-44b3-98ed-abffc78325b6	2025-07-30 15:33:10.884429	f
213	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:33:47.007619	55f8fc36-591a-4a52-a18b-d3a7bb51e15d	2025-07-30 15:33:47.038276	f
217	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-04	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-31 15:05:12.195399	8464f47b-ee5a-4607-8771-3116684b97e5	2025-07-31 15:09:18.926221	t
193	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-07-15	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-07-30 09:38:47.473782	86ff9426-bce2-42ef-95fe-8e034fad85f0	2025-07-30 09:39:09.983215	t
194	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:13:31.940107	5a2ab58e-a7a1-4364-a88b-31157acbff8e	2025-07-30 15:13:31.993272	f
195	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:13:57.307641	740f9898-b334-4dc5-bc81-2422da6480e7	2025-07-30 15:13:57.337109	f
196	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:14:50.82263	d47ca4d2-ca0f-4259-853d-f3de318c2782	2025-07-30 15:14:50.876517	f
197	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:15:12.646554	ab5d1047-a7a1-4593-8c18-8e0d68e02906	2025-07-30 15:15:12.69749	f
198	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:17:39.419236	faef380e-2511-4e09-a42f-d14ce601827b	2025-07-30 15:17:39.448843	f
199	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:18:28.752037	e0283f65-b585-402d-9fb6-c6632f2ce883	2025-07-30 15:18:28.803962	f
200	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:19:31.832137	5afbce5c-e0e6-429f-b2b4-57d1ab7445fb	2025-07-30 15:19:31.84563	f
201	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:20:24.329858	8b801f5e-73c6-4c1b-a7a6-2697c41c70b1	2025-07-30 15:20:24.381629	f
202	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:21:27.903293	63d27283-466e-49e0-8a79-5c9a0dead918	2025-07-30 15:21:27.956996	f
203	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:22:29.741729	f8f6e9d7-a408-412b-8d8f-6a81e00393dd	2025-07-30 15:22:29.755254	f
204	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:23:27.208694	f435de5c-bad4-4ffe-bab5-44dfb8006e78	2025-07-30 15:23:27.260918	f
226	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-06	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-31 15:24:33.670231	6670001f-4bdf-4a43-a9b9-0613b21031e3	2025-07-31 15:29:52.124758	t
206	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:24:17.817032	b058d551-a12e-4d11-87e5-7b6e025a07e5	2025-07-30 15:24:17.819946	f
205	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:23:53.065071	7634c178-546f-4c45-8c7f-9515171246cd	2025-07-30 15:25:00.188624	t
207	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	5999-01-20	\N	\N	\N	\N	2025-07-30 15:25:00.208444	76cc800c-d81d-4d49-9804-a5ef20561861	2025-07-30 15:27:52.710234	t
231	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-05	a426aa21-8248-4fad-8ed2-f82aa388d1b5	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:35:05.2311	47b01922-6c62-4a40-9422-8073bd484093	2025-07-31 15:35:44.959919	t
214	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-04	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-30 15:34:47.645356	e76164cf-af13-4d83-97d2-3fa80f19964c	2025-07-30 15:35:36.193058	t
229	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-06	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:30:42.585085	ef947764-a91c-4ed7-8e23-1a912e5613eb	2025-07-31 15:32:18.25914	t
219	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-08-05	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-07-31 15:09:18.978872	80c4982d-12cb-47e2-97d6-ef3c4b68d5c9	2025-07-31 15:10:13.894163	t
224	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-05	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-31 15:22:05.574604	77de375c-006f-4137-bc87-6e2be5644c6c	2025-07-31 15:24:10.926328	t
215	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-04	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-30 15:35:36.204652	7f31db52-27b2-4460-9bc7-8a72f0224b21	2025-07-30 15:36:05.806078	t
220	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	\N	\N	\N	\N	2025-07-31 15:10:13.922203	04187a96-e010-4931-8e9b-fe7180fcbb66	2025-07-31 15:10:50.968542	t
242	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-07	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:52:21.962243	cc5e4234-5048-4b2c-82b1-1be0046a0b47	2025-07-31 15:53:30.110661	t
227	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-06	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-31 15:29:52.178895	84756142-1ee7-4b46-a8ce-a9f2ea583ddc	2025-07-31 15:30:09.099976	t
233	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-05	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:39:56.045165	de75fc10-9853-49f9-b5cb-c1a47d15f0d3	2025-07-31 15:41:16.544295	t
240	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-05	f70dda6c-3b1c-4248-bc15-93aefba973bb	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:50:15.903667	81f695c8-c77a-4762-aa5f-2275ee14b51e	2025-07-31 15:50:52.466336	t
222	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	5999-01-20	\N	\N	\N	\N	2025-07-31 15:18:19.009438	9f99c47a-3b55-4d92-8baa-d3633d12e613	2025-07-31 15:18:19.013572	f
225	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-05	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-31 15:24:10.977667	fc947527-fccf-450c-b761-76ca9c5b552c	2025-07-31 15:24:33.61741	t
239	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-08-04	e40964e1-8934-428e-a06e-18379a30ebae	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:46:24.257185	899e9172-83de-4592-9916-bd134e862324	2025-07-31 15:50:15.872666	t
237	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:43:53.019287	2419ffd8-83fb-4839-9e9e-7c40b08dc4bb	2025-07-31 15:44:12.068518	t
230	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-04	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:32:18.288549	fcd56dac-f2be-44b8-bd2b-cf663eb80f3a	2025-07-31 15:35:05.216718	t
228	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-07	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-07-31 15:30:09.153	e59da40e-7f23-4d36-bb99-bc8695dec52a	2025-07-31 15:30:42.563876	t
232	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-05	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-07-31 15:35:45.019278	bf3ca77e-9bbc-4fa5-ab05-c43908ed2e82	2025-07-31 15:39:56.016738	t
236	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-04	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:43:39.660615	b321da79-37c4-4f78-8cb1-a35e95f57aec	2025-07-31 15:43:52.966017	t
235	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-04	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-07-31 15:42:08.786988	02ea39a4-cde4-48a4-9c66-34de05c5d364	2025-07-31 15:43:39.607974	t
243	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-06	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-07-31 15:53:30.162703	24d59ce5-6a03-48c7-84fd-241acfe0ee48	2025-07-31 15:53:49.258381	t
241	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-07	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-07-31 15:50:52.479727	6a897c3b-ee06-420b-b490-8b49e57aea89	2025-07-31 15:52:21.908764	t
245	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-07-31 15:54:02.35843	74529b13-43de-4d10-8d5a-f3f39a0a0adc	2025-07-31 15:54:44.018076	t
244	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-07	1d7b838c-9f35-43e6-9cde-d63c11d9097f	\N	\N	\N	2025-07-31 15:53:49.310171	f6b66967-6e43-4168-bdb1-1a4adbd6483e	2025-07-31 15:54:02.305787	t
246	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-04	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-07-31 15:54:44.069736	c89b7a46-ac4f-4d11-b5cb-298a7ee9272a	2025-07-31 15:57:30.893354	t
247	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-05	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-07-31 15:57:30.944072	67d599fc-32f7-4c4b-b1c2-fdd13deb334b	2025-07-31 15:57:43.405757	t
248	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-01 15:15:02.406149	5b125217-42a1-4582-9ced-f59cb6fd5957	2025-08-01 15:15:02.419682	f
445	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	\N	\N	\N	2025-08-08 11:13:45.671374	e26bcbc9-3895-4178-a284-e4e4bf6f0548	2025-08-08 11:14:08.384743	t
467	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-19	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 07:13:26.522536	d7c9e207-498f-41ee-bf71-a0bb0f5e0f33	2025-08-11 07:25:03.748501	t
418	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-12	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-07 13:28:08.098826	61a0deca-a88e-4538-97ec-cfed67db9eba	2025-08-07 13:28:26.422797	t
249	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-01 15:18:50.737295	02b0b571-4fba-4f96-9097-0bc03e44efb0	2025-08-01 15:19:32.334951	t
420	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 13:31:52.562549	1afef180-d794-4ae4-bce5-2b02f6cdf49a	2025-08-07 13:35:17.830119	t
254	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	\N	\N	\N	2025-08-01 15:25:09.868609	5266a1f6-89cd-4944-a6cc-17e4d53b44dc	2025-08-01 15:26:11.350157	t
424	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-11	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	\N	\N	\N	2025-08-07 13:39:11.792099	1bad6a2f-805f-4a3c-8d52-1ad9b5ce3e90	2025-08-07 13:40:22.873264	t
527	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:01:55.678647	dea271ae-5dfb-4346-8bb5-e3c00306ec1a	2025-08-15 13:03:38.47885	t
464	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-19	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-11 07:09:39.963483	17ce0be4-4595-4c6d-b70e-abe66f1eb982	2025-08-11 07:10:29.832751	t
426	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-12	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-07 13:40:32.659206	266b027d-4d21-470e-be3e-439a39cfe8e1	2025-08-07 13:40:59.716985	t
468	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 07:25:03.801336	23c14f7f-0608-4b0c-854d-a83d20c6e106	2025-08-11 07:26:01.620665	t
427	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-12	\N	\N	\N	\N	2025-08-07 13:40:59.769365	ad6dbcc0-25dc-40e4-b5df-81c020790163	2025-08-07 13:41:06.864774	t
471	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	\N	\N	\N	\N	2025-08-11 08:50:51.852561	4efdf181-e4ac-4406-b3d0-4a95a0158144	2025-08-11 08:51:02.991559	f
465	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-19	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-11 07:10:29.883745	b55d7be2-b6eb-4bb3-9d8a-904630828da6	2025-08-11 07:11:11.543571	t
429	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-14	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-07 13:41:43.163603	1e08c9e7-68b1-4ee6-bf0f-272660aa7cbc	2025-08-07 13:43:13.848426	t
490	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-08-19	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-13 12:32:32.640418	ef13ee5e-bd7d-412c-8b19-535a9d01f0d6	2025-08-13 12:33:56.868311	t
433	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-08-07 13:53:08.917994	dab91b08-4d6f-491b-bab3-90c62bad792f	2025-08-07 13:57:44.907011	t
530	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:05:00.276392	34f89530-9728-4d99-b917-23b4b22672db	2025-08-15 13:05:41.468092	t
473	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-18	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-11 10:07:53.568098	5c39add6-fd6c-4965-8d7f-aebc948e1ca8	2025-08-11 10:09:38.887994	t
434	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-07 13:57:44.958184	095be37b-1e48-45fb-88f4-c0ec617efd03	2025-08-07 13:58:00.163922	f
476	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-08-11 12:21:45.320257	4c3f621d-d9cb-4c3d-b79e-eed2ae1d81b1	2025-08-11 12:21:45.378248	f
438	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-08 10:27:34.051114	ca60af16-68db-40da-be72-340874220419	2025-08-08 10:27:34.054973	f
466	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-19	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 07:11:11.555935	722e8a5d-8621-4e41-a44f-00bdff919452	2025-08-11 07:13:26.47063	t
531	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:05:41.520246	52012268-1904-412c-bb72-c3b2b865d609	2025-08-15 13:05:41.523825	f
482	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-12 14:05:08.308243	322fe15f-12bb-49ef-be87-172327b1e325	2025-08-12 14:05:32.5993	t
442	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-08 11:08:17.391701	78dfc7e3-4521-4c95-96ae-186a8a34ea48	2025-08-08 11:10:12.910296	t
436	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-08 09:53:28.278079	19a9f071-6074-4373-8a33-d851338da40f	2025-08-08 11:12:11.210844	t
532	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:41:10.202079	1dcfbd2e-cfe5-4eb7-8865-9a14b3a2c93a	2025-08-15 13:41:10.252705	f
497	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-13 14:05:06.218086	79f567d3-b919-4fc5-9097-75665612d4da	2025-08-18 10:23:25.039495	t
444	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	\N	\N	\N	2025-08-08 11:12:11.240653	3cb14fda-7e4e-45c0-a304-d54d948a48e2	2025-08-08 11:13:45.619459	t
491	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-18	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-13 12:33:56.919724	9c180002-d64c-4508-990b-a2a55c343b76	2025-08-13 12:35:17.050507	t
486	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-19	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-13 12:19:29.792744	4bdffc05-9f3f-47dd-a62e-46d25eabccd0	2025-08-13 12:22:11.497292	t
546	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-27	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-19 10:19:41.090237	3941875b-daed-4f06-9fe2-7c93ecc62b2a	2025-08-19 10:20:17.238103	t
493	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-19	\N	\N	\N	\N	2025-08-13 12:37:23.970983	d3cc8dfa-fa8f-41b9-be5a-7c03ba65390f	2025-08-13 12:37:42.862954	t
547	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-19 10:20:17.288245	3d344c99-2e50-4e32-ac8e-2c4f59f0514d	2025-08-19 10:20:34.477441	t
540	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-26	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-18 10:23:46.246914	f6b57642-1b2f-419a-9595-cd37f96acf58	2025-08-18 10:26:10.449577	t
488	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-19	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-13 12:23:17.86153	1c144d46-6f47-4b4f-9755-73dd0e303b48	2025-08-13 12:24:21.933751	t
494	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	5999-01-20	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-13 12:37:42.896656	91e753ed-09de-499e-b0f0-c16826d84fdf	2025-08-13 12:39:20.004115	t
553	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	\N	\N	2025-08-20 08:31:55.114642	60a46b87-f9c3-4c5f-9e52-1be9a021062b	2025-08-20 08:32:03.123098	f
541	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-28	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-18 10:26:10.502539	a69ff31f-0c87-488b-b771-4a99c58100de	2025-08-18 10:28:19.2204	t
284	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 10:58:25.105705	df150717-a9cc-45fd-a752-d60155350ad3	2025-08-04 10:58:26.609266	f
250	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	\N	\N	\N	\N	2025-08-01 15:19:32.357082	75a34459-fa37-431d-a20e-19e61cf8f22c	2025-08-01 15:19:42.670479	t
274	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 10:22:30.000668	6eae6260-3b5d-4a74-a5fb-34956bceb88a	2025-08-04 10:22:40.482858	t
251	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	\N	\N	\N	\N	2025-08-01 15:19:42.685631	9561271b-4641-4d36-95f2-2554d38c4b84	2025-08-01 15:20:00.99115	t
266	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-04 09:07:51.593544	9269c13f-cc91-4dd7-922a-daa44d199e26	2025-08-04 09:10:29.909883	t
295	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:46:24.720386	e7134f71-5076-4eaa-9de2-65c0482ac498	2025-08-04 13:48:45.00558	t
285	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 11:14:29.403853	432beef7-74c5-4ab2-8086-e95d48cdb762	2025-08-04 11:14:31.315556	f
252	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-01 15:20:01.0426	cfe447cc-407f-47da-8b61-3e4c5254a71c	2025-08-01 15:24:55.675135	t
267	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-12	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-04 09:10:29.961006	13fd5c57-0b38-40f3-848d-a3baf6fc8a84	2025-08-04 09:11:06.508559	t
253	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-11	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	\N	\N	\N	2025-08-01 15:24:55.727471	d83501ea-fa24-4c06-b78b-4e0b2cb5c616	2025-08-01 15:25:09.855128	t
286	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 12:32:59.874737	56b71dfc-3f01-4709-b506-2016c0078433	2025-08-04 12:32:59.927196	f
276	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 10:45:49.651086	90b21bc9-d691-4816-ab9d-f181d3cb4a08	2025-08-04 10:46:33.491533	t
268	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	\N	\N	\N	\N	2025-08-04 09:11:06.560855	7202fcd3-6050-464f-9755-087f895d20f7	2025-08-04 10:01:22.973974	t
255	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-01 15:26:11.402484	fd447fc9-8fbe-4791-987a-c56b34b1195c	2025-08-01 15:26:50.551587	t
269	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 10:01:23.020029	c150cf08-41a2-4490-8efa-6e6df5327a69	2025-08-04 10:01:58.247588	t
256	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-08-01 15:26:50.603593	f94ccf57-8a5e-4e7d-8584-43f41055f917	2025-08-01 15:27:07.546303	f
257	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:24:51.282329	140cadd6-4279-4425-86bf-99c5d03b3cec	2025-08-04 07:24:51.297258	f
277	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 10:46:33.505577	47a03e71-7b89-4ca4-b557-c6b738242373	2025-08-04 10:47:50.683348	t
259	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:29:09.334981	0f875eb2-625d-494e-9d05-c1a8b5e4cbb4	2025-08-04 07:29:09.337851	f
258	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:25:46.691152	80f3a964-cbbd-41e2-9e32-6967dd81b952	2025-08-04 07:29:55.767734	t
260	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:29:55.798498	0eae2870-4363-4752-b3b9-97623c60f4eb	2025-08-04 07:31:20.146311	t
308	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 14:53:55.349226	37ab9b86-4974-4850-a218-6534e863438f	2025-08-04 15:39:01.532448	t
261	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:31:20.160479	412667a8-8549-493b-a7bf-038aca89d325	2025-08-04 07:31:44.500535	t
270	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-04 10:01:58.276743	9aac8c4a-17bd-4182-a2e2-9d54fb48b906	2025-08-04 10:02:21.795017	t
262	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 07:31:44.552569	b9f4412d-bcaa-48ca-932d-280b6e5e3304	2025-08-04 07:36:09.483041	t
278	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 10:47:50.71177	3f9205d3-0bfb-4c81-b28a-a700355b565b	2025-08-04 10:49:26.488222	t
263	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	\N	\N	2025-08-04 07:36:09.538892	1ec87498-3a67-46d0-bb34-76547ecd3c30	2025-08-04 07:36:31.587459	f
264	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 09:02:12.859993	fb16abc3-e760-4af0-a7ba-9df8e51b77bf	2025-08-04 09:02:12.912677	f
296	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	\N	\N	\N	\N	2025-08-04 13:48:45.05693	0bd1e8c2-b9de-4b3c-8079-a94c6061adb2	2025-08-04 13:48:50.877128	f
288	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 13:39:04.476018	ccb1ed4a-0c5a-47ac-b57c-e1a6bac60438	2025-08-04 13:39:25.13636	t
360	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	\N	\N	\N	2025-08-06 11:34:45.827532	d343d866-6519-41fb-b061-e43c133bef19	2025-08-06 11:37:55.199565	t
271	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-04 10:06:55.731774	20b0ddc8-913a-47fc-b7e8-fcf1b4241d95	2025-08-04 10:08:20.615725	t
265	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-11	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-04 09:05:34.656387	7385030f-3d01-440a-8e65-bdf3af5bbdf9	2025-08-04 09:07:51.579314	t
291	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:40:46.248196	d41b25c9-f6d7-44bc-86e6-3588c9b5801e	2025-08-04 13:49:36.668934	t
279	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	571c313e-8ec3-4777-bac7-40855117d510	\N	\N	\N	2025-08-04 10:49:26.541171	93ebff25-76bf-493a-8d17-0fa40842f9f9	2025-08-04 10:50:01.352985	t
272	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 10:08:20.628395	77e7a548-7437-44c3-aac1-becc4f56ef28	2025-08-04 10:08:56.201712	t
289	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 13:39:25.186885	5d5a0fe7-d6bc-459e-9c00-7724c70681b4	2025-08-04 13:40:28.714339	t
280	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 10:50:01.404577	f08a0302-ccab-456e-9e2c-d69c25c4980f	2025-08-04 10:50:19.207488	t
273	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	571c313e-8ec3-4777-bac7-40855117d510	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-04 10:08:56.25237	0f7d0a49-d699-4567-9fad-653ff5278a8f	2025-08-04 10:22:29.971106	t
301	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 14:03:40.222058	1d5f5275-1b93-4ec8-b5b0-b498e06a7085	2025-08-04 14:03:48.663288	t
281	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 10:50:19.258903	db54361c-e142-4906-9a0f-0e85d4d56539	2025-08-04 10:54:18.840705	t
290	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:40:28.728517	153a5f3d-951f-4ce6-a082-c916d5f9bc24	2025-08-04 13:40:46.218555	t
282	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 10:54:18.892741	1c72df5a-439f-4efe-96f6-fc1c2477173d	2025-08-04 10:57:14.112888	t
287	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 13:38:53.078278	a98272df-ec51-4a63-af69-8e740cea2902	2025-08-04 13:42:31.492255	t
283	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-13	\N	\N	\N	\N	2025-08-04 10:57:14.166296	6e3b2f5b-12f0-4c8c-96e2-d6ad17c0e593	2025-08-04 10:58:25.050906	t
305	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 14:22:26.667189	039138b6-2215-4c97-8a3f-b61f0f5d97df	2025-08-04 14:23:00.802736	t
297	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 13:49:36.721046	09c28d86-bc94-405b-8166-455f78f7dbe5	2025-08-04 13:49:44.577053	t
292	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:42:31.504679	3bd8c0b6-55b0-4e33-a99d-dd9f0cfe0c25	2025-08-04 13:42:47.800451	t
293	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:42:47.81303	512e833c-ebbe-4e08-9549-504284a9c3ff	2025-08-04 13:44:30.759332	t
294	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 13:44:30.811076	c0ef6397-bab2-4239-b79a-4e3ef14424c4	2025-08-04 13:46:24.708022	t
302	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 14:03:48.713638	9f813aff-3e81-464c-892e-08a862b0a8bb	2025-08-04 14:04:04.026404	t
298	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 13:49:44.628632	69f0e23a-655b-4b6f-920f-31ade9bc14c0	2025-08-04 14:03:14.646003	t
311	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:43:44.849339	63253c5e-7597-4610-8a36-abbbcb4d3cbe	2025-08-04 15:45:27.322553	t
309	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:39:01.585357	2c3770d0-7ef6-4ccf-a787-7af0fdfcb137	2025-08-04 15:41:09.257706	t
299	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 14:03:14.698389	0b801092-53f6-4432-b737-c1f770f91142	2025-08-04 14:03:25.600599	t
303	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 14:04:04.080041	8946e72a-3b50-4a2e-bdb0-1230bca04015	2025-08-04 14:15:32.849375	t
300	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	\N	\N	\N	\N	2025-08-04 14:03:25.652577	b97c057c-b54f-423b-9abe-fe8bbcb1fb69	2025-08-04 14:03:40.208902	t
306	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-04 14:23:00.814866	4904e71b-84cb-4774-8d69-09d6404e1513	2025-08-04 14:23:45.229383	t
304	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-11	\N	\N	\N	\N	2025-08-04 14:15:32.900526	041f4163-399b-4c91-8b45-92e98268d108	2025-08-04 14:22:26.654212	t
314	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-19	\N	\N	\N	\N	2025-08-04 15:46:59.271713	a55141af-40ad-45b0-9884-9b6dff4249ef	2025-08-04 15:47:03.815295	t
310	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:41:09.271777	506e8e21-ce82-4674-b2e2-cfa5ddeb9d17	2025-08-04 15:43:44.795539	t
316	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:50:17.597267	05c79be4-8f03-4039-b5e7-872537e89cc2	2025-08-04 15:50:17.65062	f
313	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-18	\N	\N	\N	\N	2025-08-04 15:46:31.49882	07f1ec6c-1fd2-4a10-9ce1-07f31bddcee4	2025-08-04 15:46:59.203799	t
312	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-18	\N	\N	\N	\N	2025-08-04 15:45:27.376064	6626e172-3f52-453f-91c6-c62bca912e7b	2025-08-04 15:46:31.484889	t
315	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-08-19	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-04 15:47:03.869512	297b23ae-85a9-401e-9c02-9d4545a67fe9	2025-08-04 15:47:19.993851	t
317	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 15:52:12.098456	f63db95a-abc8-46e0-ba00-03ae9e05e87b	2025-08-04 15:52:16.107025	t
319	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:53:24.912442	d592dde7-c95d-4767-a1a3-12ed85242b05	2025-08-04 15:53:24.916105	f
318	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-08-04 15:52:16.158709	df6404cb-ef6d-4f91-bb45-868f039deee6	2025-08-04 15:53:24.882465	t
320	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 07:19:17.59803	3a056b0b-0037-4e48-8864-e17082e111bd	2025-08-05 07:21:02.134379	t
321	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 07:21:02.187348	414be89c-8b03-4e37-82d8-c892b22259ae	2025-08-05 07:21:33.971321	t
307	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	\N	\N	\N	\N	2025-08-04 14:23:45.280958	79519693-19f3-4c7c-a493-c9fccef6b386	2025-08-05 07:48:42.841218	t
275	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	\N	\N	2025-08-04 10:22:40.535573	51de7536-4b76-4503-b8ca-a023020e9fc2	2025-08-07 10:43:56.54845	t
419	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	5999-01-20	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	\N	\N	\N	2025-08-07 13:31:35.993766	9a2dccf8-5f26-41c3-8789-e4890855fdcc	2025-08-07 13:31:52.548263	t
322	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-06	\N	\N	\N	\N	2025-08-05 07:21:34.023395	56b2dead-149d-44e9-a786-5517d679e4ba	2025-08-05 07:21:43.541035	t
421	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 13:35:18.002264	86cf443a-86a6-4ab2-9b86-53d124bbfa96	2025-08-07 13:35:23.702619	t
323	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-05	\N	\N	\N	\N	2025-08-05 07:21:43.554355	c1733f18-4efa-448e-8d18-b02f9aa5e9cc	2025-08-05 07:21:57.258618	t
325	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 07:23:08.880272	128030f1-0759-48d3-a2e2-239f9ac74ec7	2025-08-05 07:23:08.883939	f
327	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	\N	\N	\N	\N	2025-08-05 07:48:52.154466	f1ca1610-e2c7-4874-9e8c-35fde460fb7a	2025-08-05 07:48:55.739915	t
423	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-12	\N	\N	\N	\N	2025-08-07 13:35:29.189453	fb41bf4c-fb35-4504-8b24-3ed21fe51735	2025-08-07 13:39:11.739235	t
328	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-05 07:48:55.833863	efcd81ae-d02c-49ad-8d04-94d85809fbb5	2025-08-05 07:48:58.307896	t
535	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-27	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-15 15:07:44.235553	99076956-0382-4e9e-ad54-a34956ec7572	2025-08-15 15:08:09.78716	t
332	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 07:50:46.142917	af18e71e-be77-4eba-bdac-5ef53193bcf1	2025-08-05 07:51:02.400376	t
425	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-11	\N	\N	\N	\N	2025-08-07 13:40:22.925889	dbd45b0b-52c5-4dd3-8d61-f493fd9200dd	2025-08-07 13:40:32.605136	t
333	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	\N	\N	\N	2025-08-05 07:51:02.452616	55fdb257-1f69-4e51-b81e-ddce7f02c67e	2025-08-05 07:51:19.519863	t
334	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-05 07:51:19.575773	709d06b6-49e7-4085-be71-3859484427cb	2025-08-05 07:52:23.146117	t
469	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-11 07:26:01.67191	9569a9b4-6857-4612-a4d5-54e9ca58dda1	2025-08-11 07:26:20.851981	t
446	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-08 11:14:08.39936	4c21f408-dede-4e4c-a948-3374a8106b26	2025-08-08 11:15:00.920882	t
517	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:50:59.367527	a6c57e61-bae3-4143-b161-2ceeb2ca3197	2025-08-15 12:50:59.370277	f
447	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-08 11:15:00.959831	a752aa4a-06a6-42cc-8527-ef67bae3413f	2025-08-08 11:15:14.143872	t
452	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-08 11:31:45.307038	c3e13c64-f457-4aca-8da9-6dd8465a79b8	2025-08-08 11:32:07.766705	t
520	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:55:24.672071	9e4d2eef-df07-4379-b930-7a6a2543fd9e	2025-08-15 12:55:24.675976	f
459	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	\N	\N	\N	2025-08-08 12:37:33.074569	d148fa8a-c4a8-4b04-9b77-7478efe2d430	2025-08-08 12:38:19.990159	t
472	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-11 10:06:30.425569	c296c2c3-275e-41c5-adcb-d34348813d6e	2025-08-11 10:07:53.53801	t
460	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-08 12:38:20.00435	6e53540e-5dc5-42f6-8ded-a71044d348d5	2025-08-08 12:38:34.485096	t
462	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-08 15:03:57.320307	d0d240f8-afda-428f-a01a-a52797d90257	2025-08-08 15:10:59.309685	t
523	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:58:30.673646	d8f707d7-65b5-4a0c-aae5-8cef7a894d7f	2025-08-15 12:58:30.676582	f
528	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:02:11.058612	e2f75830-f551-4909-ae2c-7c30a6d43391	2025-08-15 13:02:11.061516	f
536	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 15:08:09.839875	552cb87a-b705-4fb0-a6e0-b169b9af0f4e	2025-08-15 15:08:18.604583	t
477	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-18	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 12:54:11.879678	c4d24aae-e13c-44b7-94b7-e3b0e9afcc6c	2025-08-11 12:54:52.844577	t
548	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-26	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-19 10:20:34.5297	815f4d42-dfb8-471a-9646-a821dff4b902	2025-08-19 12:27:23.807066	t
537	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-28	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-15 15:08:18.656591	d22c5475-9e7e-47f4-b674-dbc70ac70144	2025-08-20 12:58:07.442186	t
479	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-18	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 12:55:34.304235	e8b20de8-a7a5-426e-b83c-dcaf479843f1	2025-08-11 12:55:50.310706	t
454	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	\N	\N	\N	2025-08-08 11:32:16.618574	55a69816-3ab2-4055-9192-be16dfd133b6	2025-08-12 14:04:00.502046	t
722	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-19 11:44:12.223331	ea9cfbed-594c-4af5-af39-72d52f75f066	2025-09-19 11:45:33.436473	t
470	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-19	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-11 07:26:20.904622	ad9894a8-ff44-4648-9832-63f3011e6aec	2025-08-13 14:05:06.189194	t
502	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-19	62608399-2245-470d-a950-4eec08632518	\N	\N	\N	2025-08-15 10:55:12.803545	1eac9ff2-f166-4a0e-b2f0-081ee7d30038	2025-08-15 12:16:44.937481	t
505	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:38:53.180561	88ff89ee-70df-4358-93ff-4bc6570d4577	2025-08-15 12:39:52.021176	t
533	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-25	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-15 15:06:25.044878	d6426121-cc50-4b54-b99b-2046469abe3c	2025-08-15 15:07:15.788904	t
506	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-25	\N	\N	\N	\N	2025-08-15 12:39:52.051105	abedbdf1-7b71-4ac8-b7fb-89184f67d452	2025-08-15 12:41:22.351239	t
507	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:41:22.403785	1eba8f9d-d3ae-4662-b491-f1b19609fd6c	2025-08-15 12:43:46.535058	t
509	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:43:46.587747	97ec806d-b6de-4756-a976-b347d4eb612b	2025-08-15 12:45:00.099991	t
534	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-26	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-15 15:07:15.802214	e6c32a0b-0eda-4ceb-96b4-96174af879c8	2025-08-15 15:07:44.22204	t
544	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-25	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-19 10:16:41.262758	988aa05d-536a-4f95-abf1-6d3184d7d641	2025-08-19 10:18:18.752461	t
545	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-25	\N	\N	\N	\N	2025-08-19 10:18:18.812263	648c9e61-23a0-4b9c-a480-894792f2b4fd	2025-08-19 10:19:41.037722	t
474	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-11 10:09:38.902381	0530c189-fe74-4be3-bb3b-8ee7d36970bd	2025-08-11 10:09:38.905385	f
324	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-06	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 07:21:57.309186	23b3fd1f-f145-4a25-bae5-37e05dbda99c	2025-08-05 07:23:08.821888	t
329	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	\N	\N	\N	\N	2025-08-05 07:48:58.320315	146e147d-c16e-4c7a-a80d-6d34665cc6b9	2025-08-05 07:49:12.548858	t
524	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:59:31.333021	ec5da895-cc17-4748-8300-b19f4a1bea6b	2025-08-15 12:59:31.336566	f
428	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-08-13	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-07 13:41:06.916467	24a3937c-805f-459d-b11b-366491ca5787	2025-08-07 13:41:43.151397	t
330	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	555a86cd-0550-42d7-b085-92842c89ee90	\N	\N	2025-08-05 07:49:12.600408	190337ca-8918-4648-bc28-adf7629342e3	2025-08-05 07:49:45.420312	t
521	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:57:06.540287	187763ab-ca63-4bc6-b894-8a0b3398e99b	2025-08-15 13:01:55.626381	t
448	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	\N	\N	\N	2025-08-08 11:15:14.159357	8e991f15-94b8-4534-8455-526f2e3c687b	2025-08-08 11:15:28.574036	t
529	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:03:38.530354	675477e6-4ff5-4b6f-9f5d-dd39415556d4	2025-08-15 13:05:00.22375	t
331	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-05 07:49:45.511278	195525c0-da9b-4532-99a6-590713979076	2025-08-05 07:50:46.1288	t
475	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-08-18	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-11 12:18:34.347089	4d31aeef-9102-43ec-a76c-8d92e4e95dbd	2025-08-11 12:54:11.820056	t
478	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-08-11 12:54:52.856918	575557e9-7bb1-4b8a-a340-2b88d95c01fc	2025-08-11 12:55:34.251815	t
538	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-18 10:23:25.068452	e91ee468-e357-4dd9-8e20-5756f636a2f2	2025-08-18 10:23:37.453511	t
539	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-18 10:23:37.466471	a181ce18-acf5-4e89-809e-48181ac4c574	2025-08-18 10:23:46.187515	t
449	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-21	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-08 11:15:28.626766	06e1ae4f-6965-411b-8c91-fdb2836818c8	2025-08-08 11:20:05.241097	t
542	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-18 10:28:19.273127	7bed6bba-875c-4e47-899c-349f9e9eed11	2025-08-18 10:35:55.213714	t
453	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	\N	\N	\N	2025-08-08 11:32:07.833761	710480a5-e177-4ae9-bf51-0290afe9c87d	2025-08-08 11:32:16.606641	t
504	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:38:08.119314	951794d9-f068-4f4c-a42c-bfed7dc0bb05	2025-08-15 12:38:08.123341	f
503	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-19	4d590629-d027-4034-8863-07a0127678be	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-15 12:16:44.951222	b6187751-9b45-42ac-a83f-29f4515fa728	2025-08-15 12:38:53.126636	t
455	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-08 12:08:56.237717	84d877d6-8419-4bfa-a66f-03559b9278f9	2025-08-08 12:10:35.15931	t
457	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-08 12:11:01.098871	ab8f2f72-d58f-4635-b4a8-a5370800f23a	2025-08-08 12:37:05.723698	t
543	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-26	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-18 10:35:55.272775	5b6bd318-f50c-4a37-8e72-f7882afe6a07	2025-08-19 10:16:41.210107	t
461	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-08 12:38:34.536922	f3682984-112b-4df2-804a-eda741dfe913	2025-08-11 07:09:39.91351	t
511	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-27	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-15 12:45:46.85925	a6ca156f-9cf9-4216-9577-e55b4211a938	2025-08-15 12:46:22.794133	t
510	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:45:00.152403	a1690bd0-2d31-4657-8ed1-798229216ebc	2025-08-15 12:50:18.293063	t
516	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:50:18.306245	59fae309-d99b-4463-b113-9ca9247b58cb	2025-08-15 12:57:06.52738	t
345	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-08-05 10:35:49.33349	efb33808-599d-4a8c-9563-a4e66c73427b	2025-08-05 10:36:30.699153	t
326	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-05 07:48:42.893803	355fd354-db14-4efc-9546-087fad5ecc33	2025-08-05 07:48:52.104042	t
387	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	\N	\N	\N	2025-08-07 07:57:31.044047	839f8f80-8b6f-4622-be76-5b75d16094c2	2025-08-07 08:26:36.365483	t
346	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:36:30.752112	39ef7647-c55f-453d-aaed-0517e801c1ff	2025-08-05 10:38:15.1627	t
368	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-08-06 11:43:18.45008	3eca3624-d265-47d5-822e-b50f8529ced9	2025-08-06 11:49:15.439776	t
347	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:38:15.215736	e9141344-0445-49f0-a87e-76a40e504346	2025-08-05 10:39:39.667943	t
348	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:39:39.719358	846298fb-4da6-4b00-88a4-6d1c92f1e14d	2025-08-05 10:58:06.87634	t
335	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 07:52:23.197921	a5fb86e9-768b-4140-9add-c209ad8cd143	2025-08-05 07:53:26.763005	t
375	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-07 07:51:21.916669	9ecbf555-4d75-44b6-9fe2-7afc7d3f89ad	2025-08-07 07:51:51.346874	t
349	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:58:06.889963	b56a0026-80b2-4653-8da8-4f8468030f14	2025-08-05 11:05:41.715277	t
350	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 11:05:41.772273	98d50245-8305-4ddb-a9db-aea07367aef8	2025-08-05 11:05:41.776031	f
336	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 07:53:26.815745	c0c2d257-7862-495c-8057-e2a835bd8eed	2025-08-05 07:54:53.538312	t
358	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-08-06 11:34:02.062497	ca1afc10-cdf2-4c79-807c-d5d1baf2338f	2025-08-06 11:34:28.999241	t
351	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 11:19:37.768799	d614b803-5d33-481f-b57f-4a031b3c19bf	2025-08-05 11:28:33.961922	t
369	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-08-06 11:49:15.498376	fdb1d514-bae8-4ca7-9645-d4365e3fb373	2025-08-06 11:49:22.340521	f
359	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-06 11:34:29.012665	42dffcce-ab2c-4ff0-8f34-7919e06f213d	2025-08-06 11:34:45.810426	t
338	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-08-05 10:21:07.306129	d26ec0eb-2f03-4f32-845f-ab84e453d43c	2025-08-05 10:21:29.737142	t
352	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 11:28:34.015503	3fa4bdaa-96e2-4556-80b1-c47cfc701fb0	2025-08-05 11:31:00.26661	t
357	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-06 11:33:52.522695	018db9e0-7eea-4306-a693-0f41e52594fe	2025-08-06 11:37:25.992283	t
339	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-14	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 10:21:29.787589	f940ddc4-ea4f-4933-adae-b83234be1e06	2025-08-05 10:22:02.624778	t
353	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-05 11:31:00.279062	97a0bd7d-3cf0-49c4-9ee0-3e2d7cbf31ae	2025-08-05 11:32:17.196802	t
381	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-08-07 07:55:20.209878	f19975bd-c990-4f4f-ad69-26748c018ec6	2025-08-07 07:55:56.535153	t
376	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-07 07:51:51.359561	23b75766-cb4b-489c-9323-0a273e6b9693	2025-08-07 07:54:00.724993	t
361	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	\N	\N	\N	\N	2025-08-06 11:37:26.04385	147917f8-3363-46c2-81d0-64cbaa1a07e5	2025-08-06 11:37:30.524662	t
341	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:26:16.089212	eb62a7e9-d8ab-4bbf-b198-07b9e5989993	2025-08-05 10:26:16.09237	f
340	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-05 10:22:02.675859	e1e9a664-f782-40ea-9f9e-94e441df764a	2025-08-05 10:26:57.653855	t
354	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 11:32:17.249097	a1489882-99d5-454b-88b7-5326e8717526	2025-08-05 11:32:38.188171	t
342	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:26:57.668742	2735d4ba-499f-429a-bfd7-2a93f24b3ba1	2025-08-05 10:29:30.010777	t
343	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:29:30.062129	2039ee9d-c79f-4cfe-8e71-961e0b8a49c3	2025-08-05 10:31:21.815667	t
370	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	2ae252e7-ff77-4445-9bba-4f12636a2234	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-08-06 12:21:42.2791	02ceb332-0ac0-4cef-9bc9-d345084b30b3	2025-08-06 12:22:17.231065	t
344	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-05 10:31:21.873474	d351e7c3-9022-4a20-ac56-caebfca069d0	2025-08-05 10:35:49.310059	t
403	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	\N	\N	\N	2025-08-07 12:02:43.216308	a7504448-5fe7-4538-8b73-065ae5938269	2025-08-08 15:03:57.268152	t
355	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-06 11:30:51.806415	44884966-48f9-43d8-b843-4dc206152676	2025-08-06 11:31:09.284215	t
363	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-06 11:37:55.251126	7b4487f8-322a-4d5c-be57-727396e90171	2025-08-06 11:39:14.335802	t
337	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-13	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-05 07:54:53.568636	299f67f2-14cc-4b89-8ee8-3d79b520e3c3	2025-08-06 11:33:52.471063	t
364	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-06 11:39:14.348337	9ca7fb02-a8f3-48d6-baab-ef10d2a4f568	2025-08-06 11:39:50.711932	t
371	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	\N	\N	2025-08-06 12:22:17.259082	f6449c55-a160-4406-930a-5de429463cb6	2025-08-06 12:22:36.746885	f
356	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-08-06 11:31:09.337206	c4f22975-55e3-403c-b4b0-c1d5ea2775b6	2025-08-06 11:34:02.031247	t
365	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-06 11:39:50.725598	46907608-1992-4d4a-a628-90709b3d559d	2025-08-06 11:40:59.590561	t
385	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-07 07:57:09.73339	392d413a-2db5-4f3e-a624-e00deb4266f6	2025-08-07 07:57:21.736626	t
366	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-06 11:40:59.649734	7e35c465-3446-458f-92ea-e5428f263d60	2025-08-06 11:43:07.07067	t
377	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	\N	\N	\N	2025-08-07 07:54:00.73698	93755319-fb03-4fba-9731-1bee321239da	2025-08-07 07:54:19.035872	t
372	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-07 07:49:46.075252	35fe892b-d94c-42e2-9cfa-cb94c0640f00	2025-08-07 07:50:23.11625	t
367	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-12	\N	\N	\N	\N	2025-08-06 11:43:07.08499	b0987075-d7c8-4111-8e96-f59032e7cce3	2025-08-06 11:43:18.396368	t
378	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 07:54:19.089338	18e722b1-a206-419c-9bb2-1be598c240a9	2025-08-07 07:54:44.391343	t
373	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-08-07 07:50:23.130901	e12d9410-116f-4a22-92e8-ab5552b5ead8	2025-08-07 07:51:02.594278	t
382	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-07 07:55:56.586259	6755d089-3922-4dbf-b23d-5fd3a7ebd610	2025-08-07 07:56:40.165253	t
374	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 07:51:02.64624	94994381-b941-4f8f-bf67-4172542bca7d	2025-08-07 07:51:21.866259	t
388	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 08:26:36.417145	25bff216-069f-468e-b405-1e9dd4e4eb06	2025-08-07 08:26:36.4208	f
379	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-07 07:54:44.420283	d1167f8e-cb1c-4a1c-9acd-73a326c8a278	2025-08-07 07:55:05.357325	t
383	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 07:56:40.228737	8996d35e-35c4-4501-b636-26424e4c3733	2025-08-07 07:56:56.135022	t
380	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 07:55:05.408173	aa1edded-6b85-4dfa-9464-11cc5c54d053	2025-08-07 07:55:20.152075	t
386	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-08-07 07:57:21.765563	9e2b53dd-357c-464f-aeae-71f14835c578	2025-08-07 07:57:30.991897	t
384	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-07 07:56:56.188785	bfc6ae55-8195-4192-af6f-f02141838827	2025-08-07 07:57:09.719753	t
391	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-07 10:43:26.188712	a1a120de-9fe9-4849-a548-72c4e17779ac	2025-08-07 10:43:55.097618	t
390	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 09:51:17.41218	6bf5c82d-09da-4f7d-8c9e-6c9a7151b9a1	2025-08-07 09:51:23.642485	f
389	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-07 09:51:01.382544	29ab7020-5c8c-41a2-bdce-6b8f3716a5b5	2025-08-07 09:51:17.361301	t
398	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	\N	\N	\N	\N	2025-08-07 11:46:30.868161	fc53a416-b5a3-4a71-8427-76f3d45e34ec	2025-08-07 11:47:43.78232	t
394	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 11:28:41.229241	5baec568-eb00-4e01-985b-81669a8919cd	2025-08-07 11:30:22.536768	t
395	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 11:30:22.549622	cfeeb88f-ffc0-44bc-8d45-cdd749745c28	2025-08-07 11:42:49.931452	t
396	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-07 11:42:49.962591	ef81d537-c738-4eb7-b903-c0f908bdc41b	2025-08-07 11:44:23.412978	t
392	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 10:43:55.110419	97641954-a7af-4fe0-98a7-64e5cc8214f1	2025-08-07 11:46:30.816164	t
397	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	\N	\N	\N	\N	2025-08-07 11:44:23.464945	e11c1a93-53ea-498b-b3b3-a3e4132cd82d	2025-08-07 11:44:30.736771	f
399	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	\N	\N	\N	\N	2025-08-07 11:47:43.836272	4c655125-6d15-4697-9b9f-c73e51a4f031	2025-08-07 11:47:47.22	f
508	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:43:07.688114	5c3fa417-0040-4131-a6ec-fd813bc7d508	2025-08-15 12:43:07.692177	f
393	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 10:43:56.601111	09526f83-5ee4-47fa-b3eb-6c27437dea51	2025-08-07 12:02:08.968334	t
512	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:45:57.7092	8f011191-f0b7-4375-9413-719a2f749077	2025-08-15 12:45:57.71265	f
400	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 11:49:35.28777	6c6dc2fd-e181-4c98-a5de-c757c1578df1	2025-08-07 11:51:34.948086	t
401	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 11:51:34.960999	28b33084-4d2e-4eb4-affa-9f35c7bf46ca	2025-08-07 11:51:50.916498	f
480	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-19	f70dda6c-3b1c-4248-bc15-93aefba973bb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-11 13:27:36.578735	d24e11ca-e5cd-4289-8e3f-3ac9ba7dc893	2025-08-11 13:27:57.950877	f
406	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	\N	\N	\N	2025-08-07 13:11:30.993919	3627f092-b9ca-4160-bc67-5f22fa3072a9	2025-08-07 13:14:14.405485	t
430	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-13	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-07 13:43:13.909807	5fa7d27c-d377-4bb7-9846-8a1dae6aee54	2025-08-07 13:44:01.553318	t
407	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 13:14:14.458345	0a5aa18f-c81c-4142-ba58-b568f9210803	2025-08-07 13:15:25.41834	t
408	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	b6387178-b0f0-4227-afae-44d21dc68b1e	\N	\N	\N	2025-08-07 13:15:25.471259	7de5b9d0-bc80-4f49-89b0-4654d0ba8668	2025-08-07 13:16:06.131854	t
483	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-12 14:05:32.656688	0df3276e-f223-4731-a222-9a3ab6007d49	2025-08-12 14:08:05.552225	t
435	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-14	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-08 09:40:49.047988	4709ee9a-fd12-4161-8b91-9eb60cf98f5b	2025-08-08 09:53:28.216638	t
484	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-12 14:08:05.60443	464887c6-10c5-4511-b733-d063c99edc98	2025-08-15 12:45:46.845272	t
412	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	\N	\N	\N	\N	2025-08-07 13:19:58.478064	694bea4c-ce65-42ca-9ef9-09127887b3b8	2025-08-07 13:19:58.481815	f
411	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-13	2ae252e7-ff77-4445-9bba-4f12636a2234	\N	\N	\N	2025-08-07 13:17:20.191109	01621a69-c1a4-4583-b90a-0e1afcc0d24c	2025-08-07 13:22:35.279667	t
450	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-08 11:20:05.29252	ab28c0e0-f44e-47ee-a08f-a1a300648754	2025-08-08 11:31:05.152891	t
513	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-28	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-15 12:46:22.813267	a9e4aab6-ea54-448b-be02-07ea0175f9fc	2025-08-15 12:47:00.944359	t
514	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-28	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-15 12:47:01.005088	348aedc5-baa5-4651-b4f2-ebac4f5dfb1c	2025-08-15 12:47:38.654379	t
518	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:52:16.801977	19041fd4-d63d-49a8-bbcb-89cb411762f8	2025-08-15 12:52:16.80584	f
522	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:57:38.1991	48fe9037-05f4-4cac-892d-41b0b949b7ef	2025-08-15 12:57:38.203095	f
525	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:00:24.104974	9dce0964-f86d-4fc7-9ead-62652324f183	2025-08-15 13:00:24.107996	f
549	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-19 12:15:45.56644	90bf5482-6c63-4311-b20f-a545240b0b2f	2025-08-19 12:19:05.590173	t
554	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-26	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-20 12:58:07.494046	0188e0dc-dc4b-4565-8aaf-daee3a4ed3a7	2025-08-20 13:32:27.664808	t
555	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-26	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-20 13:32:27.701767	744f0f23-2523-403b-9c9d-c62eaa08470b	2025-08-20 13:33:59.80233	t
402	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	2ae252e7-ff77-4445-9bba-4f12636a2234	\N	\N	\N	2025-08-07 12:02:08.998238	4d5a201f-702a-4df8-96ff-75ef40474464	2025-08-07 12:02:43.161976	t
417	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-11	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 13:26:39.503311	50c99c96-fafc-4227-b0aa-bbc9e4339156	2025-08-07 13:28:08.046614	t
456	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	\N	\N	\N	2025-08-08 12:10:35.172689	134979f1-3b5a-4b31-8f12-873ba63ddd0d	2025-08-08 12:11:01.039444	t
501	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-20	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-14 12:40:15.637621	122d7119-7b44-4224-816f-d4205046f8a0	2025-08-15 15:06:25.002474	t
404	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 13:10:05.442737	e706a380-f970-4b79-b446-14ef48aea953	2025-08-07 13:11:09.61075	t
458	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-08-08 12:37:05.780377	d02e490d-2583-4bbe-a918-4079f05319f2	2025-08-08 12:37:33.022497	t
431	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-08-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-08-07 13:44:01.569374	3bb52ad5-a49f-4aa9-9baf-b1308e24135f	2025-08-07 13:51:21.608941	t
550	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-19 12:19:05.641588	158e4c5d-d8a3-4d16-937b-406166894819	2025-08-19 12:19:05.645328	f
405	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-13	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 13:11:09.662396	d6dff781-4970-479e-98c2-6b6578987272	2025-08-07 13:11:30.942701	t
495	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-18	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-13 12:39:20.016912	23123fcb-c1cf-4e5c-9d06-203d32a44e39	2025-08-13 12:40:10.566367	t
409	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-11	2ae252e7-ff77-4445-9bba-4f12636a2234	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-08-07 13:16:06.185904	c0a8279f-06c9-4a91-b644-162f0e795607	2025-08-07 13:16:27.985419	t
432	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-08-14	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-07 13:51:21.663022	2b38e621-1aca-42fa-8045-1db6e8e4c517	2025-08-07 13:53:08.863654	t
362	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-08-06 11:37:30.575137	b63574fc-ba9b-4493-86ca-3b580972b0f2	2025-08-08 09:40:48.995279	t
410	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	\N	\N	\N	\N	2025-08-07 13:16:28.048828	d0a3961d-3653-4a0f-99e9-2229b437c045	2025-08-07 13:17:20.139143	t
413	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-08-11	\N	\N	\N	\N	2025-08-07 13:22:35.332931	c670da7d-d22f-4704-ac9b-2a07b7ddd46e	2025-08-07 13:22:43.173491	t
481	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-12 14:04:00.516459	6de44ba0-92f9-448e-b3a7-93be89bb9770	2025-08-12 14:05:08.258066	t
485	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-08-13 12:16:44.051126	9dceaedd-ed09-48b4-b36c-0778ab551914	2025-08-13 12:19:29.763937	t
437	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-12	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-08 10:08:41.033499	4376ae29-319c-4ef5-87c3-06a16312569d	2025-08-08 10:27:34.022391	t
414	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-08-11	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-07 13:22:43.224781	5c323d5e-b79e-454b-b750-49eb83982c8a	2025-08-07 13:24:21.332835	t
439	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-08 10:53:01.211237	6bcd3b1e-ab78-4a51-be83-2154d024de34	2025-08-08 10:53:01.264498	f
415	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-07 13:24:21.354833	2897eda8-023f-41e1-926d-b4fe0099fdcc	2025-08-07 13:25:01.996649	t
496	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-18	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-13 12:40:10.579103	0612d79e-0e87-40c8-8092-6ee32888cd59	2025-08-13 12:40:38.450573	t
487	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-08-13 12:22:11.548691	f6185c31-022f-49a2-b729-f97beb99af87	2025-08-13 12:23:17.809078	t
416	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	7b74a6a1-d92b-476a-befc-0783a20e9170	\N	\N	\N	2025-08-07 13:25:02.012339	524ee7dc-6000-40ac-93bd-cee62fc7b068	2025-08-07 13:26:39.450759	t
463	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-08-19	\N	\N	\N	\N	2025-08-08 15:10:59.324232	0fd4b11d-8534-48ac-9c94-aa7d146b7d7f	2025-08-14 07:58:34.723316	t
440	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-18	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-08 11:06:21.603549	b6535cbe-1af2-4bcc-9005-3319d6782722	2025-08-08 11:07:22.948947	t
498	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-14 07:58:34.776479	d79921e4-6e34-4c39-9ca0-5f6674a215f3	2025-08-14 07:59:14.31685	t
441	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-08 11:07:22.977573	1a997869-20d1-4f88-8946-1b1121148f30	2025-08-08 11:08:17.339078	t
489	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-08-19	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-13 12:24:21.945995	9ac99ca5-a0a7-4231-9979-4faaef55d287	2025-08-13 12:32:32.626727	t
451	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	\N	\N	\N	2025-08-08 11:31:05.204817	07c1e6f0-8e43-4155-b46b-7d345777f1bb	2025-08-08 11:31:45.257465	t
443	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-08-08 11:10:12.961177	144f967c-1a6a-48e3-9123-358dcdfb9217	2025-08-08 12:08:56.184068	t
499	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-14 07:59:14.370954	4392ef0b-2cbf-4ca4-8ad1-049817a30ba0	2025-08-14 12:39:27.295698	t
500	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	2ae252e7-ff77-4445-9bba-4f12636a2234	\N	\N	\N	2025-08-14 12:39:27.347587	cb58c903-252d-48f9-a7bb-aac9c7d267e0	2025-08-14 12:40:15.60698	t
492	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-08-19	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-13 12:35:17.069333	14fe8221-aee4-4e69-8bb2-1e7696a7d46d	2025-08-13 12:37:23.919798	t
552	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	\N	\N	\N	2025-08-20 08:30:04.811907	eab8e19b-ca8b-4e3c-8119-4dfa185dc7f7	2025-08-20 08:31:55.062623	t
519	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 12:53:48.914018	b25c6538-8745-4f9b-b03b-bf23323c3b8e	2025-08-15 12:53:48.91783	f
526	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-15 13:00:52.043642	607f64ae-f17b-4f41-992e-921ff71910eb	2025-08-15 13:00:52.047215	f
561	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-22 13:27:16.354656	f38f097a-437b-414e-844b-b8cd4f8822c8	2025-08-22 13:27:16.367012	f
560	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-01	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-22 13:26:06.605545	590abf0c-e11a-481a-811c-e1f43c937968	2025-08-22 13:29:19.324561	t
570	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-25 06:52:18.70224	478e569c-0424-4831-9264-6c3456652aff	2025-08-25 06:54:30.593153	t
556	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-08-26	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-22 07:21:56.959119	83ba03a2-0b37-4cf2-b415-ab303b0b65d6	2025-08-22 07:22:07.808249	t
551	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-19 12:27:23.858653	d6f88deb-6be3-4bcc-89f2-27577fd63c5f	2025-08-22 08:46:30.013593	t
565	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-01	3893f977-8f70-49be-903b-ed0149e4a505	\N	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-22 15:31:01.285069	14b15036-6bb8-4cf8-a866-99a3f678fc63	2025-08-22 15:31:17.191711	t
562	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-22 13:29:19.338427	5b1fbbb5-7413-46e5-afa9-ba2593bbf32a	2025-08-22 13:29:35.870761	t
557	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-25	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-22 08:46:30.027836	910e989b-cc2c-4e1d-9af8-82fd6a07aa1b	2025-08-22 08:48:13.406126	t
579	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-01	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-29 07:48:39.746191	5f95b5fb-94aa-40e3-aa90-c42ece828df6	2025-08-29 07:49:45.221271	t
576	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-25 12:37:30.667107	0046dfd1-2568-4e84-8eb1-2e3b9d7b124e	2025-08-25 12:38:01.726785	t
563	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-01	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-22 13:29:35.923258	e00e1e86-4d4d-49a1-adb2-27ded978134a	2025-08-22 13:29:58.288073	t
558	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-08-26	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-22 08:48:13.459974	3a6d89c2-bfdf-4b01-b375-738b1fa21e89	2025-08-22 11:42:24.906284	t
559	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-08-22 11:42:24.960227	806f55c1-f9a6-47a9-827f-4ba1c8c891b9	2025-08-22 13:26:06.587047	t
572	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-01	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	\N	\N	2025-08-25 07:40:52.267932	a7b5cb8e-b673-4cb1-8b93-e8f00e97d783	2025-08-25 07:40:59.436934	f
571	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-25 06:54:30.625855	8b60d1f8-7fb8-4772-9629-e387c565e069	2025-08-25 07:51:25.830801	t
567	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-03	\N	\N	\N	\N	2025-08-25 06:50:20.682951	a6533355-47fc-40dd-800a-7bb0739994a3	2025-08-25 06:51:25.080936	t
564	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-01	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-22 13:29:58.340184	8784fc98-a36c-4378-bacc-2e20d4527e7c	2025-08-22 13:30:16.57228	t
515	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-08-27	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-15 12:47:38.67826	d9187161-0a84-4243-a596-90d45329a76c	2025-08-22 15:31:01.231448	t
568	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-03	\N	\N	\N	\N	2025-08-25 06:51:25.094982	d654b803-d73b-48c1-b7ad-d6cf1dc942c2	2025-08-25 06:51:40.424981	t
582	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-09-01	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-29 07:51:18.672871	b97c9cb1-b9d4-46bd-b473-81f7846bd234	2025-08-29 07:52:43.942151	t
569	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-04	\N	\N	\N	\N	2025-08-25 06:51:40.4821	03c935d1-a143-49df-a534-ee56ef048aad	2025-08-25 06:52:18.68087	t
581	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-09-01	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-29 07:50:39.78608	82f79515-916f-459f-ae51-9829ac88b761	2025-08-29 07:51:18.619117	t
577	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-08-25 12:38:01.779937	2ce7fc6a-fcd4-4b8d-86e1-268928b25f94	2025-08-25 12:38:07.197848	f
574	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-04	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-25 07:51:54.22404	3bb4ac67-2c65-4032-9280-a0b304c932d4	2025-08-29 07:39:42.584575	t
573	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-03	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-25 07:51:25.885898	67b9dc7f-f5aa-4976-a7e2-9fbf10a1fe37	2025-08-25 07:51:54.168263	t
575	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-09-03	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-08-25 12:32:10.771566	11ae55c0-2a40-45b3-afce-2844e06039e1	2025-08-25 12:37:30.638442	t
580	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-09-03	4d590629-d027-4034-8863-07a0127678be	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-29 07:49:45.274038	17b4d1fb-1787-4c7e-8b7b-922d1ea980f1	2025-08-29 07:50:39.72485	t
585	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-02	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-29 08:02:16.848535	6fb12437-c848-439f-9e92-d78525a7fa99	2025-08-29 08:02:46.953676	t
583	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-01	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-29 07:52:44.006868	2baa4cbb-10d9-4a0a-8b51-a241f3390863	2025-08-29 07:53:42.229735	t
584	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 07:53:42.283176	652a3a0c-2df0-4d4c-aa5a-56ec6367f540	2025-08-29 08:02:16.795482	t
586	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-01	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-29 08:02:47.003779	e1e9777b-fa91-473a-b874-ea3602cdafd3	2025-08-29 08:03:18.449144	t
587	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-02	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-29 08:03:18.50047	3160d778-2faa-432f-bd74-1e22e823a40e	2025-08-29 08:12:10.350859	t
588	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-02	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:12:10.380067	2feff239-7a5e-4618-a7ba-e2e29c1c2718	2025-08-29 08:13:16.823691	t
578	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 07:39:42.598295	b77a76d7-22d5-4de7-8505-6eb8c431718c	2025-08-29 11:20:14.325894	t
727	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-09-22 08:35:32.827084	abfe4bda-2159-42da-80c3-85d3d69a2bf3	2025-09-22 08:36:22.118918	t
589	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-03	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:13:16.876911	2f58a5b6-1abe-4196-8961-bc777630f298	2025-08-29 08:16:48.029794	t
597	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-03	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:27:37.909319	794a7319-67ca-4d8b-9006-56c3561d365f	2025-08-29 08:29:33.944548	t
621	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-09-01 10:32:49.076471	7419930b-f745-4c36-965e-897dc905dac1	2025-09-01 10:33:36.256154	t
590	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:16:48.043851	d7061abd-b701-4a30-90e7-e00659842b29	2025-08-29 08:21:33.292739	t
604	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-09-03	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	\N	\N	\N	2025-08-29 12:51:23.906484	07bad132-b23b-40bf-8241-785bf431bbd8	2025-08-29 12:51:41.819742	t
591	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 08:21:33.346463	5c12964d-e725-4746-834d-b0e3604d2582	2025-08-29 08:21:37.802405	t
634	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 15:03:02.858541	f9e514ac-7c23-46fa-8da4-136b6abbef0a	2025-09-02 15:04:01.67065	t
598	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-03	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:29:33.998272	edbfd25b-7d92-4b5b-bbfd-3492a3d23456	2025-08-29 08:31:32.346381	t
592	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:21:37.815213	baa94dfe-e2ea-4d5b-9df6-9f65067d8764	2025-08-29 08:22:02.138839	t
632	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-15	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-09-02 10:19:22.268794	18f16005-0e64-466a-8b94-49780785b49c	2025-09-02 10:21:39.836514	t
618	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-09-04	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-29 14:14:52.95195	56f0cdbf-dcb5-4edb-b1ca-4521ea505b22	2025-08-29 14:18:35.298709	t
610	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 13:11:08.218641	ddf042de-f9f3-4f2d-b599-59cb0326a15f	2025-08-29 13:11:21.502058	t
605	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-09-03	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-29 12:51:41.833339	0fa6e247-2127-4e61-9e75-61af936550ec	2025-08-29 12:52:06.557094	t
593	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-04	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-29 08:22:02.1946	84428908-8dda-4f70-9ecb-85e9ae14e287	2025-08-29 08:22:20.096565	t
603	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 11:20:14.380378	d7e89e39-5803-4eb2-8137-559c515ecfa6	2025-08-29 13:19:47.266918	t
612	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 13:19:47.320652	ef0ca439-63a1-4637-ac38-e9c3b02c8c34	2025-08-29 13:51:52.331214	t
594	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-04	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-29 08:22:20.125669	7fdc1380-b1d5-49db-b9d0-d93476d1d660	2025-08-29 08:25:24.465325	t
606	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-09-04	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-08-29 12:52:06.610784	c0b6cfdb-b6f2-4b58-8982-440ef2a77d39	2025-08-29 12:55:17.168783	t
599	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:31:32.370851	718d78ca-dda0-4d33-be67-2104955db196	2025-08-29 08:38:21.470063	t
622	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-09-01 10:33:36.284703	49852217-5a7e-445b-83d7-c93cc6615e68	2025-09-01 10:34:04.492015	t
611	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 13:16:05.746496	25d51f4a-7ae2-460d-a338-c49272baef60	2025-08-29 13:57:56.718727	t
595	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-04	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	\N	\N	2025-08-29 08:25:24.518932	54011757-4d32-4826-aa77-52ca2fabd201	2025-08-29 08:26:52.823869	t
614	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 13:57:56.77294	67ccea82-e98c-46a0-b54c-594664c414eb	2025-08-29 14:05:58.306739	t
600	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:38:21.522583	73cd9e69-49ea-471a-a1a7-2f0bf21b9e84	2025-08-29 08:39:52.083979	t
607	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-02	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-29 12:55:17.228395	b577480d-da48-460f-94de-c78804cafcd3	2025-08-29 12:56:03.283214	t
615	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 14:05:58.359137	d4bcc22a-bba8-4779-9874-c7872591c067	2025-08-29 14:06:54.863375	t
596	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-04	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:26:52.837172	e1ac80d2-eeb1-4653-85d1-06392ad4c6e8	2025-08-29 08:27:37.85826	t
601	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-03	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:39:52.138286	f3cc868c-4812-4a8a-86e9-ec46deb5e882	2025-08-29 08:40:15.558133	t
623	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-09-01 10:34:04.506446	69389ded-c49a-4725-bf21-cb3a75d6faf2	2025-09-01 10:34:55.758158	t
619	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-09-08	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-08-29 14:18:35.352766	ac50dcd4-a5f3-4219-be4a-dcd789c55123	2025-08-29 14:19:03.378474	t
608	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-03	e40964e1-8934-428e-a06e-18379a30ebae	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-08-29 12:56:03.335159	1f7a7742-285e-4beb-9c2a-74a1537d43d9	2025-08-29 13:01:34.230708	t
613	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-08-29 13:51:52.385183	bfe693c8-68df-46c5-8aab-001d21e2d1ef	2025-08-29 15:12:06.051711	t
602	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-04	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-08-29 08:40:15.610162	2ff1e779-5663-4977-9c45-7ea9d02b418d	2025-08-29 08:40:35.06947	t
628	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-09-02 10:05:11.545493	475fca77-c406-4969-9ebe-d081fc939cad	2025-09-02 10:15:05.93036	t
616	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-09-01	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-08-29 14:06:54.877497	46aac088-917b-42b0-b9e9-1af51f36e79f	2025-08-29 14:10:50.828076	t
624	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	\N	\N	\N	2025-09-01 10:34:55.775974	5788c136-b07c-46e1-bde3-13919b15c7f1	2025-09-01 10:35:11.428853	t
609	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-02	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-29 13:01:34.284311	8b96f8f2-e150-4d8e-96c8-86104e128caa	2025-08-29 13:11:08.164581	t
638	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-09-16	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-02 15:07:47.004965	f8f21d93-450b-452e-b635-11c235471ce3	2025-09-02 15:08:47.366493	t
617	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-09-02	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-08-29 14:10:50.887559	2ba045f7-d7a0-4090-b86d-3344d48aeb62	2025-08-29 14:14:52.887203	t
629	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 10:15:05.983985	61daff8e-5c3f-4db0-8dcd-c7583df30765	2025-09-02 10:15:26.902069	t
625	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	62608399-2245-470d-a950-4eec08632518	\N	\N	\N	2025-09-01 10:35:11.483713	6ee24c99-f53a-4546-b9e7-0b259f646340	2025-09-01 10:35:20.589539	t
631	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-09-15	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-02 10:16:28.065823	9626b0fa-2095-419a-a216-bf915a721970	2025-09-02 10:19:22.214657	t
626	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	f70dda6c-3b1c-4248-bc15-93aefba973bb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-09-01 10:35:20.641821	baf82cc0-5a7a-4e90-8006-84c207ef351d	2025-09-01 10:38:29.911823	t
639	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-09-15	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-09-02 15:08:47.387521	a58468d4-63f9-456b-a198-005777cb74ff	2025-09-02 15:11:16.540559	t
637	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-02 15:07:24.06387	8ba26e92-02d4-4c45-8f38-3df940592430	2025-09-02 15:07:46.99253	t
627	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	f70dda6c-3b1c-4248-bc15-93aefba973bb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-09-01 10:38:29.926287	b9e0c606-65e8-4f01-a982-56572ea448d8	2025-09-02 10:05:11.49023	t
630	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-09-15	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 10:15:26.955404	90775395-9b8c-4ede-8629-27c5a1ae0cfe	2025-09-02 10:16:28.012843	t
633	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-02 10:21:39.889659	93e20383-8069-4b94-8ff1-2a96f88f18a1	2025-09-02 15:03:02.804634	t
636	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-15	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 15:05:18.351595	31fefa3f-01c6-47e2-9c86-68cf47483b28	2025-09-02 15:07:24.010364	t
635	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-15	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-02 15:04:01.685446	219809be-2e7c-479e-b6d7-09b248afe339	2025-09-02 15:05:18.297446	t
641	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-02 15:13:11.76046	5dca0584-b260-44f6-b5b9-0084424ad884	2025-09-02 15:14:40.614837	t
640	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-18	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-09-02 15:11:16.554748	bb647e54-bf44-4bf6-b8bf-156707454a5d	2025-09-02 15:13:11.708169	t
645	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 15:19:28.068186	316aefba-26df-441e-97ec-96b4cfb7395e	2025-09-02 15:19:28.071257	f
642	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 15:14:40.667387	2cdcbd4f-5704-4307-b742-98afa44b4468	2025-09-02 15:15:16.90746	t
644	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 15:16:45.304102	de534e4c-5a98-4ea8-82be-615d42fd6058	2025-09-02 15:16:45.307943	f
646	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-02 15:19:59.911431	0f074f92-ec77-4d29-8886-02b895533ee7	2025-09-02 15:19:59.914887	f
647	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-09-22	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-02 15:20:40.220166	b2127310-8413-42c5-a2bb-756f504389f8	2025-09-02 15:21:51.0767	t
643	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-17	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 15:15:16.920879	feff5643-8496-48d5-8e18-c9212fb48c73	2025-09-02 15:20:40.191264	t
653	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-22	\N	\N	\N	\N	2025-09-02 15:29:06.755477	6e9b46f2-12b2-4b91-953e-0c47ee319acd	2025-09-02 15:29:11.784242	t
658	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-22	\N	\N	\N	\N	2025-09-02 15:33:26.034584	c7f26d29-325d-4d86-8bd7-119f985152e9	2025-09-02 15:33:36.231338	t
648	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-22	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 15:21:51.10653	32c792b1-8f17-4316-b2a5-e07caa6f7207	2025-09-02 15:22:43.558829	t
649	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-22	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-09-02 15:22:43.612168	3df2ef98-a1c5-4c75-a8da-61c336dc7c6b	2025-09-02 15:23:33.022643	t
659	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-09-22	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 15:33:36.285638	bd93714f-8773-4ee4-992a-1d47c567bbfa	2025-09-02 15:33:58.836507	t
620	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-10	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-08-29 15:12:06.106326	bf8b1dbc-08ad-41e0-8297-9a94677198ab	2025-09-05 13:38:32.440592	t
650	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-22	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-02 15:23:33.075523	1f832e40-77f6-45f5-8750-ca64178bf8e4	2025-09-02 15:24:44.64757	t
651	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-09-22	7da0bd39-87ac-4b74-b152-236e519597e1	\N	\N	\N	2025-09-02 15:24:44.701752	14e41fe3-a163-4641-b485-92358e9ce6c1	2025-09-02 15:24:59.648184	t
660	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-25	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 13:38:32.494552	3be36f59-d61b-41d8-af34-dca2626b1dd8	2025-09-05 13:40:38.025749	t
652	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-09-22	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-02 15:24:59.70001	3e8d851e-5d65-4862-8671-9d6b8f738982	2025-09-02 15:29:06.703178	t
662	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-23	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 13:42:17.034488	4cc2a0af-e55d-4f00-8e39-f0a8416b68bf	2025-09-05 13:42:48.388336	t
654	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-25	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-09-02 15:29:11.836136	3bc296ed-6974-4a0a-af2f-011f0307a361	2025-09-02 15:30:20.281842	t
655	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-22	\N	\N	\N	\N	2025-09-02 15:30:20.334899	d473a701-7425-4c6a-bb7c-564b2a1fffa6	2025-09-02 15:30:28.288774	t
663	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-24	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 13:42:48.440206	88d19b8c-e002-488a-90c6-8fa141efc67a	2025-09-05 14:11:23.909685	t
656	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-25	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-02 15:30:28.342192	88af9849-1906-4d06-952c-b4f4276e074c	2025-09-02 15:31:30.956692	t
657	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-24	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-02 15:31:31.010388	5e9f6764-f5f8-48b9-9330-e471f23092ef	2025-09-02 15:33:26.019397	t
695	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-16	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-09-11 12:47:00.046334	8f7a3ef3-ec5a-4c49-b7a2-abd133ae004d	2025-09-11 12:47:08.13763	f
674	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-08	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:27:29.327948	9707a761-0065-4583-8ecf-3dd763998587	2025-09-08 09:28:14.232298	t
661	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-22	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 13:40:38.079004	a42c379f-64ca-4229-967c-73959f4424bf	2025-09-05 13:42:16.980338	t
690	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-17	261aa121-300a-43d2-bfcf-b4d27630954c	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-09-11 10:47:04.56894	a24fd3c3-f030-47d6-ba7a-e77c9dab2622	2025-09-11 10:50:40.282452	t
685	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-09	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-08 09:45:45.29779	a9fd250b-97f5-4f41-b190-2f56ec3c2875	2025-09-08 09:47:10.992586	t
664	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-09-05 14:11:23.961889	7f60aee5-6dce-4a2f-9647-177312e0cf95	2025-09-05 14:12:04.443362	t
680	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-09	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:37:22.102331	de8e199e-d5ac-48bf-923f-c0a11ad2538e	2025-09-08 09:38:10.539375	t
665	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-05 14:12:04.4717	d11db945-d70f-46d4-9c85-b5eea4b4fba3	2025-09-05 14:12:46.686942	t
667	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	5999-01-20	\N	\N	\N	\N	2025-09-05 14:16:12.822373	a94c5a95-c0cb-4a98-b37b-d8f5c63f1af0	2025-09-05 14:16:12.877081	f
666	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-05 14:12:46.748916	3f655d07-af23-4bbf-9500-0833c204eccf	2025-09-05 14:16:34.008283	t
675	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-09-08	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-08 09:28:14.28527	e1507ce5-ba64-41c2-9897-9d490aed7c82	2025-09-08 09:30:06.329714	t
681	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-09	\N	\N	\N	\N	2025-09-08 09:38:10.592104	fc6c95ab-7613-4a52-a585-b84aaa13df5b	2025-09-08 09:38:16.745582	t
668	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-15	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-05 14:16:34.036857	73402eeb-5847-4413-bc81-5c88555797a8	2025-09-05 14:17:05.580618	t
713	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	5999-01-20	\N	\N	\N	\N	2025-09-12 10:05:26.473795	f3a2ac67-baba-4441-8bdf-4e19c31dd34d	2025-09-12 10:05:26.477119	f
701	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-16	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-09-12 08:55:11.793484	065f47de-ae95-412e-a26a-51325f099d7f	2025-09-12 08:57:53.25816	t
696	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-16	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-09-11 12:55:02.146737	907326cc-6306-4cda-992b-43acc1b64a51	2025-09-11 12:55:15.844343	f
676	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-08	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:30:06.358285	88d5881f-229f-4d9f-b417-915b312232ce	2025-09-08 09:31:58.98244	t
669	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-16	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 14:17:05.630234	80c34e9a-0112-416f-992c-168ef7e7b166	2025-09-05 14:18:14.319319	t
686	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-09-09	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-08 09:47:11.077609	fd3c85d9-2533-41d0-89c4-289248e0c1f5	2025-09-08 09:47:36.232012	t
670	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	\N	\N	\N	2025-09-05 14:18:14.371296	dd201389-1b4e-43de-a96f-46b91d105af0	2025-09-05 14:19:03.985791	t
682	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-10	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:38:16.799483	35440654-a3a2-4b80-9e82-3287b7033185	2025-09-08 09:42:47.621094	t
691	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-16	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-09-11 10:50:40.336481	2abdf4c7-c7b9-49ad-9e51-f476ea532e77	2025-09-11 12:34:43.6907	t
671	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-18	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	\N	\N	\N	2025-09-05 14:19:04.014761	fa3f8f2c-7b09-479b-9a33-2e2c07ce53e1	2025-09-05 14:20:04.56008	t
677	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-09-08	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-08 09:31:59.012517	d607385c-3e84-4eff-b85f-bfeffdd95dd3	2025-09-08 09:33:56.532617	t
706	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-09-15	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-09-12 09:10:44.629761	94e1f8fb-87a1-43cc-bf6b-b85a2e1ab5fb	2025-09-12 09:10:58.337216	t
687	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-09-16	\N	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-09-11 10:42:36.688317	b378d2ac-1829-4469-931e-2156d780d5e5	2025-09-11 10:43:31.869589	t
672	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-16	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 14:20:04.573197	c15e39ea-aa8c-445d-939e-cb55b5c99d90	2025-09-05 14:20:41.098492	t
683	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-10	261aa121-300a-43d2-bfcf-b4d27630954c	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:42:47.635242	0967b43d-357a-4bb8-863c-29d0388174d9	2025-09-08 09:44:25.129947	t
678	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-08	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-08 09:33:56.59193	f22e516c-20d9-403a-b7bb-974eefeb89b6	2025-09-08 09:35:44.299467	t
673	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-17	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-05 14:20:41.150406	2118d08b-f060-43d2-af51-7f6761102630	2025-09-05 14:21:01.657995	t
692	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-15	73129017-ac9d-4a55-9020-7192a2b3150a	\N	\N	\N	2025-09-11 12:34:43.741489	7afafb95-4e05-40dc-b9c9-9f154ba68670	2025-09-11 12:43:36.085861	t
697	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-15	\N	\N	\N	\N	2025-09-12 08:25:52.360886	9f17d3fe-3f45-41f5-b4c5-8225d01ba3c1	2025-09-12 08:26:47.521679	t
688	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-16	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-09-11 10:43:31.922629	ba2d4e43-5d16-46c6-9bc1-e6b67461db9f	2025-09-11 10:44:23.035538	t
679	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-08	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-08 09:35:44.353465	48150176-6692-41a3-93dc-c112cbd4f29e	2025-09-08 09:37:22.072003	t
712	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	5999-01-20	\N	\N	\N	\N	2025-09-12 10:05:19.605378	4a800639-e2ea-486d-b4cf-90dde1259366	2025-09-12 10:05:19.608461	f
684	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-09	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-08 09:44:25.182217	2063f280-6ef6-48e5-a0c9-270d2ad77186	2025-09-08 09:45:45.284528	t
698	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-15	\N	\N	\N	\N	2025-09-12 08:26:47.575713	732c7b88-63cc-488c-a6f1-c203e723aac3	2025-09-12 08:31:05.441306	t
693	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-16	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-11 12:43:36.137156	b9395222-be8d-4be1-8984-0110653e795a	2025-09-11 12:43:50.353217	t
689	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-16	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-09-11 10:44:23.086468	e730f754-ad84-486b-aa9b-f10da373d605	2025-09-11 10:47:04.516941	t
714	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	2025-09-17	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:23:20.969668	bf1cc040-8fb0-40cd-9a16-16f38f313eb4	2025-09-12 10:23:40.142472	t
705	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-09-16	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-12 08:59:17.889776	1d43f2e2-1447-4bf5-91b5-4477eca01b66	2025-09-12 09:10:44.577601	t
699	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-09-15	\N	\N	\N	\N	2025-09-12 08:31:05.493702	f06410e9-30a0-4f9a-ab03-d0ba7ceb0370	2025-09-12 08:31:11.468337	t
694	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-09-16	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-09-11 12:43:50.405624	4de0642c-4b54-468f-9628-a7a83d374fec	2025-09-11 12:46:59.994358	t
702	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-09-15	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-12 08:57:53.271578	0eba83f8-cc32-4139-a114-c4e186021676	2025-09-12 08:58:24.320226	t
703	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-09-12 08:58:24.371804	e89ec56a-bd45-430a-8398-0e31cfeb168d	2025-09-12 08:58:40.59403	t
700	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	488bedde-e9a3-4ab1-a96a-585818dde2d0	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-12 08:31:11.520108	09aedbdc-8f1d-4d9a-9cd8-d3df53c41c51	2025-09-12 08:31:34.606912	f
709	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	2025-09-15	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:02:12.059253	612e0e61-59fc-4f55-a7aa-21a8c532491c	2025-09-12 10:04:44.51487	t
708	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-09-17	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-09-12 09:11:46.908113	56823553-ec5a-4bc8-ae4b-8c98d91507b4	2025-09-12 10:02:12.045732	t
704	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-09-15	\N	\N	\N	\N	2025-09-12 08:58:40.651603	5b5c9508-af32-40ee-a284-bccde527dd66	2025-09-12 08:59:17.83661	t
707	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-09-16	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-09-12 09:10:58.386248	000e936b-8f95-4305-bdc6-828f92ecf3b6	2025-09-12 09:11:46.897511	t
835	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-20 08:45:31.828159	b81ea2a5-5cb3-4bac-903b-ac0c90b362d8	2025-10-20 08:45:31.879601	f
710	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	2025-09-15	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:04:44.564756	64cdcec3-a529-48be-a91d-441f4b8049eb	2025-09-12 10:05:03.050806	t
711	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	2025-09-16	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:05:03.103075	051935a5-c94d-49d3-b0b4-a07576e864b5	2025-09-12 10:23:20.911608	t
717	69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0	\N	2025-09-15	d7b878e3-64f8-4627-b34c-b9acc1cae09e	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:29:51.067905	a185d7f6-c41d-4e8e-9956-9fd645aa54d5	2025-09-12 10:30:26.518714	t
716	69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0	\N	5999-01-20	\N	\N	\N	\N	2025-09-12 10:27:00.48355	e6569eed-deb9-45a1-98ca-eac5e93dbad6	2025-09-12 10:27:00.486655	f
715	6ef1e776-af1e-48ba-b443-d26c231b6292	\N	2025-09-18	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:23:40.193604	3e155310-e52b-46fa-a2b6-c5ad34638296	2025-09-12 10:29:51.016707	t
718	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-16	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:30:26.571271	10e26365-ccea-4998-8118-8cdd73d9ce8a	2025-09-12 10:30:44.811966	t
719	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-17	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:30:44.824665	199b8682-be8b-497b-950b-81ed750ffcaf	2025-09-12 10:31:04.47062	t
720	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-09-18	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-09-12 10:31:04.522619	e7dc1183-e99c-43b7-b825-3c24c4f3b093	2025-09-12 10:31:15.790436	t
721	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-24	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-15 13:03:03.422637	06ed67cb-5cbb-4740-86b8-71a22c687e84	2025-09-15 13:03:37.901639	t
723	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-19 11:45:33.487295	f509f812-fec4-4fdf-a02f-882094ed621d	2025-09-19 11:45:33.49125	f
724	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-22	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-09-22 08:33:25.573916	2d1bc1ec-b2dd-4a3f-93c4-5f7f70e60362	2025-09-22 08:33:53.235439	t
726	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-09-22 08:34:55.321534	c229068c-3606-453a-b809-4c259e4a910b	2025-09-22 08:35:32.775222	t
728	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-09-22 08:36:22.170991	c4c85562-e2ef-49eb-85ed-023e53de2006	2025-09-23 08:24:48.997055	t
725	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-22 08:33:53.287986	686f0b32-501b-4658-af90-f16a7a8bd427	2025-09-22 08:34:55.26955	t
566	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-09-02	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-08-22 15:31:17.244757	d6b90464-b180-43f4-9882-72086f409ff7	2025-09-22 12:56:50.569437	t
740	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-30	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-26 16:34:48.077009	75d2b893-30cd-4b1f-821b-6291daac6942	2025-09-26 16:36:18.389519	t
754	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 09:26:19.077038	c7c8cf3c-46ec-4304-8c68-b799506680e5	2025-09-29 09:27:16.80497	t
730	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-09-23 08:24:49.027289	d533369b-b4b9-4cf0-818a-88faea65f19a	2025-09-23 08:25:17.964862	t
748	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-06	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-26 16:43:30.084437	a9605dec-20f0-400a-baf4-c182b651a2bb	2025-09-26 16:45:07.532435	t
731	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-09-23 08:25:18.015804	80d24dc2-4277-4d64-b2df-c249e10ef0a6	2025-09-23 09:31:51.4484	t
732	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-09-23 09:31:51.505585	4803e93e-9c4a-4897-b3bd-bf63419895b1	2025-09-23 09:31:51.508728	f
741	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-26 16:36:18.443096	d8cf43de-7d67-4dd7-b1e6-9e88dba3c998	2025-09-26 16:38:23.016354	t
733	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-29	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-09-23 09:36:31.085786	908a3351-c147-42d1-93c4-330550c3a134	2025-09-23 09:36:47.095901	t
749	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-06	\N	\N	\N	\N	2025-09-26 16:45:07.587243	6e572d7f-75f8-4d22-875a-78f33d76d997	2025-09-26 16:45:11.583846	f
734	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	7129f484-2524-4bc2-a857-7a4663b6abbb	\N	\N	\N	2025-09-23 09:36:47.156777	3707e57a-fbf4-4cf3-81d9-5f73b01350ed	2025-09-23 09:36:54.853334	f
742	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-06	\N	\N	\N	\N	2025-09-26 16:38:23.030028	408e4d47-21ff-4b52-93d6-4b5d9b093ae3	2025-09-26 16:38:27.158673	t
758	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-08	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 09:33:24.74377	486d44aa-a51d-4244-b188-c608a319f98d	2025-09-29 09:33:45.191844	t
735	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-09-30	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-24 07:28:08.270699	be7c6047-7c45-4a36-a2f0-84c74d061f88	2025-09-24 07:29:04.666364	t
743	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-26 16:38:27.21159	785c91d2-79b6-4840-af3b-9eb282cde794	2025-09-26 16:38:47.163045	t
750	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-07	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 08:36:34.47656	b637bbc9-091d-42db-bdbb-51167895970a	2025-09-29 08:37:45.530194	t
729	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-09-22 12:56:50.583336	d12643a4-de46-4b30-b2c2-d4857977fad4	2025-09-24 15:30:51.993034	t
744	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-26 16:38:47.214451	b8a4f66f-1420-4df8-b273-8d8909319c40	2025-09-26 16:40:55.491741	t
755	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 09:27:16.818801	7f0cee26-eb88-457d-b69a-1eb0c599a093	2025-09-29 09:28:59.942705	t
736	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-01	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-24 07:29:04.718836	f1a467fc-01e5-4402-86e6-c89e406f9ab3	2025-09-26 14:59:51.062881	t
738	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-09-26 14:59:51.116045	00e2edca-0f49-4305-8d30-49a7bab609cb	2025-09-26 14:59:51.119192	f
745	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-09-26 16:40:55.545161	d55f0f8b-5318-4056-892b-c0927a242cff	2025-09-26 16:42:22.835112	t
739	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-09-29	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-26 16:34:25.029824	56b5b3e1-a11b-4c7f-9312-0e37aba312b9	2025-09-26 16:34:48.053993	t
746	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-09-26 16:42:22.917704	462f2da6-7c4d-4d85-ba13-48e9097f00d9	2025-09-26 16:42:59.770094	t
751	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-08	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 08:37:45.581568	73362e11-1de0-41aa-a7fd-09aeaa9ecfb8	2025-09-29 08:38:13.843605	t
756	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 09:28:59.995751	eea8c44f-7408-442c-8cdb-a26faa03e932	2025-09-29 09:33:00.257524	t
747	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-06	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-26 16:42:59.819869	0b4707e0-4494-4776-b8c7-bf38391c3208	2025-09-26 16:43:30.017669	t
752	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-09	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 08:38:13.896293	16afa50a-2ef1-46d7-9c81-a7a8dd2e8fe9	2025-09-29 09:18:41.705234	t
753	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-06	\N	\N	\N	\N	2025-09-29 09:18:41.77576	370d82d4-26ef-42bc-9018-0402d34f1323	2025-09-29 09:26:19.027255	t
757	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-09-29 09:33:00.27226	2ee895c4-366f-45cc-9053-42e6c277b1ea	2025-09-29 09:33:24.692378	t
737	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-01	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-24 15:30:52.013346	3d072004-198d-45b2-aec2-56c745b49062	2025-09-30 07:41:48.272098	t
765	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-10-13	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-06 09:59:10.042054	597c57ef-a827-4d8e-ac66-72c8f9983cc5	2025-10-06 09:59:32.442058	t
764	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-14	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-06 09:56:59.170104	1d1f1b12-d02b-4648-b5f1-fb61f8c00f7d	2025-10-06 09:59:10.028618	t
762	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-06	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-02 10:44:18.606264	aa57092f-c2de-4225-aebb-dd6c34623907	2025-10-02 10:45:42.555096	t
760	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-07	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-30 07:42:04.618754	e9d2c9d7-0cc1-4db8-9d43-cd346a779ec2	2025-09-30 07:47:29.721992	t
759	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-30 07:41:48.351341	7c54f899-57df-4d64-8369-7af2062504e0	2025-09-30 07:42:04.604958	t
763	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-13	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-06 09:56:38.535182	0ca837ac-7315-4f6c-8760-4aba2439dcf4	2025-10-06 09:56:59.11756	t
767	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-10-16	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-06 10:00:55.339685	d021a5db-e466-4194-9e10-5b79f6edf415	2025-10-06 10:01:19.738447	t
766	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-10-14	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-06 09:59:32.494129	7b092794-b29c-4cf4-bcf8-34d03abfe5c5	2025-10-06 10:00:55.287469	t
768	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-10-16	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:01:19.790953	0085c3f3-52ea-4dfc-aea3-a01bb29ab754	2025-10-06 10:02:05.265017	t
771	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-13	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:02:42.335011	fa4b9af4-0483-461b-8cf2-eff94fbafa76	2025-10-06 10:03:21.591016	t
769	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-10-06 10:02:05.318348	d10a081a-3d39-40ee-b75f-038491d3facf	2025-10-06 10:02:30.049652	t
770	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-10-06 10:02:30.079491	fcf1b2f7-9fe9-4f33-b0c3-78eae13ce55d	2025-10-06 10:02:42.320965	t
776	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	\N	\N	\N	2025-10-06 10:05:54.67773	3ffe6135-e8a1-4259-bf50-59c6a460ae8e	2025-10-06 10:06:08.724515	t
837	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	\N	\N	\N	\N	2025-10-21 08:14:37.732836	d323dc24-39d1-4730-b46a-c788d5b94325	2025-10-21 08:14:42.364059	t
772	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-14	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:03:21.642712	1a5eaea5-55d3-43b3-ac45-3b8141420d9b	2025-10-06 10:04:17.289438	t
773	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-10-14	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-06 10:04:17.343204	c5025b8a-98bc-4338-aea8-7cf36f5e7f4f	2025-10-06 10:05:20.456263	t
774	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-13	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:05:20.507723	d4ef80f4-8be6-466b-8627-4824ae9fd4d5	2025-10-06 10:05:45.811845	t
777	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	\N	\N	\N	\N	2025-10-06 10:06:08.738642	e26c0bf8-30d3-450d-93c6-c90bee4371c0	2025-10-06 10:08:27.977464	t
775	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-10-06 10:05:45.841005	f8914c6a-f388-4239-9f07-14ddf47f6363	2025-10-06 10:05:54.626183	t
786	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-13	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-06 12:40:55.216634	8f75c58b-5365-47a0-bfc6-4711ed9e1e33	2025-10-06 12:41:26.535562	t
778	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	\N	\N	\N	\N	2025-10-06 10:08:28.029828	4a239602-efdd-4d6e-9019-49389848efdd	2025-10-06 10:10:46.187553	t
794	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:46:43.948155	871f3a94-6136-4a69-b2d0-9d779ce7a112	2025-10-07 10:50:48.411767	t
779	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	\N	\N	\N	\N	2025-10-06 10:10:46.240302	c64b5563-41fe-489d-8f15-0155f45aa1b0	2025-10-06 10:11:53.246077	t
799	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-15	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-07 10:57:39.748893	1c7c5f0b-ba3a-41d3-8b76-ff8d7f851028	2025-10-07 10:58:08.585372	t
803	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-16	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-07 11:00:25.781774	3ec6358c-85d1-47f5-9c1a-a0bea55f7e68	2025-10-07 11:01:23.691152	t
787	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-14	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-06 12:41:26.593346	118cbe13-f130-4650-8d40-7356507b17f1	2025-10-06 12:41:49.677881	t
782	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-13	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-06 10:13:44.946157	f7d89ac9-0ca0-4a07-84c1-d9572e39e29a	2025-10-06 14:30:52.577159	t
780	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:11:53.300363	b94333a6-fb81-4d7f-9531-43f1cad6ad9f	2025-10-06 10:12:48.596158	t
814	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-22	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-10 13:09:56.906176	ae69eb83-fc21-4252-a460-ab1ca14aa5ab	2025-10-10 13:10:20.04608	t
788	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	1045bf64-4fb8-4c44-95c2-afe09bffa580	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-06 14:30:52.629348	dd81c5b2-09d1-48fa-9832-a96f8f8fdbe4	2025-10-06 14:31:32.211823	t
795	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:50:48.464359	211590cd-a6e6-432b-9ef2-66d394f8ebe3	2025-10-07 10:53:17.536081	t
781	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-10-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-06 10:12:48.647749	ca49946c-c171-4851-a901-23fffc9c8e0c	2025-10-06 10:13:44.932831	t
807	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-10-15	9990d420-939a-48ce-b6ed-b4d9ef480bc5	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 11:13:52.500082	65c790dd-0373-4547-83d6-ac3539e1e2ca	2025-10-07 11:14:32.76623	f
800	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-16	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-07 10:58:08.636786	66f2805e-894e-4a84-a0fd-eefa229df1ae	2025-10-07 10:59:16.973259	t
789	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-14	571c313e-8ec3-4777-bac7-40855117d510	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-06 14:31:32.225476	f6f87b48-8c0e-4130-b0ba-f283ba8c7578	2025-10-06 14:32:30.540511	t
822	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-23	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-14 12:42:31.065278	d5612c0e-f4ba-4209-8977-4616601a8ad1	2025-10-14 12:43:10.035645	t
796	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:53:17.588973	d0196931-7648-4724-9454-8e4d46046ab2	2025-10-07 10:54:11.489952	t
790	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	8797874d-0abe-4021-89f4-f64cf3582f9f	\N	\N	\N	2025-10-06 14:32:30.593383	3980425d-7c7d-403d-9240-03167e4c7073	2025-10-06 14:32:48.004309	t
783	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-13	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-06 10:18:49.793452	61ba08c9-a7b4-42a6-8842-4c9adbe6a4fd	2025-10-06 10:19:21.218609	t
791	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-13	\N	\N	\N	\N	2025-10-06 14:32:48.05714	97736024-f5c0-4406-85e8-134f71a24dc3	2025-10-06 14:32:49.312909	f
808	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-10 12:42:18.327121	e50aac83-e3d7-4114-b02b-342ea9b4369d	2025-10-10 12:42:58.264013	t
804	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-16	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-07 11:01:23.743296	d196c227-be6a-4d4c-97d8-73fdf03ec8c6	2025-10-07 11:10:57.502138	t
784	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-14	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-06 10:19:21.270051	704f4f75-d234-4930-89da-af3be19524ed	2025-10-06 10:19:54.587307	t
812	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-10 13:09:07.638039	e02a31d0-0535-4a98-b7df-e0612e63233d	2025-10-10 13:09:32.236531	t
801	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-15	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-07 10:59:17.001974	0938ec29-4774-4275-b201-6365da472e8b	2025-10-07 10:59:53.106555	t
792	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-10-16	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:43:43.826616	f5469750-2898-4a95-9b51-4a588f9e644b	2025-10-07 10:44:29.210991	t
797	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:54:11.5426	c4556294-25ae-4f6a-a84d-de4294afca07	2025-10-07 10:54:57.441967	t
785	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-15	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-06 10:19:54.640689	9d85b95a-9d48-4407-ac76-4cab3bf77a08	2025-10-06 10:20:23.50029	t
809	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-10 12:42:58.315984	dfac660d-2e8e-46d6-b99a-7ea97ebda99c	2025-10-10 13:08:09.877654	t
805	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-10-13	9990d420-939a-48ce-b6ed-b4d9ef480bc5	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 11:10:57.542264	3d233292-7ccf-43d0-ad90-ebb789827f6f	2025-10-07 11:13:44.258999	t
793	753cd7ca-9dcc-4b54-8d30-baedf1296e22	\N	2025-10-16	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-07 10:44:29.2619	dc7059e3-6e1e-4c78-a525-841a774c7943	2025-10-07 10:46:43.918999	t
798	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-13	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-07 10:54:57.494064	29779a32-9127-46ae-912c-cf70129eaadd	2025-10-07 10:57:39.694484	t
818	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-20	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-10 14:52:05.85377	09953a33-b079-4f40-9871-7797fe7d7790	2025-10-10 14:52:40.590677	t
802	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-15	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-07 10:59:53.134928	b85ef209-1bae-402b-bdf9-6ff8cd2412e0	2025-10-07 11:00:25.729308	t
806	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-10-14	\N	\N	\N	\N	2025-10-07 11:13:44.272836	8ffa5353-86b1-4810-8b4c-50e1592b7e45	2025-10-07 11:13:52.441602	t
810	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-10 13:08:09.907589	299e7ef5-4988-495e-bc63-8614b6bf6842	2025-10-10 13:08:45.845057	t
830	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-27	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-17 13:31:43.249004	2be57f54-6cbb-4907-8730-21f94f5afd4f	2025-10-17 13:32:33.532309	t
813	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-21	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-10 13:09:32.286981	c511fafb-e004-4f3b-8180-31ba83ff775b	2025-10-10 13:09:56.853173	t
825	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-17 08:10:18.688892	240bce4b-51d8-4bb3-99d6-8ef783235e89	2025-10-17 12:56:12.456651	t
811	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-10 13:08:45.897956	330f7b39-5f23-493b-aa2e-16bf6b854a7b	2025-10-10 13:09:07.587147	t
817	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-22	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-10 14:51:36.499837	fce62f02-eabf-42fe-8ce0-3db71c833811	2025-10-10 14:52:05.841238	t
823	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-22	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-14 12:43:10.088567	f3bc6df2-3e3c-4862-8ce5-00c3a6b5be5a	2025-10-14 12:43:27.311366	t
820	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-22	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-10 14:53:11.633434	94750317-dfdb-4380-b83c-669051c37c60	2025-10-10 14:53:34.052883	t
761	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-09-30 07:47:29.736513	c90c7ee1-db68-451f-b5cb-2f52337a0e8e	2025-10-14 12:42:14.199653	t
819	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-21	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-10 14:52:40.643846	0a9d9f71-b694-4d3b-8ddd-3cbcdd2280df	2025-10-10 14:53:11.581355	t
816	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-20	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-10 14:50:54.896915	947df238-b975-462f-90ff-ec00dcf72f7f	2025-10-10 14:51:36.440013	t
821	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-22	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-14 12:42:14.253837	8c8526a3-0d68-431d-8ef6-b792c20aa737	2025-10-14 12:42:31.034851	t
815	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-23	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-10 13:10:20.098217	3c5080e1-e3af-4fa7-b806-0c0d1ec60725	2025-10-17 08:10:18.643873	t
828	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	\N	\N	\N	2025-10-17 13:24:48.828009	8846dfe8-8d35-4cfd-b198-e47d7e995734	2025-10-17 13:24:54.677045	t
827	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-28	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	\N	\N	\N	2025-10-17 13:24:15.633094	b69419c6-747a-43ba-ab19-22ad4602bf77	2025-10-17 13:24:48.798764	t
826	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-17 12:56:12.509253	a0ee33e0-c1f6-4755-a831-846766ae8548	2025-10-17 13:31:43.19703	t
829	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-31	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-10-17 13:24:54.707002	ec87eb02-08fa-4521-bd3b-8d67e2344a38	2025-10-17 13:25:02.109906	f
831	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-30	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-17 13:32:33.58409	5531f038-a54d-488c-a6fc-de8ede3dabdc	2025-10-17 13:33:10.596413	t
833	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-17 13:33:34.631938	d4218be5-a470-4f5a-a974-2af63604fb6b	2025-10-17 14:05:40.777614	t
832	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-10-31	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-17 13:33:10.648869	0942606c-f5d5-4118-8a18-1cbcbdf6fff9	2025-10-17 13:33:34.580065	t
836	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	e40964e1-8934-428e-a06e-18379a30ebae	\N	\N	\N	2025-10-21 08:14:17.908042	aa570682-f43c-4af3-bfa0-9e42ad039c13	2025-10-21 08:14:37.679233	t
838	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	fdc73d75-74c1-44e9-b276-2b748d35620b	\N	\N	\N	2025-10-21 08:14:42.384602	8fa68aa9-30ef-4230-9b0d-244a7a04c060	2025-10-21 08:16:10.715197	t
834	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-17 14:05:40.828289	64ee3fc8-4488-4086-aa6f-50cb41df4604	2025-10-21 09:32:06.200026	t
845	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	e40964e1-8934-428e-a06e-18379a30ebae	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-21 10:29:11.785755	1e13a816-455b-4dd0-be6a-a9e5dc0b36e5	2025-10-21 10:29:28.54595	f
848	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-28	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-21 12:13:02.69912	ed119ab1-2b57-4e6d-8909-61b9b98cb0f3	2025-10-21 12:13:31.799246	t
850	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-10-21 13:50:33.852334	66b84114-9468-4ae9-9889-c1d3e664c94a	2025-10-21 13:50:54.649004	f
840	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-21 09:32:06.251208	2c78f56f-786f-4ad3-8e5a-681d84b67f0c	2025-10-27 08:49:36.116641	t
839	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-10-21 08:16:10.769172	adf676e9-6e0d-4922-9b95-35c2bd20872f	2025-10-21 08:16:21.958011	f
842	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-10-29	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-21 10:15:40.671462	886c2dda-49a0-4ba4-84db-c5c6f0137766	2025-10-21 10:24:07.381325	t
824	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-23	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-14 12:43:27.364095	4b10f878-5eb4-437d-886e-8b793f6a1934	2025-10-21 11:11:21.132085	t
849	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-10-29	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-21 12:13:31.819433	1341d5dc-804b-4523-9adb-7c35a0965afb	2025-10-21 12:13:58.764686	t
856	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-28	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-21 15:11:21.121177	a84c391f-319c-45f1-a05c-75950b1b2b0a	2025-10-21 15:11:41.84521	t
841	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-10-21 10:14:45.204739	d1a7e6a8-8efa-4181-8218-467d80b3cf80	2025-10-21 10:15:40.619637	t
857	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	\N	\N	\N	\N	2025-10-21 15:11:41.896022	0b44f2f8-a917-4260-ac00-fbbb8c163fd1	2025-10-21 15:11:41.899006	f
843	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	\N	\N	\N	\N	2025-10-21 10:24:07.432892	e63160b3-b27f-4129-8164-b186a93abc9b	2025-10-21 10:24:15.445723	t
844	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	5999-01-20	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-21 10:24:15.458447	89e86b9f-4829-4f9a-9eb7-48d3e26cca13	2025-10-21 10:29:11.772805	t
872	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-30	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 09:11:00.277028	9ae040e8-3e67-4073-b53c-405ea2c33c58	2025-10-22 09:13:03.740929	t
863	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-27	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 08:50:50.605374	c0ccde28-cd98-4a47-9686-51589405c262	2025-10-22 08:51:43.492957	t
858	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-27	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 08:46:26.358472	7593fb38-f033-4dbe-b6e6-256dcd1f3753	2025-10-22 08:47:06.840703	t
846	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-31	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-21 11:11:21.184619	cc842c8d-8108-442b-b5e4-30829ba5fb2c	2025-10-21 11:11:49.957491	t
868	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-28	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-22 08:54:26.841554	e00b39e7-c906-4894-af5d-5dee401e7556	2025-10-22 08:56:02.558259	t
880	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-22 11:51:36.411875	bd40e863-ea7e-4993-9356-09a61b044751	2025-10-22 11:56:41.253436	t
851	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	\N	\N	\N	\N	2025-10-21 15:02:52.789657	d712532e-8ae1-4e05-b076-1a88d08af5b9	2025-10-21 15:05:06.531449	t
889	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:12:50.492157	f421f83f-bc26-4256-8c05-5e39d9195e3e	2025-10-22 12:13:48.451832	t
859	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-28	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 08:47:06.852935	c098cf82-5d00-4282-b54a-ce1701738d59	2025-10-22 08:49:03.291677	t
864	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-28	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 08:51:43.543736	a0bbce15-b4c8-405f-a118-540b428de156	2025-10-22 08:52:49.481585	t
852	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-27	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-21 15:05:06.58338	5a54c23d-03d9-45a7-abad-2b5689cf839a	2025-10-21 15:08:38.452079	t
881	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	62608399-2245-470d-a950-4eec08632518	\N	\N	\N	2025-10-22 11:56:41.305862	bdedbcff-fe5c-48f8-8015-2e3380a6badc	2025-10-22 11:57:08.222718	t
877	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-29	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 11:22:58.058136	b40ed4cb-7e31-4ceb-af12-81a52d10d5c6	2025-10-22 11:23:41.787441	t
847	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-21 11:11:50.009188	2908192f-f882-424f-9bdd-669b825cb8b9	2025-10-22 11:14:44.735223	t
860	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-29	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 08:49:03.344305	2a4ae581-a6b7-4785-aaf6-c28fd18cea60	2025-10-22 08:49:51.023564	t
853	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-10-28	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-21 15:08:38.504144	54c7100c-97fa-4880-b819-48f909d57f05	2025-10-21 15:09:15.455834	t
869	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-10-31	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-22 08:56:02.579713	15ec4a18-1c06-4361-a67d-ca7417aeaf67	2025-10-22 08:56:49.649523	t
865	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-27	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 08:52:49.533039	25e95b89-120e-41ad-aa1b-4f598a513b7e	2025-10-22 08:53:31.712402	t
854	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-28	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-21 15:09:15.510432	4505d96b-5895-4b13-9147-f646a4e6d68e	2025-10-21 15:09:42.766883	t
861	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-28	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-22 08:49:51.074775	2940a5df-a092-497b-ad4d-6b069f6f1280	2025-10-22 08:50:11.121322	t
855	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-28	571cd566-5150-4b80-9221-233cd3d39b87	\N	\N	\N	2025-10-21 15:09:42.796555	e22b775b-e264-4a35-8757-1fa1859e846d	2025-10-21 15:11:21.108203	t
891	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	\N	\N	\N	\N	2025-10-22 12:25:33.678042	d51c8cf8-0fc8-4f38-befb-f0c877de9e79	2025-10-22 12:25:39.762539	t
870	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 08:56:49.699799	3ab0fce0-b721-4642-bee4-6e32c37f3862	2025-10-22 08:57:11.723839	f
866	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-28	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 08:53:31.76469	0b1eae48-9748-4ee7-b03b-9550543ce922	2025-10-22 08:54:03.652987	t
887	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:03:52.555812	3de90895-5fdf-40c1-b10a-791e5352aaa7	2025-10-22 12:10:14.294283	t
862	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-10-29	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-22 08:50:11.173826	4c6f5435-e96e-45d2-b8aa-ac1928ece390	2025-10-22 08:50:50.575558	t
878	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	\N	\N	2025-10-22 11:49:58.556241	7b0f156a-3218-49f8-8e9b-b9448798004f	2025-10-22 11:50:18.29292	t
874	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-29	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 11:14:44.786864	fb69dfb7-bd1e-4771-9d5d-31ba056a4f55	2025-10-22 11:15:33.606128	t
871	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-28	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	\N	2025-10-22 09:07:08.467932	7ae96a4a-fc10-418d-8294-890a13de0b7d	2025-10-22 09:11:00.225495	t
867	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-10-27	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-22 08:54:03.707601	556724dd-368d-438d-a434-e281635e4350	2025-10-22 08:54:26.752541	t
884	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-29	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:00:35.903517	75cc09ec-5203-4a2a-8d44-726489b679f9	2025-10-22 12:03:30.340216	t
879	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-22 11:50:18.306393	64dc6296-da7a-45f4-973e-23a603761149	2025-10-22 11:51:36.381125	t
882	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 11:57:08.234876	7092157c-610e-49e0-9d05-92f112b430fc	2025-10-22 11:58:36.717296	t
875	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-10-30	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 11:15:33.665511	3356ec49-5849-486a-a251-0a7599ad1c7d	2025-10-22 11:16:04.271356	t
895	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 12:58:57.313643	712234c7-a001-441f-82a5-efda117919f5	2025-10-22 13:00:42.645836	t
885	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	\N	\N	\N	\N	2025-10-22 12:03:30.393591	c0dedd6d-2edb-4bc7-b8b0-c95221aed927	2025-10-22 12:03:36.468134	t
883	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-22 11:58:36.769688	409af3e2-3b4b-49b6-bae1-c31f9c5424c6	2025-10-22 11:58:53.979767	f
893	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	\N	\N	\N	\N	2025-10-22 12:47:27.20806	f3d16398-1953-4b17-964a-a799b0bb1234	2025-10-22 12:52:28.213781	t
898	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 13:02:12.141146	cb369dc3-cf47-4896-98c3-17db6d6321b8	2025-10-22 13:10:03.406934	t
886	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	62608399-2245-470d-a950-4eec08632518	\N	\N	\N	2025-10-22 12:03:36.520156	305b94df-de00-4dbf-808a-36fd60294cab	2025-10-22 12:03:52.503673	t
888	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-28	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:10:14.316394	26e7ed75-3df5-4ff5-b76f-e4da21b5fa5d	2025-10-22 12:12:50.438404	t
890	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-10-27	9990d420-939a-48ce-b6ed-b4d9ef480bc5	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:13:48.505033	492ef89a-1c9d-414f-b81b-583fd5b5470c	2025-10-22 12:25:33.665163	t
892	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 12:25:39.814936	12a7c8a9-399d-4ff7-b44c-e992dc96bd08	2025-10-22 12:47:27.194218	t
894	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	091e7bb0-f31d-4465-8e6f-130e5f83d454	\N	\N	\N	2025-10-22 12:52:28.226234	41ca1019-4d84-4101-a784-33505d43c77c	2025-10-22 12:52:31.770787	f
896	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-22 13:00:42.698419	86b5bf1d-fb9d-424d-8f8f-d182926bed32	2025-10-22 13:01:46.443144	t
897	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	\N	\N	2025-10-22 13:01:46.495642	2024599a-6d29-4cf7-bff1-8eddb6db85db	2025-10-22 13:02:12.0876	t
899	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-29	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 13:10:03.420482	6b78c390-df6d-443e-97ac-e824e2d3fd30	2025-10-22 13:11:07.383862	t
901	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	\N	\N	\N	2025-10-22 13:12:41.275697	28e67437-2245-4f24-933f-4a07c2a05fca	2025-10-22 13:17:01.059435	t
900	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-22 13:11:07.435514	c2756990-23f5-42e8-a451-c393cac545a3	2025-10-22 13:12:41.223738	t
904	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	\N	\N	\N	2025-10-22 13:19:23.876955	e654c435-c904-4d2e-9caa-ed6f89b43564	2025-10-22 13:19:38.788893	t
876	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	3893f977-8f70-49be-903b-ed0149e4a505	\N	\N	\N	2025-10-22 11:16:04.323136	173af823-913b-4bfe-943c-b373996c2a19	2025-10-24 12:27:12.588533	t
902	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-22 13:17:01.110808	45a1a590-61ab-4c8a-93fa-d95366cb0f77	2025-10-22 13:18:33.446875	t
907	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-28	11d35a66-b246-40f7-ba06-53580222523b	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 13:26:45.802296	8a3d49eb-354a-4598-9788-5e413c3172ea	2025-10-22 13:26:54.91751	f
903	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-28	f70dda6c-3b1c-4248-bc15-93aefba973bb	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-10-22 13:18:33.499759	c16b8826-3ec1-46d2-8842-ddf780302879	2025-10-22 13:19:23.824384	t
906	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	11d35a66-b246-40f7-ba06-53580222523b	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 13:25:53.978994	598b8cc5-f1e5-43ea-aff4-5a2c64fb330d	2025-10-22 13:26:45.771579	t
911	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-28	563ae91e-3338-45f7-aead-c5a3c7a57f63	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 14:09:22.520733	19a79d05-5d68-4acb-ba40-d419e6e5e462	2025-10-22 14:10:00.882232	t
915	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:42:38.162027	6bf1f7a0-9ae6-4536-b4e3-d93f22fdb2a9	2025-10-24 13:42:41.634097	t
919	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:52:03.380804	56a14b61-5438-4916-bb85-623dbbe31576	2025-10-24 14:01:00.884752	t
920	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-11-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-24 14:01:00.897559	ff3d60aa-f7e7-4892-ba2a-339cff7b5ca0	2025-10-24 14:01:13.374545	t
905	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-28	\N	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-10-22 13:19:38.839458	1b6dab6f-fbe6-47a0-b930-fb81f489243d	2025-10-22 13:30:14.209842	t
908	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	563ae91e-3338-45f7-aead-c5a3c7a57f63	\N	\N	\N	2025-10-22 13:30:14.262395	f0038c01-8c5c-4fb2-9e01-c850846e520d	2025-10-22 13:30:49.240783	t
910	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	2025-10-27	563ae91e-3338-45f7-aead-c5a3c7a57f63	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-22 13:34:21.814372	f0a9e292-3d59-4f68-9a66-0487aca91355	2025-10-22 13:34:42.028616	f
909	a4636783-1d55-415b-bbc2-deb27cdcf0f2	\N	5999-01-20	11d35a66-b246-40f7-ba06-53580222523b	8bfe7234-ce4a-487c-8728-82b5f1956a71	\N	\N	2025-10-22 13:30:49.293967	c376c1d1-3d3f-4646-a17d-43996edec32a	2025-10-22 14:09:22.46801	t
913	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 12:27:23.384033	dcd427f2-ab54-452e-8a49-10d9b0b2a09b	2025-10-24 13:12:40.677978	t
914	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:12:40.729563	0ee31183-077a-4cce-923f-663b00c97237	2025-10-24 13:42:38.149555	t
916	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:42:41.646459	7e8a370b-0cf7-40d3-8035-567ddef51ed9	2025-10-24 13:42:50.417493	t
921	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 14:01:01.05331	764f74ad-4808-44a5-aa37-b3f47ecce427	2025-10-24 14:01:01.066162	f
948	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-05	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-28 14:46:22.151437	d1ec420f-e815-42c4-9e92-e13bdb54b832	2025-10-28 14:46:36.021199	t
912	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 12:27:12.611131	310fdaa3-7850-4491-922b-0dbb66b3fcde	2025-10-24 12:27:23.331148	t
917	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:42:50.468546	833d8891-11f4-4b4c-a472-23a1d6070729	2025-10-24 13:51:52.843229	t
934	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 09:08:47.765311	6004c347-504a-4f71-b35f-8d8fa33353b2	2025-10-28 09:08:47.767975	f
918	cdf23166-345a-4084-8437-92c51adbbe78	\N	5999-01-20	\N	\N	\N	\N	2025-10-24 13:51:52.901737	9720c154-4b06-4c4f-a9f1-e9b302f12910	2025-10-24 13:52:03.328322	t
933	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	9990d420-939a-48ce-b6ed-b4d9ef480bc5	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-28 09:07:05.382314	fa55ec33-227f-4a6f-aaab-d00ca8bc96d5	2025-10-28 09:13:19.735698	t
935	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 09:13:19.788634	2d886371-1b6b-459b-ac83-bc764e5c1877	2025-10-28 09:13:19.79251	f
922	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-11-05	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-10-27 08:49:36.169974	5124f941-27e8-40c2-a992-6604091fd6c8	2025-10-27 08:50:01.608683	t
969	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	87e352df-7694-466a-a100-26aa80ff28e9	\N	\N	\N	2025-10-29 08:23:37.730633	b6aecb0f-d1e6-47e5-8b8e-f970a76ecc8c	2025-10-29 08:23:49.243946	t
943	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 14:22:14.32909	78d1a5e1-62f8-4e11-9d39-8689f993e541	2025-10-28 14:23:19.374984	t
936	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-28 09:17:46.437641	6a4e1f1a-9414-43a0-8120-5483723c54cd	2025-10-28 09:19:41.301964	t
954	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 14:49:10.738996	6b95c624-29b0-4639-9a85-192ded23b0d8	2025-10-28 14:54:59.372224	t
924	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-10-27 09:02:19.732438	f45cf56d-8dcc-489b-babb-40bf88ba4486	2025-10-27 09:03:14.631098	f
925	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	\N	\N	\N	\N	2025-10-28 08:43:00.815681	ac24c875-c878-4bf4-96d9-1e9265ed60ce	2025-10-28 08:43:16.269144	f
964	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-06	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-10-29 07:31:43.000585	e6426263-815e-4139-a19f-da0ee5451a20	2025-10-29 07:35:17.762082	t
937	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-28 09:19:41.355209	cdc88e81-b8d8-4eee-9e81-946a5c20ff80	2025-10-28 09:19:58.447689	t
926	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	1a901c9f-deb2-4451-a71b-4a059e561058	\N	\N	\N	2025-10-28 08:51:33.37289	68666f11-666c-4622-84bc-31862f93f811	2025-10-28 08:52:45.234762	t
962	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	\N	2025-10-29 07:09:54.814944	d8a29239-9948-4c92-b349-04e438b66a6f	2025-10-29 07:10:12.450149	t
944	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 14:23:19.386438	a1060a51-3cee-4175-bde0-1213aebe830b	2025-10-28 14:24:02.153011	t
949	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-05	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 14:46:36.033184	e3c22ce1-0f4f-4ea5-8752-d1b196558ff3	2025-10-28 14:47:17.762031	t
945	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 14:24:02.18338	57a82d08-b96c-43c5-8819-33602d65b9fd	2025-10-28 14:24:13.22298	t
928	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 09:05:20.215657	a3ee5adf-3151-41cf-b765-b1027818235c	2025-10-28 09:05:59.017901	t
938	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-28 09:19:58.460447	b87c8330-a2df-4ad2-a6b9-dcee9581b342	2025-10-28 09:20:29.415469	t
939	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	\N	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-28 09:20:29.46864	c3a306aa-31a1-4cef-98fd-bdfbe233acdd	2025-10-28 09:20:35.664078	t
929	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 09:05:59.030584	f5c1332f-b685-48c8-bbf7-9d9a18609024	2025-10-28 09:06:16.747695	t
955	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	\N	\N	\N	\N	2025-10-28 14:54:59.385852	430df113-6d4a-436c-b088-581d04e353b9	2025-10-28 14:55:05.564951	t
930	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	488bedde-e9a3-4ab1-a96a-585818dde2d0	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-28 09:06:16.799167	2ec369b8-000e-4019-a33e-506d4c53d32e	2025-10-28 09:06:33.425862	t
940	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	5999-01-20	\N	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 09:20:35.676192	efbb1e19-ffca-4e51-84b0-bae758b91b36	2025-10-28 09:20:51.659459	t
931	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-28 09:06:33.43834	4cab47ba-6473-4b68-8fcc-61f10ba638ff	2025-10-28 09:06:57.158673	t
932	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 09:06:57.178621	8a333fe4-7481-4a2b-96e8-d4c1c9597585	2025-10-28 09:07:05.331016	t
946	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 14:24:13.274174	cb85bcae-340d-43d2-b530-ebbfae1ae817	2025-10-28 14:24:58.673327	t
942	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 14:07:45.866305	98fc2802-af36-4f96-b83b-56e54a9946d3	2025-10-28 14:45:53.839302	t
959	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-06	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 15:03:14.760081	7814546b-2630-42ac-87dd-93d561600366	2025-10-28 15:07:15.531714	t
950	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-06	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 14:47:17.813355	ac8c07cb-0bb9-49f6-b5c3-94430abba8d3	2025-10-28 14:48:26.411229	t
941	e8b5c31f-6da6-4385-adbb-06014c9e6e01	\N	2025-11-05	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 09:20:51.711511	fc60ccc4-0192-401e-8544-e9db21818736	2025-10-28 09:21:43.904972	t
968	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-05	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-29 08:22:56.396584	11d45654-fb72-4057-8d29-573d0bfc6498	2025-10-29 08:23:37.71754	t
927	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 08:52:45.287543	7a75d3d1-2c35-4b99-afcf-25911897848b	2025-10-28 14:22:14.315079	t
951	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-05	\N	\N	\N	\N	2025-10-28 14:48:26.464309	9c23e8fc-a5da-438d-a6af-56a5587954f5	2025-10-28 14:48:40.237926	t
947	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-05	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-10-28 14:45:53.892914	163039aa-ca6b-40ee-84b3-e6e39381fbe8	2025-10-28 14:46:22.098769	t
956	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-06	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 14:55:05.617302	ac957b30-c26f-4000-9a42-2a3229b1a1b0	2025-10-28 15:02:03.780772	t
963	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-10-29 07:10:12.502677	f0d4dfff-2b18-4443-ba26-76fd370d568b	2025-10-29 07:10:17.389099	f
960	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	\N	\N	\N	2025-10-28 15:07:15.545125	ac464d98-413d-4c39-a670-8ebdd7e081f6	2025-10-28 15:09:51.845842	t
957	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	\N	\N	\N	\N	2025-10-28 15:02:03.867905	07d5160b-f4ab-4680-b222-38f025443654	2025-10-28 15:02:10.369319	t
952	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-06	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-28 14:48:40.292651	4a0dca52-2237-4854-8481-4fe2d0b26a0f	2025-10-28 14:49:03.630477	t
953	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-10-28 14:49:03.690204	a248f919-b1d8-481a-b3d9-77441e6f3f82	2025-10-28 14:49:10.688116	t
977	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	eecdd0f8-7244-4bf6-8f96-65622901a51d	\N	\N	\N	2025-10-29 09:24:27.551506	3218751b-fc45-44b0-8d23-ea343d0a1056	2025-10-29 09:24:43.564176	t
961	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-28 15:09:51.898677	9a1c4553-ce0d-43be-90f4-b9a49161631f	2025-10-28 15:09:57.474043	f
958	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-06	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-28 15:02:10.389453	2ddc7035-29d1-426a-a377-cf3592437736	2025-10-28 15:03:14.708592	t
967	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-05	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	\N	\N	2025-10-29 07:46:41.308379	fe0c4b8a-9f00-4b5e-bb88-46ad9496dc2c	2025-10-29 07:46:52.77906	f
971	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-06	\N	\N	\N	\N	2025-10-29 08:24:06.738514	e5db9d97-03af-4c84-87e7-e663087db028	2025-10-29 08:24:14.377304	t
970	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-06	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-29 08:23:49.27321	bab41b1b-2215-4cdf-bb45-ac0b193b483d	2025-10-29 08:24:06.708818	t
966	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-05	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-29 07:45:57.912777	427ab4cc-9fe2-453b-8b50-5a12c71aac22	2025-10-29 07:46:41.277361	t
974	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-06	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-29 08:27:10.570078	e86c4226-8c6b-4e58-9718-bea0a553f85d	2025-10-29 08:27:25.914844	t
973	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-06	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	\N	\N	\N	2025-10-29 08:24:32.754972	905aa07b-8c84-4c2f-87b3-fe2271fc2438	2025-10-29 08:27:10.557552	t
972	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-06	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	\N	\N	2025-10-29 08:24:14.428754	564a11da-99ac-4260-9ad9-e312467c1608	2025-10-29 08:24:32.696328	t
873	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-10-31	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-22 09:13:03.766713	2f3f730d-e23c-4b55-bef3-0cb3d867b6e3	2025-10-29 08:49:28.241257	t
975	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-06	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-29 08:49:28.25417	44317bd1-3d85-48b6-b4a5-17e55d7995cc	2025-10-29 08:56:30.078902	t
976	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	5999-01-20	\N	\N	\N	\N	2025-10-29 08:56:30.090774	be7a6f20-69bd-4f94-bfd5-d8dc9d05fe57	2025-10-29 08:56:30.093323	f
965	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	5999-01-20	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	\N	\N	\N	2025-10-29 07:35:17.813329	fd340744-31d7-476d-a4f1-eac979b1bf7f	2025-10-29 09:24:27.499262	t
978	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	\N	2025-11-06	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-29 09:24:43.616793	9555ecb6-7073-4288-bbda-aea1be9254fe	2025-10-29 09:25:16.70545	f
998	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-06	\N	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-29 13:22:40.185073	b51e447d-a6a2-4722-a57b-1640cdce2ab0	2025-10-29 13:23:03.31837	t
979	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-29 09:26:16.503971	ddc31616-49ba-43c9-a371-1dec4c6269d2	2025-10-29 09:27:02.586763	t
980	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	\N	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 09:27:02.639568	bcbd9266-c0da-4f44-bdba-b407456a24cf	2025-10-29 09:32:11.369082	t
1000	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-29 13:25:01.288492	0ad48479-2a2e-49fc-91a6-34cdebbef982	2025-10-29 13:25:55.812964	t
983	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-05	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	\N	\N	2025-10-29 09:45:27.855257	ab90ab0e-8324-4f6f-928c-ea3909386634	2025-10-29 09:46:37.94374	t
984	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-06	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-29 09:46:38.000192	a93505de-3923-4034-8fd0-6e075004bce3	2025-10-29 09:46:52.319766	f
987	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-10-29 10:24:14.648285	ba77e227-61be-45ca-a144-6fd58e6c6857	2025-10-29 10:24:14.651155	f
1001	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-29 13:25:55.864323	dc9bdbfd-5113-44c8-a87a-ebad47f21f88	2025-10-29 13:26:11.40176	t
988	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	\N	\N	\N	\N	2025-10-29 10:43:57.471956	297b04ef-8abf-404e-8316-8b7263abd2e4	2025-10-29 10:46:13.827414	t
992	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-29 10:52:04.752603	22fc6855-8a4d-4178-8036-0a6808ee3526	2025-10-29 10:54:48.78391	t
994	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-05	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-10-29 11:01:46.637944	b5a3fc4b-d70b-45a3-88e9-cd95a2569bc7	2025-10-29 11:03:47.136401	t
996	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-11-05	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-10-29 13:20:03.399801	56828910-f318-4224-8c49-d08924c27f6f	2025-10-29 13:22:19.665027	t
997	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-05	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-29 13:22:19.685377	a8bb23cb-ae7f-41f8-97dd-3ff916be8f47	2025-10-29 13:22:40.133906	t
1032	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-11-10	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	\N	\N	\N	2025-10-31 12:45:57.604147	8b9fdb66-3d54-49c9-bbaf-470a98704ad2	2025-10-31 12:46:06.292073	f
1023	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-31 11:08:36.053151	4d244b45-d973-4f34-a88d-57283f313a75	2025-10-31 11:09:19.649798	t
1008	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-11-06	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-30 08:20:21.22011	a04b8fef-a0e3-47f3-b5d6-d4f55ea92477	2025-10-30 08:21:12.986053	t
999	04567c72-d2d7-43fc-baa5-d22abe61e00e	\N	2025-11-06	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-29 13:23:03.33099	38c88927-0890-4991-8aa7-96920178017a	2025-10-29 13:25:01.236464	t
981	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-05	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-29 09:32:11.421809	00ac7956-3269-4676-8633-6471cd13f90f	2025-10-29 09:35:25.89837	t
1042	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:45:43.258826	d3e31248-9e7b-4d4e-aaf2-a9a8cc79b542	2025-10-31 13:46:42.563832	t
1009	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	5999-01-20	\N	\N	\N	\N	2025-10-30 11:41:05.12237	ecd7a400-cf54-4c88-ab8e-b05ab9a37759	2025-10-30 11:41:05.135279	f
985	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 10:21:16.658188	d5746bbb-a28e-4a09-bee2-8d72bacd1db8	2025-10-29 10:23:09.62562	t
1002	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-29 13:26:11.453601	a3bb0cde-7869-4808-a16a-5bc2f8ae1144	2025-10-29 13:27:18.596236	t
986	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	5999-01-20	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	\N	\N	2025-10-29 10:23:09.675296	4adc1384-0595-4389-b2cc-53f1a53e75ef	2025-10-29 10:24:14.63654	t
1018	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-30 13:12:44.696371	0ad13df8-4177-48c3-a9d4-c41a6b24c03d	2025-10-30 13:13:01.714752	t
1003	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-05	f546d1c3-036a-47dd-8662-9b37a914408f	\N	\N	\N	2025-10-29 13:27:18.648591	3488d3d3-8734-4d24-99be-a2587f4983e0	2025-10-29 13:27:33.720732	t
989	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 10:46:13.840622	3b242b2a-2d7c-4b81-9bf8-d53319b582f8	2025-10-29 10:49:40.816875	t
1011	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	5999-01-20	\N	\N	\N	\N	2025-10-30 11:43:46.704707	401b1297-11e5-4a7f-90a8-39aba881ddf1	2025-10-30 11:43:46.708949	f
1010	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	2025-11-06	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-30 11:42:14.279418	6dde9984-a749-4f20-a28e-3ef1102cba02	2025-10-30 11:44:50.13849	t
990	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-29 10:49:40.86978	91686881-8001-48c8-bee2-a92e226bc039	2025-10-29 10:51:21.415042	t
1012	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	2025-11-05	\N	\N	\N	\N	2025-10-30 11:44:50.150902	90a741b4-f0f9-48b1-9d51-0bce368fd8c1	2025-10-30 11:44:55.26596	f
1004	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-05	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 13:27:33.774444	30504bae-1011-49f6-bf59-526de4cd04b4	2025-10-29 13:28:07.744977	t
1034	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-11-10	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-31 13:02:57.30229	333c0032-9d53-4f79-886c-1267d7072262	2025-10-31 13:03:46.602035	t
991	16bd440d-2799-48da-b879-b1c7975e0ab6	\N	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 10:51:21.466421	455ff0fc-48a3-4e11-a188-68dd592b95e8	2025-10-29 10:52:04.691231	t
1019	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-30 13:13:01.76825	6b17b2de-7d97-4f83-a921-8d11677e1afc	2025-10-30 13:13:14.065655	t
1005	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-06	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 13:28:07.796156	be40ec83-b525-4f15-8ebd-68c73e1d9f93	2025-10-29 13:28:24.277705	t
993	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-05	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-10-29 10:54:48.83573	a04913b6-f49a-40e7-8b82-cb668fbc887c	2025-10-29 10:55:01.352025	f
1013	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	2025-11-05	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	\N	2025-10-30 12:05:20.018807	53d9c7f2-6cc0-41d7-a3ce-b0238fd3d4d8	2025-10-30 12:06:51.651517	t
1014	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	\N	5999-01-20	\N	\N	\N	\N	2025-10-30 12:07:34.29324	99c28aec-dd17-4513-a0a6-9f6e56c5cc84	2025-10-30 12:07:34.323007	f
1006	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-11-06	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-30 07:39:41.882285	e2bc1308-5d0a-4e2d-92e7-7fa90cf5c921	2025-10-30 07:39:55.559486	f
923	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-11-05	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-27 08:50:01.66084	bb4d1297-cbc9-4d86-956d-bf27625c6076	2025-10-30 12:31:09.317225	t
995	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-06	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-29 11:03:47.188322	cf9e8891-8705-4b62-a511-120838807028	2025-10-29 11:04:22.095768	t
1030	26341b8b-cb3e-430b-972c-c37f2b983743	\N	5999-01-20	\N	\N	\N	\N	2025-10-31 12:39:24.104024	bcd4fa81-5cc8-4a14-812b-29c961ec487f	2025-10-31 12:39:24.107622	f
1029	cdf23166-345a-4084-8437-92c51adbbe78	\N	2025-11-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 12:36:35.922094	387c48e4-f5b4-4905-aaf4-1a41fddf7981	2025-10-31 12:40:18.869822	t
1024	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-10-31 11:09:19.663477	f55f48c2-093a-45db-84e8-c0ac052b8177	2025-10-31 12:36:16.529882	t
1015	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	2025-11-06	bcb16827-828e-4e71-b66e-9ed61a8351b9	\N	1e4fa050-70ba-4031-9201-31d8cbd60b9a	\N	2025-10-30 12:31:09.369669	d3189c76-e87f-4fdc-98fd-3ebfb59f3e5a	2025-10-30 12:32:19.299354	t
1007	da96acd3-d31d-447e-9f4e-a805a1fc478c	\N	2025-11-06	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-30 08:18:58.861682	b804498d-2f96-49f7-b729-2a43405764c4	2025-10-30 08:20:21.167023	t
1020	c051ac7f-3de8-4be8-876f-ac50ab6b7824	\N	2025-11-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-30 13:13:14.079157	ed4b1d20-b647-468d-a3bd-7a0dae728107	2025-10-30 13:13:26.130077	t
1016	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	00bc93e0-ef32-471d-aade-da29ce6a1660	\N	\N	\N	2025-10-30 12:32:19.351233	ef7864a4-8fd7-4903-a834-52ea1fe261aa	2025-10-30 12:32:37.218528	t
1037	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-11-12	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-31 13:10:02.882786	b250c6a2-06b5-402f-ba6d-888af624b0dc	2025-10-31 13:10:25.540683	t
1017	cca63e0d-6cd7-4c22-8189-7aad30964b37	\N	5999-01-20	ace768c2-60a5-40f1-b745-63829f6b8d9f	\N	\N	\N	2025-10-30 12:32:37.272332	91dd142a-3649-4e8f-9eb2-33ec4e5aeeba	2025-10-30 12:32:53.570468	f
1027	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-10-31 12:36:16.582694	d383e16b-c790-4d84-a9a1-78adcbd2b399	2025-10-31 12:36:27.366618	t
1021	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	\N	\N	\N	\N	2025-10-31 11:07:55.361908	579df2df-722a-4424-a444-98f44eddf6db	2025-10-31 11:08:14.443382	t
982	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	\N	\N	\N	\N	2025-10-29 09:35:25.950847	0ed3653a-0d8c-4f3e-9cfd-3fac2b4cb248	2025-10-31 13:43:38.28032	t
1022	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-05	699509be-9a62-464c-b04f-d42efbd2154d	\N	\N	\N	2025-10-31 11:08:14.497151	4cafc862-f235-461f-891f-881ab41ece95	2025-10-31 11:08:35.999501	t
1026	ee16775d-0650-4c3f-b16d-6877ac69afe5	\N	2025-11-05	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	\N	2025-10-31 12:32:51.424946	d1c115bd-1953-444c-978f-63f1be93edfc	2025-10-31 12:36:35.909219	t
1033	81c6bb75-8c30-404b-904b-5d5afb2b2c47	\N	2025-11-10	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 12:50:15.630749	6d3ab642-9074-423b-916a-00fb2efb812c	2025-10-31 12:51:16.84974	t
1025	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	5999-01-20	\N	\N	\N	\N	2025-10-31 11:35:42.41389	6e76b853-1dac-460d-9f26-eb3b71dcdc5a	2025-10-31 13:02:57.289336	t
1036	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-11-11	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-31 13:09:31.817222	7196116e-3cd3-47bb-8b30-4fc1ec100af5	2025-10-31 13:10:02.830237	t
1031	26341b8b-cb3e-430b-972c-c37f2b983743	\N	2025-11-06	f59ee163-b076-4776-85b3-d0ba4c768838	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-31 12:40:18.921521	c462ab05-5861-48e2-bafe-321f57276496	2025-10-31 12:45:57.550235	t
1035	a6902413-ff8a-46a6-9b42-9db06927cc30	\N	2025-11-11	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	\N	2025-10-31 13:03:46.616413	5624ccdd-e024-453b-a798-cc14b7bbfcb1	2025-10-31 13:09:31.804718	t
1039	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-10	\N	\N	\N	\N	2025-10-31 13:44:47.21012	aef2e473-e2e6-4df8-b4c5-3da0850f4a38	2025-10-31 13:45:10.049769	t
1044	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-10	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:48:35.174076	77ceac56-6536-4687-a56b-92c4325368eb	2025-10-31 13:49:27.012328	t
1038	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-10	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:43:38.310923	3e4bc6d0-c974-4982-96c4-a4ea28961431	2025-10-31 13:44:50.380186	t
1040	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:44:50.412671	a75b129c-2908-43ef-986b-3c75a62cd8b6	2025-10-31 13:45:43.205251	t
1047	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-10	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-31 13:51:01.553529	0c636cd6-5411-40a4-96f5-80a9fc962d28	2025-10-31 13:51:11.638277	f
1043	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:46:42.576639	86131900-2df2-48d1-8203-613a72a58be2	2025-10-31 13:48:35.123221	t
1045	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-10-31 13:49:27.024356	33533a8a-0cd7-4b6d-afdb-d403146f7823	2025-10-31 13:50:31.547431	t
1041	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-10	\N	\N	\N	\N	2025-10-31 13:45:10.102903	8c93db3a-a7a1-40f5-bfe6-5b226b616b22	2025-10-31 13:51:01.503088	t
1046	806f8ddc-ab22-4e19-9513-953dab466dde	\N	5999-01-20	87e352df-7694-466a-a100-26aa80ff28e9	\N	\N	\N	2025-10-31 13:50:31.600872	05f9fab3-65ea-4a15-82c1-e96562a46aa4	2025-10-31 13:50:35.63707	f
1028	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	5999-01-20	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	\N	\N	2025-10-31 12:36:27.418552	e750d546-a656-4fcf-b505-98ded87db003	2025-11-01 06:39:08.005349	t
1048	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	\N	2025-11-11	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	\N	2025-10-31 14:03:30.267247	804bdf84-3e8b-4552-b2ba-c7e962fd7518	2025-10-31 14:04:13.708888	t
1049	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-11	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 06:39:08.019735	6aaeaa4b-54b1-40fe-aac1-332e917b0710	2025-11-01 06:39:41.756391	t
1050	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-12	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 06:39:41.778553	5091a71e-6a33-432a-a2d4-3435d21216ee	2025-11-01 06:39:56.470555	t
1051	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-13	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 06:39:56.522715	5bfbab77-6080-4be8-91a3-ae6b7c35ab81	2025-11-01 06:40:09.07419	t
1052	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-11	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	\N	\N	2025-11-01 07:15:19.576597	b9b8b0eb-e38e-4b73-a1f3-519e71af1231	2025-11-01 07:15:35.075481	t
1053	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-11	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 07:15:35.128613	05171264-8622-45a5-b7cd-acbf6fa8be36	2025-11-01 07:15:52.634214	t
1054	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-12	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 07:15:52.658237	19e4ed9c-ce3a-4774-8d05-33ca8a1fd632	2025-11-01 07:16:11.108916	t
1055	eb71ab5f-3f77-4ed0-abd1-b616992094a0	\N	2025-11-13	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	\N	2025-11-01 07:16:11.160965	4c848b4a-e072-4d77-9020-67ea3319f848	2025-11-01 07:17:40.441302	t
1056	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-13	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-11-01 07:17:40.492801	c7e68866-9112-469b-adb9-4383ad54a1c6	2025-11-01 07:18:05.166422	t
1057	806f8ddc-ab22-4e19-9513-953dab466dde	\N	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	\N	2025-11-01 07:18:05.186574	5c13bbe1-26fa-46fd-8aeb-ffc716d32ca2	2025-11-01 07:18:17.02268	t
\.


--
-- Data for Name: control_enter_isopenregistration; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_isopenregistration (id, created, modified, is_open, week_period) FROM stdin;
a0694526-edb1-46ff-97dc-1279f506b94a	2025-08-06 11:49:49.936381+00	2025-08-08 10:27:10.095482+00	f	11.08.2025-17.08.2025
111e4c5f-da17-4ed6-b373-c5993dedeb20	2025-08-08 10:27:20.268057+00	2025-08-15 12:40:34.066509+00	f	18.08.2025-24.08.2025
e736a5fa-b4a2-47aa-8925-db56d80f1fff	2025-08-15 12:59:21.137648+00	2025-08-22 13:24:15.983878+00	f	25.08.2025-31.08.2025
79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	2025-08-22 13:24:33.925644+00	2025-09-02 10:14:17.080612+00	f	01.09.2025-07.09.2025
8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	2025-08-29 14:05:35.500374+00	2025-09-08 14:58:55.211703+00	f	08.09.2025-14.09.2025
ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	2025-09-02 10:14:34.26132+00	2025-09-12 14:22:30.513725+00	f	15.09.2025-21.09.2025
77227e03-66c7-4acc-a3fa-d668e5b0082f	2025-09-02 15:16:29.457499+00	2025-09-23 09:34:33.077362+00	f	22.09.2025-28.09.2025
aea1e297-c227-4225-be65-58c2e016c6d9	2025-09-23 09:34:49.453109+00	2025-09-26 16:38:00.814458+00	f	29.09.2025-05.10.2025
404336fe-f633-4f90-a1d8-a46359509a67	2025-09-26 16:38:15.493691+00	2025-10-06 07:27:28.29392+00	f	06.10.2025-12.10.2025
ec24e516-92eb-4581-a649-078e2de3301f	2025-10-06 07:27:42.399858+00	2025-10-10 12:59:15.86503+00	f	13.10.2025-19.10.2025
6945203f-cd5a-451e-b768-cb4eb28883b5	2025-10-10 12:59:23.023737+00	2025-10-17 13:21:22.217702+00	f	20.10.2025-26.10.2025
895302a6-490e-4171-bfd4-d624f125094b	2025-10-17 13:21:35.604999+00	2025-10-24 13:59:33.856412+00	f	27.10.2025-02.11.2025
c3dcb4fa-80c3-4f1b-a6fd-6ffa99298556	2025-10-24 13:59:39.082219+00	2025-10-24 13:59:39.082234+00	f	03.11.2025-09.11.2025
f7a5b933-2ca1-4f5b-9357-55c34e0bd068	2025-10-24 14:00:51.566685+00	2025-10-31 12:45:33.334112+00	f	03.11.2025-09.11.2025
b52db266-73e5-4b78-ac94-34fa6ad2ab7f	2025-10-31 12:45:43.083289+00	2025-10-31 12:45:43.083303+00	t	10.11.2025-16.11.2025
\.


--
-- Data for Name: control_enter_openwindowforordering; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_openwindowforordering (id, created, modified, start_date, start_time, end_time, for_priority, week_period) FROM stdin;
\.


--
-- Data for Name: control_enter_workerweekstatus; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_workerweekstatus (id, created, modified, week_period, period_start, monday, tuesday, wednesday, thursday, friday, saturday, sunday, limit_executor, executor_id) FROM stdin;
a47be37b-5512-4cb9-8796-13181dac9497	2025-08-15 12:31:55.559875+00	2025-08-15 12:31:55.559889+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
b41bb678-f0c6-4441-a462-c674f46956b2	2025-08-15 12:32:13.682488+00	2025-08-15 12:32:13.682504+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
5c01d5e3-1d0c-4d92-bd73-bc7895d344ba	2025-08-15 12:32:34.197869+00	2025-08-15 12:32:34.197884+00	25.08.2025-31.08.2025	2025-08-25	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
9c312975-64df-45bb-bf96-f49e735a0960	2025-08-15 12:32:45.057839+00	2025-08-15 12:32:45.057853+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
a7f5656b-dff9-475e-847a-e08be1624efb	2025-08-15 12:33:05.06682+00	2025-08-15 12:33:24.960125+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
607230af-85fb-4ec2-8e3f-8a41c5826f62	2025-08-15 12:33:14.032526+00	2025-08-15 12:33:34.787886+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
0dcdf461-9649-431f-92fb-479cdf6d1b64	2025-08-15 12:35:46.627224+00	2025-08-15 12:35:46.627238+00	25.08.2025-31.08.2025	2025-08-25	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
78b75650-05f7-4084-97ba-ee7531fa0a15	2025-08-15 12:35:13.36614+00	2025-08-15 12:36:03.02503+00	25.08.2025-31.08.2025	2025-08-25	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
76beaf10-b674-4314-9aee-8704136fff31	2025-08-15 12:36:28.903823+00	2025-08-15 12:36:28.903838+00	25.08.2025-31.08.2025	2025-08-25	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
779cc487-2b5b-45ba-b818-6387d0d1a7c4	2025-08-15 12:56:37.623211+00	2025-08-15 12:56:37.623226+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
42a2bdfc-1fc6-4fc0-bcc4-2af8ee220d03	2025-08-15 12:55:13.740431+00	2025-08-22 13:25:13.201773+00	01.09.2025-07.09.2025	2025-09-01	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
208b008e-dad5-42ed-89f0-f80116afcce2	2025-08-22 13:25:26.40937+00	2025-08-22 13:25:26.409384+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
5099ecf0-94b0-4ec4-a72d-177b580d8ff2	2025-08-22 13:25:37.054932+00	2025-08-22 13:25:37.054947+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
08c065b2-d1e7-4a1d-ac4e-d188e517de0f	2025-08-22 13:25:48.513892+00	2025-08-22 13:25:48.513906+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
2c76d3d7-220c-4776-be87-d41875dd1b20	2025-08-22 13:26:14.346222+00	2025-08-22 13:26:14.346235+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
4e785b34-1157-4c7f-a4a6-0f27b9539464	2025-08-22 13:26:26.614994+00	2025-08-22 13:26:26.615006+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
45d112db-0c7f-443a-8ce6-86a2558244ed	2025-08-22 13:26:36.262439+00	2025-08-22 13:26:36.262452+00	18.08.2025-24.08.2025	2025-08-18	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
6370c504-fd9a-48cc-aaee-ce5ea7f11700	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
07bcbce1-08b6-4e9a-8e4f-56c00046c90b	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
427d1b1c-d32c-4df6-adaf-c8d6c95e00fe	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
08c3b374-8d44-4324-a9b1-c70494f3e59b	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
1177a664-900e-4a59-8ffd-f96dcf29beac	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
8c1f9c79-1cec-4778-83bc-fd28bad20c71	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
708056c6-1b90-4f0e-807d-4236890131f3	2025-08-25 00:00:00.043844+00	2025-08-25 00:00:00.043844+00	08.09.2025-14.09.2025	2025-09-08	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
0843f7ac-ecea-4159-b811-2b4076e91066	2025-08-25 07:40:14.537032+00	2025-08-25 07:40:14.537045+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
d7d6b855-5be5-47cd-a1c5-eb8436b630c5	2025-08-29 08:31:22.312424+00	2025-08-29 08:31:22.312438+00	01.09.2025-07.09.2025	2025-09-01	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
96fd9303-4fab-457f-b1b0-eba9bd1264a0	2025-08-25 00:00:00.043844+00	2025-08-29 14:04:08.778253+00	08.09.2025-14.09.2025	2025-09-08	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
08b32f01-e297-49f4-ac7c-480779481f41	2025-08-25 00:00:00.043844+00	2025-08-29 14:04:52.450665+00	08.09.2025-14.09.2025	2025-09-08	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
ee1fb136-e926-4ef7-be40-48d5eb38d3ec	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
6ce3fcb3-65f8-4644-9614-002a3dd58016	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
56ae274d-c8ee-49fb-9016-a3a58e92335d	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
abd9e8e8-6eb0-4bb8-a427-0ddc7a9991d8	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
5ef4b391-0b0a-4c98-8712-60d8c91e5b81	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
fdeebf1f-f389-4fdb-ab6a-210d3518d784	2025-09-01 00:00:00.045334+00	2025-09-02 10:18:31.865349+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
3246ad00-5c0e-411f-9ef7-75c942b74946	2025-09-01 00:00:00.045334+00	2025-09-11 12:46:33.722575+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
7cc46216-d4e5-4fdc-a75f-2653802bb430	2025-09-01 00:00:00.045334+00	2025-09-01 00:00:00.045334+00	15.09.2025-21.09.2025	2025-09-15	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
866ae771-00d0-4750-995f-5297c04efc17	2025-09-01 00:00:00.045334+00	2025-09-02 10:13:44.47732+00	15.09.2025-21.09.2025	2025-09-15	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
a7a61096-dc07-403f-8e14-e43677acef0d	2025-09-02 15:17:23.564462+00	2025-09-02 15:17:23.564475+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
c874821a-93f2-4635-a6bb-3fe15d46e32d	2025-09-02 15:17:36.648944+00	2025-09-02 15:17:36.648959+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
fa6de8aa-cb6c-4a6f-b076-3b495054a95e	2025-09-02 15:17:53.568442+00	2025-09-02 15:17:53.568456+00	22.09.2025-28.09.2025	2025-09-22	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
5431eadf-8d1b-4fc0-ac00-e43425428c2e	2025-09-02 15:18:07.328421+00	2025-09-02 15:18:07.328435+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
52d9fdaa-5c79-4724-af9f-665d04a20a16	2025-09-02 15:18:22.399734+00	2025-09-02 15:18:22.399749+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
b982a3c4-a931-4ea3-871e-c5d5fa88d0dc	2025-09-02 15:18:33.698182+00	2025-09-02 15:18:33.698195+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
6e32b21e-4b8e-4ba8-b66c-7baa79e4451f	2025-09-02 15:18:47.115827+00	2025-09-02 15:18:47.11584+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
68b00990-addc-42b5-9f4c-cf268655cbbf	2025-09-02 15:18:57.520772+00	2025-09-02 15:18:57.520786+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
13c92d54-95cb-4271-a767-061d3455157e	2025-09-02 15:19:16.410393+00	2025-09-02 15:19:16.410408+00	22.09.2025-28.09.2025	2025-09-22	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
f0394526-6379-4686-8a8f-0e4fdfb7b2ee	2025-09-02 15:26:45.020754+00	2025-09-02 15:26:45.020768+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
1946ae10-15e4-4fe9-b69d-c229fd94fd9e	2025-09-02 15:26:53.457992+00	2025-09-02 15:26:53.458005+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
ab5f9680-fbda-4cc6-b2a5-09c031a17da3	2025-09-02 15:27:02.590583+00	2025-09-02 15:27:02.590598+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
b1abe730-e0eb-4a23-94b2-77ad124caef4	2025-09-02 15:27:13.463376+00	2025-09-02 15:27:13.46339+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
4eefedd2-4d10-4d37-a62a-8e26c130f9eb	2025-09-02 15:27:26.19266+00	2025-09-02 15:27:26.192675+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
b38eb701-2493-4afe-ac30-79c4f6294d14	2025-09-02 15:27:38.835522+00	2025-09-02 15:27:38.835536+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
aafcc10e-198f-4ff4-8dbc-f44f9a10f83b	2025-09-02 15:27:55.220548+00	2025-09-02 15:27:55.220562+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
def530cc-abb8-4219-b909-c931548f703c	2025-09-02 15:28:04.558273+00	2025-09-02 15:28:04.558287+00	29.09.2025-05.10.2025	2025-09-29	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
7f0f481c-08d3-4e4d-8c03-7d6f547c6e63	2025-09-02 15:28:31.494711+00	2025-09-02 15:28:31.494725+00	29.09.2025-05.10.2025	2025-09-29	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
78642159-da42-449e-9ca7-a3ef8431ea0b	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
75ce9e4f-92c1-492c-ade1-08ec19e66fa4	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
bb080454-74d1-41eb-854a-d900bc9203f5	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
63902ed9-16cc-4bfe-a90e-d882e998d4fc	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
7864e244-6f8d-44f0-8926-8a7a00703bd7	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
85f8c1e8-8d91-4e4b-991a-232d657c964d	2025-09-22 00:00:00.046792+00	2025-09-22 00:00:00.046792+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
1d924d32-5564-4e87-8b00-9f8dc68a3864	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
18ae7b95-f315-4c8e-a37a-0a5501040572	2025-09-22 00:00:00.046792+00	2025-09-26 16:44:32.301233+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
3edbb7dd-8b7f-4e46-a284-dd918ddc4ae5	2025-09-22 00:00:00.046792+00	2025-09-26 16:44:48.832752+00	06.10.2025-12.10.2025	2025-10-06	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
9cc0d556-4343-4374-99be-73289e83f965	2025-09-22 00:00:00.046792+00	2025-09-26 16:44:57.564035+00	06.10.2025-12.10.2025	2025-10-06	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
c8dc7493-4057-4dd5-84b1-1e30fac19e7b	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
9c3eed22-2ba9-4274-97aa-c54f4f53d484	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
3b0a10ce-c3db-4ecb-823b-1d05e15a3141	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
42815817-2b72-4c90-8b0d-eb107fff1286	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
a3a224a9-cef0-4381-a71b-3f6b1e1c300d	2025-09-29 00:00:00.04431+00	2025-09-29 00:00:00.04431+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
22b5208d-81f9-4722-8e21-cb42a54befe8	2025-09-29 00:00:00.04431+00	2025-10-06 10:08:14.953098+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
d9cf8df7-cd28-49b8-8463-87a9366b8034	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
0eaeea25-3386-493a-9350-5120ac26ea5a	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
6558edde-5f9c-404c-acbb-7f11c5292b85	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
bacaaf4e-7ac0-4e2f-89db-f72d6c9d68b5	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
5cca469c-20c1-4bd9-b10c-0580694612dd	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
d05ca694-d5e9-4d67-9d67-8d7b57f97199	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
359226d1-bde0-4794-9a70-571c3cff878e	2025-10-06 00:00:00.07276+00	2025-10-06 00:00:00.07276+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
a0fc5f7d-c135-4063-b93e-d7fa9a295bef	2025-09-29 00:00:00.04431+00	2025-10-06 07:28:07.808721+00	13.10.2025-19.10.2025	2025-10-13	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
64ebdc07-ef15-451e-952d-57a08e881e60	2025-09-29 00:00:00.04431+00	2025-10-06 07:28:22.473428+00	13.10.2025-19.10.2025	2025-10-13	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
cecb1dfc-a584-4631-8ca7-5b3bd472ac51	2025-10-06 00:00:00.07276+00	2025-10-10 12:59:47.32721+00	20.10.2025-26.10.2025	2025-10-20	Болеет	Болеет	Болеет	Болеет	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
3db34704-b18b-4359-bb10-64927eaee7d6	2025-10-06 00:00:00.07276+00	2025-10-10 13:00:00.055091+00	20.10.2025-26.10.2025	2025-10-20	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
bd8aadaa-b780-400e-a1ee-50e3f1fe2a67	2025-10-13 00:00:00.046565+00	2025-10-17 13:22:08.915185+00	27.10.2025-02.11.2025	2025-10-27	Болеет	Болеет	Болеет	Болеет	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
c16f6854-29f2-44c6-ab38-880a45d0a833	2025-10-13 00:00:00.046565+00	2025-10-17 13:22:22.073592+00	27.10.2025-02.11.2025	2025-10-27	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
76969487-1ab3-47bf-aae3-b51b19af17eb	2025-10-13 00:00:00.046565+00	2025-10-17 13:22:45.29587+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Работает	Отпуск	Отпуск	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
fd56ff90-3825-454b-8902-14e5d397bff4	2025-10-13 00:00:00.046565+00	2025-10-17 13:22:56.912558+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Работает	Работает	Работает	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
fcb4ccc9-4d0b-4ac7-a3e6-595dc1b81388	2025-10-13 00:00:00.046565+00	2025-10-17 13:23:08.594084+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
e06c621b-469b-4d29-bfa4-097344423544	2025-10-13 00:00:00.046565+00	2025-10-17 13:23:24.194264+00	27.10.2025-02.11.2025	2025-10-27	Отпуск	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
34d39da1-cd64-412e-a663-0a3da87ec181	2025-10-13 00:00:00.046565+00	2025-10-17 13:23:30.481748+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Работает	Работает	Работает	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
9c237591-8956-4d86-b60d-ca682524ccd6	2025-10-13 00:00:00.046565+00	2025-10-17 13:23:36.499813+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Работает	Работает	Работает	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
0cf60478-6ea3-4e68-89ff-282808e730fd	2025-10-13 00:00:00.046565+00	2025-10-17 13:23:41.559459+00	27.10.2025-02.11.2025	2025-10-27	Работает	Работает	Работает	Работает	Работает	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
5782c9d9-4b9c-4f29-828f-ebc5e6cb58dd	2025-10-20 00:00:00.015286+00	2025-10-24 13:57:41.827848+00	03.11.2025-09.11.2025	2025-11-03	Выходной	Выходной	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
fc90d32f-947b-4f2b-880b-4c671c7c53fc	2025-10-20 00:00:00.015286+00	2025-10-24 13:58:46.110601+00	03.11.2025-09.11.2025	2025-11-03	Выходной	Выходной	Работает	Работает	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
3bd1b0b6-47ee-441b-a62f-a9b3d04ff9d5	2025-10-20 00:00:00.015286+00	2025-10-24 13:59:00.488951+00	03.11.2025-09.11.2025	2025-11-03	Выходной	Выходной	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
a0caa712-1c9a-4b4b-8dd3-4d309d50319b	2025-10-20 00:00:00.015286+00	2025-10-29 13:25:39.728174+00	03.11.2025-09.11.2025	2025-11-03	Отпуск	Отпуск	Работает	Работает	Отпуск	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
63436250-e1b3-43fd-ae48-e4d2fe5cea33	2025-10-20 00:00:00.015286+00	2025-10-24 13:56:54.472633+00	03.11.2025-09.11.2025	2025-11-03	Выходной	Выходной	Работает	Работает	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
c03d7b1b-388a-4a98-8b22-333dd48b7f99	2025-10-20 00:00:00.015286+00	2025-10-24 13:58:14.169547+00	03.11.2025-09.11.2025	2025-11-03	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
cc6a37ae-eaad-440a-ac4e-d1814820f6e4	2025-10-20 00:00:00.015286+00	2025-10-24 13:58:36.27986+00	03.11.2025-09.11.2025	2025-11-03	Выходной	Выходной	Работает	Работает	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
49f5e5c7-547a-4107-9995-c778c303e2a3	2025-10-27 00:00:00.046434+00	2025-10-27 00:00:00.046434+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
6eec7517-90af-4d97-90d7-525fa7f56a59	2025-10-27 00:00:00.046434+00	2025-10-27 00:00:00.046434+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	86bea85e-a62d-4dc0-8c0b-30541fd7782c
95a8d6e4-27c6-4d7c-9131-22746e7842cb	2025-10-27 00:00:00.046434+00	2025-10-27 00:00:00.046434+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1e4fa050-70ba-4031-9201-31d8cbd60b9a
b44e0b06-7c67-49b4-acdf-6609c9459ea4	2025-10-27 00:00:00.046434+00	2025-10-27 00:00:00.046434+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
a53017cb-d477-4c7d-8cd0-81a82fef44ca	2025-10-27 00:00:00.046434+00	2025-10-27 00:00:00.046434+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Работает	Работает	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
0f17ef02-06f8-4e12-8b32-19e37970f7a8	2025-10-20 00:00:00.015286+00	2025-10-29 11:13:24.398822+00	03.11.2025-09.11.2025	2025-11-03	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	8afa309b-cec8-4aaa-9031-06fe2b8267bf
57842e9a-041f-4e38-bd7f-abe0603644d1	2025-10-20 00:00:00.015286+00	2025-10-29 13:17:59.764767+00	03.11.2025-09.11.2025	2025-11-03	Отпуск	Отпуск	Работает	Работает	Выходной	Выходной	Выходной	2	1a5902da-bf12-4f7e-b055-775956f6adda
b6c038c1-e9f2-41b5-b946-9f7801a6ad39	2025-10-27 00:00:00.046434+00	2025-10-29 13:38:05.628903+00	10.11.2025-16.11.2025	2025-11-10	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
cd7e6d33-6dfa-46cf-a4cc-468bbe695826	2025-10-27 00:00:00.046434+00	2025-10-29 13:38:23.913208+00	10.11.2025-16.11.2025	2025-11-10	Работает	Работает	Выходной	Выходной	Выходной	Выходной	Выходной	2	09d8307c-2256-4f71-94e1-958c21e6f1bc
89e10785-2b23-4cdc-bbdb-10db3dce65fb	2025-10-27 00:00:00.046434+00	2025-10-29 13:38:57.507798+00	10.11.2025-16.11.2025	2025-11-10	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	d36c9e4f-2406-492b-b467-de7884e9a2e6
18a16145-4de3-46f7-b03d-de8c63f409bd	2025-10-27 00:00:00.046434+00	2025-10-29 13:39:15.336169+00	10.11.2025-16.11.2025	2025-11-10	Отпуск	Отпуск	Отпуск	Отпуск	Выходной	Выходной	Выходной	2	58c12ab6-e451-48b5-917e-26fc1855847a
\.


--
-- Data for Name: control_enter_workingdayofweek; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.control_enter_workingdayofweek (id, created, modified, week_period, period_start, monday, tuesday, wednesday, thursday, friday, saturday, sunday) FROM stdin;
32e6ef03-58f4-4e8f-80c4-bf5537058666	2025-06-04 13:28:07.751838+00	2025-06-04 13:28:07.751856+00	02.06.2025-08.06.2025	2025-06-02	t	t	t	t	t	f	f
65986bb1-234e-4c54-b5dd-ccd386a15b10	2025-06-02 18:10:42.698768+00	2025-06-06 10:34:34.539488+00	09.06.2025-15.06.2025	2025-06-09	t	t	t	t	t	f	f
b654ea09-0b0d-4b6b-a734-f986016465a5	2025-06-02 17:44:08.060738+00	2025-06-06 10:34:40.860717+00	16.06.2025-22.06.2025	2025-06-16	t	t	t	t	t	f	f
38c8dd99-25eb-4218-93d7-8a0dd5f207bf	2025-06-16 00:10:00.043962+00	2025-06-16 00:10:00.043962+00	30.06.2025-06.07.2025	2025-06-30	t	t	t	t	f	f	f
0cd4b566-36de-47fd-b77f-6d54c046230a	2025-06-23 00:10:00.043707+00	2025-06-23 00:10:00.043707+00	07.07.2025-13.07.2025	2025-07-07	t	t	t	t	f	f	f
db153c1a-0d8e-42a5-88fa-4e44c0fc99cc	2025-06-30 00:10:00.043757+00	2025-07-08 11:46:11.869991+00	14.07.2025-20.07.2025	2025-07-14	t	t	t	t	t	f	f
44f18cef-3faa-4e25-825a-0065626bf637	2025-07-14 00:10:00.008311+00	2025-07-14 00:10:00.008311+00	28.07.2025-03.08.2025	2025-07-28	t	t	t	t	f	f	f
c850b4c4-6f83-49c6-b0ca-6561cc8ce177	2025-07-28 00:10:00.007171+00	2025-07-28 00:10:00.007171+00	11.08.2025-17.08.2025	2025-08-11	t	t	t	t	f	f	f
2868184d-6f4b-4421-bdc2-d5599c7cb059	2025-07-21 00:10:00.044913+00	2025-07-30 15:20:48.888723+00	04.08.2025-10.08.2025	2025-08-04	t	t	t	t	f	f	f
8e456756-df25-49ec-b29a-51982a6cbd96	2025-08-04 00:10:00.006265+00	2025-08-04 00:10:00.006265+00	18.08.2025-24.08.2025	2025-08-18	t	t	t	t	f	f	f
21308ae9-d2c1-4359-ad6c-de864798f585	2025-08-11 00:10:00.043382+00	2025-08-11 00:10:00.043382+00	25.08.2025-31.08.2025	2025-08-25	t	t	t	t	f	f	f
085be2fb-6f81-4d4c-90b7-bc630b018ce7	2025-08-25 00:10:00.044362+00	2025-08-25 00:10:00.044362+00	08.09.2025-14.09.2025	2025-09-08	t	t	t	t	f	f	f
d92d6319-c2ab-4577-a978-21dbb6ad190e	2025-08-15 12:53:31.724083+00	2025-08-29 08:30:33.770013+00	01.09.2025-07.09.2025	2025-09-01	t	t	t	t	f	f	f
2656d2f7-6d95-4cc2-a0ab-e989f23c8585	2025-09-01 00:10:00.044043+00	2025-09-01 00:10:00.044043+00	15.09.2025-21.09.2025	2025-09-15	t	t	t	t	f	f	f
28bfdeb7-0078-425c-9ae3-ea66712dbf8a	2025-09-02 15:20:31.094854+00	2025-09-02 15:20:31.09487+00	22.09.2025-28.09.2025	2025-09-22	t	t	t	t	t	f	f
8b9ad3c9-9f6e-4cb4-b510-64a36bccb592	2025-09-02 15:26:10.068555+00	2025-09-02 15:26:10.068589+00	29.09.2025-05.10.2025	2025-09-29	t	t	t	t	t	f	f
24bcf2e8-af94-42ac-a57d-33d1bec00e23	2025-09-22 00:10:00.044669+00	2025-09-22 00:10:00.044669+00	06.10.2025-12.10.2025	2025-10-06	t	t	t	t	f	f	f
5e678abf-ffd0-465d-a847-f6e68416976f	2025-09-29 00:10:00.044108+00	2025-09-29 00:10:00.044108+00	13.10.2025-19.10.2025	2025-10-13	t	t	t	t	f	f	f
5f1a4d33-0503-4cde-a400-0b8fce90c8bb	2025-10-06 00:10:00.044041+00	2025-10-06 00:10:00.044041+00	20.10.2025-26.10.2025	2025-10-20	t	t	t	t	f	f	f
b110e071-dea3-4499-97f2-bc42268b926c	2025-10-13 00:10:00.042779+00	2025-10-17 13:24:05.780701+00	27.10.2025-02.11.2025	2025-10-27	t	t	t	t	t	f	f
e4a724f7-1dd6-4ce8-94c1-06269515afca	2025-10-20 00:10:00.044342+00	2025-10-24 13:59:16.810171+00	03.11.2025-09.11.2025	2025-11-03	f	f	t	t	f	f	f
b9b17583-2929-4b57-83b7-2cc8b503d052	2025-10-27 00:10:00.043406+00	2025-10-27 00:10:00.043406+00	10.11.2025-16.11.2025	2025-11-10	t	t	t	t	f	f	f
\.


--
-- Data for Name: dependings_analyzeperequipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_analyzeperequipment (id, count_samples, analazy_id, equipment_name_id) FROM stdin;
7dd395a4-3652-4450-98a0-80cb8a9b3693	12	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90
4ab314fc-7430-480b-a2e4-8209fcf92b19	12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
08dc2b8b-9ef1-43bd-831f-3e43112a125c	8	1b6870c5-c028-4f7d-b3a6-da026ec81032	ef5851f3-9428-411b-a8e0-77086b2e9d90
4e194ce7-ca13-4e35-b5ae-ad7f304dd741	6	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48
e80d95d5-3b67-448f-b8c5-a4dad25485d1	12	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
1d4210d8-b9e3-47cf-9fd2-c138db2b8191	12	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5
47520068-d119-47e0-a9b7-82cf86c41e38	8	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51
f4d86890-3f47-474b-89f2-41f44f2ee4af	12	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	fb09a7e8-8696-45ab-abc4-baa9e1440da5
9e5c8536-1488-4521-abef-5e2162d3e57d	12	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
de22a9eb-3341-4f6e-a7e2-08306aae6cfb	12	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3
151661f6-b9a4-485e-a0b0-79eec9653190	12	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09
f36c4f83-7cdc-466c-b0c6-f53eee215e52	12	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5
d1bfe6e8-c571-4188-a3f9-185b9954aebe	6	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384
07fa9507-7399-4cdb-ba6f-0fd7ab71feb5	6	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895
2bcddd69-9709-445d-9567-a86b0a947972	6	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895
44c5358c-8aee-4820-83c7-7a568f9d4065	12	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71
71cdf309-436c-41e2-ba9f-00290a6e03ce	12	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5
9283b3c3-596a-44c4-b907-1c36355e75f6	12	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5
7786e1b5-15f0-4730-b91f-9d2588d7b941	6	e40964e1-8934-428e-a06e-18379a30ebae	1de040d3-f437-4e55-a77c-c71c38fe0384
1d19b9bf-c98e-47d3-9c8e-4221f8e495c6	12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
3b35ac23-0b75-43dc-85ed-76dddd522db2	6	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384
ed0ed014-2191-4b97-af22-9d1ba16ba4c9	20	7da0bd39-87ac-4b74-b152-236e519597e1	e028e32c-581f-4b39-92ae-9a81552b7862
0ca15667-5429-4a44-b009-b1815a7fa312	12	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
007dd4bd-15cf-4911-a4af-80eaf37fa445	12	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
b94cee75-d835-424a-9486-55711407d0db	6	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48
2261a1c8-dd9f-4ba8-9fa1-ec23ddc712d9	8	13649857-bdb6-4771-8105-8dc1fd503ac9	612b7c5b-61b6-4795-8d07-98bc92bc4c51
dccd8d63-fa3a-4047-8909-fd25061670d9	12	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d
8d16e8bd-0e67-4612-ba99-bc03b3fea5b9	12	8cb45323-f121-47ad-969d-0ed9c2336674	0c0b62b6-c1b4-4828-8c87-b90396e2288d
b1f3e239-4317-4b5a-a752-e1aab475f793	12	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5
5645adea-fa77-4418-b7e7-2dbc05d4bdbb	6	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384
7ddc3b1d-54af-46fb-b500-14b8c36d398d	6	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384
7bbd84dd-6703-42e0-bfe1-f01da0373b59	12	e32c058b-38a7-4a49-a335-548da531c9b0	fb09a7e8-8696-45ab-abc4-baa9e1440da5
a37304bd-fc47-416e-97b6-f608b67a2f4b	12	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
37bdfb2c-3a5b-400e-8cfd-86bc61065487	12	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5
f4219c2e-5e50-4b01-b68a-2c42ebb65cbd	12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5
28ea3d9c-343e-42ed-96f3-9f96826a807c	12	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d
5ab69397-5731-4b15-a1dd-d62c647cac62	60	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	fb09a7e8-8696-45ab-abc4-baa9e1440da5
c0a83528-217f-423b-ac8b-0cc28f5d27b6	12	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71
aef268e6-5f4a-49df-b7d3-a64461905279	12	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
8fe966e3-5285-42a4-b619-ca707c9784e5	12	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5
f68b9664-d014-4676-948d-52498a46ca27	6	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384
c29e42b9-0143-4fb9-aff1-55067ffbf357	12	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
03c4508a-7099-4bcb-9860-2b8ba70c5f61	12	e40964e1-8934-428e-a06e-18379a30ebae	8bfe7234-ce4a-487c-8728-82b5f1956a71
bb943237-5422-4400-8732-e6208468ba5e	12	f70dda6c-3b1c-4248-bc15-93aefba973bb	8bfe7234-ce4a-487c-8728-82b5f1956a71
8bbaed61-6385-4441-9b1b-29b29e9e6bba	12	f70dda6c-3b1c-4248-bc15-93aefba973bb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
ce90b427-5ba7-4733-b069-fae18c0ed29f	12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71
4df9cb35-e582-4d8b-aadc-6aa30f438310	6	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51
f8d6c899-bbf4-48cd-9457-901947d9a933	12	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	0c0b62b6-c1b4-4828-8c87-b90396e2288d
9eebac2d-c944-4f98-9ec8-ca65b521dc3a	12	571c313e-8ec3-4777-bac7-40855117d510	fb09a7e8-8696-45ab-abc4-baa9e1440da5
8648582b-99a0-4c98-9aed-4ce84a6bb076	12	571c313e-8ec3-4777-bac7-40855117d510	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
c8ad8da1-b333-44d6-9675-7f98e3dd00e5	12	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5
9b363f9a-f896-402d-a91e-a142810e3ace	12	b6387178-b0f0-4227-afae-44d21dc68b1e	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
6ac32e74-b4aa-41dd-951a-cc2ebd42e5bb	6	b71923ee-67eb-4665-8b04-a71717ab9521	1de040d3-f437-4e55-a77c-c71c38fe0384
8ab9b452-5474-4631-a6c0-ae41d2526187	6	8797874d-0abe-4021-89f4-f64cf3582f9f	1de040d3-f437-4e55-a77c-c71c38fe0384
7823c2d6-91a3-4d22-bdc1-7cc65a49216f	12	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d
5a506418-b7ec-468c-a708-746a92fa11dd	6	1045bf64-4fb8-4c44-95c2-afe09bffa580	1de040d3-f437-4e55-a77c-c71c38fe0384
71e1a127-5520-4b2e-8b0a-deacd51a8803	12	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5
cb722bf8-c435-4c66-9944-069a7f5436a9	12	2ae252e7-ff77-4445-9bba-4f12636a2234	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
cbce33a1-3c56-4c54-b194-315442818858	12	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5
f86e431a-35a5-4355-9189-d0c9777daf32	12	1d7b838c-9f35-43e6-9cde-d63c11d9097f	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
56dce3bd-f938-4099-8242-08fd97768f51	12	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5
4dfce92c-0815-44bf-b5e1-ae773624a579	68	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
84df3dc6-49c1-4733-b757-ac6f61ef781e	12	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a
5825d295-a9b0-4220-9dca-659c73ea9ba0	6	9990d420-939a-48ce-b6ed-b4d9ef480bc5	1de040d3-f437-4e55-a77c-c71c38fe0384
aa00c97f-2258-4e04-8b9d-ee9c2d13bae2	12	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
3b2f0fa5-d5ff-4b74-bc28-a0bb4103597a	6	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48
d952f5ed-8100-42e3-befe-667ece5750e3	12	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
db048f9e-e4e9-457b-b02c-cd1f8ffe885a	6	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51
c04a24f8-7c9e-4e04-ba80-992cc8e10f20	6	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48
076d6629-1673-4e85-86d4-661d47c51931	12	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5
ab52e557-dc09-4846-a544-95187ce77822	12	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
b5752093-8aa4-4afc-bb23-2eaa75b5d973	12	e40964e1-8934-428e-a06e-18379a30ebae	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
816a15ab-4636-4b60-8c01-5f6a914e66f3	12	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3
82b86dd0-1992-4c77-bd63-34cf5e618442	6	261aa121-300a-43d2-bfcf-b4d27630954c	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
4cbf9bb5-b9b4-403e-b8a7-2ea41784201c	12	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
81fc3753-a62e-49f5-ad15-1951fbd60060	12	488bedde-e9a3-4ab1-a96a-585818dde2d0	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
fcceda6b-8d2f-4ff2-9755-514f6efef62a	12	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	62824931-02d2-45a1-9fb1-17050db2b92b
5ca41c64-e78c-455c-ad3c-2d73be0fe1c3	12	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b
38149389-b029-408f-a779-2f1fea6a7460	2	d7b878e3-64f8-4627-b34c-b9acc1cae09e	ef5851f3-9428-411b-a8e0-77086b2e9d90
71cecbd7-d29a-4128-9509-8e65b2d05fc7	12	fdc73d75-74c1-44e9-b276-2b748d35620b	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
65a30651-7236-4933-a05a-e8c774663c5e	12	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
0b924349-8b40-4893-826f-1f762571b345	12	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3
6ce21107-4e96-4198-8744-f38680e66785	18	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3
ff514302-8ae9-4343-9bb3-53c7e1395fc6	6	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384
ad9e717a-11c5-4304-a23b-d5499680af1b	12	563ae91e-3338-45f7-aead-c5a3c7a57f63	8bfe7234-ce4a-487c-8728-82b5f1956a71
a802e109-6b53-42fd-aeb9-81c5ff902b17	12	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	fb09a7e8-8696-45ab-abc4-baa9e1440da5
63ade532-4c50-4d62-9441-db2b732b4083	12	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf
83635efb-56a4-4bff-a8f2-245739f40fc7	12	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1
14bb3a20-dc58-4d92-ad61-be551ccad6e4	24	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb
9ecc8c22-1520-4ec8-99c2-c07ae2169f1e	6	f59ee163-b076-4776-85b3-d0ba4c768838	54e28c12-acd4-4c69-a0a6-815a77c4e895
2232369d-4410-4839-9121-bea4fe8ed9d1	6	f59ee163-b076-4776-85b3-d0ba4c768838	1de040d3-f437-4e55-a77c-c71c38fe0384
98815365-3bbe-4d9f-a26d-93034a0c11a3	15	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1
\.


--
-- Data for Name: dependings_operatorperequipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_operatorperequipment (id, is_priority, equipment_id, operator_id) FROM stdin;
c37e1b7a-bf5b-427d-ab59-f530c2810d10	f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c
8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	t	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c
ebe0ca91-0214-453a-91f3-925bd53f5606	t	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda
59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	t	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda
3c24341c-235d-4d4b-8561-1f7cf0d108ff	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c
5f9f0bd3-186e-4ee7-9207-8dcbc67c4ea9	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	d36c9e4f-2406-492b-b467-de7884e9a2e6
14cdc62c-f9c2-4043-85a3-99451ebee7fc	t	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6
94189595-1d95-4782-8464-b338640e1b5e	t	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a
eed4b9b6-0e16-4811-ac84-9c8851e8d4ae	t	0c0b62b6-c1b4-4828-8c87-b90396e2288d	58c12ab6-e451-48b5-917e-26fc1855847a
4adae582-a899-4520-9bf1-c4e1411938b9	t	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a
e1dfe070-72f1-4a0f-ae0d-300903a686e2	t	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a
3add5154-d941-43d3-a891-28512fd90890	f	0c0b62b6-c1b4-4828-8c87-b90396e2288d	86bea85e-a62d-4dc0-8c0b-30541fd7782c
8e372a71-ce34-4bcd-8d2a-71379b5b2e58	t	27dc31dd-0a11-452e-ac1e-aeb052f18226	8afa309b-cec8-4aaa-9031-06fe2b8267bf
bd3d2f53-fdf4-4ff5-b267-13435039ecde	t	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf
b70cb072-2435-472e-8579-a0e6d5d9e70e	t	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf
821c378b-aaed-45b3-a007-8b620e34126f	t	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
438c240d-734b-44d9-a17f-7259172dc398	f	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
54968de3-1f18-4d08-a485-a83a3e89cb3f	f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
a5d446a8-3fa6-47f3-9a84-eb428f14e600	f	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a
109918bd-fe82-40b4-88a8-7ace7535ab4c	t	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a
3d2dc186-dcb4-4876-9d18-7252d8181131	f	322bde1c-c844-44d7-8846-a773b9f97679	1e4fa050-70ba-4031-9201-31d8cbd60b9a
4ef7cae5-4722-45b1-bc60-d3a241c8d08f	f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc
c47fcc37-09db-4099-aad3-462f24cb56a2	f	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc
d7a75b52-413a-4746-ad74-86b7c9fbac7c	f	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda
d498d870-a170-4a66-b65d-4d0068fd336e	f	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
e3348e14-7e1d-4f98-b0a7-42cff53daa3a	t	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf
fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	f	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	86bea85e-a62d-4dc0-8c0b-30541fd7782c
702157a8-9348-41e5-bae7-961a0e3e5940	t	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf
9fea634d-d28f-4130-928f-ed64f39998c3	t	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6
08449636-2537-4ea7-a4e0-78b92ced819b	f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3
1c725a40-a0af-4618-b088-1f6bb594a2fe	f	62824931-02d2-45a1-9fb1-17050db2b92b	09d8307c-2256-4f71-94e1-958c21e6f1bc
f13c28fd-3664-4830-a367-1192991999cd	f	62824931-02d2-45a1-9fb1-17050db2b92b	d36c9e4f-2406-492b-b467-de7884e9a2e6
db23fb9e-8a5a-411e-98b0-359bdd876217	f	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a
0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	f	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
7a2e39e0-972a-4e11-aaf7-4091306b4bb4	t	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a
ddbbbef1-5970-4d30-9056-866ae656b91a	f	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a
20d1960d-7758-4ca0-9a70-50ad8d901f09	f	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	ad7a9a32-69c3-46c0-b5b9-80f11dc55797
\.


--
-- Data for Name: dependings_projectperanalyze; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.dependings_projectperanalyze (id, limit_samples, analazy_n_id, project_n_id) FROM stdin;
d3b71632-d535-4eae-ad5f-a26e5536f503	12	eecdd0f8-7244-4bf6-8f96-65622901a51d	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
fc476729-c88c-456d-b1fd-3125b23bc244	60	0b6e2138-4fc5-4404-b584-6707d4890102	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
d2307861-ee3b-426a-98fa-259d83ac47d0	60	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
ed419b7e-46a8-40d0-9b86-7f292f45bfcf	24	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
eccc3238-6a69-450f-a3e2-4785fefe6ed4	60	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
cdb3e289-dd41-4e0e-826c-b99270b5eeb2	40	601b7b77-ab12-477c-918e-ca3910a3bb96	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
c0d394f6-e583-4327-9acc-20a826b40cac	60	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	cdf23166-345a-4084-8437-92c51adbbe78
1c051ae6-a3a0-4637-8011-45d15e7d7590	60	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	cdf23166-345a-4084-8437-92c51adbbe78
5a4b0048-0b0a-484b-942a-404ff2f5c530	60	1b6870c5-c028-4f7d-b3a6-da026ec81032	16bd440d-2799-48da-b879-b1c7975e0ab6
ff3de101-baf4-4b64-9c64-7e7e7127ef38	60	7b74a6a1-d92b-476a-befc-0783a20e9170	16bd440d-2799-48da-b879-b1c7975e0ab6
b8fddb19-3e5d-4538-9db3-800c8ca2602f	60	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	806f8ddc-ab22-4e19-9513-953dab466dde
09db72b2-a1b9-4d7d-87bf-152bca5232b3	60	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	c051ac7f-3de8-4be8-876f-ac50ab6b7824
cd93279c-e67a-4059-b8b8-090fa9478f8b	60	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	cdf23166-345a-4084-8437-92c51adbbe78
15006c04-e8b0-4334-8170-2ea34badf7f8	60	3893f977-8f70-49be-903b-ed0149e4a505	cdf23166-345a-4084-8437-92c51adbbe78
072d6497-ead1-40d7-93ea-da2b11b3fd96	60	ca0a4632-47de-4590-b84b-5835604a02c6	cdf23166-345a-4084-8437-92c51adbbe78
31880a90-ca26-45c6-a028-9f7437fb2750	36	00bc93e0-ef32-471d-aade-da29ce6a1660	cca63e0d-6cd7-4c22-8189-7aad30964b37
48e67666-a178-4dfb-b8d2-85ce726187a6	48	ace768c2-60a5-40f1-b745-63829f6b8d9f	cca63e0d-6cd7-4c22-8189-7aad30964b37
a9155a4a-52b3-4fd2-8914-0b5946202948	60	7129f484-2524-4bc2-a857-7a4663b6abbb	cca63e0d-6cd7-4c22-8189-7aad30964b37
a70d2f4d-4f31-4850-9aae-be1e525f12ef	60	fdc73d75-74c1-44e9-b276-2b748d35620b	ee16775d-0650-4c3f-b16d-6877ac69afe5
009c1502-fe8e-4d71-a9f3-148896cae5be	24	e40964e1-8934-428e-a06e-18379a30ebae	ee16775d-0650-4c3f-b16d-6877ac69afe5
56273adb-0ad0-464b-ad71-01602e166556	24	62608399-2245-470d-a950-4eec08632518	a4636783-1d55-415b-bbc2-deb27cdcf0f2
ce69a7e9-c0b4-4c5e-aa3c-6d42e45bcba3	24	5902477d-a765-4934-a832-4fb9a01cf704	1a7ae4d5-2c2e-419e-b36a-2eca4be41641
a19efd46-bef1-4ff5-beb0-1cda8bc2f192	48	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	a6902413-ff8a-46a6-9b42-9db06927cc30
236f9fd5-dec6-4395-a98c-4195510b8835	48	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	a6902413-ff8a-46a6-9b42-9db06927cc30
f54c9bf8-c3e0-4176-92aa-c139c61167d8	48	c5484c5f-6ed9-4743-b796-b668e486b652	a6902413-ff8a-46a6-9b42-9db06927cc30
f6478254-e3db-48a0-a535-3b91e8eb1e34	48	1d7b838c-9f35-43e6-9cde-d63c11d9097f	a6902413-ff8a-46a6-9b42-9db06927cc30
68d539c7-3ce7-4876-b08c-5776e3b3a683	48	571c313e-8ec3-4777-bac7-40855117d510	a6902413-ff8a-46a6-9b42-9db06927cc30
fbd0b4bb-1d67-4889-ab11-965bf33215d7	48	b6387178-b0f0-4227-afae-44d21dc68b1e	a6902413-ff8a-46a6-9b42-9db06927cc30
e41f35ff-883b-4720-b86f-8f6da2eaf2d2	24	b71923ee-67eb-4665-8b04-a71717ab9521	a6902413-ff8a-46a6-9b42-9db06927cc30
d594ffb9-8a9a-4538-968a-c924e507fd96	24	8797874d-0abe-4021-89f4-f64cf3582f9f	a6902413-ff8a-46a6-9b42-9db06927cc30
41e43acd-3e47-44f6-81c6-54d415800280	24	1045bf64-4fb8-4c44-95c2-afe09bffa580	a6902413-ff8a-46a6-9b42-9db06927cc30
8e63aaf4-36cf-468d-bd2a-57ab02c41961	48	2ae252e7-ff77-4445-9bba-4f12636a2234	a6902413-ff8a-46a6-9b42-9db06927cc30
9d6ec97a-a496-4175-8d31-4ce669c561e4	96	bcb16827-828e-4e71-b66e-9ed61a8351b9	cca63e0d-6cd7-4c22-8189-7aad30964b37
ba1c5859-9d15-45e3-9ffe-34e3ce304911	68	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	04567c72-d2d7-43fc-baa5-d22abe61e00e
b8d660a9-f7b3-44fe-bc0d-0cdb98bb368e	48	7da0bd39-87ac-4b74-b152-236e519597e1	c051ac7f-3de8-4be8-876f-ac50ab6b7824
736cdf51-9199-4643-aed6-f49f59fe149c	24	9990d420-939a-48ce-b6ed-b4d9ef480bc5	16bd440d-2799-48da-b879-b1c7975e0ab6
c02fdcab-8cff-423c-9c9c-699bdecb0f2d	48	49334d2e-dc24-4efc-b25a-8054959b1fcb	16bd440d-2799-48da-b879-b1c7975e0ab6
dd05d845-ee8a-4b39-bab3-c0a9cf2ef9f3	48	16ea24f6-2468-4895-9715-2edadc26b522	81c6bb75-8c30-404b-904b-5d5afb2b2c47
16602904-8d9c-430b-9e40-408b6c7a1e6d	24	2f016b91-0b94-4000-bb68-b6fd5be22a0e	81c6bb75-8c30-404b-904b-5d5afb2b2c47
d06accd4-2d6d-4272-8815-a2ec02ea975c	24	6c07ef7d-b39c-4c57-8c2b-0758a52be082	81c6bb75-8c30-404b-904b-5d5afb2b2c47
c997c665-eaf0-4e08-b35b-dd1e7bf77cba	24	9fe01f07-a489-4eca-8639-403986129de1	81c6bb75-8c30-404b-904b-5d5afb2b2c47
6af93ff9-35d2-4b7f-b16c-338481c8827e	48	020da433-e3a3-419c-851f-f52102a5fe00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
16dc611c-5452-4276-8889-22ad584de69e	24	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
53b9b602-157f-458c-913b-54f1cbdd1290	24	f546d1c3-036a-47dd-8662-9b37a914408f	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
b87b137b-eaf8-4080-bd8e-019b3ad8f91f	48	699509be-9a62-464c-b04f-d42efbd2154d	eb71ab5f-3f77-4ed0-abd1-b616992094a0
cadfd728-9a0b-45d3-9322-6417c1f3e09f	24	f76acc0f-710d-4387-8731-dc6d8fd5782c	eb71ab5f-3f77-4ed0-abd1-b616992094a0
67bb91e8-fd94-400d-9ecd-14dd8d28fa86	60	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	eb71ab5f-3f77-4ed0-abd1-b616992094a0
4b51feb8-cfdb-48e8-89f4-53f4a66681eb	48	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	da96acd3-d31d-447e-9f4e-a805a1fc478c
69e1197d-b78f-46fb-b42a-b460bc03d044	24	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3
47e89628-b81d-4a9c-a7ea-575983c77587	12	261aa121-300a-43d2-bfcf-b4d27630954c	ee16775d-0650-4c3f-b16d-6877ac69afe5
bcfee098-7bc9-4085-bd58-a0c8cd7f7987	48	488bedde-e9a3-4ab1-a96a-585818dde2d0	16bd440d-2799-48da-b879-b1c7975e0ab6
71a3826c-bb94-499b-bf32-b10cd9dc54cc	4	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	6ef1e776-af1e-48ba-b443-d26c231b6292
dada5a13-0108-428d-8b41-13f0cf4a969c	4	d7b878e3-64f8-4627-b34c-b9acc1cae09e	69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0
99237cae-e1a4-445e-ba5e-a76176cc8d13	48	87e352df-7694-466a-a100-26aa80ff28e9	806f8ddc-ab22-4e19-9513-953dab466dde
474344e6-912c-4b0f-93b1-0cfd05c8045c	24	571cd566-5150-4b80-9221-233cd3d39b87	04567c72-d2d7-43fc-baa5-d22abe61e00e
1f3f2834-b7c9-4769-b7a8-c8c279aad56d	24	4e1fbb62-07ef-441b-a27b-1956581e9ca8	04567c72-d2d7-43fc-baa5-d22abe61e00e
a3730243-6266-4ebd-ad68-85c18c17eae5	12	a426aa21-8248-4fad-8ed2-f82aa388d1b5	04567c72-d2d7-43fc-baa5-d22abe61e00e
4fa09ea1-0cd5-461f-a93b-ab597ee7bdba	24	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	04567c72-d2d7-43fc-baa5-d22abe61e00e
90fb5920-1cc7-414b-b898-6986549124b2	18	73129017-ac9d-4a55-9020-7192a2b3150a	ee16775d-0650-4c3f-b16d-6877ac69afe5
a74ea5ba-8ddf-423b-a37f-73a8d60deb9e	24	f70dda6c-3b1c-4248-bc15-93aefba973bb	a4636783-1d55-415b-bbc2-deb27cdcf0f2
b65afc11-acb0-40cd-8a83-bcf593f9a228	48	091e7bb0-f31d-4465-8e6f-130e5f83d454	a4636783-1d55-415b-bbc2-deb27cdcf0f2
2ce2279d-3822-40b1-a608-4f1559c9f593	24	563ae91e-3338-45f7-aead-c5a3c7a57f63	a4636783-1d55-415b-bbc2-deb27cdcf0f2
6815673c-2446-4a80-b398-c62ed68461c2	48	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	e8b5c31f-6da6-4385-adbb-06014c9e6e01
4f2ab503-d684-47b9-a232-f3ac48b341c5	48	1a901c9f-deb2-4451-a71b-4a059e561058	16bd440d-2799-48da-b879-b1c7975e0ab6
e932f75a-1e19-4815-8b0b-bb01c9a1b2b1	48	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e
35ac0b0a-56b7-44b9-bf14-5c3e99e175f1	24	f59ee163-b076-4776-85b3-d0ba4c768838	26341b8b-cb3e-430b-972c-c37f2b983743
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-05-04 13:10:26.356542+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор admin	1	[{"added": {}}]	11	1
2	2025-05-04 13:11:32.681579+00	c7dba098-3d33-445c-a23b-57c247eee687	тип1	1	[{"added": {}}]	12	1
3	2025-05-04 13:11:35.493498+00	dd7560f9-712c-405d-9c82-190ff14317d2	Анализ1 : тип1	1	[{"added": {}}]	16	1
4	2025-05-04 13:11:51.592492+00	3b62ef9e-48c6-4129-b130-47b56bc69974	Иван  Иванов  Иванович	1	[{"added": {}}]	14	1
5	2025-05-04 13:11:58.69856+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Прибор1	1	[{"added": {}}]	13	1
6	2025-05-04 13:12:09.785285+00	dcd67bb3-44d5-47f1-8264-5b691f5860b7	Анализ1 : тип1 - Прибор1	1	[{"added": {}}]	19	1
7	2025-05-04 13:12:51.930736+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	15	1
8	2025-05-04 13:12:59.57707+00	b3a39687-1f34-4afe-8adf-3d90e539fbcd	Иван  Иванов  Иванович - Прибор1	1	[{"added": {}}]	18	1
9	2025-05-04 13:13:14.593118+00	341aa76d-7d9d-4865-b89c-43dee4771fd4	Окно бронирования на 04.05.2025 с 00:00 до 24:00, период недели: 05.05.2025-11.05.2025	1	[{"added": {}}]	8	1
10	2025-05-04 13:13:25.298694+00	2f9e27ae-f0f8-40e9-8be3-a02e18501804	05.05.2025-11.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
11	2025-05-04 13:13:33.049846+00	2623aef7-c1f0-4f03-b927-d982e763c860	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">05.05.2025-11.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
12	2025-05-04 13:14:24.299961+00	b0bbc07e-59be-4579-a6df-94890c712abd	Анализ1 : тип1 - proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	17	1
13	2025-05-09 10:38:14.86792+00	bc96aaf3-0c60-4837-b95a-0bb644d28774	12.05.2025-18.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
14	2025-05-09 10:38:30.145418+00	7a891ed2-b504-44c6-84d8-61ab1af181e1	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">12.05.2025-18.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
15	2025-05-09 10:38:52.641487+00	46aeb0ce-6415-449c-bde8-daa90370a369	Окно бронирования на 09.05.2025 с 00:00 до 17:00, период недели: 12.05.2025-18.05.2025	1	[{"added": {}}]	8	1
16	2025-05-19 18:42:14.572622+00	46aeb0ce-6415-449c-bde8-daa90370a369	Окно бронирования на 09.05.2025 с 00:00 до 17:00, период недели: 12.05.2025-18.05.2025	3		8	1
17	2025-05-19 18:42:14.581764+00	341aa76d-7d9d-4865-b89c-43dee4771fd4	Окно бронирования на 04.05.2025 с 00:00 до 24:00, период недели: 05.05.2025-11.05.2025	3		8	1
18	2025-05-19 18:42:25.801396+00	3765642b-4174-4a95-814f-cc9f185db017	Окно бронирования на 19.05.2025 с 00:00 до 24:00, период недели: 19.05.2025-25.05.2025	1	[{"added": {}}]	8	1
19	2025-05-19 18:42:32.538128+00	bc96aaf3-0c60-4837-b95a-0bb644d28774	12.05.2025-18.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
20	2025-05-19 18:42:32.541621+00	2f9e27ae-f0f8-40e9-8be3-a02e18501804	05.05.2025-11.05.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
21	2025-05-19 18:42:32.544282+00	1773bb1d-8d81-4068-a79c-c23c86e71d62	26.05.2025-01.06.2025 - Иван  Иванов  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	1
22	2025-05-19 18:42:42.111868+00	ad217dad-235c-4b8d-84c7-cfbd9b945585	19.05.2025-25.05.2025 - Иван  Иванов  Иванович | Выходной | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
23	2025-05-19 18:42:49.138996+00	dce619e0-b00a-4c2f-be06-4f5959f6fc96	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
24	2025-05-19 18:42:49.141367+00	7a891ed2-b504-44c6-84d8-61ab1af181e1	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">12.05.2025-18.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
25	2025-05-19 18:42:49.143121+00	2623aef7-c1f0-4f03-b927-d982e763c860	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">05.05.2025-11.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
26	2025-05-19 18:42:55.265751+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
27	2025-05-20 11:56:55.090681+00	c7dba098-3d33-445c-a23b-57c247eee687	Основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	1
28	2025-05-20 11:57:33.152481+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met : Основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	1
29	2025-05-20 11:58:33.389719+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примесь	1	[{"added": {}}]	12	1
30	2025-05-20 11:58:41.572403+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	1
31	2025-05-20 11:59:21.996104+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Петрович	1	[{"added": {}}]	14	1
32	2025-05-20 11:59:35.557005+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  None	2	[{"changed": {"fields": ["\\u041e\\u0442\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	14	1
33	2025-05-20 12:04:55.067782+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Иванович	2	[{"changed": {"fields": ["\\u041e\\u0442\\u0447\\u0435\\u0441\\u0442\\u0432\\u043e"]}}]	14	1
34	2025-05-20 12:05:41.822897+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
35	2025-05-20 12:05:59.680195+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Saykam	1	[{"added": {}}]	13	1
36	2025-05-20 12:06:13.704088+00	322bde1c-c844-44d7-8846-a773b9f97679	Waters	1	[{"added": {}}]	13	1
1185	2025-09-12 09:17:42.883403+00	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	ResearchGSH : Reaserch	1	[{"added": {}}]	16	5
37	2025-05-20 12:06:49.262831+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (project1рук) : Приоритетный 	2	[]	15	1
38	2025-05-20 12:08:20.863078+00	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	Met_2 : Примеси	1	[{"added": {}}]	16	1
39	2025-05-20 12:08:26.869082+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met_1 : Основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	1
40	2025-05-20 12:08:56.763335+00	ba1093f0-eb98-4903-a5c4-46c590689d07	Met_2 : Примеси - Saykam	1	[{"added": {}}]	19	1
41	2025-05-20 12:09:08.850991+00	dcd67bb3-44d5-47f1-8264-5b691f5860b7	Met_1 : Основной продукт - Agilent	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	1
42	2025-05-20 12:09:31.765042+00	b7740e8c-2d86-448a-a2ce-43e245433772	Петр  Петров  Иванович - Saykam	1	[{"added": {}}]	18	1
43	2025-05-20 12:09:54.189214+00	bf2f0c85-d935-4a3f-8f60-5d67902948a9	Met_2 : Примеси - proj_1 (project1рук) : Приоритетный 	1	[{"added": {}}]	17	1
44	2025-05-20 12:14:19.970049+00	9fe49fe0-d44f-4fa0-a14c-2f42900d5011	26.05.2025-01.06.2025 - Петр  Петров  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
45	2025-05-21 14:11:02.481017+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	proj_1 (Сидоров) : Приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	1
46	2025-05-21 14:11:23.406345+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	1
47	2025-05-21 14:12:29.085338+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	1
48	2025-05-21 14:22:51.751737+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: gray;'>Вт  	2	[{"changed": {"fields": ["\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	9	1
49	2025-05-21 14:46:51.068764+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	15	1
50	2025-05-21 15:07:39.095856+00	837ada9a-9407-47ef-a0c0-aee56edb6160	Администратор Иван	1	[{"added": {}}]	11	1
51	2025-05-21 15:08:36.660232+00	da3047ce-76fe-4d82-ba86-c121399b066e	Ттипа	1	[{"added": {}}]	12	1
52	2025-05-21 15:08:55.74264+00	3b95b72a-5cfb-4a4d-9307-3a382d1e19d7	АнализТестовый : Ттипа	1	[{"added": {}}]	16	1
53	2025-05-21 15:13:17.032622+00	75849d6f-a7a0-4297-b44b-db351e31e5d8	АнализТестовый : Ттипа - Waters	1	[{"added": {}}]	19	1
54	2025-05-21 15:14:23.263894+00	45827d69-eb35-4a5d-bb96-2f86fa5fea27	АнализТестовый : Ттипа - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	1
55	2025-05-21 15:14:51.563069+00	9e42712b-a968-4b81-858f-02b31f9ab85a	Иван  Иванов  Иванович - Waters	1	[{"added": {}}]	18	1
56	2025-05-21 15:17:59.849071+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	8	1
57	2025-05-21 15:20:39.713128+00	55bc1448-28a9-46ec-8a9c-da2cb4d3f069	26.05.2025-01.06.2025 - Иван  Иванов  Иванович | Работает | Занят | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
58	2025-05-21 15:21:06.887206+00	97112c5a-e332-4efe-9b45-b717c45523a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
59	2025-05-21 15:22:17.736919+00	9c956582-d1b6-40d2-8077-879fd07079ed	19.05.2025-25.05.2025 - Петр  Петров  Иванович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
60	2025-05-21 15:22:35.977062+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	7	1
61	2025-05-21 15:22:45.535923+00	406d22a2-a71c-4278-9800-c05973e728d2	Закрыта период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	1
62	2025-05-21 15:22:59.175432+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
63	2025-05-21 15:23:22.776632+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	1
64	2025-05-21 15:36:54.114497+00	adf5ec6d-c735-4f8b-a24f-7e314d90b1cd	Окно бронирования на 22.05.2025 с 06:00 до 15:00, период недели: 26.05.2025-01.06.2025	1	[{"added": {}}]	8	1
65	2025-05-21 15:45:47.103493+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	1	[{"added": {}}]	11	1
66	2025-05-21 15:46:00.081438+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	2	[{"changed": {"fields": ["\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	11	1
67	2025-05-21 15:46:14.112137+00	3014289a-9317-49cf-bbff-cec1e82c9121	Администратор test2admin	3		11	1
68	2025-05-21 16:16:36.736094+00	837ada9a-9407-47ef-a0c0-aee56edb6160	Администратор Федорова Е.Н.	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	11	1
69	2025-05-21 16:19:01.254104+00	28aeaae9-88d4-43da-9f5f-663912f3461f	Администратор Киверо А.Д.	1	[{"added": {}}]	11	1
70	2025-05-21 16:19:26.143288+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор Admin Main	2	[{"changed": {"fields": ["\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e"]}}]	11	1
163	2025-05-29 14:18:55.407037+00	c37e1b7a-bf5b-427d-ab59-f530c2810d10	Борзенко  Татьяна  Сергеевна - Methrohm	1	[{"added": {}}]	18	5
71	2025-05-21 16:19:42.583991+00	b0e67ba7-ed16-448a-8c60-71768a7972bd	Администратор Admin Majour	2	[{"changed": {"fields": ["\\u0414\\u0430\\u043d\\u043d\\u044b\\u0435 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0433\\u043e"]}}]	11	1
72	2025-05-22 10:15:44.828597+00	15b8a729-e300-42be-abb3-ba19dc9a2fc9	Эктоин : Основной продукт	1	[{"added": {}}]	16	5
73	2025-05-22 10:17:22.439068+00	15b8a729-e300-42be-abb3-ba19dc9a2fc9	Эктоин : Основной продукт	3		16	5
74	2025-05-28 14:34:09.076204+00	057a1181-d534-453c-8ee5-0b2256347844	Татьяна  Борзенко  None	1	[{"added": {}}]	14	5
75	2025-05-28 14:34:27.42067+00	eaa6f6ee-dc4f-43cb-b776-12cc61a1f2e0	Анна  Новикова  None	1	[{"added": {}}]	14	5
76	2025-05-28 14:34:36.996839+00	eaa6f6ee-dc4f-43cb-b776-12cc61a1f2e0	Анна  Новикова  None	3		14	5
77	2025-05-28 14:34:47.277865+00	057a1181-d534-453c-8ee5-0b2256347844	Татьяна  Борзенко  None	3		14	5
78	2025-05-28 14:35:27.658115+00	6270b586-556e-4539-a76a-514be466f978	Татьяна  Сергеевна  Борзенко	1	[{"added": {}}]	14	5
79	2025-05-28 14:37:23.045666+00	0794bf3d-6d15-4e7c-b077-b250c3b373f7	Егор  Александрович  Сёменов	1	[{"added": {}}]	14	5
80	2025-05-28 14:37:52.770171+00	6270b586-556e-4539-a76a-514be466f978	Татьяна  Сергеевна  Борзенко	3		14	5
81	2025-05-28 14:38:07.442045+00	b1d920a8-1381-4857-abd7-48ccdb7c16f0	Петр  Петров  Иванович	3		14	5
82	2025-05-28 14:38:17.350272+00	3b62ef9e-48c6-4129-b130-47b56bc69974	Иван  Иванов  Иванович	3		14	5
83	2025-05-28 14:38:27.359923+00	0794bf3d-6d15-4e7c-b077-b250c3b373f7	Егор  Александрович  Сёменов	3		14	5
84	2025-05-28 14:39:15.362494+00	86bea85e-a62d-4dc0-8c0b-30541fd7782c	Борзенко  Татьяна  Сергеевна	1	[{"added": {}}]	14	5
85	2025-05-28 14:39:51.191336+00	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	Акжигитова  Дарья  Павловна	1	[{"added": {}}]	14	5
86	2025-05-28 14:40:19.39666+00	09d8307c-2256-4f71-94e1-958c21e6f1bc	Новикова  Анна  Евгеньевна	1	[{"added": {}}]	14	5
87	2025-05-28 14:40:59.662991+00	1a5902da-bf12-4f7e-b055-775956f6adda	Санто  Леонид  Павлович	1	[{"added": {}}]	14	5
88	2025-05-28 14:41:27.426425+00	8afa309b-cec8-4aaa-9031-06fe2b8267bf	Киверо  Александр  Дмитриевич	1	[{"added": {}}]	14	5
89	2025-05-28 14:42:32.353652+00	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	Варламова  Дарья  Олеговна	1	[{"added": {}}]	14	5
90	2025-05-28 14:42:59.554736+00	58c12ab6-e451-48b5-917e-26fc1855847a	Федоров  Антон  Сергеевич	1	[{"added": {}}]	14	5
91	2025-05-28 14:43:27.472513+00	1e4fa050-70ba-4031-9201-31d8cbd60b9a	Федорова  Елизавета  Николаевна	1	[{"added": {}}]	14	5
92	2025-05-29 13:11:43.07677+00	dd7560f9-712c-405d-9c82-190ff14317d2	Met_1 : Основной продукт	3		16	5
93	2025-05-29 13:11:52.933928+00	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	Met_2 : Примеси	3		16	5
94	2025-05-29 13:11:58.845098+00	3b95b72a-5cfb-4a4d-9307-3a382d1e19d7	АнализТестовый : Ттипа	3		16	5
95	2025-05-29 13:13:19.146254+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
96	2025-05-29 13:13:48.165263+00	da3047ce-76fe-4d82-ba86-c121399b066e	Примеси аминокислоты	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
97	2025-05-29 13:14:40.836535+00	7469f991-2e03-491d-b168-f7d7f8feef4d	Эктоин : Примеси аминокислоты	1	[{"added": {}}]	16	5
98	2025-05-29 13:15:14.562309+00	7469f991-2e03-491d-b168-f7d7f8feef4d	Эктоин : Основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
99	2025-05-29 13:19:04.044744+00	b16068e8-0fcf-47af-ba21-86213f92d426	Эктоин	1	[{"added": {}}]	12	5
100	2025-05-29 13:19:23.741313+00	b16068e8-0fcf-47af-ba21-86213f92d426	Эктоин основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
101	2025-05-29 13:19:34.159199+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[]	12	5
102	2025-05-29 13:19:41.630174+00	c3866711-d6e9-47b6-aa48-f976bb276685	Примеси органические кислоты	2	[]	12	5
103	2025-05-29 13:20:05.352001+00	c3866711-d6e9-47b6-aa48-f976bb276685	Эктоин примеси органических кислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
104	2025-05-29 13:20:22.699924+00	c7dba098-3d33-445c-a23b-57c247eee687	Основной продукт	3		12	5
105	2025-05-29 13:20:47.016385+00	da3047ce-76fe-4d82-ba86-c121399b066e	Эктоин примеси аминокислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
106	2025-05-29 13:28:04.35654+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин основной продукт : Эктоин основной продукт	1	[{"added": {}}]	16	5
107	2025-05-29 13:28:34.733392+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : Эктоин основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
108	2025-05-29 13:29:04.824583+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : Эктоин примеси органических кислот	1	[{"added": {}}]	16	5
109	2025-05-29 13:30:05.723892+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : Эктоин примеси аминокислот	1	[{"added": {}}]	16	5
110	2025-05-29 13:30:30.67236+00	b16068e8-0fcf-47af-ba21-86213f92d426	основной продукт	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
111	2025-05-29 13:30:36.923877+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
112	2025-05-29 13:30:55.498286+00	c3866711-d6e9-47b6-aa48-f976bb276685	примеси органических кислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
113	2025-05-29 13:31:16.145889+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : примеси органических кислот	2	[]	16	5
114	2025-05-29 13:31:31.50066+00	da3047ce-76fe-4d82-ba86-c121399b066e	примеси аминокислот	2	[{"changed": {"fields": ["\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	12	5
115	2025-05-29 13:31:34.579339+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : примеси аминокислот	2	[]	16	5
116	2025-05-29 13:37:29.220266+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu3 органические кислоты	1	[{"added": {}}]	13	5
117	2025-05-29 13:38:42.978403+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000 аминокислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
118	2025-05-29 13:39:27.290339+00	322bde1c-c844-44d7-8846-a773b9f97679	Waters Alliance New	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430", "\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b"]}}]	13	5
119	2025-05-29 13:40:06.86374+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam433	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
120	2025-05-29 13:40:15.060454+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam 433	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
121	2025-05-29 13:41:01.555266+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260 аминокислоты	1	[{"added": {}}]	13	5
122	2025-05-29 13:41:39.41316+00	e028e32c-581f-4b39-92ae-9a81552b7862	Waters Alliance Old	1	[{"added": {}}]	13	5
123	2025-05-29 13:48:21.788059+00	54e28c12-acd4-4c69-a0a6-815a77c4e895	Hitachi 8900	1	[{"added": {}}]	13	5
124	2025-05-29 13:49:02.220575+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu6 органические кислоты	1	[{"added": {}}]	13	5
125	2025-05-29 13:49:24.644259+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3 органические кислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
126	2025-05-29 13:49:40.206065+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6 органические кислоты	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
127	2025-05-29 13:51:03.592429+00	27dc31dd-0a11-452e-ac1e-aeb052f18226	Agilent 7100 CE	1	[{"added": {}}]	13	5
128	2025-05-29 13:52:14.6906+00	612b7c5b-61b6-4795-8d07-98bc92bc4c51	Methrohm	1	[{"added": {}}]	13	5
129	2025-05-29 13:52:42.207693+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
130	2025-05-29 13:52:52.571696+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
131	2025-05-29 13:53:25.556608+00	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	Dionex ICS 5000	1	[{"added": {}}]	13	5
132	2025-05-29 13:53:45.365327+00	0c0b62b6-c1b4-4828-8c87-b90396e2288d	Dionex ICS 5000 2	1	[{"added": {}}]	13	5
133	2025-05-29 13:57:51.863916+00	370b51e9-685c-4a6d-bcc5-67bed5d29f48	Aracus	1	[{"added": {}}]	13	5
134	2025-05-29 13:59:29.334356+00	555a86cd-0550-42d7-b085-92842c89ee90	Shimadzu 4	1	[{"added": {}}]	13	5
135	2025-05-29 13:59:55.459928+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	1	[{"added": {}}]	13	5
136	2025-05-29 14:00:14.281088+00	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	Shimadzu 7	1	[{"added": {}}]	13	5
137	2025-05-29 14:01:02.408838+00	4b3bb52f-df8d-421c-893e-37052e982bcb	Shimadzu 30	1	[{"added": {}}]	13	5
138	2025-05-29 14:01:24.56301+00	a8222354-63a4-4c12-b4ee-00ff34788fa1	Shimadzu GC 2010	1	[{"added": {}}]	13	5
139	2025-05-29 14:01:51.578352+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	1	[{"added": {}}]	13	5
140	2025-05-29 14:03:05.049898+00	1fb0d24b-975e-4366-b981-ae320ff1265a	Waters  LC-MS/MS Acquity	1	[{"added": {}}]	13	5
141	2025-05-29 14:04:05.786078+00	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	Shimadzu LC-MS 8050	1	[{"added": {}}]	13	5
142	2025-05-29 14:07:16.920949+00	7dd395a4-3652-4450-98a0-80cb8a9b3693	Эктоин 1 : основной продукт - Shimadzu 4	1	[{"added": {}}]	19	5
143	2025-05-29 14:07:45.273566+00	32460d60-bb76-47fc-8668-d651530c08ee	Эктоин 2 : примеси органических кислот - Shimadzu 3 органические кислоты	1	[{"added": {}}]	19	5
144	2025-05-29 14:08:08.471535+00	32460d60-bb76-47fc-8668-d651530c08ee	Эктоин 2 : примеси органических кислот - Shimadzu 3 органические кислоты	3		19	5
145	2025-05-29 14:08:18.937691+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6 органические кислоты	2	[]	13	5
146	2025-05-29 14:08:26.400179+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
147	2025-05-29 14:08:31.88643+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3 органические кислоты	2	[]	13	5
148	2025-05-29 14:08:37.362312+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
149	2025-05-29 14:11:47.684813+00	f4219c2e-5e50-4b01-b68a-2c42ebb65cbd	Эктоин 2 : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
150	2025-05-29 14:12:14.039526+00	4a8d426e-1a4c-4e7e-b7c7-b23a9bf0bcc1	Эктоин 2 : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
151	2025-05-29 14:12:53.677711+00	4ab314fc-7430-480b-a2e4-8209fcf92b19	Эктоин 3 : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
152	2025-05-29 14:13:04.841713+00	f68b9664-d014-4676-948d-52498a46ca27	Эктоин 3 : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
153	2025-05-29 14:14:06.873022+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Эктоин 1 : основной продукт - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
154	2025-05-29 14:16:14.446921+00	8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	Борзенко  Татьяна  Сергеевна - Agilent 1260	1	[{"added": {}}]	18	5
155	2025-05-29 14:16:40.433929+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 11000	1	[{"added": {}}]	18	5
156	2025-05-29 14:16:56.577146+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 11000	2	[]	13	5
157	2025-05-29 14:17:02.096914+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 1100	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
158	2025-05-29 14:17:32.589828+00	59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	Санто  Леонид  Павлович - Sykam 433	1	[{"added": {}}]	18	5
159	2025-05-29 14:17:56.607826+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	1	[{"added": {}}]	18	5
160	2025-05-29 14:18:09.968488+00	ebe0ca91-0214-453a-91f3-925bd53f5606	Санто  Леонид  Павлович - Hitachi 8900	1	[{"added": {}}]	18	5
161	2025-05-29 14:18:25.631958+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	1	[{"added": {}}]	18	5
162	2025-05-29 14:18:45.380336+00	94189595-1d95-4782-8464-b338640e1b5e	Федоров  Антон  Сергеевич - Methrohm	1	[{"added": {}}]	18	5
164	2025-05-29 14:20:22.927545+00	d36c9e4f-2406-492b-b467-de7884e9a2e6	Сёменов  Егор  Александрович	1	[{"added": {}}]	14	5
165	2025-05-29 14:20:49.214107+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	1	[{"added": {}}]	18	5
166	2025-05-30 14:17:34.283769+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	1	[{"added": {}}]	8	1
167	2025-05-30 14:24:25.212971+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	2	[]	8	1
168	2025-06-02 18:10:26.885797+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 23:00, период недели: 09.06.2025-15.06.2025	1	[{"added": {}}]	8	1
169	2025-06-02 18:10:35.463834+00	558d6fee-fc77-4e01-9876-e48d5f98879b	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	1
170	2025-06-02 18:10:42.699611+00	65986bb1-234e-4c54-b5dd-ccd386a15b10	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">09.06.2025-15.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	1
171	2025-06-02 18:11:19.630388+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин 2 : примеси органических кислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	1
172	2025-06-02 18:11:27.097715+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин 3 : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	1
173	2025-06-02 18:26:50.946841+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
174	2025-06-02 18:27:07.413895+00	406d22a2-a71c-4278-9800-c05973e728d2	Открыта период недели: 26.05.2025-01.06.2025	3		7	1
175	2025-06-02 18:27:20.891718+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
176	2025-06-02 18:27:31.385948+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 02.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	1
177	2025-06-03 12:23:28.646958+00	c37e1b7a-bf5b-427d-ab59-f530c2810d10	Борзенко  Татьяна  Сергеевна - Methrohm	2	[]	18	5
178	2025-06-03 12:24:20.558854+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	1	[{"added": {}}]	18	5
179	2025-06-03 12:24:53.026563+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	2	[]	18	5
180	2025-06-03 12:25:48.851552+00	8b565dc9-f75f-42b9-a5ca-49b6bd2c6b92	Борзенко  Татьяна  Сергеевна - Agilent 1260	2	[]	18	5
181	2025-06-03 12:26:10.48317+00	ebe0ca91-0214-453a-91f3-925bd53f5606	Санто  Леонид  Павлович - Hitachi 8900	2	[]	18	5
182	2025-06-03 12:26:15.12582+00	59266bdd-56be-4e7b-8e25-b7d8d0f97cc3	Санто  Леонид  Павлович - Sykam 433	2	[]	18	5
183	2025-06-03 12:26:31.494357+00	3c24341c-235d-4d4b-8561-1f7cf0d108ff	Борзенко  Татьяна  Сергеевна - Agilent 1100	2	[]	18	5
184	2025-06-03 12:26:41.128799+00	fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000	1	[{"added": {}}]	18	5
185	2025-06-03 12:27:15.769339+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	2	[]	18	5
186	2025-06-03 12:27:59.518163+00	5f9f0bd3-186e-4ee7-9207-8dcbc67c4ea9	Сёменов  Егор  Александрович - Agilent 1100	1	[{"added": {}}]	18	5
187	2025-06-03 12:29:41.254611+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	2	[]	18	5
188	2025-06-03 12:30:00.215937+00	14cdc62c-f9c2-4043-85a3-99451ebee7fc	Сёменов  Егор  Александрович - Shimadzu 30	1	[{"added": {}}]	18	5
189	2025-06-03 12:30:14.38348+00	94189595-1d95-4782-8464-b338640e1b5e	Федоров  Антон  Сергеевич - Methrohm	2	[]	18	5
190	2025-06-03 12:30:29.202076+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	1	[{"added": {}}]	18	5
191	2025-06-03 12:30:50.356847+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[]	18	5
192	2025-06-03 12:31:07.765117+00	e1dfe070-72f1-4a0f-ae0d-300903a686e2	Федоров  Антон  Сергеевич - Dionex ICS 5000	1	[{"added": {}}]	18	5
193	2025-06-03 12:31:16.805525+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[]	18	5
194	2025-06-03 12:31:26.224615+00	eed4b9b6-0e16-4811-ac84-9c8851e8d4ae	Федоров  Антон  Сергеевич - Dionex ICS 5000 2	1	[{"added": {}}]	18	5
195	2025-06-03 12:31:31.182927+00	4adae582-a899-4520-9bf1-c4e1411938b9	Федоров  Антон  Сергеевич - Shimadzu 7	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043b\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0442\\u043e\\u0440 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	18	5
196	2025-06-03 12:45:40.978368+00	e1dfe070-72f1-4a0f-ae0d-300903a686e2	Федоров  Антон  Сергеевич - Dionex ICS 5000	2	[]	18	5
197	2025-06-03 12:45:45.721377+00	fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000	2	[]	18	5
198	2025-06-03 12:46:13.011622+00	3add5154-d941-43d3-a891-28512fd90890	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000 2	1	[{"added": {}}]	18	5
199	2025-06-03 12:47:12.016623+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	2	[]	18	5
200	2025-06-03 12:47:26.957215+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	1	[{"added": {}}]	18	5
201	2025-06-03 12:47:31.616866+00	8e372a71-ce34-4bcd-8d2a-71379b5b2e58	Киверо  Александр  Дмитриевич - Agilent 7100 CE	2	[]	18	5
202	2025-06-03 12:47:47.162344+00	bd3d2f53-fdf4-4ff5-b267-13435039ecde	Киверо  Александр  Дмитриевич - Shimadzu LC-MS 8050	1	[{"added": {}}]	18	5
203	2025-06-03 12:47:53.07458+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	2	[]	18	5
204	2025-06-03 12:48:11.169881+00	b70cb072-2435-472e-8579-a0e6d5d9e70e	Киверо  Александр  Дмитриевич - Shimadzu GC 2010	1	[{"added": {}}]	18	5
205	2025-06-03 12:48:23.985091+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	2	[]	18	5
206	2025-06-03 12:48:38.588846+00	702157a8-9348-41e5-bae7-961a0e3e5940	Киверо  Александр  Дмитриевич - Shimadzu GC 2014	1	[{"added": {}}]	18	5
207	2025-06-03 12:49:30.649207+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 1100	2	[]	18	5
208	2025-06-03 12:50:07.136766+00	821c378b-aaed-45b3-a007-8b620e34126f	Варламова  Дарья  Олеговна - Aracus	1	[{"added": {}}]	18	5
209	2025-06-03 12:50:20.023433+00	438c240d-734b-44d9-a17f-7259172dc398	Варламова  Дарья  Олеговна - Agilent 1100	2	[]	18	5
210	2025-06-03 12:50:46.197707+00	54968de3-1f18-4d08-a485-a83a3e89cb3f	Варламова  Дарья  Олеговна - Shimadzu 3	1	[{"added": {}}]	18	5
211	2025-06-03 12:51:16.04865+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
212	2025-06-03 12:51:47.599238+00	a5d446a8-3fa6-47f3-9a84-eb428f14e600	Федорова  Елизавета  Николаевна - Shimadzu 4	1	[{"added": {}}]	18	5
213	2025-06-03 12:51:55.140081+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
214	2025-06-03 12:52:13.478217+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	1	[{"added": {}}]	18	5
215	2025-06-03 12:52:20.262299+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	2	[]	18	5
216	2025-06-03 12:52:33.363847+00	7a2e39e0-972a-4e11-aaf7-4091306b4bb4	Федорова  Елизавета  Николаевна - Shimadzu 6	1	[{"added": {}}]	18	5
217	2025-06-03 13:02:27.251361+00	109918bd-fe82-40b4-88a8-7ace7535ab4c	Федорова  Елизавета  Николаевна - Shimadzu 3	2	[]	18	5
218	2025-06-03 13:02:52.405737+00	3d2dc186-dcb4-4876-9d18-7252d8181131	Федорова  Елизавета  Николаевна - Waters Alliance New	1	[{"added": {}}]	18	5
219	2025-06-03 13:03:01.279781+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Федорова  Елизавета  Николаевна - Sykam 433	2	[]	18	5
220	2025-06-03 13:03:22.446096+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	1	[{"added": {}}]	18	5
221	2025-06-03 13:03:39.152747+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	2	[]	18	5
222	2025-06-03 13:03:49.047772+00	4ef7cae5-4722-45b1-bc60-d3a241c8d08f	Новикова  Анна  Евгеньевна - Shimadzu 5	1	[{"added": {}}]	18	5
223	2025-06-03 13:04:07.638553+00	4ef7cae5-4722-45b1-bc60-d3a241c8d08f	Новикова  Анна  Евгеньевна - Shimadzu 5	2	[]	18	5
224	2025-06-03 13:04:28.699439+00	c47fcc37-09db-4099-aad3-462f24cb56a2	Новикова  Анна  Евгеньевна - Shimadzu 30	1	[{"added": {}}]	18	5
225	2025-06-03 13:05:39.101358+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
226	2025-06-03 13:07:05.617768+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile) : основной продукт	1	[{"added": {}}]	16	5
227	2025-06-03 13:07:27.527129+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile) : основной продукт	2	[]	16	5
228	2025-06-03 13:07:47.50009+00	563ae91e-3338-45f7-aead-c5a3c7a57f63	BCAA(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
229	2025-06-03 13:07:54.313091+00	563ae91e-3338-45f7-aead-c5a3c7a57f63	BCAA(AA) : примеси аминокислот	2	[]	16	5
230	2025-06-03 13:08:23.467493+00	091e7bb0-f31d-4465-8e6f-130e5f83d454	BCAA(OA,2IPM,3IPM) : примеси органических кислот	1	[{"added": {}}]	16	5
231	2025-06-03 13:08:39.293055+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин 1 : основной продукт	2	[]	16	5
232	2025-06-03 13:08:47.987131+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
233	2025-06-03 13:08:52.257312+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин 2 : примеси органических кислот	2	[]	16	5
234	2025-06-03 13:09:07.503545+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин (OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
235	2025-06-03 13:09:30.067782+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин 3 : примеси аминокислот	2	[]	16	5
236	2025-06-03 13:09:43.844012+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин (AA) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
237	2025-06-03 13:23:04.14012+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn : основной продукт	1	[{"added": {}}]	16	5
238	2025-06-03 13:23:26.327781+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn(OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
239	2025-06-03 13:23:36.127038+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn(OA) : примеси органических кислот	2	[]	16	5
240	2025-06-03 13:23:44.868595+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn : основной продукт	1	[{"added": {}}]	16	5
241	2025-06-03 13:23:56.848477+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn : основной продукт	2	[]	16	5
242	2025-06-03 13:24:11.145502+00	4e1fbb62-07ef-441b-a27b-1956581e9ca8	Asn(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
243	2025-06-03 13:25:01.066649+00	3893f977-8f70-49be-903b-ed0149e4a505	DAP : основной продукт	1	[{"added": {}}]	16	5
244	2025-06-03 13:25:04.593923+00	3893f977-8f70-49be-903b-ed0149e4a505	DAP : основной продукт	2	[]	16	5
245	2025-06-03 13:25:26.783858+00	ca0a4632-47de-4590-b84b-5835604a02c6	DAP(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
246	2025-06-03 13:25:31.727139+00	ca0a4632-47de-4590-b84b-5835604a02c6	DAP(OA) : примеси органических кислот	2	[]	16	5
247	2025-06-03 13:30:48.84451+00	73129017-ac9d-4a55-9020-7192a2b3150a	Ser : основной продукт	1	[{"added": {}}]	16	5
248	2025-06-03 13:31:03.515185+00	fdc73d75-74c1-44e9-b276-2b748d35620b	Ser(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
249	2025-06-03 13:31:11.818608+00	fdc73d75-74c1-44e9-b276-2b748d35620b	Ser(OA) : примеси органических кислот	2	[]	16	5
250	2025-06-03 13:31:28.140659+00	e40964e1-8934-428e-a06e-18379a30ebae	Ser(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
251	2025-06-03 13:40:04.798069+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg : основной продукт	1	[{"added": {}}]	16	5
252	2025-06-03 13:40:09.383601+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg : основной продукт	2	[]	16	5
253	2025-06-03 13:40:20.476288+00	eecdd0f8-7244-4bf6-8f96-65622901a51d	Arg(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
254	2025-06-03 13:40:42.417165+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg(AA) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
255	2025-06-03 13:42:15.410558+00	7da0bd39-87ac-4b74-b152-236e519597e1	a-AP : основной продукт	1	[{"added": {}}]	16	5
256	2025-06-03 13:42:34.010655+00	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	a-AP(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
257	2025-06-03 13:43:25.357688+00	020da433-e3a3-419c-851f-f52102a5fe00	Cys(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
258	2025-06-03 13:53:26.881029+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
259	2025-06-03 13:53:49.325106+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(AA) : примеси аминокислот	2	[]	16	5
260	2025-06-03 13:54:03.307826+00	f546d1c3-036a-47dd-8662-9b37a914408f	Cys(sCys) : примеси аминокислот	1	[{"added": {}}]	16	5
261	2025-06-03 14:00:05.819893+00	6b8c318d-699a-494c-b63f-44156f6a7a1d	примеси неорганических анионов	1	[{"added": {}}]	12	5
262	2025-06-03 14:00:36.946579+00	13649857-bdb6-4771-8105-8dc1fd503ac9	Ser(IA) : примеси неорганических анионов	1	[{"added": {}}]	16	5
263	2025-06-03 14:03:10.047499+00	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	GSH,GC : основной продукт	1	[{"added": {}}]	16	5
264	2025-06-03 14:06:05.373289+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	1	[{"added": {}}]	16	5
265	2025-06-03 14:06:18.202347+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	2	[]	16	5
266	2025-06-03 14:06:45.429394+00	1d7b838c-9f35-43e6-9cde-d63c11d9097f	Gr(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
267	2025-06-03 14:06:51.341344+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr : основной продукт	2	[]	16	5
268	2025-06-03 14:07:44.49691+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR : основной продукт	1	[{"added": {}}]	16	5
269	2025-06-03 14:08:11.605514+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR : основной продукт	2	[]	16	5
270	2025-06-03 14:08:33.086643+00	571c313e-8ec3-4777-bac7-40855117d510	HxR(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
271	2025-06-03 14:09:30.920435+00	04ffa9b6-2db9-496b-a154-c68bc55fcefd	анализ сахаров	1	[{"added": {}}]	12	5
272	2025-06-03 14:10:18.333959+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr(sugar) : анализ сахаров	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
273	2025-06-03 14:10:27.366334+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr(sugar) : анализ сахаров	2	[]	16	5
274	2025-06-03 14:10:50.269913+00	8cb45323-f121-47ad-969d-0ed9c2336674	HxR(sugar) : анализ сахаров	1	[{"added": {}}]	16	5
275	2025-06-03 14:12:29.331501+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	1	[{"added": {}}]	16	5
276	2025-06-03 14:12:36.189117+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
277	2025-06-03 14:13:05.884744+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS(Ala-Gln) : основной продукт	1	[{"added": {}}]	16	5
278	2025-06-03 14:13:34.258615+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
279	2025-06-03 14:14:21.853697+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS-His(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
280	2025-06-03 14:14:31.248761+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS(Ala-Gln) : основной продукт	2	[]	16	5
281	2025-06-03 14:14:42.653962+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS_Ala-Gln : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
282	2025-06-03 14:14:57.62561+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS-His(OA) : примеси органических кислот	2	[]	16	5
283	2025-06-03 14:15:09.348656+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS_His (OA) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
284	2025-06-03 14:15:12.670652+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS_His (OA) : примеси органических кислот	2	[]	16	5
285	2025-06-03 14:15:23.306637+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS(His) : основной продукт	2	[]	16	5
286	2025-06-03 14:15:31.255959+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS_His : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
287	2025-06-03 14:18:24.438257+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS_Ala-Gln : основной продукт	2	[]	16	5
288	2025-06-03 14:18:43.061543+00	e32c058b-38a7-4a49-a335-548da531c9b0	KSS_Ala-Gln (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
289	2025-06-03 14:19:19.973302+00	9fe01f07-a489-4eca-8639-403986129de1	KSS_Carnosine : основной продукт	1	[{"added": {}}]	16	5
290	2025-06-03 14:20:29.345022+00	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	Fatty acid : основной продукт	1	[{"added": {}}]	16	5
291	2025-06-03 14:21:50.398446+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	1	[{"added": {}}]	16	5
292	2025-06-03 14:22:05.063468+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	2	[]	16	5
293	2025-06-03 14:22:09.684794+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft : основной продукт	2	[]	16	5
294	2025-06-03 14:22:35.92531+00	7b74a6a1-d92b-476a-befc-0783a20e9170	Amisoft(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
295	2025-06-03 14:23:19.691921+00	1b6870c5-c028-4f7d-b3a6-da026ec81032	Lauric acid : основной продукт	1	[{"added": {}}]	16	5
296	2025-06-03 14:23:33.391357+00	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	Met : основной продукт	1	[{"added": {}}]	16	5
297	2025-06-03 14:23:47.700449+00	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	Met (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
298	2025-06-03 14:24:33.396271+00	601b7b77-ab12-477c-918e-ca3910a3bb96	Met (IA) : примеси неорганических анионов	1	[{"added": {}}]	16	5
299	2025-06-03 14:27:47.493544+00	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	Gln : основной продукт	1	[{"added": {}}]	16	5
300	2025-06-03 14:27:59.784137+00	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	Gln (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
301	2025-06-03 14:28:38.626557+00	ace768c2-60a5-40f1-b745-63829f6b8d9f	Glu : основной продукт	1	[{"added": {}}]	16	5
302	2025-06-03 14:28:53.644811+00	7129f484-2524-4bc2-a857-7a4663b6abbb	Glu (OA) : примеси органических кислот	1	[{"added": {}}]	16	5
303	2025-06-03 14:29:59.490608+00	00bc93e0-ef32-471d-aade-da29ce6a1660	Glu (AA) : примеси аминокислот	1	[{"added": {}}]	16	5
304	2025-06-03 14:38:25.411212+00	08dc2b8b-9ef1-43bd-831f-3e43112a125c	Lauric acid : основной продукт - Shimadzu GC 2014	1	[{"added": {}}]	19	5
305	2025-06-03 14:39:07.192493+00	4e194ce7-ca13-4e35-b5ae-ad7f304dd741	Met : основной продукт - Aracus	1	[{"added": {}}]	19	5
306	2025-06-03 14:39:30.806768+00	e80d95d5-3b67-448f-b8c5-a4dad25485d1	Met (OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
307	2025-06-03 14:39:41.219091+00	e80d95d5-3b67-448f-b8c5-a4dad25485d1	Met (OA) : примеси органических кислот - Shimadzu 6	2	[]	19	5
308	2025-06-03 14:39:58.611465+00	1d4210d8-b9e3-47cf-9fd2-c138db2b8191	Met (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
309	2025-06-03 14:40:39.09608+00	47520068-d119-47e0-a9b7-82cf86c41e38	Met (IA) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
310	2025-06-03 14:41:46.278851+00	0b924349-8b40-4893-826f-1f762571b345	Gln : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
311	2025-06-03 14:43:42.970194+00	f4d86890-3f47-474b-89f2-41f44f2ee4af	Gln (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
312	2025-06-03 14:43:53.096529+00	f4d86890-3f47-474b-89f2-41f44f2ee4af	Gln (OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
313	2025-06-03 14:44:08.829169+00	9e5c8536-1488-4521-abef-5e2162d3e57d	Gln (OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
314	2025-06-04 13:19:56.237361+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
315	2025-06-04 13:23:55.862815+00	d3b71632-d535-4eae-ad5f-a26e5536f503	Эктоин (OA) : примеси органических кислот - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
316	2025-06-04 13:24:15.874438+00	d2307861-ee3b-426a-98fa-259d83ac47d0	Эктоин : основной продукт - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
317	2025-06-04 13:27:38.277251+00	536f650e-ae6f-42b0-bf1a-f06eee086923	Окно бронирования на 04.06.2025 с 00:00 до 24:00, период недели: 02.06.2025-08.06.2025	1	[{"added": {}}]	8	5
318	2025-06-04 13:28:07.752618+00	32e6ef03-58f4-4e8f-80c4-bf5537058666	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">02.06.2025-08.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	5
319	2025-06-04 13:33:15.630416+00	0b6e2138-4fc5-4404-b584-6707d4890102	Arg : основной продукт	1	[{"added": {}}]	16	5
320	2025-06-04 13:34:15.971887+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	1	[{"added": {}}]	17	5
321	2025-06-04 13:35:07.971314+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[]	15	5
322	2025-06-05 09:56:15.913135+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	2	[]	17	5
323	2025-06-05 10:03:10.403474+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин (OA) : примеси органических кислот - Methionine (Сидоров) : Не приоритетный 	2	[]	17	5
324	2025-06-05 10:03:42.726991+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	2	[]	17	5
325	2025-06-05 10:04:06.053803+00	cdb3e289-dd41-4e0e-826c-b99270b5eeb2	Fatty acid : основной продукт - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
326	2025-06-05 10:05:51.30702+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[]	15	5
327	2025-06-05 10:06:13.007484+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Сидоров) : Не приоритетный 	2	[]	15	5
328	2025-06-05 10:07:01.859647+00	c0d394f6-e583-4327-9acc-20a826b40cac	Cys(AA) : примеси аминокислот - Methionine (Сидоров) : Не приоритетный 	1	[{"added": {}}]	17	5
329	2025-06-05 10:18:06.505235+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	1	[{"added": {}}]	15	5
330	2025-06-05 10:18:58.791403+00	1c051ae6-a3a0-4637-8011-45d15e7d7590	Эктоин (OA) : примеси органических кислот - Эктоин (Гераскина) : Не приоритетный 	1	[{"added": {}}]	17	5
331	2025-06-05 10:25:19.972909+00	de22a9eb-3341-4f6e-a7e2-08306aae6cfb	Glu : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
332	2025-06-05 10:25:35.535442+00	151661f6-b9a4-485e-a0b0-79eec9653190	BCAA(Ile) : основной продукт - Dionex ICS 5000	1	[{"added": {}}]	19	5
333	2025-06-05 10:25:57.666435+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
334	2025-06-05 10:26:22.128213+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(OA,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
335	2025-06-05 10:26:43.301476+00	f36c4f83-7cdc-466c-b0c6-f53eee215e52	Glu (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
336	2025-06-05 10:27:02.458052+00	d1bfe6e8-c571-4188-a3f9-185b9954aebe	Glu (AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
337	2025-06-05 10:27:44.452808+00	816a15ab-4636-4b60-8c01-5f6a914e66f3	Arg : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
338	2025-06-05 10:28:08.810493+00	c29e42b9-0143-4fb9-aff1-55067ffbf357	Asn(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
339	2025-06-05 10:28:28.919178+00	07fa9507-7399-4cdb-ba6f-0fd7ab71feb5	Asn : основной продукт - Hitachi 8900	1	[{"added": {}}]	19	5
340	2025-06-05 10:28:51.306181+00	2bcddd69-9709-445d-9567-a86b0a947972	Asn(AA) : примеси аминокислот - Hitachi 8900	1	[{"added": {}}]	19	5
341	2025-06-05 10:29:39.917087+00	44c5358c-8aee-4820-83c7-7a568f9d4065	DAP : основной продукт - Agilent 1100	1	[{"added": {}}]	19	5
342	2025-06-05 10:29:58.478527+00	71cdf309-436c-41e2-ba9f-00290a6e03ce	DAP(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
343	2025-06-05 10:31:48.744901+00	6ce21107-4e96-4198-8744-f38680e66785	Ser : основной продукт - Shimadzu 5	1	[{"added": {}}]	19	5
344	2025-06-05 10:32:09.81416+00	9283b3c3-596a-44c4-b907-1c36355e75f6	Ser(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
345	2025-06-05 10:32:35.083718+00	7786e1b5-15f0-4730-b91f-9d2588d7b941	Ser(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
346	2025-06-05 10:32:58.404074+00	37bdfb2c-3a5b-400e-8cfd-86bc61065487	Arg(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
347	2025-06-05 10:33:42.878964+00	1d19b9bf-c98e-47d3-9c8e-4221f8e495c6	Arg(AA) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
348	2025-06-05 10:34:06.912408+00	3b35ac23-0b75-43dc-85ed-76dddd522db2	Asn(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
349	2025-06-05 10:34:30.027093+00	ed0ed014-2191-4b97-af22-9d1ba16ba4c9	a-AP : основной продукт - Waters Alliance Old	1	[{"added": {}}]	19	5
350	2025-06-05 10:35:02.424767+00	0ca15667-5429-4a44-b009-b1815a7fa312	a-AP(AA) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
351	2025-06-05 10:35:16.231784+00	007dd4bd-15cf-4911-a4af-80eaf37fa445	Cys(OA) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
352	2025-06-05 10:35:43.141207+00	b94cee75-d835-424a-9486-55711407d0db	Cys(AA) : примеси аминокислот - Aracus	1	[{"added": {}}]	19	5
353	2025-06-05 10:36:00.244056+00	3b2f0fa5-d5ff-4b74-bc28-a0bb4103597a	Cys(sCys) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
354	2025-06-05 10:36:52.317836+00	2261a1c8-dd9f-4ba8-9fa1-ec23ddc712d9	Ser(IA) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
355	2025-06-05 10:37:18.491432+00	83635efb-56a4-4bff-a8f2-245739f40fc7	GSH,GC : основной продукт - Shimadzu 30	1	[{"added": {}}]	19	5
356	2025-06-05 10:37:41.608829+00	cbce33a1-3c56-4c54-b194-315442818858	Gr(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
357	2025-06-05 10:37:57.731099+00	dccd8d63-fa3a-4047-8909-fd25061670d9	HxR : основной продукт - Shimadzu 7	1	[{"added": {}}]	19	5
358	2025-06-05 10:38:19.369462+00	9eebac2d-c944-4f98-9ec8-ca65b521dc3a	HxR(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
359	2025-06-05 10:38:37.891557+00	f8d6c899-bbf4-48cd-9457-901947d9a933	Gr(sugar) : анализ сахаров - Dionex ICS 5000 2	1	[{"added": {}}]	19	5
360	2025-06-05 10:39:03.655056+00	8d16e8bd-0e67-4612-ba99-bc03b3fea5b9	HxR(sugar) : анализ сахаров - Dionex ICS 5000 2	1	[{"added": {}}]	19	5
361	2025-06-05 10:39:21.153518+00	b1f3e239-4317-4b5a-a752-e1aab475f793	KSS_His (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
362	2025-06-05 10:39:41.740202+00	5645adea-fa77-4418-b7e7-2dbc05d4bdbb	KSS_His : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
363	2025-06-05 10:39:54.850472+00	7ddc3b1d-54af-46fb-b500-14b8c36d398d	KSS_Ala-Gln : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
364	2025-06-05 10:41:15.119937+00	7bbd84dd-6703-42e0-bfe1-f01da0373b59	KSS_Ala-Gln (OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
365	2025-06-05 10:41:45.428515+00	a37304bd-fc47-416e-97b6-f608b67a2f4b	KSS_Carnosine : основной продукт - Agilent 1260	1	[{"added": {}}]	19	5
366	2025-06-05 10:42:13.479358+00	cd1696ac-e37f-4c0e-99a1-039450bb4ade	Fatty acid : основной продукт - Shimadzu GC 2014	1	[{"added": {}}]	19	5
367	2025-06-05 10:42:26.679959+00	14bb3a20-dc58-4d92-ad61-be551ccad6e4	Amisoft : основной продукт - Shimadzu 30	1	[{"added": {}}]	19	5
368	2025-06-05 10:42:42.281661+00	8fe966e3-5285-42a4-b619-ca707c9784e5	Amisoft(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
369	2025-06-05 10:44:09.733469+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
370	2025-06-05 10:44:37.134305+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[]	15	5
371	2025-06-05 10:44:49.816011+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	2	[]	15	5
372	2025-06-05 11:17:24.929316+00	97112c5a-e332-4efe-9b45-b717c45523a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">26.05.2025-01.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	3		9	1
373	2025-06-05 11:17:24.938419+00	27c4c430-e7a8-49f4-80f5-d941264a4444	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">19.05.2025-25.05.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: gray;'>Вт  	3		9	1
374	2025-06-05 11:18:35.873491+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 23:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
375	2025-06-05 11:19:32.994041+00	adf5ec6d-c735-4f8b-a24f-7e314d90b1cd	Окно бронирования на 22.05.2025 с 06:00 до 15:00, период недели: 26.05.2025-01.06.2025	3		8	1
376	2025-06-05 11:19:32.9968+00	9866a82c-6381-4608-a187-4d98f72d6d7c	Окно бронирования на 21.05.2025 с 18:00 до 20:00, период недели: 26.05.2025-01.06.2025	3		8	1
377	2025-06-05 11:19:32.999607+00	3765642b-4174-4a95-814f-cc9f185db017	Окно бронирования на 19.05.2025 с 00:00 до 24:00, период недели: 19.05.2025-25.05.2025	3		8	1
378	2025-06-05 11:19:33.00127+00	05e2b04b-0620-49c5-924b-71d0a0ed85ef	Окно бронирования на 30.05.2025 с 17:00 до 18:00, период недели: 02.06.2025-08.06.2025	3		8	1
379	2025-06-05 11:19:41.939747+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 05.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	1
380	2025-06-05 11:59:14.797952+00	fab9df77-6191-4482-acc5-61e247aca6cf	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	1	[{"added": {}}]	10	1
381	2025-06-06 08:37:19.867324+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
382	2025-06-06 08:38:27.113063+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
383	2025-06-06 08:40:20.231614+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
384	2025-06-06 08:51:19.14394+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин) : Не приоритетный 	2	[]	17	5
385	2025-06-06 09:48:21.811951+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Met : основной продукт - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
386	2025-06-06 09:48:33.062328+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Эктоин (OA) : примеси органических кислот - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
387	2025-06-06 09:48:49.633774+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Met (OA) : примеси органических кислот - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
388	2025-06-06 09:49:43.869097+00	d3b71632-d535-4eae-ad5f-a26e5536f503	Arg(OA) : примеси органических кислот - Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
389	2025-06-06 09:50:32.336244+00	d2307861-ee3b-426a-98fa-259d83ac47d0	Arg(AA) : примеси аминокислот - Arginine (Кирюхин) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
390	2025-06-06 09:50:55.61109+00	cdb3e289-dd41-4e0e-826c-b99270b5eeb2	Met (IA) : примеси неорганических анионов - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
391	2025-06-06 09:51:46.531529+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
392	2025-06-06 09:52:24.856972+00	c0d394f6-e583-4327-9acc-20a826b40cac	Эктоин : основной продукт - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442", "\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
393	2025-06-06 09:54:47.903834+00	fab9df77-6191-4482-acc5-61e247aca6cf	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	3		10	5
394	2025-06-06 09:54:52.416488+00	f3876eca-6fbc-4499-a071-f121b03a1f6d	16.06.2025-22.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
395	2025-06-06 09:54:56.789043+00	e81d5de2-0ee0-4f11-99f9-db6bfd39a19e	16.06.2025-22.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
396	2025-06-06 09:55:01.039826+00	ddf616b6-e88b-4b3e-8b9d-17c94833d9ec	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
397	2025-06-06 09:55:06.122869+00	ddb248fc-54cb-4ef6-a23d-dda0052a6092	16.06.2025-22.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
398	2025-06-06 09:55:11.276794+00	b3109dfd-7f1b-4efd-8a92-c20a50761839	16.06.2025-22.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
399	2025-06-06 09:55:24.030934+00	a5ccc551-db5c-4c71-960d-69c988ae505f	16.06.2025-22.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
400	2025-06-06 09:55:29.591608+00	65c6f9ce-ce2a-41bd-93b5-13673d716e1b	16.06.2025-22.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
401	2025-06-06 09:55:35.231214+00	65360ba8-3bfc-48d2-8272-64a4afa49ad6	16.06.2025-22.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
627	2025-07-28 14:39:59.261131+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 09.07.2025 с 00:00 до 24:00, период недели: 14.07.2025-20.07.2025	3		8	5
402	2025-06-06 09:55:40.989704+00	558d6fee-fc77-4e01-9876-e48d5f98879b	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
403	2025-06-06 09:55:46.210419+00	52d6742c-4f75-43d7-bedd-430de3fd61e0	16.06.2025-22.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
404	2025-06-06 09:56:16.308491+00	5219d651-27b3-4eaf-879d-7885a7dea985	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
405	2025-06-06 09:56:25.577132+00	5219d651-27b3-4eaf-879d-7885a7dea985	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u043e\\u0432 \\u043d\\u0430 \\u0441\\u043e\\u0442\\u0440\\u0443\\u0434\\u043d\\u0438\\u043a\\u0430 \\u0432 \\u0434\\u0435\\u043d\\u044c"]}}]	10	5
406	2025-06-06 09:56:38.782519+00	13c9e994-564b-4577-96fb-9856b96e2933	16.06.2025-22.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
407	2025-06-06 09:56:51.968157+00	10ff566f-7aa7-4b59-866c-02699cce953c	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
408	2025-06-06 09:57:06.63526+00	2ef307d9-4a72-43f0-94d0-32e27af4b41f	16.06.2025-22.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
409	2025-06-06 09:57:30.715566+00	386cfcc5-8f81-41b8-901d-4e7933f369cc	09.06.2025-15.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
410	2025-06-06 09:57:46.918589+00	cc74c9b7-7478-4d9c-bfa0-efa19c9d7df0	16.06.2025-22.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
411	2025-06-06 09:58:10.362514+00	faf7f1ac-d6d3-4971-9614-079940658474	09.06.2025-15.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
412	2025-06-06 09:58:21.525402+00	9c8949f1-b97b-4d7b-aa8e-5f7cfef56f6a	16.06.2025-22.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
413	2025-06-06 09:58:34.581509+00	7da16033-9b11-44da-96ca-058675a53e9e	09.06.2025-15.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
414	2025-06-06 09:58:47.322678+00	90185b56-b39e-40c7-9798-024213deac70	16.06.2025-22.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
415	2025-06-06 09:59:10.588556+00	26a010b1-e1b5-4155-8fd4-36b17ca1ae3b	09.06.2025-15.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
416	2025-06-06 09:59:22.582088+00	35a3585e-dd65-4761-8871-54471d4d53cc	16.06.2025-22.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
417	2025-06-06 10:21:28.082147+00	8685c020-7469-47aa-9746-fe038ae0c55c	09.06.2025-15.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
418	2025-06-06 10:21:39.154153+00	74ca31c7-210d-4f29-8593-f767f2d33969	16.06.2025-22.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
419	2025-06-06 10:23:13.994734+00	7d5bca70-ee72-43cf-b4a9-c5416a2137fc	09.06.2025-15.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
420	2025-06-06 10:23:35.683783+00	1382ddde-24a5-443a-9af8-133c83477218	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
421	2025-06-06 10:24:04.593265+00	75b4833a-4a8a-451d-83d2-9c5f305eef5c	09.06.2025-15.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
422	2025-06-06 10:25:28.958805+00	6651c987-6301-48ea-a14b-b450ae0548d6	16.06.2025-22.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
423	2025-06-06 10:32:18.345888+00	536f650e-ae6f-42b0-bf1a-f06eee086923	Окно бронирования на 04.06.2025 с 00:00 до 24:00, период недели: 02.06.2025-08.06.2025	3		8	5
424	2025-06-06 10:32:22.165423+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 06.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
425	2025-06-06 10:33:58.821149+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 06.06.2025 с 00:00 до 24:00, период недели: 09.06.2025-15.06.2025	2	[]	8	5
456	2025-06-09 10:30:25.327318+00	370b51e9-685c-4a6d-bcc5-67bed5d29f48	Aracus	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
426	2025-06-06 10:34:34.540417+00	65986bb1-234e-4c54-b5dd-ccd386a15b10	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">09.06.2025-15.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0431\\u0431\\u043e\\u0442\\u0430"]}}]	9	5
427	2025-06-06 10:34:40.86158+00	b654ea09-0b0d-4b6b-a734-f986016465a5	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">16.06.2025-22.06.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
428	2025-06-06 10:55:12.589328+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
429	2025-06-06 10:58:01.39518+00	f68b9664-d014-4676-948d-52498a46ca27	Эктоин (AA) : примеси аминокислот - Sykam 433	2	[]	19	5
430	2025-06-06 11:26:31.603286+00	37bdfb2c-3a5b-400e-8cfd-86bc61065487	Arg(OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
431	2025-06-09 08:55:23.156239+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 09.06.2025 с 00:00 до 24:00, период недели: 16.06.2025-22.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	1
432	2025-06-09 10:21:17.736965+00	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	Дарья  Акжигитова  Павловна	2	[]	14	5
433	2025-06-09 10:21:44.453166+00	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	Акжигитова  Дарья  Павловна	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
434	2025-06-09 10:22:10.939825+00	d36c9e4f-2406-492b-b467-de7884e9a2e6	Сёменов  Егор  Александрович	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
435	2025-06-09 10:22:29.7238+00	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	Варламова  Дарья  Олеговна	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
436	2025-06-09 10:22:50.961794+00	8afa309b-cec8-4aaa-9031-06fe2b8267bf	Киверо  Александр  Дмитриевич	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
437	2025-06-09 10:23:16.112628+00	86bea85e-a62d-4dc0-8c0b-30541fd7782c	Борзенко  Татьяна  Сергеевна	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
438	2025-06-09 10:23:41.986899+00	58c12ab6-e451-48b5-917e-26fc1855847a	Федоров  Антон  Сергеевич	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
439	2025-06-09 10:24:03.091507+00	1e4fa050-70ba-4031-9201-31d8cbd60b9a	Федорова  Елизавета  Николаевна	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
440	2025-06-09 10:24:22.598079+00	1a5902da-bf12-4f7e-b055-775956f6adda	Санто  Леонид  Павлович	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
441	2025-06-09 10:24:37.417396+00	09d8307c-2256-4f71-94e1-958c21e6f1bc	Новикова  Анна  Евгеньевна	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f", "\\u0418\\u043c\\u044f"]}}]	14	5
442	2025-06-09 10:25:16.872489+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
443	2025-06-09 10:26:42.504333+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
444	2025-06-09 10:26:52.312359+00	e028e32c-581f-4b39-92ae-9a81552b7862	Waters Alliance Old	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
445	2025-06-09 10:26:58.315397+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
446	2025-06-09 10:28:06.501381+00	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	Dionex ICS 5000	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
447	2025-06-09 10:28:11.372281+00	a8222354-63a4-4c12-b4ee-00ff34788fa1	Shimadzu GC 2010	2	[]	13	5
448	2025-06-09 10:28:24.111528+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 1100	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
449	2025-06-09 10:28:28.664129+00	612b7c5b-61b6-4795-8d07-98bc92bc4c51	Methrohm	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
450	2025-06-09 10:28:41.729879+00	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	Shimadzu LC-MS 8050	2	[]	13	5
451	2025-06-09 10:29:05.842921+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
452	2025-06-09 10:29:28.923598+00	555a86cd-0550-42d7-b085-92842c89ee90	Shimadzu 4	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
453	2025-06-09 10:29:50.429744+00	54e28c12-acd4-4c69-a0a6-815a77c4e895	Hitachi 8900	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
454	2025-06-09 10:29:58.981952+00	4b3bb52f-df8d-421c-893e-37052e982bcb	Shimadzu 30	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
455	2025-06-09 10:30:09.648869+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
732	2025-07-31 15:49:15.215799+00	bb943237-5422-4400-8732-e6208468ba5e	BCAA(g-EV) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
457	2025-06-09 10:30:35.801309+00	322bde1c-c844-44d7-8846-a773b9f97679	Waters Alliance New	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
458	2025-06-09 10:31:01.173509+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam 433	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
459	2025-06-09 10:31:17.0849+00	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	Shimadzu 7	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
460	2025-06-09 10:31:24.536931+00	0c0b62b6-c1b4-4828-8c87-b90396e2288d	Dionex ICS 5000 2	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
461	2025-06-09 10:40:48.616084+00	f4219c2e-5e50-4b01-b68a-2c42ebb65cbd	Эктоин (OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
462	2025-06-09 10:41:09.19743+00	4a8d426e-1a4c-4e7e-b7c7-b23a9bf0bcc1	Эктоин (OA) : примеси органических кислот - Shimadzu 6	3		19	5
463	2025-06-09 10:44:04.183045+00	1382ddde-24a5-443a-9af8-133c83477218	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[]	10	5
464	2025-06-09 10:50:21.520869+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Met : основной продукт - Methionine (Зиятдинов) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
465	2025-06-09 10:56:22.367588+00	1c051ae6-a3a0-4637-8011-45d15e7d7590	Эктоин (OA) : примеси органических кислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
466	2025-06-09 10:57:59.933692+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
467	2025-06-09 10:58:35.979309+00	c0d394f6-e583-4327-9acc-20a826b40cac	Эктоин : основной продукт - Эктоин (Гераскина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
468	2025-06-10 18:49:53.975368+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
469	2025-06-10 18:50:00.688519+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
470	2025-06-10 18:50:23.227568+00	e028e32c-581f-4b39-92ae-9a81552b7862	Waters Alliance Old	2	[]	13	1
471	2025-06-10 18:50:25.061428+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6	2	[]	13	1
472	2025-06-10 18:50:49.595259+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
473	2025-06-10 18:51:03.521876+00	555a86cd-0550-42d7-b085-92842c89ee90	Shimadzu 4	2	[]	13	1
474	2025-06-10 18:51:19.392508+00	370b51e9-685c-4a6d-bcc5-67bed5d29f48	Aracus	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
475	2025-06-10 18:51:35.060469+00	370b51e9-685c-4a6d-bcc5-67bed5d29f48	Aracus	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
476	2025-06-10 18:52:21.058806+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	1
477	2025-06-24 08:49:16.46424+00	aea349b3-2d91-423e-b832-5211bcdb541a	30.06.2025-06.07.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
478	2025-06-24 08:50:05.331351+00	d33d9600-468d-414c-b833-6fa3b690acf8	07.07.2025-13.07.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
479	2025-06-24 08:50:25.625905+00	faf7f1ac-d6d3-4971-9614-079940658474	09.06.2025-15.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
480	2025-06-24 08:50:34.750677+00	cc74c9b7-7478-4d9c-bfa0-efa19c9d7df0	16.06.2025-22.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
481	2025-06-24 08:50:43.306687+00	cb20bd09-1429-4883-8b00-99a4714b65a5	07.07.2025-13.07.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
482	2025-06-24 08:50:51.583996+00	9c8949f1-b97b-4d7b-aa8e-5f7cfef56f6a	16.06.2025-22.06.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
483	2025-06-24 08:50:58.957839+00	90185b56-b39e-40c7-9798-024213deac70	16.06.2025-22.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
484	2025-06-24 08:51:10.147416+00	86ba5ca1-a242-4b7a-85df-59231019c1d1	07.07.2025-13.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
485	2025-06-24 08:51:19.475406+00	8565f8b8-c55a-4d6d-b737-88fe6f8f3dd0	07.07.2025-13.07.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
486	2025-06-24 08:51:24.501532+00	8685c020-7469-47aa-9746-fe038ae0c55c	09.06.2025-15.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
487	2025-06-24 08:51:30.095908+00	81dfc494-2de2-4379-b10e-691cc9fbcbd5	07.07.2025-13.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
488	2025-06-24 08:51:34.818189+00	7da16033-9b11-44da-96ca-058675a53e9e	09.06.2025-15.06.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
489	2025-06-24 08:51:38.956624+00	7d5bca70-ee72-43cf-b4a9-c5416a2137fc	09.06.2025-15.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
490	2025-06-24 08:52:00.431645+00	769b5ed9-ab99-450c-bc55-662cc5257660	07.07.2025-13.07.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
491	2025-06-24 08:52:04.804248+00	75b4833a-4a8a-451d-83d2-9c5f305eef5c	09.06.2025-15.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
492	2025-06-24 08:52:10.224093+00	74ca31c7-210d-4f29-8593-f767f2d33969	16.06.2025-22.06.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
493	2025-06-24 08:52:14.938866+00	57c0de4f-a068-4c41-9df0-afce5fed8756	07.07.2025-13.07.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
494	2025-06-24 08:52:20.249813+00	6651c987-6301-48ea-a14b-b450ae0548d6	16.06.2025-22.06.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
495	2025-06-24 08:52:25.315418+00	56b11872-b698-4ba8-bea5-9ed3a62afbf7	07.07.2025-13.07.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
496	2025-06-24 08:52:30.953186+00	5219d651-27b3-4eaf-879d-7885a7dea985	09.06.2025-15.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
497	2025-06-24 08:52:39.506422+00	386cfcc5-8f81-41b8-901d-4e7933f369cc	09.06.2025-15.06.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	3		10	5
498	2025-06-24 08:52:48.269861+00	35a3585e-dd65-4761-8871-54471d4d53cc	16.06.2025-22.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
499	2025-06-24 08:52:54.010477+00	2f39a79c-bbb3-4039-86dc-41637321c565	07.07.2025-13.07.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
500	2025-06-24 08:52:59.180402+00	2ef307d9-4a72-43f0-94d0-32e27af4b41f	16.06.2025-22.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
501	2025-06-24 08:53:04.072417+00	26a010b1-e1b5-4155-8fd4-36b17ca1ae3b	09.06.2025-15.06.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
502	2025-06-24 08:53:08.499386+00	13c9e994-564b-4577-96fb-9856b96e2933	16.06.2025-22.06.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
503	2025-06-24 08:53:14.062046+00	1382ddde-24a5-443a-9af8-133c83477218	16.06.2025-22.06.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
504	2025-06-24 08:53:29.053609+00	10ff566f-7aa7-4b59-866c-02699cce953c	09.06.2025-15.06.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
505	2025-06-24 08:55:42.87844+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 00:00, период недели: 30.06.2025-06.07.2025	1	[{"added": {}}]	8	5
506	2025-06-24 08:56:39.968381+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 00:00, период недели: 23.06.2025-29.06.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
507	2025-06-24 08:56:52.56923+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 00:00, период недели: 30.06.2025-06.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
508	2025-06-24 09:17:28.567164+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 24:00, период недели: 30.06.2025-06.07.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
509	2025-06-24 09:17:58.470721+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 24:00, период недели: 30.06.2025-06.07.2025	2	[]	8	5
510	2025-06-24 09:18:15.306768+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 24.06.2025 с 00:00 до 24:00, период недели: 23.06.2025-29.06.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
511	2025-06-24 09:19:23.042779+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 30.06.2025-06.07.2025	1	[{"added": {}}]	7	5
512	2025-07-08 09:20:21.14497+00	a6902413-ff8a-46a6-9b42-9db06927cc30	GAA-2(Gr,Hx) (Ростова) : Не приоритетный 	1	[{"added": {}}]	15	5
513	2025-07-08 09:24:47.864009+00	16bd440d-2799-48da-b879-b1c7975e0ab6	C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	15	5
514	2025-07-08 09:25:04.504477+00	cdf23166-345a-4084-8437-92c51adbbe78	Эктоин (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	5
515	2025-07-08 09:25:32.363163+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин Михаил Юрьевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	5
516	2025-07-08 09:25:48.018553+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine (Зиятдинов Михаил Харисович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	5
517	2025-07-08 09:29:30.726194+00	a6902413-ff8a-46a6-9b42-9db06927cc30	GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	5
518	2025-07-08 09:39:14.445309+00	806f8ddc-ab22-4e19-9513-953dab466dde	g-EV (Гак Евгений Родионович) : Не приоритетный 	1	[{"added": {}}]	15	5
519	2025-07-08 10:40:19.849957+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин Михаил Юрьевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
520	2025-07-08 10:41:11.165555+00	fc476729-c88c-456d-b1fd-3125b23bc244	Arg : основной продукт - Arginine (Кирюхин Михаил Юрьевич) : Не приоритетный 	2	[]	17	5
521	2025-07-08 10:41:40.665637+00	d2307861-ee3b-426a-98fa-259d83ac47d0	Arg(AA) : примеси аминокислот - Arginine (Кирюхин Михаил Юрьевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
522	2025-07-08 10:42:02.538858+00	ed419b7e-46a8-40d0-9b86-7f292f45bfcf	Met : основной продукт - Methionine (Зиятдинов Михаил Харисович) : Не приоритетный 	2	[]	17	5
523	2025-07-08 10:42:13.274732+00	eccc3238-6a69-450f-a3e2-4785fefe6ed4	Met (OA) : примеси органических кислот - Methionine (Зиятдинов Михаил Харисович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
524	2025-07-08 10:42:27.065394+00	cdb3e289-dd41-4e0e-826c-b99270b5eeb2	Met (IA) : примеси неорганических анионов - Methionine (Зиятдинов Михаил Харисович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
525	2025-07-08 10:42:54.043362+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
526	2025-07-08 10:43:23.552923+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина Наталия) : Не приоритетный 	2	[]	17	5
527	2025-07-08 10:43:32.270755+00	c0d394f6-e583-4327-9acc-20a826b40cac	Эктоин : основной продукт - Эктоин (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
528	2025-07-08 10:43:46.423221+00	1c051ae6-a3a0-4637-8011-45d15e7d7590	Эктоин (OA) : примеси органических кислот - Эктоин (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
529	2025-07-08 10:44:10.366118+00	eecdd0f8-7244-4bf6-8f96-65622901a51d	Arg(OA) : примеси органических кислот	2	[]	16	5
530	2025-07-08 10:45:53.036422+00	5a4b0048-0b0a-484b-942a-404ff2f5c530	Lauric acid : основной продукт - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
531	2025-07-08 10:46:26.371109+00	4f2ab503-d684-47b9-a232-f3ac48b341c5	Amisoft : основной продукт - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
532	2025-07-08 10:46:54.558409+00	ff3de101-baf4-4b64-9c64-7e7e7127ef38	Amisoft(OA) : примеси органических кислот - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
533	2025-07-08 10:47:25.184169+00	f3e3808a-a486-42a5-a6f4-ab85698f04fe	HxR : основной продукт - GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
534	2025-07-08 10:48:01.700129+00	431e1787-1ba1-4f94-8c95-451e8a7f8154	Gr(OA) : примеси органических кислот - GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
535	2025-07-08 10:48:20.585153+00	ff5c9912-e1ea-460a-b787-7fac82acd65f	HxR(OA) : примеси органических кислот - GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
536	2025-07-08 10:49:56.529731+00	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	Gr(основной продукт) : основной продукт	1	[{"added": {}}]	16	5
537	2025-07-08 10:50:33.627973+00	28ea3d9c-343e-42ed-96f3-9f96826a807c	Gr(основной продукт) : основной продукт - Shimadzu 7	1	[{"added": {}}]	19	5
538	2025-07-08 10:51:05.276909+00	39d57c00-c13a-4c06-9dd6-4f163e74308a	Gr(основной продукт) : основной продукт - GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
539	2025-07-08 10:52:22.327824+00	87e352df-7694-466a-a100-26aa80ff28e9	g-EV : основной продукт	1	[{"added": {}}]	16	5
540	2025-07-08 10:52:57.976193+00	c0a83528-217f-423b-ac8b-0cc28f5d27b6	g-EV : основной продукт - Agilent 1100	1	[{"added": {}}]	19	5
541	2025-07-08 10:53:20.047058+00	aef268e6-5f4a-49df-b7d3-a64461905279	g-EV : основной продукт - Agilent 1260	1	[{"added": {}}]	19	5
542	2025-07-08 10:56:06.039317+00	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	g-EV(OA) : примеси органических кислот	1	[{"added": {}}]	16	5
543	2025-07-08 10:56:38.72905+00	5ab69397-5731-4b15-a1dd-d62c647cac62	g-EV(OA) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
544	2025-07-08 10:57:13.175387+00	b8fddb19-3e5d-4538-9db3-800c8ca2602f	g-EV(OA) : примеси органических кислот - g-EV (Гак Евгений Родионович) : Не приоритетный 	1	[{"added": {}}]	17	5
545	2025-07-08 11:00:43.200038+00	c051ac7f-3de8-4be8-876f-ac50ab6b7824	a-AP (Смирнов Сергей Васильевич) : Не приоритетный 	1	[{"added": {}}]	15	5
546	2025-07-08 11:02:03.24434+00	09db72b2-a1b9-4d7d-87bf-152bca5232b3	a-AP(AA) : примеси аминокислот - a-AP (Смирнов Сергей Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
547	2025-07-08 11:25:56.164193+00	816a15ab-4636-4b60-8c01-5f6a914e66f3	Arg : основной продукт - Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
548	2025-07-08 11:28:39.352414+00	816a15ab-4636-4b60-8c01-5f6a914e66f3	Arg : основной продукт - Shimadzu 5	2	[]	19	5
549	2025-07-08 11:29:15.395081+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
550	2025-07-08 11:30:59.157511+00	0b63af56-09d1-4852-a5ce-9ea0cf9af6ab	30.06.2025-06.07.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
551	2025-07-08 11:31:12.528938+00	1c8dbfd4-4904-47a9-b5f9-fb66292aa6aa	14.07.2025-20.07.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
552	2025-07-08 11:31:17.188413+00	22fc773c-6c87-423f-9d60-f3cab0fa2276	14.07.2025-20.07.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
553	2025-07-08 11:31:24.668718+00	2611532a-bee5-4e7a-8ff9-083457b9322b	30.06.2025-06.07.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
554	2025-07-08 11:31:29.105799+00	d2c7b282-7f1c-48d7-aafa-a7625854db47	14.07.2025-20.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
555	2025-07-08 11:31:34.259087+00	2df38fb3-0c6a-448a-b3ef-8dd450151792	30.06.2025-06.07.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
556	2025-07-08 11:31:39.727919+00	2e35d83b-847c-4ee5-ace8-d907660f82e8	30.06.2025-06.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
557	2025-07-08 11:31:45.895806+00	3b96294a-632f-40ec-852c-8532dac3e38b	14.07.2025-20.07.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
558	2025-07-08 11:31:52.111629+00	468da7f7-ba0a-4aab-82b3-8a1437d39d9a	14.07.2025-20.07.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
559	2025-07-08 11:31:56.915678+00	5f0f3516-2c50-41b0-9225-df8e1fe306a6	30.06.2025-06.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
560	2025-07-08 11:32:05.857348+00	70edbd30-635a-4127-9989-d4c77c78603c	30.06.2025-06.07.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
561	2025-07-08 11:32:11.143284+00	671fb6cd-1221-4d83-99e0-93bc23416926	14.07.2025-20.07.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
562	2025-07-08 11:32:16.004359+00	790e5453-aab7-4edd-997e-8a4bc6c4af55	14.07.2025-20.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
563	2025-07-08 11:32:21.219326+00	84fb166d-486a-4a64-bd36-0e1fbb9c1bd0	14.07.2025-20.07.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
564	2025-07-08 11:32:26.362786+00	aea349b3-2d91-423e-b832-5211bcdb541a	30.06.2025-06.07.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
565	2025-07-08 11:32:31.026375+00	b3e3cab9-94e5-4e54-8aa2-26f5601f77f3	30.06.2025-06.07.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
566	2025-07-08 11:32:35.535983+00	d314a346-4bdc-47e9-b2aa-6eaadc81c815	30.06.2025-06.07.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
567	2025-07-08 11:32:40.206392+00	e775406e-ad71-46bc-a35e-f89df3403c6e	14.07.2025-20.07.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
568	2025-07-08 11:35:41.742468+00	c52e999b-2f8a-4778-a523-7167b683ab00	14.07.2025-20.07.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
569	2025-07-08 11:35:55.130691+00	a26efb39-c26e-4198-aca1-3b0408d78ae5	14.07.2025-20.07.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
570	2025-07-08 11:36:14.92923+00	be4fc228-237f-4054-8429-a0a4b680884d	07.07.2025-13.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
571	2025-07-08 11:36:33.23667+00	83c9b11d-e0ca-4baa-b978-bd6c58163ec5	14.07.2025-20.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
572	2025-07-08 11:36:39.730261+00	be4fc228-237f-4054-8429-a0a4b680884d	07.07.2025-13.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
573	2025-07-08 11:36:51.831603+00	5314f7f1-bcd7-4644-94f9-7f408676cce2	14.07.2025-20.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
574	2025-07-08 11:37:17.136353+00	87cdb38f-3e04-489d-b83e-cfafeccd8886	07.07.2025-13.07.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	1	[{"added": {}}]	10	5
575	2025-07-08 11:37:34.755308+00	e4a07e65-3d62-41f5-9382-d8e4e3f4f36c	14.07.2025-20.07.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
576	2025-07-08 11:38:09.305044+00	a3457e1b-808b-472a-8acd-89e41cb8f2f8	14.07.2025-20.07.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	1	[{"added": {}}]	10	5
577	2025-07-08 11:38:17.965278+00	87cdb38f-3e04-489d-b83e-cfafeccd8886	07.07.2025-13.07.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	3		10	5
578	2025-07-08 11:38:42.436532+00	5bd9d4fb-5155-4338-bae1-ed3d3a10f801	14.07.2025-20.07.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	1	[{"added": {}}]	10	5
579	2025-07-08 11:40:36.798499+00	954fa69a-f32a-4e83-bf8a-d7f3c047536b	14.07.2025-20.07.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
580	2025-07-08 11:41:00.228774+00	877a02cf-73bb-4b0f-99e2-95ea5fefc6f8	14.07.2025-20.07.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
581	2025-07-08 11:42:18.676612+00	db153c1a-0d8e-42a5-88fa-4e44c0fc99cc	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">14.07.2025-20.07.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[]	9	5
582	2025-07-08 11:42:56.136116+00	48aa396d-b3e9-46f9-be34-7fe71392332f	Окно бронирования на 24.06.2025 с 00:00 до 24:00, период недели: 30.06.2025-06.07.2025	3		8	5
583	2025-07-08 11:43:03.409738+00	e9f2ece1-0501-4634-bd3c-1623fb54284d	Окно бронирования на 24.06.2025 с 00:00 до 24:00, период недели: 23.06.2025-29.06.2025	3		8	5
584	2025-07-08 11:43:51.94383+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 08.07.2025 с 00:00 до 00:00, период недели: 07.07.2025-13.07.2025	1	[{"added": {}}]	8	5
585	2025-07-08 11:46:11.870838+00	db153c1a-0d8e-42a5-88fa-4e44c0fc99cc	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">14.07.2025-20.07.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
586	2025-07-08 11:46:59.166759+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 08.07.2025 с 00:00 до 24:00, период недели: 07.07.2025-13.07.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
587	2025-07-08 11:48:22.257062+00	a35c492e-c61f-42ca-9d6c-f4a0075ac541	Закрыта период недели: 14.07.2025-20.07.2025	1	[{"added": {}}]	7	5
588	2025-07-08 11:49:28.580999+00	a35c492e-c61f-42ca-9d6c-f4a0075ac541	Закрыта период недели: 14.07.2025-20.07.2025	3		7	5
589	2025-07-08 11:49:36.210857+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 14.07.2025-20.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	7	5
590	2025-07-08 11:51:27.550865+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 08.07.2025 с 00:00 до 24:00, период недели: 14.07.2025-20.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
591	2025-07-08 11:52:19.395227+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 08.07.2025 с 00:00 до 00:00, период недели: 14.07.2025-20.07.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
592	2025-07-08 12:00:42.314441+00	99237cae-e1a4-445e-ba5e-a76176cc8d13	g-EV : основной продукт - g-EV (Гак Евгений Родионович) : Не приоритетный 	1	[{"added": {}}]	17	5
593	2025-07-08 12:01:11.380465+00	87e352df-7694-466a-a100-26aa80ff28e9	g-EV : основной продукт	2	[]	16	5
594	2025-07-08 12:03:06.093522+00	99237cae-e1a4-445e-ba5e-a76176cc8d13	g-EV : основной продукт - g-EV (Гак Евгений Родионович) : Не приоритетный 	2	[]	17	5
595	2025-07-08 12:04:22.094631+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 1100	2	[]	13	5
596	2025-07-08 12:04:27.329541+00	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	Agilent 1260	2	[]	13	5
597	2025-07-08 12:05:02.786025+00	c0a83528-217f-423b-ac8b-0cc28f5d27b6	g-EV : основной продукт - Agilent 1100	2	[]	19	5
598	2025-07-08 12:05:12.584313+00	aef268e6-5f4a-49df-b7d3-a64461905279	g-EV : основной продукт - Agilent 1260	2	[]	19	5
599	2025-07-08 12:05:28.942101+00	99237cae-e1a4-445e-ba5e-a76176cc8d13	g-EV : основной продукт - g-EV (Гак Евгений Родионович) : Не приоритетный 	2	[]	17	5
600	2025-07-08 12:05:42.979378+00	8bfe7234-ce4a-487c-8728-82b5f1956a71	Agilent 1100	2	[]	13	5
601	2025-07-08 12:09:38.635095+00	d36c9e4f-2406-492b-b467-de7884e9a2e6	Сёменов  Егор  Александрович	2	[]	14	5
602	2025-07-08 12:12:53.467053+00	7b74a6a1-d92b-476a-befc-0783a20e9170	Amisoft(OA) : примеси органических кислот	2	[]	16	5
603	2025-07-08 12:13:04.512165+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[]	13	5
604	2025-07-08 12:13:34.502328+00	8fe966e3-5285-42a4-b619-ca707c9784e5	Amisoft(OA) : примеси органических кислот - Shimadzu 3	2	[]	19	5
605	2025-07-08 12:14:23.947177+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
606	2025-07-08 12:25:05.330378+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 07.07.2025-13.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	7	5
607	2025-07-08 12:26:06.435514+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 07.07.2025-13.07.2025	2	[]	7	5
608	2025-07-08 12:26:37.962521+00	53438eb7-19c9-4dfd-9bf4-8dee154d15ce	07.07.2025-13.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
609	2025-07-09 14:57:20.406538+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 09.07.2025 с 00:00 до 00:00, период недели: 07.07.2025-13.07.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
610	2025-07-09 14:59:21.402147+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 09.07.2025 с 00:00 до 24:00, период недели: 07.07.2025-13.07.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
611	2025-07-09 15:02:44.699672+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 14.07.2025-20.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	7	5
612	2025-07-09 15:03:34.686135+00	b548eacf-3d33-48c5-9163-09ccd337821d	Открыта период недели: 14.07.2025-20.07.2025	2	[]	7	5
613	2025-07-09 15:04:25.775634+00	52f858a2-2aae-452e-8766-3c21dd44c7d1	Окно бронирования на 09.07.2025 с 00:00 до 24:00, период недели: 14.07.2025-20.07.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
614	2025-07-10 07:41:01.264039+00	cd93279c-e67a-4059-b8b8-090fa9478f8b	Эктоин (AA) : примеси аминокислот - Эктоин (Гераскина Наталия) : Не приоритетный 	2	[]	17	5
615	2025-07-10 07:41:38.728573+00	f68b9664-d014-4676-948d-52498a46ca27	Эктоин (AA) : примеси аминокислот - Sykam 433	2	[]	19	5
616	2025-07-10 17:34:36.710148+00	cdf23166-345a-4084-8437-92c51adbbe78	Biostimulant (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	5
617	2025-07-10 17:37:13.234918+00	15006c04-e8b0-4334-8170-2ea34badf7f8	DAP : основной продукт - Biostimulant (Гераскина Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
618	2025-07-10 17:38:22.050701+00	072d6497-ead1-40d7-93ea-da2b11b3fd96	DAP(OA) : примеси органических кислот - Biostimulant (Гераскина Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
619	2025-07-10 17:45:29.731915+00	ee16775d-0650-4c3f-b16d-6877ac69afe5	Serine (Самсонов Виктор Васильевич) : Не приоритетный 	1	[{"added": {}}]	15	5
620	2025-07-10 17:48:57.273719+00	04567c72-d2d7-43fc-baa5-d22abe61e00e	Глутамин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	15	5
621	2025-07-10 18:09:37.533607+00	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	Methionine/Cystine (Зиятдинов Михаил Харисович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	5
622	2025-07-10 18:12:40.877226+00	eb71ab5f-3f77-4ed0-abd1-b616992094a0	Fatty acid (Матросова Елена) : Не приоритетный 	1	[{"added": {}}]	15	5
623	2025-07-10 18:15:33.968347+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталия) : Не приоритетный 	1	[{"added": {}}]	15	5
624	2025-07-10 18:32:06.015286+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталия) : Не приоритетный 	2	[]	15	5
625	2025-07-10 18:34:09.262986+00	cca63e0d-6cd7-4c22-8189-7aad30964b37	GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	1	[{"added": {}}]	15	5
626	2025-07-28 14:39:34.431444+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 28.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	8	5
628	2025-07-28 14:42:04.622604+00	e5283d88-97eb-4dfc-a1ef-1720fbdeb3dc	11.08.2025-17.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
629	2025-07-28 14:43:58.829322+00	2073916b-fc25-45eb-8215-5909ef973ee1	04.08.2025-10.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433", "\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
630	2025-07-28 14:44:09.333662+00	fd1bb011-4e5b-461c-877f-c1086929a232	28.07.2025-03.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
631	2025-07-28 14:44:15.291156+00	f744f576-8797-42e3-a4bf-3331ab50bfd8	04.08.2025-10.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
632	2025-07-28 14:44:19.528188+00	e81bdbd3-9950-431c-8285-4533b4de16a7	28.07.2025-03.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
633	2025-07-28 14:44:23.821772+00	e4a07e65-3d62-41f5-9382-d8e4e3f4f36c	14.07.2025-20.07.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
634	2025-07-28 14:44:28.34115+00	dd3d04ef-0a56-4fcb-92b7-bc87c526bfa9	28.07.2025-03.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
635	2025-07-28 14:44:33.497902+00	cbdc96a3-4fc9-45e2-bc17-718d0c89c6d3	11.08.2025-17.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
636	2025-07-28 14:44:38.681064+00	ca06c9b0-b0f1-46ae-a43d-d6aa70380404	28.07.2025-03.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
637	2025-07-28 14:44:44.682502+00	c52e999b-2f8a-4778-a523-7167b683ab00	14.07.2025-20.07.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
638	2025-07-28 14:44:49.86763+00	c4573481-2dee-4994-bff8-1c78fd051ff3	11.08.2025-17.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
639	2025-07-28 14:45:05.529826+00	b76af4b3-c869-4eae-89eb-4c2007b2ba26	04.08.2025-10.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
640	2025-07-28 14:45:11.416193+00	b675f26a-da50-4795-93c8-d3c80e77e5aa	04.08.2025-10.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
641	2025-07-30 14:58:48.445622+00	b4285483-6a55-4f88-8843-aea1e58c6ddd	28.07.2025-03.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
642	2025-07-30 14:58:53.0426+00	b1295195-f3b0-4858-84ff-55c39f114a2e	11.08.2025-17.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
643	2025-07-30 14:59:05.681999+00	af810d0a-c0da-456c-afcc-d5e4009fd8a1	04.08.2025-10.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
644	2025-07-30 14:59:10.0943+00	a56f88b2-e2e4-4b87-a8ac-a747e1bb62fb	11.08.2025-17.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
645	2025-07-30 14:59:16.273564+00	a3457e1b-808b-472a-8acd-89e41cb8f2f8	14.07.2025-20.07.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	3		10	5
646	2025-07-30 14:59:20.325688+00	a26efb39-c26e-4198-aca1-3b0408d78ae5	14.07.2025-20.07.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
647	2025-07-30 14:59:24.577797+00	954fa69a-f32a-4e83-bf8a-d7f3c047536b	14.07.2025-20.07.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
648	2025-07-30 14:59:28.417451+00	8f911baf-4ba5-442c-9bcb-01f79bd24b29	04.08.2025-10.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
649	2025-07-30 14:59:39.95052+00	88c7912a-8532-4113-a29e-853f12152ac6	04.08.2025-10.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
650	2025-07-30 14:59:44.879959+00	877a02cf-73bb-4b0f-99e2-95ea5fefc6f8	14.07.2025-20.07.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	3		10	5
651	2025-07-30 14:59:49.822687+00	857964d8-06f2-47f9-9b88-49f96c40dd1c	28.07.2025-03.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
652	2025-07-30 14:59:54.55334+00	83c9b11d-e0ca-4baa-b978-bd6c58163ec5	14.07.2025-20.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
762	2025-08-04 07:34:10.3675+00	1a5902da-bf12-4f7e-b055-775956f6adda	Санто  Леонид  Павлович	2	[]	14	5
653	2025-07-30 14:59:59.777427+00	75908282-cecd-4b5e-b4ad-75a108cf6efd	28.07.2025-03.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
654	2025-07-30 15:00:03.979879+00	738f89e1-be11-4a53-a9fa-971cb72a49d8	04.08.2025-10.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
655	2025-07-30 15:00:08.865034+00	5bd9d4fb-5155-4338-bae1-ed3d3a10f801	14.07.2025-20.07.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск 	3		10	5
656	2025-07-30 15:00:13.103285+00	56159b90-1e44-4d3a-ba0e-562d5af146c8	11.08.2025-17.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
657	2025-07-30 15:00:17.696828+00	53438eb7-19c9-4dfd-9bf4-8dee154d15ce	07.07.2025-13.07.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
658	2025-07-30 15:00:21.750109+00	5314f7f1-bcd7-4644-94f9-7f408676cce2	14.07.2025-20.07.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
659	2025-07-30 15:00:26.909463+00	453f0d05-bb8e-4d3f-b7b1-1308f6959048	28.07.2025-03.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
660	2025-07-30 15:00:31.015532+00	3d7be472-345e-443a-94fb-94d8d48c009a	11.08.2025-17.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
661	2025-07-30 15:00:35.042112+00	2f2af2cc-f726-4841-9d4b-13227601881f	28.07.2025-03.08.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
662	2025-07-30 15:00:41.057227+00	27a98d69-2f35-4f71-8fc0-449a05afbdfb	11.08.2025-17.08.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
663	2025-07-30 15:00:45.169593+00	244da4b3-d30a-41af-9735-c45d1a2b2f41	11.08.2025-17.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
664	2025-07-30 15:00:49.481008+00	23ae596b-ef5f-48c9-82a5-32709dea27da	04.08.2025-10.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
665	2025-07-30 15:00:54.219158+00	2073916b-fc25-45eb-8215-5909ef973ee1	04.08.2025-10.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной 	3		10	5
666	2025-07-30 15:01:23.425672+00	cb0eec54-c522-4d70-953e-85b22ac9f48a	04.08.2025-10.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
667	2025-07-30 15:01:41.663855+00	be58c5d5-4332-4f84-85be-cbf5754d2764	28.07.2025-03.08.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
668	2025-07-30 15:02:00.668194+00	90332cd0-e5f3-47e3-9110-9b987c49c085	28.07.2025-03.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
669	2025-07-30 15:02:20.007947+00	be58c5d5-4332-4f84-85be-cbf5754d2764	04.08.2025-10.08.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
670	2025-07-30 15:02:29.328684+00	90332cd0-e5f3-47e3-9110-9b987c49c085	04.08.2025-10.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
671	2025-07-30 15:02:52.035024+00	c7144c74-4a00-4c18-929d-2f2313cc0b54	28.07.2025-03.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
672	2025-07-30 15:03:12.363572+00	39a5a40d-4067-45ff-b73a-a514f30aeb8a	28.07.2025-03.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
673	2025-07-30 15:03:22.410988+00	9b43ef95-fcfd-41e6-85b9-c6a2ba564886	28.07.2025-03.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
674	2025-07-30 15:03:30.849604+00	04d4b86b-0de6-4f4a-a4c4-4207d9d6b8f4	28.07.2025-03.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
675	2025-07-30 15:03:49.725494+00	2b2592a4-2052-4b51-b2d4-9bc450788fc1	28.07.2025-03.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
676	2025-07-30 15:04:07.122342+00	6d401f73-76fb-4583-9bda-2a680700714a	04.08.2025-10.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1186	2025-09-12 09:18:16.228764+00	62824931-02d2-45a1-9fb1-17050db2b92b	Shimadzu 40	1	[{"added": {}}]	13	5
677	2025-07-30 15:04:13.803518+00	39a5a40d-4067-45ff-b73a-a514f30aeb8a	04.08.2025-10.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
678	2025-07-30 15:04:21.212217+00	c7144c74-4a00-4c18-929d-2f2313cc0b54	04.08.2025-10.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
679	2025-07-30 15:04:31.496942+00	9b43ef95-fcfd-41e6-85b9-c6a2ba564886	04.08.2025-10.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
680	2025-07-30 15:06:31.816797+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
681	2025-07-30 15:06:39.881991+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
682	2025-07-30 15:06:57.816378+00	45b126ee-5a9d-4dc4-aa24-4a554109deb9	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
683	2025-07-30 15:14:33.754543+00	45b126ee-5a9d-4dc4-aa24-4a554109deb9	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
684	2025-07-30 15:14:40.973922+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
685	2025-07-30 15:15:50.692752+00	dc24b0c7-671b-42bc-84aa-416733f9e4fd	Закрыта период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	7	5
686	2025-07-30 15:15:58.816901+00	992de94e-13e2-4c41-9161-2f77beb1a48c	Закрыта период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	7	5
687	2025-07-30 15:16:37.654557+00	b548eacf-3d33-48c5-9163-09ccd337821d	Закрыта период недели: 28.07.2025-03.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	7	5
688	2025-07-30 15:16:46.729884+00	dc24b0c7-671b-42bc-84aa-416733f9e4fd	Открыта период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
689	2025-07-30 15:17:08.910593+00	992de94e-13e2-4c41-9161-2f77beb1a48c	Закрыта период недели: 11.08.2025-17.08.2025	2	[]	7	5
690	2025-07-30 15:17:15.635573+00	992de94e-13e2-4c41-9161-2f77beb1a48c	Закрыта период недели: 11.08.2025-17.08.2025	3		7	5
691	2025-07-30 15:18:19.286511+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
692	2025-07-30 15:19:01.916912+00	45b126ee-5a9d-4dc4-aa24-4a554109deb9	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 11.08.2025-17.08.2025	3		8	5
693	2025-07-30 15:19:12.288924+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	2	[]	8	5
694	2025-07-30 15:20:48.889776+00	2868184d-6f4b-4421-bdc2-d5599c7cb059	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">04.08.2025-10.08.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[]	9	5
695	2025-07-30 15:21:18.936586+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
696	2025-07-30 15:22:05.095673+00	b548eacf-3d33-48c5-9163-09ccd337821d	Закрыта период недели: 28.07.2025-03.08.2025	3		7	5
697	2025-07-30 15:22:19.243106+00	dc24b0c7-671b-42bc-84aa-416733f9e4fd	Открыта период недели: 04.08.2025-10.08.2025	2	[]	7	5
698	2025-07-30 15:23:10.35566+00	2b2592a4-2052-4b51-b2d4-9bc450788fc1	04.08.2025-10.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
731	2025-07-31 15:48:46.731376+00	a74ea5ba-8ddf-423b-a37f-73a8d60deb9e	BCAA(g-EV) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
699	2025-07-30 15:23:18.248157+00	04d4b86b-0de6-4f4a-a4c4-4207d9d6b8f4	04.08.2025-10.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
700	2025-07-30 15:25:42.3563+00	cca63e0d-6cd7-4c22-8189-7aad30964b37	GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	2	[]	15	5
701	2025-07-30 15:27:29.06051+00	31880a90-ca26-45c6-a028-9f7437fb2750	Glu (AA) : примеси аминокислот - GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	1	[{"added": {}}]	17	5
702	2025-07-30 15:30:04.279956+00	a75bb5f5-2fec-4bc0-843f-43bb33011de0	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
703	2025-07-30 15:30:20.857741+00	dc24b0c7-671b-42bc-84aa-416733f9e4fd	Открыта период недели: 04.08.2025-10.08.2025	3		7	5
704	2025-07-30 15:31:12.153641+00	a75bb5f5-2fec-4bc0-843f-43bb33011de0	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
705	2025-07-30 15:31:21.161276+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
706	2025-07-30 15:32:03.021416+00	4cc94e2f-2ec3-4fdd-ad52-b86a1599250d	Открыта период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	7	5
707	2025-07-30 15:32:57.583006+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 00:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
708	2025-07-30 15:34:12.243877+00	a75bb5f5-2fec-4bc0-843f-43bb33011de0	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
709	2025-07-30 15:34:22.2357+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 30.07.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
710	2025-07-30 15:34:37.428796+00	4cc94e2f-2ec3-4fdd-ad52-b86a1599250d	Открыта период недели: 04.08.2025-10.08.2025	2	[]	7	5
711	2025-07-31 14:06:11.18504+00	fb09a7e8-8696-45ab-abc4-baa9e1440da5	Shimadzu 3	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
712	2025-07-31 14:10:47.607356+00	84df3dc6-49c1-4733-b757-ac6f61ef781e	a-AP : основной продукт - Waters  LC-MS/MS Acquity	1	[{"added": {}}]	19	5
713	2025-07-31 14:11:51.062764+00	b8d660a9-f7b3-44fe-bc0d-0cdb98bb368e	a-AP : основной продукт - a-AP (Смирнов Сергей Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
714	2025-07-31 14:17:08.325604+00	48e67666-a178-4dfb-b8d2-85ce726187a6	Glu : основной продукт - GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	1	[{"added": {}}]	17	5
715	2025-07-31 14:18:24.853077+00	a9155a4a-52b3-4fd2-8914-0b5946202948	Glu (OA) : примеси органических кислот - GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	1	[{"added": {}}]	17	5
716	2025-07-31 15:08:10.064391+00	90fb5920-1cc7-414b-b898-6986549124b2	Ser : основной продукт - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
717	2025-07-31 15:08:34.300313+00	a70d2f4d-4f31-4850-9aae-be1e525f12ef	Ser(OA) : примеси органических кислот - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
718	2025-07-31 15:08:58.882652+00	009c1502-fe8e-4d71-a9f3-148896cae5be	Ser(AA) : примеси аминокислот - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
719	2025-07-31 15:13:20.621987+00	753cd7ca-9dcc-4b54-8d30-baedf1296e22	Asn (Родионова Мария) : Не приоритетный 	1	[{"added": {}}]	15	5
720	2025-07-31 15:17:31.130935+00	93ae7c4c-e51c-417b-b362-4a023df7a2a0	Asn : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
721	2025-07-31 15:20:08.629215+00	e6d9620a-67b3-4786-b3bd-53492d937ae0	Asn : основной продукт - Asn (Родионова Мария) : Не приоритетный 	1	[{"added": {}}]	17	5
722	2025-07-31 15:20:49.302919+00	822067b3-4c67-427d-8c09-45aa1fb6cab5	Asn(AA) : примеси аминокислот - Asn (Родионова Мария) : Не приоритетный 	1	[{"added": {}}]	17	5
723	2025-07-31 15:21:17.348351+00	3dc24816-b0cc-460b-875f-26b653d41d6a	Asn(OA) : примеси органических кислот - Asn (Родионова Мария) : Не приоритетный 	1	[{"added": {}}]	17	5
724	2025-07-31 15:27:30.765916+00	a4636783-1d55-415b-bbc2-deb27cdcf0f2	Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	15	5
725	2025-07-31 15:28:15.166356+00	2ce2279d-3822-40b1-a608-4f1559c9f593	BCAA(AA) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
726	2025-07-31 15:28:32.951935+00	56273adb-0ad0-464b-ad71-01602e166556	BCAA(Ile) : основной продукт - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
727	2025-07-31 15:28:52.70998+00	b65afc11-acb0-40cd-8a83-bcf593f9a228	BCAA(OA,2IPM,3IPM) : примеси органических кислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
728	2025-07-31 15:38:51.168643+00	c29e42b9-0143-4fb9-aff1-55067ffbf357	Asn(OA) : примеси органических кислот - Shimadzu 6	2	[{"changed": {"fields": ["\\u041f\\u0440\\u0438\\u0431\\u043e\\u0440"]}}]	19	5
729	2025-07-31 15:45:40.482804+00	03c4508a-7099-4bcb-9860-2b8ba70c5f61	Ser(AA) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
730	2025-07-31 15:48:18.838641+00	f70dda6c-3b1c-4248-bc15-93aefba973bb	BCAA(g-EV) : примеси аминокислот	1	[{"added": {}}]	16	5
733	2025-07-31 15:49:29.418049+00	8bbaed61-6385-4441-9b1b-29b29e9e6bba	BCAA(g-EV) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
734	2025-07-31 15:52:12.341136+00	ce90b427-5ba7-4733-b069-fae18c0ed29f	Arg(AA) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
735	2025-07-31 15:56:01.487357+00	5902477d-a765-4934-a832-4fb9a01cf704	Arg(IA) : примеси неорганических анионов	1	[{"added": {}}]	16	5
736	2025-07-31 15:56:27.821214+00	4df9cb35-e582-4d8b-aadc-6aa30f438310	Arg(IA) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
737	2025-07-31 15:57:22.735754+00	ce69a7e9-c0b4-4c5e-aa3c-6d42e45bcba3	Arg(IA) : примеси неорганических анионов - Arginine (Кирюхин Михаил Юрьевич) : Не приоритетный 	1	[{"added": {}}]	17	5
738	2025-08-01 15:13:09.601473+00	4cc94e2f-2ec3-4fdd-ad52-b86a1599250d	Открыта период недели: 04.08.2025-10.08.2025	3		7	5
739	2025-08-01 15:13:29.573676+00	d2ae9c1a-0c58-4f02-a805-d921504112de	Открыта период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	7	5
740	2025-08-01 15:14:34.291166+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 01.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
741	2025-08-01 15:14:50.463644+00	cdf23166-345a-4084-8437-92c51adbbe78	Biostimulant (Гераскина Наталия) : Приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
742	2025-08-01 15:15:37.250496+00	2fe8855e-e324-4320-a418-654f32b7128a	28.07.2025-03.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
743	2025-08-01 15:15:52.042271+00	2fe8855e-e324-4320-a418-654f32b7128a	11.08.2025-17.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
744	2025-08-01 15:16:10.331804+00	42e1968d-6801-45b8-beed-ab5605e91378	11.08.2025-17.08.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
745	2025-08-01 15:16:30.609281+00	85950adf-ed11-4996-b5cd-44bc6c9a0e0e	11.08.2025-17.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
746	2025-08-01 15:16:41.437716+00	5ede4e21-837e-44fd-9529-852b6891e768	11.08.2025-17.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
747	2025-08-01 15:17:03.997387+00	828edf90-9408-4736-9367-eda206447c16	11.08.2025-17.08.2025 - Федоров  Антон  Сергеевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
748	2025-08-01 15:17:17.262694+00	2fe8855e-e324-4320-a418-654f32b7128a	11.08.2025-17.08.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
749	2025-08-01 15:17:48.825637+00	8cba9800-21f9-45a7-85c4-bb33726607bb	28.07.2025-03.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
750	2025-08-01 15:18:04.099922+00	3dbe7c70-bc0b-4489-92da-3aec39c9b792	11.08.2025-17.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
751	2025-08-01 15:18:16.292085+00	d02252d7-5d39-4f9d-aaaa-794efb3c3ad0	11.08.2025-17.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
752	2025-08-01 15:18:36.874+00	2cb84b6a-ae9f-487f-ba8b-0cb9a1de10e9	11.08.2025-17.08.2025 - Сёменов  Егор  Александрович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
753	2025-08-01 15:21:12.740398+00	cdf23166-345a-4084-8437-92c51adbbe78	Biostimulant (Гераскина Наталия) : Приоритетный 	2	[]	15	5
754	2025-08-01 15:21:49.346958+00	d2ae9c1a-0c58-4f02-a805-d921504112de	Открыта период недели: 11.08.2025-17.08.2025	2	[]	7	5
755	2025-08-01 15:22:26.154024+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 01.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[]	8	5
756	2025-08-01 15:24:01.179559+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 01.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[]	8	5
757	2025-08-04 07:24:36.413912+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
758	2025-08-04 07:27:02.55014+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
759	2025-08-04 07:31:07.494892+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
760	2025-08-04 07:32:39.972576+00	a6902413-ff8a-46a6-9b42-9db06927cc30	GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	2	[]	15	5
761	2025-08-04 07:33:12.791564+00	ff5c9912-e1ea-460a-b787-7fac82acd65f	HxR(OA) : примеси органических кислот - GAA-2(Gr,Hx) (Ростова Юлия Георгиевна) : Не приоритетный 	2	[]	17	5
763	2025-08-04 07:34:29.818194+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR : основной продукт	2	[]	16	5
764	2025-08-04 07:34:57.284374+00	d7a75b52-413a-4746-ad74-86b7c9fbac7c	Санто  Леонид  Павлович - Shimadzu 7	1	[{"added": {}}]	18	5
765	2025-08-04 07:35:58.410928+00	f0df5086-f463-4d98-95ed-8b90ddb9d0d0	11.08.2025-17.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
766	2025-08-04 10:29:09.185404+00	a6902413-ff8a-46a6-9b42-9db06927cc30	Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	5
767	2025-08-04 10:29:39.816255+00	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	HxR(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
768	2025-08-04 10:30:11.746403+00	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	Gr(основной продукт) : основной продукт	2	[]	16	5
769	2025-08-04 10:31:03.418756+00	c5484c5f-6ed9-4743-b796-b668e486b652	GAA2(основной продукт) : основной продукт	1	[{"added": {}}]	16	5
770	2025-08-04 10:31:41.339423+00	b6387178-b0f0-4227-afae-44d21dc68b1e	GAA2(органические кислоты) : примеси органических кислот	1	[{"added": {}}]	16	5
771	2025-08-04 10:32:14.395205+00	1045bf64-4fb8-4c44-95c2-afe09bffa580	GAA2(примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
772	2025-08-04 10:33:07.278461+00	571c313e-8ec3-4777-bac7-40855117d510	HxR(органические кислоты)) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
773	2025-08-04 10:33:43.605776+00	8797874d-0abe-4021-89f4-f64cf3582f9f	HxR(примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
774	2025-08-04 10:34:12.924993+00	1d7b838c-9f35-43e6-9cde-d63c11d9097f	Gr(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
775	2025-08-04 10:34:44.370456+00	b71923ee-67eb-4665-8b04-a71717ab9521	Gr(примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
776	2025-08-04 10:35:19.275811+00	f8d6c899-bbf4-48cd-9457-901947d9a933	Gr(sugar) : анализ сахаров - Dionex ICS 5000 2	2	[]	19	5
777	2025-08-04 10:35:47.754749+00	9eebac2d-c944-4f98-9ec8-ca65b521dc3a	HxR(органические кислоты)) : примеси органических кислот - Shimadzu 3	2	[]	19	5
778	2025-08-04 10:36:51.246554+00	8648582b-99a0-4c98-9aed-4ce84a6bb076	HxR(органические кислоты)) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
779	2025-08-04 10:38:42.1838+00	c8ad8da1-b333-44d6-9675-7f98e3dd00e5	GAA2(органические кислоты) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
780	2025-08-04 10:39:05.417703+00	9b363f9a-f896-402d-a91e-a142810e3ace	GAA2(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
781	2025-08-04 10:40:05.183618+00	6ac32e74-b4aa-41dd-951a-cc2ebd42e5bb	GAA2(примеси аминокислот) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
782	2025-08-04 10:40:15.249441+00	6ac32e74-b4aa-41dd-951a-cc2ebd42e5bb	Gr(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	19	5
783	2025-08-04 10:40:29.095366+00	8ab9b452-5474-4631-a6c0-ae41d2526187	HxR(примеси аминокислот) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
784	2025-08-04 10:42:10.020811+00	1c04b1f5-56d1-487a-97a0-a48e8312b03d	Gr(sugar) : анализ сахаров - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
785	2025-08-04 10:42:32.973739+00	ed31a3f0-94cb-423b-a668-78acd8343104	HxR(sugar) : анализ сахаров - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
786	2025-08-04 10:43:48.721385+00	ed31a3f0-94cb-423b-a668-78acd8343104	GAA2(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
787	2025-08-04 10:44:05.910733+00	ed31a3f0-94cb-423b-a668-78acd8343104	GAA2(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
788	2025-08-04 10:44:14.836668+00	ed31a3f0-94cb-423b-a668-78acd8343104	GAA2(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
789	2025-08-04 10:44:40.551365+00	ed31a3f0-94cb-423b-a668-78acd8343104	HxR(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437", "\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
790	2025-08-04 10:44:52.902238+00	ed31a3f0-94cb-423b-a668-78acd8343104	HxR(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
791	2025-08-04 10:45:19.029742+00	ed31a3f0-94cb-423b-a668-78acd8343104	Gr(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0410\\u043d\\u0430\\u043b\\u0438\\u0437"]}}]	17	5
792	2025-08-04 10:47:40.952831+00	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	Shimadzu 7	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
793	2025-08-04 10:48:50.538207+00	571c313e-8ec3-4777-bac7-40855117d510	HxR(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
794	2025-08-04 10:51:40.064595+00	7823c2d6-91a3-4d22-bdc1-7cc65a49216f	GAA2(основной продукт) : основной продукт - Shimadzu 7	1	[{"added": {}}]	19	5
795	2025-08-04 10:52:42.959103+00	7c1053b5-7234-4359-97ba-799327ae8eac	GAA2(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
796	2025-08-04 10:53:07.529427+00	7311b703-f8e8-49c3-b268-5601465b961d	GAA2(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
797	2025-08-04 10:53:45.191598+00	7c1053b5-7234-4359-97ba-799327ae8eac	GAA2(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
798	2025-08-04 10:55:47.244939+00	ddd9678a-e677-426c-84df-cfdb787a7aa1	GAA2(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
799	2025-08-04 10:56:04.786796+00	c05be6a8-b2a5-45dd-990f-03105a50dc27	HxR(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
800	2025-08-04 10:56:25.333721+00	1c04b1f5-56d1-487a-97a0-a48e8312b03d	Gr(sugar) : анализ сахаров - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
801	2025-08-04 11:07:27.230097+00	ff5c9912-e1ea-460a-b787-7fac82acd65f	HxR(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
802	2025-08-04 11:07:32.405851+00	f3e3808a-a486-42a5-a6f4-ab85698f04fe	HxR(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
803	2025-08-04 11:07:37.521198+00	ed31a3f0-94cb-423b-a668-78acd8343104	Gr(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
804	2025-08-04 11:07:45.101627+00	ddd9678a-e677-426c-84df-cfdb787a7aa1	GAA2(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
805	2025-08-04 11:08:05.191622+00	c05be6a8-b2a5-45dd-990f-03105a50dc27	HxR(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
806	2025-08-04 11:08:16.3454+00	7c1053b5-7234-4359-97ba-799327ae8eac	GAA2(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
807	2025-08-04 11:08:27.408586+00	7311b703-f8e8-49c3-b268-5601465b961d	GAA2(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
808	2025-08-04 11:08:38.577611+00	431e1787-1ba1-4f94-8c95-451e8a7f8154	Gr(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
809	2025-08-04 11:08:46.940587+00	39d57c00-c13a-4c06-9dd6-4f163e74308a	Gr(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	3		17	5
810	2025-08-04 11:09:55.819737+00	5a506418-b7ec-468c-a708-746a92fa11dd	GAA2(примеси аминокислот) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
811	2025-08-04 11:10:46.29623+00	a19efd46-bef1-4ff5-beb0-1cda8bc2f192	Gr(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
812	2025-08-04 11:11:03.712643+00	236f9fd5-dec6-4395-a98c-4195510b8835	HxR(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
813	2025-08-04 11:11:31.10537+00	f54c9bf8-c3e0-4176-92aa-c139c61167d8	GAA2(основной продукт) : основной продукт - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
814	2025-08-04 11:12:32.65356+00	f6478254-e3db-48a0-a535-3b91e8eb1e34	Gr(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
815	2025-08-04 11:12:53.546528+00	68d539c7-3ce7-4876-b08c-5776e3b3a683	HxR(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
816	2025-08-04 11:13:24.299858+00	fbd0b4bb-1d67-4889-ab11-965bf33215d7	GAA2(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
817	2025-08-04 11:13:37.995682+00	e41f35ff-883b-4720-b86f-8f6da2eaf2d2	Gr(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
818	2025-08-04 11:14:03.859399+00	d594ffb9-8a9a-4538-968a-c924e507fd96	HxR(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
819	2025-08-04 11:14:19.174913+00	41e43acd-3e47-44f6-81c6-54d415800280	GAA2(примеси аминокислот) : примеси аминокислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
820	2025-08-04 13:42:01.722678+00	f8a6e6fb-eb6b-429c-a189-ffa88f0ac853	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
821	2025-08-04 13:44:00.983435+00	95036be7-2539-43b4-b53d-c37d64c38066	Закрыта период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	7	5
822	2025-08-04 13:44:10.929375+00	d2ae9c1a-0c58-4f02-a805-d921504112de	Закрыта период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
823	2025-08-04 13:44:15.824492+00	95036be7-2539-43b4-b53d-c37d64c38066	Открыта период недели: 18.08.2025-24.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
824	2025-08-04 13:47:10.517425+00	f8a6e6fb-eb6b-429c-a189-ffa88f0ac853	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	2	[]	8	5
825	2025-08-04 13:47:37.070652+00	95036be7-2539-43b4-b53d-c37d64c38066	Открыта период недели: 18.08.2025-24.08.2025	2	[]	7	5
826	2025-08-04 13:50:07.416505+00	95036be7-2539-43b4-b53d-c37d64c38066	Открыта период недели: 18.08.2025-24.08.2025	2	[]	7	5
827	2025-08-04 13:50:19.366493+00	69c5be44-0cbb-481f-85be-bdc0577f8e38	Закрыта период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	7	5
828	2025-08-04 14:36:08.654928+00	cdf23166-345a-4084-8437-92c51adbbe78	Biostimulant (Гераскина Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
829	2025-08-04 14:36:33.458331+00	a4636783-1d55-415b-bbc2-deb27cdcf0f2	Ile(BCAA) (Саврасова Екатерина) : Приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
830	2025-08-04 14:53:13.835176+00	bc0e6ea1-ecae-42ef-add7-1d1783d395ec	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	8	5
831	2025-08-04 15:36:11.233973+00	bc0e6ea1-ecae-42ef-add7-1d1783d395ec	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	3		8	5
832	2025-08-04 15:36:29.190531+00	f8a6e6fb-eb6b-429c-a189-ffa88f0ac853	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	2	[]	8	5
833	2025-08-04 15:36:34.813576+00	f8a6e6fb-eb6b-429c-a189-ffa88f0ac853	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
834	2025-08-04 15:36:44.55962+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
835	2025-08-04 15:36:49.765143+00	f8a6e6fb-eb6b-429c-a189-ffa88f0ac853	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
836	2025-08-04 15:37:53.170096+00	d2ae9c1a-0c58-4f02-a805-d921504112de	Закрыта период недели: 11.08.2025-17.08.2025	3		7	5
837	2025-08-04 15:37:56.934532+00	95036be7-2539-43b4-b53d-c37d64c38066	Открыта период недели: 18.08.2025-24.08.2025	3		7	5
838	2025-08-04 15:38:01.830747+00	69c5be44-0cbb-481f-85be-bdc0577f8e38	Закрыта период недели: 04.08.2025-10.08.2025	3		7	5
839	2025-08-04 15:40:24.80352+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
840	2025-08-04 15:43:08.42323+00	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	Arginine (Кирюхин Михаил Юрьевич) : Приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
841	2025-08-04 15:44:50.805719+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
842	2025-08-04 15:45:06.74956+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
843	2025-08-05 07:18:59.892742+00	56fc5de8-3595-488b-bdcb-65bdc6aa362f	Окно бронирования на 04.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
844	2025-08-05 07:19:07.180286+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
845	2025-08-05 07:20:12.005328+00	a32c72d5-9c3e-44a4-854f-3225965284ee	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	8	5
846	2025-08-05 07:20:45.557193+00	2660b4b3-4f08-4948-b8a6-83914f07bb51	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	1	[{"added": {}}]	8	5
847	2025-08-05 07:20:51.913496+00	a32c72d5-9c3e-44a4-854f-3225965284ee	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	3		8	5
848	2025-08-05 07:21:25.225015+00	12995cec-4c9d-4f98-81f5-794322b07b50	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
849	2025-08-05 07:22:35.392601+00	2660b4b3-4f08-4948-b8a6-83914f07bb51	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 04.08.2025-10.08.2025	3		8	5
850	2025-08-05 07:22:57.7626+00	8056e937-8277-4af6-a0ce-da662a7022b1	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
1187	2025-09-12 09:18:46.730107+00	fcceda6b-8d2f-4ff2-9755-514f6efef62a	ResearchGSH : Reaserch - Shimadzu 40	1	[{"added": {}}]	19	5
851	2025-08-05 10:19:08.195004+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталия) : Приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
852	2025-08-05 10:20:13.601764+00	8056e937-8277-4af6-a0ce-da662a7022b1	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[]	8	5
853	2025-08-05 10:20:43.496691+00	4cb36787-15c2-44fb-a37a-5c18b3755fb7	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
854	2025-08-05 10:27:30.276129+00	4cb36787-15c2-44fb-a37a-5c18b3755fb7	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	2	[]	8	5
855	2025-08-05 10:28:11.459646+00	8056e937-8277-4af6-a0ce-da662a7022b1	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
856	2025-08-05 10:31:12.597718+00	19f12d86-0a46-498b-a2e3-c4082a2dbc88	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
857	2025-08-05 10:34:40.872837+00	19f12d86-0a46-498b-a2e3-c4082a2dbc88	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
858	2025-08-05 10:34:45.358066+00	4cb36787-15c2-44fb-a37a-5c18b3755fb7	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
859	2025-08-05 10:35:02.917571+00	68f54b0e-c474-40d7-9b5d-ed78a6d0a008	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
860	2025-08-05 10:35:20.231119+00	f2a9de11-3cc3-4558-b3d7-b460b1d8e9e7	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
861	2025-08-05 10:37:25.1787+00	f2a9de11-3cc3-4558-b3d7-b460b1d8e9e7	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
862	2025-08-05 10:37:57.955084+00	4c9ed81c-a218-40fb-91b7-d4b80f908bb2	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
863	2025-08-05 10:38:49.989695+00	4c9ed81c-a218-40fb-91b7-d4b80f908bb2	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
864	2025-08-05 10:38:55.647569+00	68f54b0e-c474-40d7-9b5d-ed78a6d0a008	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
865	2025-08-05 10:39:14.718628+00	ea91d492-a7a3-4579-a7cd-d1d1c4bded1c	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
866	2025-08-05 10:39:29.431438+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	8	5
867	2025-08-05 11:15:26.250776+00	ea91d492-a7a3-4579-a7cd-d1d1c4bded1c	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
868	2025-08-05 11:16:30.583052+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 05.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[]	8	5
869	2025-08-05 11:22:07.018667+00	b6387178-b0f0-4227-afae-44d21dc68b1e	GAA2(органические кислоты) ферментация : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
870	2025-08-05 11:24:05.325977+00	2ae252e7-ff77-4445-9bba-4f12636a2234	GAA2(органические кислоты) : примеси органических кислот	1	[{"added": {}}]	16	5
871	2025-08-05 11:24:39.888992+00	8e63aaf4-36cf-468d-bd2a-57ab02c41961	GAA2(органические кислоты) : примеси органических кислот - Gr,Hx,GAA-2 (Ростова Юлия Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
872	2025-08-05 11:26:01.00992+00	71e1a127-5520-4b2e-8b0a-deacd51a8803	GAA2(органические кислоты) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
873	2025-08-05 11:26:26.851415+00	cb722bf8-c435-4c66-9944-069a7f5436a9	GAA2(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
874	2025-08-05 11:26:51.613082+00	cbce33a1-3c56-4c54-b194-315442818858	Gr(органические кислоты) : примеси органических кислот - Shimadzu 3	2	[]	19	5
875	2025-08-05 11:27:40.934138+00	f86e431a-35a5-4355-9189-d0c9777daf32	Gr(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
876	2025-08-06 11:11:34.829508+00	ffdd044d-1c42-4cb7-aed4-0bdbdab77d41	Gr(анализ сахаров) : анализ сахаров	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
877	2025-08-06 11:11:53.079574+00	fdc73d75-74c1-44e9-b276-2b748d35620b	Ser(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
878	2025-08-06 11:12:22.34741+00	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	Gln(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
879	2025-08-06 11:14:24.122511+00	f546d1c3-036a-47dd-8662-9b37a914408f	Cys(сульфоцистеин) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
880	2025-08-06 11:14:45.479975+00	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	Met (органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
881	2025-08-06 11:15:08.829362+00	eecdd0f8-7244-4bf6-8f96-65622901a51d	Arg(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
882	2025-08-06 11:15:27.972518+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1070	2025-08-29 08:10:46.879985+00	98815365-3bbe-4d9f-a26d-93034a0c11a3	Lipid fermentation(основной продукт) : основной продукт - Shimadzu GC 2014	1	[{"added": {}}]	19	5
883	2025-08-06 11:15:55.18159+00	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	Эктоин (основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
884	2025-08-06 11:16:20.322494+00	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	Fatty acid(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
885	2025-08-06 11:17:00.147745+00	e40964e1-8934-428e-a06e-18379a30ebae	Ser(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
886	2025-08-06 11:17:22.457082+00	e32c058b-38a7-4a49-a335-548da531c9b0	KSS_Ala-Gln (органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
887	2025-08-06 11:17:51.473554+00	cf00c1c2-3c4a-4783-bd78-577444bdf9c3	Gln (органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
888	2025-08-06 11:18:16.417066+00	ca0a4632-47de-4590-b84b-5835604a02c6	DAP(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
889	2025-08-06 11:18:34.70048+00	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	Эктоин (органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
890	2025-08-06 11:19:00.19705+00	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	Met(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
891	2025-08-06 11:19:21.153982+00	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	Эктоин (примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
892	2025-08-06 11:19:45.175459+00	ace768c2-60a5-40f1-b745-63829f6b8d9f	Glu(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
893	2025-08-06 11:20:23.962866+00	a426aa21-8248-4fad-8ed2-f82aa388d1b5	Asn(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
894	2025-08-06 11:20:56.099583+00	9fe01f07-a489-4eca-8639-403986129de1	KSS_Carnosine(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
895	2025-08-06 11:21:17.755707+00	9a25e1ab-4232-4bd8-ab26-f0d7e9860f3d	g-EV(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
896	2025-08-06 11:21:35.659048+00	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	a-AP(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
897	2025-08-06 11:21:55.981293+00	8cb45323-f121-47ad-969d-0ed9c2336674	HxR(анализ сахаров) : анализ сахаров	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
898	2025-08-06 11:22:29.140913+00	87e352df-7694-466a-a100-26aa80ff28e9	g-EV(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
899	2025-08-06 11:22:47.96506+00	7da0bd39-87ac-4b74-b152-236e519597e1	a-AP(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
900	2025-08-06 11:23:13.965988+00	7b74a6a1-d92b-476a-befc-0783a20e9170	Amisoft(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
901	2025-08-06 11:23:31.930762+00	73129017-ac9d-4a55-9020-7192a2b3150a	Ser(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
902	2025-08-06 11:24:24.387541+00	563ae91e-3338-45f7-aead-c5a3c7a57f63	BCAA(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
903	2025-08-06 11:24:54.227179+00	091e7bb0-f31d-4465-8e6f-130e5f83d454	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
904	2025-08-06 11:27:56.227702+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 06.08.2025 с 00:00 до 00:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438", "\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
905	2025-08-06 11:28:58.769447+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 06.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
906	2025-08-06 11:32:48.434194+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 07.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
907	2025-08-06 11:33:31.11994+00	796b2e1e-154b-4369-8946-edc63565d2ca	Открыта период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	7	5
1071	2025-08-29 08:11:04.756823+00	c04a24f8-7c9e-4e04-ba80-992cc8e10f20	Lipid fermentation (примеси аминокислот) : примеси аминокислот - Aracus	1	[{"added": {}}]	19	5
908	2025-08-06 11:35:24.395329+00	796b2e1e-154b-4369-8946-edc63565d2ca	Закрыта период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
909	2025-08-06 11:35:33.034004+00	796b2e1e-154b-4369-8946-edc63565d2ca	Закрыта период недели: 11.08.2025-17.08.2025	3		7	5
910	2025-08-06 11:36:06.516431+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 06.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
911	2025-08-06 11:37:08.160451+00	79d5b7ed-667e-4b4f-ae77-ee4ca91b3409	Закрыта период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	7	5
912	2025-08-06 11:37:15.218525+00	79d5b7ed-667e-4b4f-ae77-ee4ca91b3409	Открыта период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
913	2025-08-06 11:37:40.149686+00	b8ee3c04-ed48-4551-a7cb-c8e248740388	Окно бронирования на 06.08.2025 с 00:00 до 24:00, период недели: 11.08.2025-17.08.2025	3		8	5
914	2025-08-06 11:39:00.953084+00	63c42cfc-27f3-4172-83a3-d37b77598078	Окно бронирования на 06.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	8	5
915	2025-08-06 11:40:42.742303+00	63c42cfc-27f3-4172-83a3-d37b77598078	Окно бронирования на 06.08.2025 с 00:00 до 24:00, период недели: 18.08.2025-24.08.2025	3		8	5
916	2025-08-06 11:42:54.880026+00	d498d870-a170-4a66-b65d-4d0068fd336e	Варламова  Дарья  Олеговна - Agilent 1260	1	[{"added": {}}]	18	5
917	2025-08-06 11:47:44.462822+00	79d5b7ed-667e-4b4f-ae77-ee4ca91b3409	Открыта период недели: 11.08.2025-17.08.2025	3		7	5
918	2025-08-06 11:49:03.261681+00	5001c1ae-7be9-45fd-8e56-0a2c78d7cd3f	Открыта период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	7	5
919	2025-08-06 11:49:44.584504+00	5001c1ae-7be9-45fd-8e56-0a2c78d7cd3f	Открыта период недели: 18.08.2025-24.08.2025	3		7	5
920	2025-08-06 11:49:49.937008+00	a0694526-edb1-46ff-97dc-1279f506b94a	Закрыта период недели: 11.08.2025-17.08.2025	1	[{"added": {}}]	7	5
921	2025-08-06 11:49:53.780318+00	a0694526-edb1-46ff-97dc-1279f506b94a	Открыта период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
922	2025-08-07 12:58:19.357446+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталия) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
923	2025-08-07 13:04:18.726224+00	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	Arg(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
924	2025-08-07 13:04:48.889032+00	7129f484-2524-4bc2-a857-7a4663b6abbb	Glu (органический кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
925	2025-08-07 13:05:24.25568+00	020da433-e3a3-419c-851f-f52102a5fe00	Cys(органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
926	2025-08-07 13:05:39.56676+00	16ea24f6-2468-4895-9715-2edadc26b522	KSS_His (органический кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
927	2025-08-07 13:06:14.928816+00	00bc93e0-ef32-471d-aade-da29ce6a1660	Glu (примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
928	2025-08-07 13:07:00.074019+00	bcb16827-828e-4e71-b66e-9ed61a8351b9	GAA3(глюконат) основной продукт : основной продукт	1	[{"added": {}}]	16	5
929	2025-08-07 13:07:20.043653+00	bcb16827-828e-4e71-b66e-9ed61a8351b9	GAA3(глюконат) основной продукт : основной продукт	2	[]	16	5
930	2025-08-07 13:07:51.662022+00	56dce3bd-f938-4099-8242-08fd97768f51	GAA3(глюконат) основной продукт : основной продукт - Shimadzu 3	1	[{"added": {}}]	19	5
931	2025-08-07 13:08:25.708349+00	4cbf9bb5-b9b4-403e-b8a7-2ea41784201c	GAA3(глюконат) основной продукт : основной продукт - Shimadzu 6	1	[{"added": {}}]	19	5
932	2025-08-07 13:09:41.757257+00	9d6ec97a-a496-4175-8d31-4ce669c561e4	GAA3(глюконат) основной продукт : основной продукт - GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	1	[{"added": {}}]	17	5
933	2025-08-07 13:21:11.258428+00	ba1c5859-9d15-45e3-9ffe-34e3ce304911	Gln (органические кислоты) : примеси органических кислот - Глутамин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
934	2025-08-07 13:22:19.774811+00	4fa09ea1-0cd5-461f-a93b-ab597ee7bdba	Gln(основной продукт) : основной продукт - Глутамин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
935	2025-08-07 13:26:22.150379+00	4dfce92c-0815-44bf-b5e1-ae773624a579	Amisoft(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
936	2025-08-07 13:36:53.861733+00	1fb0d24b-975e-4366-b981-ae320ff1265a	Waters  LC-MS/MS Acquity	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
937	2025-08-07 13:37:30.922036+00	7da0bd39-87ac-4b74-b152-236e519597e1	a-AP(основной продукт) : основной продукт	2	[]	16	5
938	2025-08-07 13:38:10.144602+00	84df3dc6-49c1-4733-b757-ac6f61ef781e	a-AP(основной продукт) : основной продукт - Waters  LC-MS/MS Acquity	2	[]	19	5
939	2025-08-07 13:38:44.996134+00	b8d660a9-f7b3-44fe-bc0d-0cdb98bb368e	a-AP(основной продукт) : основной продукт - a-AP (Смирнов Сергей Васильевич) : Не приоритетный 	2	[]	17	5
940	2025-08-07 13:38:58.656215+00	e3348e14-7e1d-4f98-b0a7-42cff53daa3a	Киверо  Александр  Дмитриевич - Waters  LC-MS/MS Acquity	2	[]	18	5
1101	2025-08-29 12:45:01.096167+00	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	Plasmid production : примеси органических кислот	1	[{"added": {}}]	16	5
941	2025-08-07 13:40:06.563074+00	85950adf-ed11-4996-b5cd-44bc6c9a0e0e	11.08.2025-17.08.2025 - Киверо  Александр  Дмитриевич | Выходной | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
942	2025-08-07 13:46:46.599961+00	9990d420-939a-48ce-b6ed-b4d9ef480bc5	EA(основной продукт) : основной продукт	1	[{"added": {}}]	16	5
943	2025-08-07 13:47:14.297719+00	736cdf51-9199-4643-aed6-f49f59fe149c	EA(основной продукт) : основной продукт - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
944	2025-08-07 13:47:48.59945+00	5825d295-a9b0-4220-9dca-659c73ea9ba0	EA(основной продукт) : основной продукт - Sykam 433	1	[{"added": {}}]	19	5
945	2025-08-07 13:49:04.049134+00	49334d2e-dc24-4efc-b25a-8054959b1fcb	EA( примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
946	2025-08-07 13:49:30.474104+00	aa00c97f-2258-4e04-8b9d-ee9c2d13bae2	EA( примеси аминокислот) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
947	2025-08-07 13:49:49.293972+00	c02fdcab-8cff-423c-9c9c-699bdecb0f2d	EA( примеси аминокислот) : примеси аминокислот - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
948	2025-08-07 13:54:09.725496+00	fdec3af3-d4eb-4cb6-a339-b38c30a5f03b	Борзенко  Татьяна  Сергеевна - Dionex ICS 5000	2	[]	18	5
949	2025-08-07 13:54:50.834509+00	42e1968d-6801-45b8-beed-ab5605e91378	11.08.2025-17.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
950	2025-08-08 10:27:10.096455+00	a0694526-edb1-46ff-97dc-1279f506b94a	Закрыта период недели: 11.08.2025-17.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
951	2025-08-08 10:27:20.268578+00	111e4c5f-da17-4ed6-b373-c5993dedeb20	Открыта период недели: 18.08.2025-24.08.2025	1	[{"added": {}}]	7	5
952	2025-08-08 10:51:19.860976+00	e8885485-9ea6-46c6-9cb8-f6bb01282075	18.08.2025-24.08.2025 - Федоров  Антон  Сергеевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
953	2025-08-08 10:51:28.158485+00	da7f550b-3b38-41ad-823b-dd7c8b346692	18.08.2025-24.08.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[]	10	5
954	2025-08-08 10:51:43.130989+00	cb134728-e64f-4925-afe2-953108348e6a	18.08.2025-24.08.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
955	2025-08-08 10:51:50.640429+00	cb0af8a9-ea68-4c1e-ab7c-fc75f6c3fe6a	18.08.2025-24.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[]	10	5
956	2025-08-08 10:52:07.184788+00	90aed26a-f197-466d-9807-f684a8ac8033	18.08.2025-24.08.2025 - Сёменов  Егор  Александрович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
957	2025-08-08 10:52:34.814019+00	51e5db3b-7cfa-4d8b-9fc4-edc12f113be4	18.08.2025-24.08.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
958	2025-08-08 12:53:55.477866+00	7129f484-2524-4bc2-a857-7a4663b6abbb	GAA-3-II (органический кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
959	2025-08-08 12:54:54.062261+00	bcb16827-828e-4e71-b66e-9ed61a8351b9	GAA-3-I (O)глюконат основной продукт : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
960	2025-08-11 12:51:18.73861+00	dd05d845-ee8a-4b39-bab3-c0a9cf2ef9f3	KSS_His (органический кислоты) : примеси органических кислот - KSS (Минаева Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
961	2025-08-11 12:51:55.504794+00	16602904-8d9c-430b-9e40-408b6c7a1e6d	KSS_Ala-Gln : основной продукт - KSS (Минаева Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
962	2025-08-13 12:17:25.73949+00	4333e45c-09aa-4db5-95b7-82e3500c4376	KSS(His) : основной продукт	1	[{"added": {}}]	16	5
963	2025-08-13 12:19:15.260368+00	d06accd4-2d6d-4272-8815-a2ec02ea975c	KSS_His : основной продукт - KSS (Минаева Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
964	2025-08-13 12:23:07.237065+00	c997c665-eaf0-4e08-b35b-dd1e7bf77cba	KSS_Carnosine(основной продукт) : основной продукт - KSS (Минаева Наталия) : Не приоритетный 	1	[{"added": {}}]	17	5
965	2025-08-15 12:02:54.387977+00	4d590629-d027-4034-8863-07a0127678be	Ile(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
966	2025-08-15 12:11:27.154543+00	dd373324-fca3-45b2-8e57-9a56914f0367	Ile(AA) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Приоритетный 	1	[{"added": {}}]	17	5
967	2025-08-15 12:12:38.768522+00	9ab6a3b0-725b-4ccd-8e9d-141f4e452664	Ile(AA) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
968	2025-08-15 12:27:30.34843+00	dc3c0c80-fb97-47fe-bfd8-7c78528e6dd0	25.08.2025-31.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
969	2025-08-15 12:28:35.320028+00	7e5a38ab-8240-41c1-9c46-6706d3491dde	25.08.2025-31.08.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
970	2025-08-15 12:28:56.246139+00	f0df5086-f463-4d98-95ed-8b90ddb9d0d0	11.08.2025-17.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
971	2025-08-15 12:29:00.122648+00	e8885485-9ea6-46c6-9cb8-f6bb01282075	18.08.2025-24.08.2025 - Федоров  Антон  Сергеевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
972	2025-08-15 12:29:04.420171+00	dc3c0c80-fb97-47fe-bfd8-7c78528e6dd0	25.08.2025-31.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
973	2025-08-15 12:29:08.655767+00	da7f550b-3b38-41ad-823b-dd7c8b346692	18.08.2025-24.08.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
974	2025-08-15 12:29:12.292679+00	d6389241-1d22-4632-9da2-4b57f851fa72	25.08.2025-31.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
975	2025-08-15 12:29:19.320442+00	d02252d7-5d39-4f9d-aaaa-794efb3c3ad0	11.08.2025-17.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
976	2025-08-15 12:29:23.721914+00	cb134728-e64f-4925-afe2-953108348e6a	18.08.2025-24.08.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
977	2025-08-15 12:29:28.197916+00	cb0eec54-c522-4d70-953e-85b22ac9f48a	04.08.2025-10.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
978	2025-08-15 12:29:32.259646+00	cb0af8a9-ea68-4c1e-ab7c-fc75f6c3fe6a	18.08.2025-24.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
979	2025-08-15 12:29:36.87276+00	9b43ef95-fcfd-41e6-85b9-c6a2ba564886	04.08.2025-10.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
980	2025-08-15 12:29:41.826772+00	c7144c74-4a00-4c18-929d-2f2313cc0b54	04.08.2025-10.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
981	2025-08-15 12:29:46.794096+00	be58c5d5-4332-4f84-85be-cbf5754d2764	04.08.2025-10.08.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
982	2025-08-15 12:29:51.073283+00	90aed26a-f197-466d-9807-f684a8ac8033	18.08.2025-24.08.2025 - Сёменов  Егор  Александрович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
983	2025-08-15 12:29:55.591733+00	90332cd0-e5f3-47e3-9110-9b987c49c085	04.08.2025-10.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
984	2025-08-15 12:29:59.225614+00	8cba9800-21f9-45a7-85c4-bb33726607bb	28.07.2025-03.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
985	2025-08-15 12:30:03.23252+00	8607974d-53a9-4b68-9d20-ed55a9601d09	25.08.2025-31.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
986	2025-08-15 12:30:07.207689+00	85950adf-ed11-4996-b5cd-44bc6c9a0e0e	11.08.2025-17.08.2025 - Киверо  Александр  Дмитриевич | Выходной | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
987	2025-08-15 12:30:11.93607+00	828edf90-9408-4736-9367-eda206447c16	11.08.2025-17.08.2025 - Федоров  Антон  Сергеевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
988	2025-08-15 12:30:15.659223+00	7e5a38ab-8240-41c1-9c46-6706d3491dde	25.08.2025-31.08.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
989	2025-08-15 12:30:20.797606+00	7d1313a2-41e4-48a8-a872-20e2a76faa19	25.08.2025-31.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
990	2025-08-15 12:30:25.839304+00	6d401f73-76fb-4583-9bda-2a680700714a	04.08.2025-10.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
991	2025-08-15 12:30:31.174183+00	670b39a1-9c8a-42d7-a5cc-63a277813514	25.08.2025-31.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
992	2025-08-15 12:30:36.170142+00	5ede4e21-837e-44fd-9529-852b6891e768	11.08.2025-17.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
993	2025-08-15 12:30:40.013951+00	51e5db3b-7cfa-4d8b-9fc4-edc12f113be4	18.08.2025-24.08.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
994	2025-08-15 12:30:44.742089+00	50821da5-3007-41db-ae1d-a9d61707ccf7	25.08.2025-31.08.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
995	2025-08-15 12:30:48.701608+00	4c36dca9-98ca-4703-b576-0b82a4b60a1b	25.08.2025-31.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
996	2025-08-15 12:30:52.449496+00	42e1968d-6801-45b8-beed-ab5605e91378	11.08.2025-17.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
997	2025-08-15 12:30:56.150865+00	3dbe7c70-bc0b-4489-92da-3aec39c9b792	11.08.2025-17.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
998	2025-08-15 12:31:00.011416+00	39a5a40d-4067-45ff-b73a-a514f30aeb8a	04.08.2025-10.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
999	2025-08-15 12:31:04.112565+00	391d57db-f6d5-461a-8b52-65f5d92c0d9b	18.08.2025-24.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1000	2025-08-15 12:31:07.861815+00	2fe8855e-e324-4320-a418-654f32b7128a	11.08.2025-17.08.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
1001	2025-08-15 12:31:11.949049+00	2f5014c2-4402-4f50-84fe-b6f6faff660c	25.08.2025-31.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1002	2025-08-15 12:31:16.263861+00	2cb84b6a-ae9f-487f-ba8b-0cb9a1de10e9	11.08.2025-17.08.2025 - Сёменов  Егор  Александрович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
1003	2025-08-15 12:31:20.264803+00	2b2592a4-2052-4b51-b2d4-9bc450788fc1	04.08.2025-10.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	3		10	5
1004	2025-08-15 12:31:27.516644+00	1bd09d65-b079-412f-88b3-ec52bb593ba0	18.08.2025-24.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1005	2025-08-15 12:31:31.53158+00	0e16a088-0959-442e-9bac-8ea9e7209541	18.08.2025-24.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1006	2025-08-15 12:31:35.371416+00	04d4b86b-0de6-4f4a-a4c4-4207d9d6b8f4	04.08.2025-10.08.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1007	2025-08-15 12:31:55.601967+00	a47be37b-5512-4cb9-8796-13181dac9497	25.08.2025-31.08.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1008	2025-08-15 12:32:13.683361+00	b41bb678-f0c6-4441-a462-c674f46956b2	25.08.2025-31.08.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1009	2025-08-15 12:32:34.198596+00	5c01d5e3-1d0c-4d92-bd73-bc7895d344ba	25.08.2025-31.08.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1010	2025-08-15 12:32:45.058503+00	9c312975-64df-45bb-bf96-f49e735a0960	25.08.2025-31.08.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1011	2025-08-15 12:33:05.067405+00	a7f5656b-dff9-475e-847a-e08be1624efb	11.08.2025-17.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1012	2025-08-15 12:33:14.033617+00	607230af-85fb-4ec2-8e3f-8a41c5826f62	11.08.2025-17.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1013	2025-08-15 12:33:24.960983+00	a7f5656b-dff9-475e-847a-e08be1624efb	25.08.2025-31.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
1014	2025-08-15 12:33:34.788994+00	607230af-85fb-4ec2-8e3f-8a41c5826f62	25.08.2025-31.08.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	10	5
1015	2025-08-15 12:35:13.366732+00	78b75650-05f7-4084-97ba-ee7531fa0a15	25.08.2025-31.08.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1016	2025-08-15 12:35:46.627904+00	0dcdf461-9649-431f-92fb-479cdf6d1b64	25.08.2025-31.08.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1181	2025-09-12 09:12:57.414725+00	ac428bf5-5e4c-417e-bb25-030383d899e9	Reaserch	1	[{"added": {}}]	12	5
1017	2025-08-15 12:36:03.025872+00	78b75650-05f7-4084-97ba-ee7531fa0a15	25.08.2025-31.08.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1018	2025-08-15 12:36:28.904501+00	76beaf10-b674-4314-9aee-8704136fff31	25.08.2025-31.08.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1019	2025-08-15 12:37:39.515133+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 25.08.2025-31.08.2025	1	[{"added": {}}]	8	5
1020	2025-08-15 12:38:46.26468+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 25.08.2025-31.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
1021	2025-08-15 12:39:41.568395+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 25.08.2025-31.08.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
1022	2025-08-15 12:40:34.067368+00	111e4c5f-da17-4ed6-b373-c5993dedeb20	Закрыта период недели: 18.08.2025-24.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1023	2025-08-15 12:40:54.78943+00	d50bdadf-2e39-4b47-852d-7d2a15ec117e	Закрыта период недели: 25.08.2025-31.08.2025	1	[{"added": {}}]	7	5
1024	2025-08-15 12:41:00.431459+00	d50bdadf-2e39-4b47-852d-7d2a15ec117e	Открыта период недели: 25.08.2025-31.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1025	2025-08-15 12:42:31.331255+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041f\\u0435\\u0440\\u0438\\u043e\\u0434 \\u043d\\u0435\\u0434\\u0435\\u043b\\u0438 (\\u0441 \\u043f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u0430 \\u043f\\u043e \\u0432\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u044c\\u0435)"]}}]	8	5
1026	2025-08-15 12:44:48.278484+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 00:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
1027	2025-08-15 12:45:45.241525+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0412\\u0440\\u0435\\u043c\\u044f \\u0437\\u0430\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0431\\u0440\\u043e\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f"]}}]	8	5
1028	2025-08-15 12:48:34.172091+00	d50bdadf-2e39-4b47-852d-7d2a15ec117e	Открыта период недели: 25.08.2025-31.08.2025	2	[]	7	5
1029	2025-08-15 12:48:55.262721+00	d50bdadf-2e39-4b47-852d-7d2a15ec117e	Открыта период недели: 25.08.2025-31.08.2025	3		7	5
1030	2025-08-15 12:49:25.438894+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[]	8	5
1031	2025-08-15 12:49:57.079771+00	0819e1f8-c4c0-4e6e-bc36-eba06c66994f	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 25.08.2025-31.08.2025	1	[{"added": {}}]	8	5
1032	2025-08-15 12:52:06.526764+00	cca63e0d-6cd7-4c22-8189-7aad30964b37	GAA3 (Альтман Ирина Борисовна) : Приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
1033	2025-08-15 12:52:51.980264+00	cca63e0d-6cd7-4c22-8189-7aad30964b37	GAA3 (Альтман Ирина Борисовна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
1034	2025-08-15 12:53:31.764498+00	d92d6319-c2ab-4577-a978-21dbb6ad190e	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">01.09.2025-07.09.2025      </span><span style='color: gray;'>Пн   </span>   <span style='color: gray;'>Вт   	1	[{"added": {}}]	9	5
1035	2025-08-15 12:55:13.741067+00	42a2bdfc-1fc6-4fc0-bcc4-2af8ee220d03	01.09.2025-07.09.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1036	2025-08-15 12:56:24.944502+00	42a2bdfc-1fc6-4fc0-bcc4-2af8ee220d03	01.09.2025-07.09.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[]	10	5
1037	2025-08-15 12:56:37.623841+00	779cc487-2b5b-45ba-b818-6387d0d1a7c4	01.09.2025-07.09.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1038	2025-08-15 12:58:07.896672+00	0819e1f8-c4c0-4e6e-bc36-eba06c66994f	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 25.08.2025-31.08.2025	3		8	5
1039	2025-08-15 12:59:21.138133+00	e736a5fa-b4a2-47aa-8925-db56d80f1fff	Открыта период недели: 25.08.2025-31.08.2025	1	[{"added": {}}]	7	5
1040	2025-08-15 13:00:15.305489+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
1041	2025-08-15 13:01:46.08035+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0414\\u043b\\u044f \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u043d\\u044b\\u0445"]}}]	8	5
1042	2025-08-15 13:03:10.318189+00	686eff54-ed28-40d3-987f-9fc5a44eec23	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	3		8	5
1043	2025-08-15 13:03:24.912269+00	e736a5fa-b4a2-47aa-8925-db56d80f1fff	Открыта период недели: 25.08.2025-31.08.2025	2	[]	7	5
1100	2025-08-29 12:44:28.107026+00	da96acd3-d31d-447e-9f4e-a805a1fc478c	Plasmid production (Голубева Любовь Игоревна) : Не приоритетный 	1	[{"added": {}}]	15	5
1044	2025-08-15 13:04:13.722021+00	d92d6319-c2ab-4577-a978-21dbb6ad190e	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">01.09.2025-07.09.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433", "\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
1045	2025-08-15 13:04:39.182783+00	7f88f9ba-d9cb-490c-a68b-90077b7bbeee	Окно бронирования на 15.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	1	[{"added": {}}]	8	5
1046	2025-08-15 13:41:00.340413+00	7f88f9ba-d9cb-490c-a68b-90077b7bbeee	Окно бронирования на 18.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
1047	2025-08-19 12:18:53.694523+00	7f88f9ba-d9cb-490c-a68b-90077b7bbeee	Окно бронирования на 19.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u0414\\u0430\\u0442\\u0430 \\u043e\\u0442\\u043a\\u0440\\u044b\\u0442\\u0438\\u044f \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438"]}}]	8	5
1048	2025-08-19 12:40:48.713812+00	7f88f9ba-d9cb-490c-a68b-90077b7bbeee	Окно бронирования на 19.08.2025 с 00:00 до 24:00, период недели: 01.09.2025-07.09.2025	3		8	5
1049	2025-08-22 13:24:15.984942+00	e736a5fa-b4a2-47aa-8925-db56d80f1fff	Закрыта период недели: 25.08.2025-31.08.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1050	2025-08-22 13:24:33.965329+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Открыта период недели: 01.09.2025-07.09.2025	1	[{"added": {}}]	7	5
1051	2025-08-22 13:25:13.202791+00	42a2bdfc-1fc6-4fc0-bcc4-2af8ee220d03	01.09.2025-07.09.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1052	2025-08-22 13:25:26.411419+00	208b008e-dad5-42ed-89f0-f80116afcce2	01.09.2025-07.09.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1053	2025-08-22 13:25:37.055691+00	5099ecf0-94b0-4ec4-a72d-177b580d8ff2	01.09.2025-07.09.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1054	2025-08-22 13:25:48.514635+00	08c065b2-d1e7-4a1d-ac4e-d188e517de0f	01.09.2025-07.09.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1055	2025-08-22 13:26:01.565281+00	abf837e9-6c0d-4584-9107-2b0cfa5c6092	01.09.2025-07.09.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1056	2025-08-22 13:26:14.346958+00	2c76d3d7-220c-4776-be87-d41875dd1b20	01.09.2025-07.09.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1057	2025-08-22 13:26:26.61579+00	4e785b34-1157-4c7f-a4a6-0f27b9539464	01.09.2025-07.09.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1058	2025-08-22 13:26:36.263156+00	45d112db-0c7f-443a-8ce6-86a2558244ed	18.08.2025-24.08.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1059	2025-08-25 07:40:14.537705+00	0843f7ac-ecea-4159-b811-2b4076e91066	01.09.2025-07.09.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1060	2025-08-29 07:55:49.114548+00	6af93ff9-35d2-4b7f-b16c-338481c8827e	Cys(органические кислоты) : примеси органических кислот - Methionine/Cystine (Зиятдинов Михаил Харисович) : Не приоритетный 	1	[{"added": {}}]	17	5
1061	2025-08-29 07:56:20.261328+00	16dc611c-5452-4276-8889-22ad584de69e	Cys(примеси аминокислот) : примеси аминокислот - Methionine/Cystine (Зиятдинов Михаил Харисович) : Не приоритетный 	1	[{"added": {}}]	17	5
1062	2025-08-29 08:00:03.220504+00	53b9b602-157f-458c-913b-54f1cbdd1290	Cys(сульфоцистеин) : примеси аминокислот - Methionine/Cystine (Зиятдинов Михаил Харисович) : Не приоритетный 	1	[{"added": {}}]	17	5
1063	2025-08-29 08:01:07.031051+00	3b2f0fa5-d5ff-4b74-bc28-a0bb4103597a	Cys(сульфоцистеин) : примеси аминокислот - Aracus	2	[{"changed": {"fields": ["\\u041f\\u0440\\u0438\\u0431\\u043e\\u0440"]}}]	19	5
1064	2025-08-29 08:04:44.672145+00	879a1834-d5f5-46c5-931c-dd29c7d9e38b	Fatty acid(основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	1	[{"added": {}}]	17	5
1065	2025-08-29 08:05:25.074169+00	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	Lipid fermentation : примеси аминокислот	1	[{"added": {}}]	16	5
1066	2025-08-29 08:08:03.456455+00	f76acc0f-710d-4387-8731-dc6d8fd5782c	Lipid fermentation (примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
1067	2025-08-29 08:08:45.619348+00	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	Lipid fermentation(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430", "\\u0422\\u0438\\u043f \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1068	2025-08-29 08:09:27.624123+00	699509be-9a62-464c-b04f-d42efbd2154d	Lipid fermentation( органические кислоты) : примеси органических кислот	1	[{"added": {}}]	16	5
1069	2025-08-29 08:10:24.485623+00	d952f5ed-8100-42e3-befe-667ece5750e3	Lipid fermentation( органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
1182	2025-09-12 09:13:13.375978+00	61975783-69e9-48bd-80a3-a642a0cccf9b	Техн.работы	1	[{"added": {}}]	12	5
1072	2025-08-29 08:14:58.560713+00	b87b137b-eaf8-4080-bd8e-019b3ad8f91f	Lipid fermentation( органические кислоты) : примеси органических кислот - Fatty acid (Матросова Елена) : Не приоритетный 	1	[{"added": {}}]	17	5
1073	2025-08-29 08:15:45.73757+00	67bb91e8-fd94-400d-9ecd-14dd8d28fa86	Lipid fermentation(основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	1	[{"added": {}}]	17	5
1074	2025-08-29 08:16:02.160068+00	cadfd728-9a0b-45d3-9322-6417c1f3e09f	Lipid fermentation (примеси аминокислот) : примеси аминокислот - Fatty acid (Матросова Елена) : Не приоритетный 	1	[{"added": {}}]	17	5
1075	2025-08-29 08:16:21.142179+00	879a1834-d5f5-46c5-931c-dd29c7d9e38b	Fatty acid(основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	3		17	5
1076	2025-08-29 08:16:35.803964+00	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	Fatty acid(основной продукт) : основной продукт	3		16	5
1077	2025-08-29 08:18:04.592064+00	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	Lipid ferm (основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1078	2025-08-29 08:18:17.089065+00	699509be-9a62-464c-b04f-d42efbd2154d	Lipid ferm ( органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1079	2025-08-29 08:18:27.551763+00	f76acc0f-710d-4387-8731-dc6d8fd5782c	Lipid ferm (примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1080	2025-08-29 08:19:05.36909+00	d952f5ed-8100-42e3-befe-667ece5750e3	Lipid ferm ( органические кислоты) : примеси органических кислот - Shimadzu 6	2	[]	19	5
1081	2025-08-29 08:19:38.433953+00	98815365-3bbe-4d9f-a26d-93034a0c11a3	Lipid ferm (основной продукт) : основной продукт - Shimadzu GC 2014	2	[]	19	5
1082	2025-08-29 08:19:51.892279+00	c04a24f8-7c9e-4e04-ba80-992cc8e10f20	Lipid ferm (примеси аминокислот) : примеси аминокислот - Aracus	2	[]	19	5
1083	2025-08-29 08:20:29.024391+00	b87b137b-eaf8-4080-bd8e-019b3ad8f91f	Lipid ferm ( органические кислоты) : примеси органических кислот - Fatty acid (Матросова Елена) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1084	2025-08-29 08:20:40.906659+00	67bb91e8-fd94-400d-9ecd-14dd8d28fa86	Lipid ferm (основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	2	[]	17	5
1085	2025-08-29 08:20:50.491763+00	cadfd728-9a0b-45d3-9322-6417c1f3e09f	Lipid ferm (примеси аминокислот) : примеси аминокислот - Fatty acid (Матросова Елена) : Не приоритетный 	2	[]	17	5
1086	2025-08-29 08:23:24.286671+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[]	13	5
1087	2025-08-29 08:23:40.012101+00	8afa309b-cec8-4aaa-9031-06fe2b8267bf	Киверо  Александр  Дмитриевич	2	[]	14	5
1088	2025-08-29 08:24:01.825803+00	eb71ab5f-3f77-4ed0-abd1-b616992094a0	Fatty acid (Матросова Елена) : Не приоритетный 	2	[]	15	5
1089	2025-08-29 08:24:23.10953+00	98815365-3bbe-4d9f-a26d-93034a0c11a3	Lipid ferm (основной продукт) : основной продукт - Shimadzu GC 2014	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1090	2025-08-29 08:24:46.630183+00	67bb91e8-fd94-400d-9ecd-14dd8d28fa86	Lipid ferm (основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1091	2025-08-29 08:25:15.653175+00	702157a8-9348-41e5-bae7-961a0e3e5940	Киверо  Александр  Дмитриевич - Shimadzu GC 2014	2	[]	18	5
1092	2025-08-29 08:29:13.637103+00	abf837e9-6c0d-4584-9107-2b0cfa5c6092	01.09.2025-07.09.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u043e\\u0432 \\u043d\\u0430 \\u0441\\u043e\\u0442\\u0440\\u0443\\u0434\\u043d\\u0438\\u043a\\u0430 \\u0432 \\u0434\\u0435\\u043d\\u044c"]}}]	10	5
1093	2025-08-29 08:30:33.770868+00	d92d6319-c2ab-4577-a978-21dbb6ad190e	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">01.09.2025-07.09.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
1094	2025-08-29 08:31:10.006639+00	abf837e9-6c0d-4584-9107-2b0cfa5c6092	01.09.2025-07.09.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	3		10	5
1095	2025-08-29 08:31:22.313439+00	d7d6b855-5be5-47cd-a1c5-eb8436b630c5	01.09.2025-07.09.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1096	2025-08-29 08:33:22.463656+00	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	Lipid ferm (основной продукт) : основной продукт	2	[]	16	5
1097	2025-08-29 08:34:07.863035+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[]	13	5
1098	2025-08-29 08:38:12.816542+00	67bb91e8-fd94-400d-9ecd-14dd8d28fa86	Lipid ferm (основной продукт) : основной продукт - Fatty acid (Матросова Елена) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1099	2025-08-29 08:39:44.426008+00	ef5851f3-9428-411b-a8e0-77086b2e9d90	Shimadzu GC 2014	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1188	2025-09-12 09:19:11.443686+00	5ca41c64-e78c-455c-ad3c-2d73be0fe1c3	ResearchGSH : Reaserch - Waters  LC-MS/MS Acquity	1	[{"added": {}}]	19	5
1102	2025-08-29 12:45:56.912128+00	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	Plasmid prod (органические кислоты) : примеси органических кислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1103	2025-08-29 12:46:37.517353+00	076d6629-1673-4e85-86d4-661d47c51931	Plasmid prod (органические кислоты) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
1104	2025-08-29 12:46:52.485021+00	ab52e557-dc09-4846-a544-95187ce77822	Plasmid prod (органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
1105	2025-08-29 12:48:34.753948+00	4b51feb8-cfdb-48e8-89f4-53f4a66681eb	Plasmid prod (органические кислоты) : примеси органических кислот - Plasmid production (Голубева Любовь Игоревна) : Не приоритетный 	1	[{"added": {}}]	17	5
1106	2025-08-29 12:50:45.215826+00	da96acd3-d31d-447e-9f4e-a805a1fc478c	Plasmid production (Голубева Любовь Игоревна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
1107	2025-08-29 12:54:56.860472+00	b5752093-8aa4-4afc-bb23-2eaa75b5d973	Ser(примеси аминокислот) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
1108	2025-08-29 12:59:23.726582+00	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	Cys(тиосульфат) : примеси неорганических анионов	1	[{"added": {}}]	16	5
1109	2025-08-29 13:00:14.546117+00	db048f9e-e4e9-457b-b02c-cd1f8ffe885a	Cys(тиосульфат) : примеси неорганических анионов - Methrohm	1	[{"added": {}}]	19	5
1110	2025-08-29 13:01:01.464767+00	69e1197d-b78f-46fb-b42a-b460bc03d044	Cys(тиосульфат) : примеси неорганических анионов - Methionine/Cystine (Зиятдинов Михаил Харисович) : Не приоритетный 	1	[{"added": {}}]	17	5
1111	2025-08-29 14:04:08.818195+00	96fd9303-4fab-457f-b1b0-eba9bd1264a0	08.09.2025-14.09.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1112	2025-08-29 14:04:52.451686+00	08b32f01-e297-49f4-ac7c-480779481f41	08.09.2025-14.09.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1113	2025-08-29 14:05:26.809066+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Закрыта период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1114	2025-08-29 14:05:35.500975+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Открыта период недели: 08.09.2025-14.09.2025	1	[{"added": {}}]	7	5
1115	2025-08-29 14:06:39.850543+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Закрыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1116	2025-08-29 14:06:43.354808+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Открыта период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1117	2025-08-29 14:08:39.723376+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1118	2025-08-29 14:09:00.467566+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1119	2025-08-29 14:09:42.064682+00	816a15ab-4636-4b60-8c01-5f6a914e66f3	Arg : основной продукт - Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1120	2025-08-29 14:10:25.797903+00	0b924349-8b40-4893-826f-1f762571b345	Gln(основной продукт) : основной продукт - Shimadzu 5	2	[]	19	5
1121	2025-08-29 14:12:21.183163+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1122	2025-08-29 14:13:06.424493+00	90fb5920-1cc7-414b-b898-6986549124b2	Ser(основной продукт) : основной продукт - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	2	[]	17	5
1123	2025-08-29 14:18:14.390126+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Закрыта период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1124	2025-08-29 14:18:20.200397+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Открыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1125	2025-09-01 10:38:06.068436+00	9fea634d-d28f-4130-928f-ed64f39998c3	Сёменов  Егор  Александрович - Agilent 1260	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043b\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0442\\u043e\\u0440 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	18	5
1126	2025-09-02 10:04:43.285523+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Закрыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1127	2025-09-02 10:04:47.437321+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Открыта период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1128	2025-09-02 10:05:00.044408+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Открыта период недели: 01.09.2025-07.09.2025	2	[]	7	5
1183	2025-09-12 09:15:09.244564+00	6ef1e776-af1e-48ba-b443-d26c231b6292	Research (Киверо Александр Дмитриевич) : Не приоритетный 	1	[{"added": {}}]	15	5
1129	2025-09-02 10:13:44.47974+00	866ae771-00d0-4750-995f-5297c04efc17	15.09.2025-21.09.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1130	2025-09-02 10:14:17.081604+00	79ca35cc-6e6a-41bb-a8e9-2b71bacfc36f	Закрыта период недели: 01.09.2025-07.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1131	2025-09-02 10:14:34.261913+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Открыта период недели: 15.09.2025-21.09.2025	1	[{"added": {}}]	7	5
1132	2025-09-02 10:18:31.866516+00	fdeebf1f-f389-4fdb-ab6a-210d3518d784	15.09.2025-21.09.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1133	2025-09-02 10:20:59.297554+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Закрыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1134	2025-09-02 10:21:03.462048+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Открыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1135	2025-09-02 15:03:40.992742+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Закрыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1136	2025-09-02 15:03:46.073423+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Открыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1137	2025-09-02 15:10:00.828062+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Закрыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1138	2025-09-02 15:10:52.495053+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Открыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1139	2025-09-02 15:16:21.272372+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Закрыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1140	2025-09-02 15:16:29.458873+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Открыта период недели: 22.09.2025-28.09.2025	1	[{"added": {}}]	7	5
1141	2025-09-02 15:17:23.565109+00	a7a61096-dc07-403f-8e14-e43677acef0d	22.09.2025-28.09.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1142	2025-09-02 15:17:36.649697+00	c874821a-93f2-4635-a6bb-3fe15d46e32d	22.09.2025-28.09.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1143	2025-09-02 15:17:53.569199+00	fa6de8aa-cb6c-4a6f-b076-3b495054a95e	22.09.2025-28.09.2025 - Варламова  Дарья  Олеговна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1144	2025-09-02 15:18:07.329112+00	5431eadf-8d1b-4fc0-ac00-e43425428c2e	22.09.2025-28.09.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1145	2025-09-02 15:18:22.400515+00	52d9fdaa-5c79-4724-af9f-665d04a20a16	22.09.2025-28.09.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1146	2025-09-02 15:18:33.698876+00	b982a3c4-a931-4ea3-871e-c5d5fa88d0dc	22.09.2025-28.09.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1147	2025-09-02 15:18:47.116507+00	6e32b21e-4b8e-4ba8-b66c-7baa79e4451f	22.09.2025-28.09.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1148	2025-09-02 15:18:57.521526+00	68b00990-addc-42b5-9f4c-cf268655cbbf	22.09.2025-28.09.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1149	2025-09-02 15:19:16.411173+00	13c92d54-95cb-4271-a767-061d3455157e	22.09.2025-28.09.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1150	2025-09-02 15:20:31.095698+00	28bfdeb7-0078-425c-9ae3-ea66712dbf8a	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">22.09.2025-28.09.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	5
1151	2025-09-02 15:26:10.070357+00	8b9ad3c9-9f6e-4cb4-b510-64a36bccb592	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">29.09.2025-05.10.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	1	[{"added": {}}]	9	5
1152	2025-09-02 15:26:45.021539+00	f0394526-6379-4686-8a8f-0e4fdfb7b2ee	29.09.2025-05.10.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1153	2025-09-02 15:26:53.458742+00	1946ae10-15e4-4fe9-b69d-c229fd94fd9e	29.09.2025-05.10.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1184	2025-09-12 09:17:12.424294+00	69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0	Технические работы (Киверо Александр Дмитриевич) : Не приоритетный 	1	[{"added": {}}]	15	5
1154	2025-09-02 15:27:02.591332+00	ab5f9680-fbda-4cc6-b2a5-09c031a17da3	29.09.2025-05.10.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1155	2025-09-02 15:27:13.464144+00	b1abe730-e0eb-4a23-94b2-77ad124caef4	29.09.2025-05.10.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1156	2025-09-02 15:27:26.193417+00	4eefedd2-4d10-4d37-a62a-8e26c130f9eb	29.09.2025-05.10.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1157	2025-09-02 15:27:38.836338+00	b38eb701-2493-4afe-ac30-79c4f6294d14	29.09.2025-05.10.2025 - Санто  Леонид  Павлович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1158	2025-09-02 15:27:55.221191+00	aafcc10e-198f-4ff4-8dbc-f44f9a10f83b	29.09.2025-05.10.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1159	2025-09-02 15:28:04.559056+00	def530cc-abb8-4219-b909-c931548f703c	29.09.2025-05.10.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1160	2025-09-02 15:28:31.495426+00	7f0f481c-08d3-4e4d-8c03-7d6f547c6e63	29.09.2025-05.10.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	1	[{"added": {}}]	10	5
1161	2025-09-05 14:15:57.414811+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Закрыта период недели: 22.09.2025-28.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1162	2025-09-05 14:16:02.60405+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Открыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1163	2025-09-08 09:26:55.801372+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Закрыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1164	2025-09-08 09:27:06.099622+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Открыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1165	2025-09-08 09:41:25.436704+00	261aa121-300a-43d2-bfcf-b4d27630954c	Ser(Glukonic acid) : примеси органических кислот	1	[{"added": {}}]	16	5
1166	2025-09-08 09:42:04.110434+00	47e89628-b81d-4a9c-a7ea-575983c77587	Ser(Glukonic acid) : примеси органических кислот - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	1	[{"added": {}}]	17	5
1167	2025-09-08 09:42:27.483309+00	82b86dd0-1992-4c77-bd63-34cf5e618442	Ser(Glukonic acid) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
1168	2025-09-08 14:58:16.380241+00	3246ad00-5c0e-411f-9ef7-75c942b74946	15.09.2025-21.09.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1169	2025-09-08 14:58:55.212571+00	8dac30c6-682e-4f5c-8a27-63a6e4d6fd9c	Закрыта период недели: 08.09.2025-14.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1170	2025-09-08 14:59:04.136712+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Открыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1171	2025-09-11 10:42:28.006857+00	5bbfe0ce-1c24-443b-8849-834ef90203d3	Shimadzu 5	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1172	2025-09-11 10:46:41.604482+00	82b86dd0-1992-4c77-bd63-34cf5e618442	Ser(Glukonic acid) : примеси органических кислот - Shimadzu 6	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1173	2025-09-11 10:46:55.996397+00	4cbf9bb5-b9b4-403e-b8a7-2ea41784201c	GAA-3-I (O)глюконат основной продукт : основной продукт - Shimadzu 6	2	[]	19	5
1174	2025-09-11 12:33:05.261346+00	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	Акжигитова  Дарья  Павловна	2	[]	14	5
1175	2025-09-11 12:46:33.724477+00	3246ad00-5c0e-411f-9ef7-75c942b74946	15.09.2025-21.09.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1176	2025-09-11 12:54:01.771268+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043b\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0442\\u043e\\u0440 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	18	5
1177	2025-09-11 12:56:18.175381+00	08449636-2537-4ea7-a4e0-78b92ced819b	Акжигитова  Дарья  Павловна - Shimadzu 5	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043b\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0442\\u043e\\u0440 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	18	5
1178	2025-09-12 08:29:07.236276+00	488bedde-e9a3-4ab1-a96a-585818dde2d0	Amisoft(примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
1179	2025-09-12 08:29:57.225451+00	81fc3753-a62e-49f5-ad15-1951fbd60060	Amisoft(примеси аминокислот) : примеси аминокислот - Agilent 1260	1	[{"added": {}}]	19	5
1180	2025-09-12 08:30:28.608588+00	bcfee098-7bc9-4085-bd58-a0c8cd7f7987	Amisoft(примеси аминокислот) : примеси аминокислот - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	1	[{"added": {}}]	17	5
1189	2025-09-12 09:19:53.745726+00	71a3826c-bb94-499b-bf32-b10cd9dc54cc	ResearchGSH : Reaserch - Research (Киверо Александр Дмитриевич) : Не приоритетный 	1	[{"added": {}}]	17	5
1190	2025-09-12 09:20:19.52938+00	1c725a40-a0af-4618-b088-1f6bb594a2fe	Новикова  Анна  Евгеньевна - Shimadzu 40	1	[{"added": {}}]	18	5
1191	2025-09-12 09:20:37.982486+00	f13c28fd-3664-4830-a367-1192991999cd	Сёменов  Егор  Александрович - Shimadzu 40	1	[{"added": {}}]	18	5
1192	2025-09-12 10:04:29.551733+00	5ca41c64-e78c-455c-ad3c-2d73be0fe1c3	ResearchGSH : Reaserch - Shimadzu LC-MS 8050	2	[{"changed": {"fields": ["\\u041f\\u0440\\u0438\\u0431\\u043e\\u0440"]}}]	19	5
1193	2025-09-12 10:22:57.284838+00	71a3826c-bb94-499b-bf32-b10cd9dc54cc	ResearchGSH : Reaserch - Research (Киверо Александр Дмитриевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1194	2025-09-12 10:28:46.702938+00	d7b878e3-64f8-4627-b34c-b9acc1cae09e	TechnicalWork : Техн.работы	1	[{"added": {}}]	16	5
1195	2025-09-12 10:29:15.040186+00	38149389-b029-408f-a779-2f1fea6a7460	TechnicalWork : Техн.работы - Shimadzu GC 2014	1	[{"added": {}}]	19	5
1196	2025-09-12 10:29:42.167268+00	dada5a13-0108-428d-8b41-13f0cf4a969c	TechnicalWork : Техн.работы - Технические работы (Киверо Александр Дмитриевич) : Не приоритетный 	1	[{"added": {}}]	17	5
1197	2025-09-12 14:22:30.5145+00	ab9cb7a6-d3f5-468a-acb1-d4f4ffe47144	Закрыта период недели: 15.09.2025-21.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1198	2025-09-12 14:22:38.830163+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Открыта период недели: 22.09.2025-28.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1199	2025-09-19 14:05:13.618979+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Закрыта период недели: 22.09.2025-28.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1200	2025-09-19 14:05:30.320941+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Открыта период недели: 22.09.2025-28.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1201	2025-09-23 09:34:33.078373+00	77227e03-66c7-4acc-a3fa-d668e5b0082f	Закрыта период недели: 22.09.2025-28.09.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1202	2025-09-23 09:34:49.492914+00	aea1e297-c227-4225-be65-58c2e016c6d9	Открыта период недели: 29.09.2025-05.10.2025	1	[{"added": {}}]	7	5
1203	2025-09-23 09:36:14.285341+00	18ae7b95-f315-4c8e-a37a-0a5501040572	06.10.2025-12.10.2025 - Федорова  Елизавета  Николаевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1204	2025-09-26 16:38:00.815265+00	aea1e297-c227-4225-be65-58c2e016c6d9	Закрыта период недели: 29.09.2025-05.10.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1205	2025-09-26 16:38:15.494515+00	404336fe-f633-4f90-a1d8-a46359509a67	Открыта период недели: 06.10.2025-12.10.2025	1	[{"added": {}}]	7	5
1206	2025-09-26 16:44:32.30225+00	18ae7b95-f315-4c8e-a37a-0a5501040572	06.10.2025-12.10.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1207	2025-09-26 16:44:48.833893+00	3edbb7dd-8b7f-4e46-a284-dd918ddc4ae5	06.10.2025-12.10.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1208	2025-09-26 16:44:57.565167+00	9cc0d556-4343-4374-99be-73289e83f965	06.10.2025-12.10.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1209	2025-10-06 07:27:28.295057+00	404336fe-f633-4f90-a1d8-a46359509a67	Закрыта период недели: 06.10.2025-12.10.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1210	2025-10-06 07:27:42.440144+00	ec24e516-92eb-4581-a649-078e2de3301f	Открыта период недели: 13.10.2025-19.10.2025	1	[{"added": {}}]	7	5
1211	2025-10-06 07:28:07.809971+00	a0fc5f7d-c135-4063-b93e-d7fa9a295bef	13.10.2025-19.10.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1212	2025-10-06 07:28:22.51357+00	64ebdc07-ef15-451e-952d-57a08e881e60	13.10.2025-19.10.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1213	2025-10-06 10:08:14.955034+00	22b5208d-81f9-4722-8e21-cb42a54befe8	13.10.2025-19.10.2025 - Борзенко  Татьяна  Сергеевна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[]	10	5
1235	2025-10-17 13:24:05.78178+00	b110e071-dea3-4499-97f2-bc42268b926c	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">27.10.2025-02.11.2025      </span><span style='color: green;'>Пн   </span>   <span style='color: green;'>Вт 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	9	5
1214	2025-10-06 10:10:36.749058+00	99237cae-e1a4-445e-ba5e-a76176cc8d13	g-EV(основной продукт) : основной продукт - g-EV (Гак Евгений Родионович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1215	2025-10-06 10:11:40.052732+00	99237cae-e1a4-445e-ba5e-a76176cc8d13	g-EV(основной продукт) : основной продукт - g-EV (Гак Евгений Родионович) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1216	2025-10-07 10:48:20.71398+00	a74ea5ba-8ddf-423b-a37f-73a8d60deb9e	BCAA(g-EV) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1217	2025-10-07 10:49:29.601339+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[]	19	5
1218	2025-10-07 10:52:34.654416+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1219	2025-10-07 10:53:52.462732+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam 433	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1220	2025-10-10 12:59:15.86609+00	ec24e516-92eb-4581-a649-078e2de3301f	Закрыта период недели: 13.10.2025-19.10.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1221	2025-10-10 12:59:23.024339+00	6945203f-cd5a-451e-b768-cb4eb28883b5	Открыта период недели: 20.10.2025-26.10.2025	1	[{"added": {}}]	7	5
1222	2025-10-10 12:59:47.331811+00	cecb1dfc-a584-4631-8ca7-5b3bd472ac51	20.10.2025-26.10.2025 - Акжигитова  Дарья  Павловна | Болеет | Болеет | Болеет | Болеет | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1223	2025-10-10 13:00:00.056201+00	3db34704-b18b-4359-bb10-64927eaee7d6	20.10.2025-26.10.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1224	2025-10-17 13:21:22.218546+00	6945203f-cd5a-451e-b768-cb4eb28883b5	Закрыта период недели: 20.10.2025-26.10.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1225	2025-10-17 13:21:35.646372+00	895302a6-490e-4171-bfd4-d624f125094b	Открыта период недели: 27.10.2025-02.11.2025	1	[{"added": {}}]	7	5
1226	2025-10-17 13:22:08.916327+00	bd8aadaa-b780-400e-a1ee-50e3f1fe2a67	27.10.2025-02.11.2025 - Акжигитова  Дарья  Павловна | Болеет | Болеет | Болеет | Болеет | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1227	2025-10-17 13:22:22.074687+00	c16f6854-29f2-44c6-ab38-880a45d0a833	27.10.2025-02.11.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1228	2025-10-17 13:22:45.303693+00	76969487-1ab3-47bf-aae3-b51b19af17eb	27.10.2025-02.11.2025 - Киверо  Александр  Дмитриевич | Работает | Работает | Работает | Отпуск | Отпуск | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433", "\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1229	2025-10-17 13:22:56.913479+00	fd56ff90-3825-454b-8902-14e5d397bff4	27.10.2025-02.11.2025 - Варламова  Дарья  Олеговна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1230	2025-10-17 13:23:08.594978+00	fcb4ccc9-4d0b-4ac7-a3e6-595dc1b81388	27.10.2025-02.11.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1231	2025-10-17 13:23:24.195193+00	e06c621b-469b-4d29-bfa4-097344423544	27.10.2025-02.11.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433", "\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1232	2025-10-17 13:23:30.48743+00	34d39da1-cd64-412e-a663-0a3da87ec181	27.10.2025-02.11.2025 - Сёменов  Егор  Александрович | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1233	2025-10-17 13:23:36.500694+00	9c237591-8956-4d86-b60d-ca682524ccd6	27.10.2025-02.11.2025 - Федоров  Антон  Сергеевич | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1234	2025-10-17 13:23:41.560365+00	0cf60478-6ea3-4e68-89ff-282808e730fd	27.10.2025-02.11.2025 - Федорова  Елизавета  Николаевна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1236	2025-10-20 08:44:35.967804+00	63436250-e1b3-43fd-ae48-e4d2fe5cea33	03.11.2025-09.11.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Работает | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1237	2025-10-20 08:44:58.501838+00	63436250-e1b3-43fd-ae48-e4d2fe5cea33	03.11.2025-09.11.2025 - Акжигитова  Дарья  Павловна | Работает | Работает | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1238	2025-10-21 08:15:58.98004+00	71cecbd7-d29a-4128-9509-8e65b2d05fc7	Ser(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
1239	2025-10-21 15:00:45.815758+00	04567c72-d2d7-43fc-baa5-d22abe61e00e	Глутамин/Аспарагин (Казиева Екатерина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	5
1240	2025-10-21 15:00:57.604433+00	753cd7ca-9dcc-4b54-8d30-baedf1296e22	Asn (Родионова Мария) : Не приоритетный 	3		15	5
1241	2025-10-21 15:01:50.389467+00	474344e6-912c-4b0f-93b1-0cfd05c8045c	Asn : основной продукт - Глутамин/Аспарагин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
1242	2025-10-21 15:02:08.474305+00	1f3f2834-b7c9-4769-b7a8-c8c279aad56d	Asn(AA) : примеси аминокислот - Глутамин/Аспарагин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
1243	2025-10-21 15:02:36.053999+00	a3730243-6266-4ebd-ad68-85c18c17eae5	Asn(органические кислоты) : примеси органических кислот - Глутамин/Аспарагин (Казиева Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
1244	2025-10-21 15:03:44.739943+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn основной продукт : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1245	2025-10-21 15:04:06.111066+00	4e1fbb62-07ef-441b-a27b-1956581e9ca8	Asn(примеси аминокислот) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1246	2025-10-21 15:04:23.202312+00	571cd566-5150-4b80-9221-233cd3d39b87	Asn (основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1247	2025-10-21 15:06:31.819279+00	4fa09ea1-0cd5-461f-a93b-ab597ee7bdba	Gln(основной продукт) : основной продукт - Глутамин/Аспарагин (Казиева Екатерина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1248	2025-10-21 15:06:49.375803+00	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	Gln(основной продукт) : основной продукт	2	[]	16	5
1249	2025-10-21 15:07:34.425847+00	0b924349-8b40-4893-826f-1f762571b345	Gln(основной продукт) : основной продукт - Shimadzu 5	2	[]	19	5
1250	2025-10-21 15:07:58.058057+00	6ce21107-4e96-4198-8744-f38680e66785	Ser(основной продукт) : основной продукт - Shimadzu 5	2	[]	19	5
1251	2025-10-21 15:08:22.814096+00	90fb5920-1cc7-414b-b898-6986549124b2	Ser(основной продукт) : основной продукт - Serine (Самсонов Виктор Васильевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1252	2025-10-21 15:10:52.577558+00	93ae7c4c-e51c-417b-b362-4a023df7a2a0	Asn (основной продукт) : основной продукт - Sykam 433	3		19	5
1253	2025-10-21 15:11:13.938122+00	db23fb9e-8a5a-411e-98b0-359bdd876217	Федорова  Елизавета  Николаевна - Hitachi 8900	1	[{"added": {}}]	18	5
1254	2025-10-22 11:51:18.794466+00	0518e2ee-f352-4dcd-8b1a-bf54b6ee4e5c	Варламова  Дарья  Олеговна - Sykam 433	2	[{"changed": {"fields": ["\\u0418\\u0441\\u043f\\u043e\\u043b\\u043d\\u0438\\u0442\\u0435\\u043b\\u044c"]}}]	18	5
1255	2025-10-22 11:52:43.899448+00	a74ea5ba-8ddf-423b-a37f-73a8d60deb9e	BCAA(g-EV) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Приоритетный 	2	[]	17	5
1256	2025-10-22 11:52:51.695373+00	a74ea5ba-8ddf-423b-a37f-73a8d60deb9e	BCAA(g-EV) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Приоритетный 	2	[]	17	5
1257	2025-10-22 11:54:02.239821+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	2	[]	19	5
1258	2025-10-22 11:54:19.511752+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[]	19	5
1259	2025-10-22 11:58:29.011748+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1260	2025-10-22 11:59:34.823192+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[]	19	5
1261	2025-10-22 12:00:07.716607+00	a4636783-1d55-415b-bbc2-deb27cdcf0f2	Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0418\\u043c\\u0435\\u0435\\u0442 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442"]}}]	15	5
1262	2025-10-22 12:02:23.658697+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[]	19	5
1263	2025-10-22 12:02:47.490628+00	2ce2279d-3822-40b1-a608-4f1559c9f593	BCAA(примеси аминокислот) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	17	5
1264	2025-10-22 12:05:09.020774+00	f70dda6c-3b1c-4248-bc15-93aefba973bb	BCAA(g-EV) : примеси аминокислот	2	[]	16	5
1265	2025-10-22 12:05:14.426881+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile) : основной продукт	2	[]	16	5
1266	2025-10-22 12:05:18.077153+00	091e7bb0-f31d-4465-8e6f-130e5f83d454	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот	2	[]	16	5
1267	2025-10-22 12:05:54.812985+00	dd373324-fca3-45b2-8e57-9a56914f0367	Ile(AA) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	3		17	5
1268	2025-10-22 12:09:55.935471+00	2ce2279d-3822-40b1-a608-4f1559c9f593	BCAA(примеси аминокислот) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	17	5
1269	2025-10-22 12:11:03.31474+00	a4636783-1d55-415b-bbc2-deb27cdcf0f2	Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	15	5
1270	2025-10-22 12:11:24.308071+00	f70dda6c-3b1c-4248-bc15-93aefba973bb	BCAA(g-EV) : примеси аминокислот	2	[]	16	5
1271	2025-10-22 12:11:47.23844+00	62608399-2245-470d-a950-4eec08632518	BCAA(Ile основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1272	2025-10-22 12:12:07.186214+00	4d590629-d027-4034-8863-07a0127678be	Ile(AA) : примеси аминокислот	3		16	5
1273	2025-10-22 12:12:34.926602+00	ff514302-8ae9-4343-9bb3-53c7e1395fc6	BCAA(примеси аминокислот) : примеси аминокислот - Sykam 433	2	[]	19	5
1274	2025-10-22 12:15:08.249649+00	1de040d3-f437-4e55-a77c-c71c38fe0384	Sykam 433	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1275	2025-10-22 12:30:30.311232+00	b65afc11-acb0-40cd-8a83-bcf593f9a228	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1276	2025-10-22 12:30:44.464474+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	2	[]	19	5
1277	2025-10-22 12:46:31.282299+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	2	[]	19	5
1278	2025-10-22 12:47:01.396972+00	b65afc11-acb0-40cd-8a83-bcf593f9a228	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	17	5
1279	2025-10-22 12:48:31.478345+00	091e7bb0-f31d-4465-8e6f-130e5f83d454	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот	2	[]	16	5
1280	2025-10-22 12:48:47.534712+00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	Shimadzu 6	2	[]	13	5
1281	2025-10-22 12:49:15.006984+00	a4636783-1d55-415b-bbc2-deb27cdcf0f2	Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	15	5
1282	2025-10-22 12:49:28.825642+00	65a30651-7236-4933-a05a-e8c774663c5e	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Shimadzu 6	2	[]	19	5
1283	2025-10-22 12:49:49.899553+00	b65afc11-acb0-40cd-8a83-bcf593f9a228	BCAA(органические кислоты,2IPM,3IPM) : примеси органических кислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	17	5
1284	2025-10-22 12:50:08.004142+00	7a2e39e0-972a-4e11-aaf7-4091306b4bb4	Федорова  Елизавета  Николаевна - Shimadzu 6	2	[]	18	5
1285	2025-10-22 13:24:52.233063+00	11d35a66-b246-40f7-ba06-53580222523b	BCAA(Ile и примеси аминокислот) : примеси аминокислот	1	[{"added": {}}]	16	5
1286	2025-10-22 13:25:18.020493+00	7eb1dd81-2913-4836-806e-5437455ac243	BCAA(Ile и примеси аминокислот) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
1287	2025-10-22 13:25:44.324253+00	2bb1b322-0c61-4cbd-be32-5aa1c79d7c64	BCAA(Ile и примеси аминокислот) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	1	[{"added": {}}]	17	5
1288	2025-10-22 13:33:12.661176+00	11d35a66-b246-40f7-ba06-53580222523b	BCAA(Ile и примеси аминокислот) : примеси аминокислот	3		16	5
1289	2025-10-22 13:33:49.551336+00	ad9e717a-11c5-4304-a23b-d5499680af1b	BCAA(примеси аминокислот) : примеси аминокислот - Agilent 1100	1	[{"added": {}}]	19	5
1290	2025-10-22 13:34:11.281797+00	2ce2279d-3822-40b1-a608-4f1559c9f593	BCAA(примеси аминокислот) : примеси аминокислот - Ile(BCAA) (Саврасова Екатерина) : Не приоритетный 	2	[]	17	5
1291	2025-10-23 13:23:41.012751+00	eb71ab5f-3f77-4ed0-abd1-b616992094a0	Lipid fermentation (Матросова Елена) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442"]}}]	15	5
1292	2025-10-23 13:43:54.142218+00	c051ac7f-3de8-4be8-876f-ac50ab6b7824	a-AP (Смирнов Сергей Васильевич) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041b\\u043e\\u0433\\u0438\\u043d \\u0434\\u043b\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u0438", "\\u041f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0432\\u0445\\u043e\\u0434\\u0430"]}}]	15	5
1293	2025-10-23 13:44:19.685822+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталия) : Не приоритетный 	2	[]	15	5
1294	2025-10-23 13:45:45.759495+00	26341b8b-cb3e-430b-972c-c37f2b983743	Peptide (Гронский Сергей) : Не приоритетный 	1	[{"added": {}}]	15	5
1295	2025-10-23 13:54:29.965645+00	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	GSH (Ямпольская Татьяна Абрамовна) : Не приоритетный 	1	[{"added": {}}]	15	5
1296	2025-10-23 13:55:55.069795+00	07e8f965-88b7-45c8-8b19-80d2cb688d17	GAA-1 (Каташкина Жанна Иосифовна) : Не приоритетный 	1	[{"added": {}}]	15	5
1297	2025-10-23 13:57:47.432994+00	e8b5c31f-6da6-4385-adbb-06014c9e6e01	RNA for biopesticides (Крылов Александр) : Не приоритетный 	1	[{"added": {}}]	15	5
1298	2025-10-24 13:56:54.518483+00	63436250-e1b3-43fd-ae48-e4d2fe5cea33	03.11.2025-09.11.2025 - Акжигитова  Дарья  Павловна | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1299	2025-10-24 13:57:15.176557+00	a0caa712-1c9a-4b4b-8dd3-4d309d50319b	03.11.2025-09.11.2025 - Борзенко  Татьяна  Сергеевна | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1300	2025-10-24 13:57:31.024429+00	a0caa712-1c9a-4b4b-8dd3-4d309d50319b	03.11.2025-09.11.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433", "\\u041f\\u044f\\u0442\\u043d\\u0438\\u0446\\u0430"]}}]	10	5
1301	2025-10-24 13:57:41.836201+00	5782c9d9-4b9c-4f29-828f-ebc5e6cb58dd	03.11.2025-09.11.2025 - Варламова  Дарья  Олеговна | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1302	2025-10-24 13:57:57.026019+00	0f17ef02-06f8-4e12-8b32-19e37970f7a8	03.11.2025-09.11.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1303	2025-10-24 13:58:02.31909+00	0f17ef02-06f8-4e12-8b32-19e37970f7a8	03.11.2025-09.11.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[]	10	5
1304	2025-10-24 13:58:14.170476+00	c03d7b1b-388a-4a98-8b22-333dd48b7f99	03.11.2025-09.11.2025 - Новикова  Анна  Евгеньевна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1305	2025-10-24 13:58:27.957216+00	57842e9a-041f-4e38-bd7f-abe0603644d1	03.11.2025-09.11.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1306	2025-10-24 13:58:36.280775+00	cc6a37ae-eaad-440a-ac4e-d1814820f6e4	03.11.2025-09.11.2025 - Сёменов  Егор  Александрович | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1307	2025-10-24 13:58:46.111684+00	fc90d32f-947b-4f2b-880b-4c671c7c53fc	03.11.2025-09.11.2025 - Федоров  Антон  Сергеевич | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1308	2025-10-24 13:59:00.490383+00	3bd1b0b6-47ee-441b-a62f-a9b3d04ff9d5	03.11.2025-09.11.2025 - Федорова  Елизавета  Николаевна | Выходной | Выходной | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	10	5
1309	2025-10-24 13:59:16.81099+00	e4a724f7-1dd6-4ce8-94c1-06269515afca	<span style="font-size: 24px;line-height: 3;"><span style="font-size: 15px;line-height: 3;">03.11.2025-09.11.2025      </span><span style='color: gray;'>Пн   </span>   <span style='color: gray;'>Вт   	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a"]}}]	9	5
1310	2025-10-24 13:59:33.857511+00	895302a6-490e-4171-bfd4-d624f125094b	Закрыта период недели: 27.10.2025-02.11.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1311	2025-10-24 13:59:39.082797+00	c3dcb4fa-80c3-4f1b-a6fd-6ffa99298556	Закрыта период недели: 03.11.2025-09.11.2025	1	[{"added": {}}]	7	5
1312	2025-10-24 14:00:51.567241+00	f7a5b933-2ca1-4f5b-9357-55c34e0bd068	Открыта период недели: 03.11.2025-09.11.2025	1	[{"added": {}}]	7	5
1313	2025-10-28 08:44:08.935254+00	1a901c9f-deb2-4451-a71b-4a059e561058	Amisoft(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1314	2025-10-28 09:11:04.398007+00	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	RNA(органические кислоты) : примеси органических кислот	1	[{"added": {}}]	16	5
1315	2025-10-28 09:11:25.172871+00	a802e109-6b53-42fd-aeb9-81c5ff902b17	RNA(органические кислоты) : примеси органических кислот - Shimadzu 3	1	[{"added": {}}]	19	5
1316	2025-10-28 09:11:40.669087+00	63ade532-4c50-4d62-9441-db2b732b4083	RNA(органические кислоты) : примеси органических кислот - Shimadzu 6	1	[{"added": {}}]	19	5
1317	2025-10-28 09:12:22.007273+00	6815673c-2446-4a80-b398-c62ed68461c2	RNA(органические кислоты) : примеси органических кислот - RNA for biopesticides (Крылов Александр) : Не приоритетный 	1	[{"added": {}}]	17	5
1318	2025-10-28 14:08:29.596507+00	0b6e2138-4fc5-4404-b584-6707d4890102	Arg(основной продукт) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1319	2025-10-28 14:54:18.525619+00	4f2ab503-d684-47b9-a232-f3ac48b341c5	Amisoft(основной продукт) : основной продукт - C12 (Дорошенко Вера Георгиевна) : Не приоритетный 	2	[{"changed": {"fields": ["\\u041e\\u0433\\u0440\\u0430\\u043d\\u0438\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043f\\u043e \\u043a\\u043e\\u043b\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u043e\\u0432"]}}]	17	5
1320	2025-10-28 14:54:46.693551+00	14bb3a20-dc58-4d92-ad61-be551ccad6e4	Amisoft(основной продукт) : основной продукт - Shimadzu 30	2	[]	19	5
1321	2025-10-28 15:01:44.671498+00	14bb3a20-dc58-4d92-ad61-be551ccad6e4	Amisoft(основной продукт) : основной продукт - Shimadzu 30	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u043e\\u0431"]}}]	19	5
1322	2025-10-28 15:03:05.492836+00	4b3bb52f-df8d-421c-893e-37052e982bcb	Shimadzu 30	2	[{"changed": {"fields": ["\\u0421\\u0443\\u0442\\u043e\\u0447\\u043d\\u044b\\u0439 \\u043b\\u0438\\u043c\\u0438\\u0442 \\u043f\\u0440\\u0438\\u0431\\u043e\\u0440\\u0430"]}}]	13	5
1323	2025-10-28 15:08:55.388808+00	d36c9e4f-2406-492b-b467-de7884e9a2e6	Семёнов  Егор  Александрович	2	[{"changed": {"fields": ["\\u0424\\u0430\\u043c\\u0438\\u043b\\u0438\\u044f"]}}]	14	5
1324	2025-10-29 10:38:46.416444+00	81c6bb75-8c30-404b-904b-5d5afb2b2c47	KSS (Минаева Наталья) : Не приоритетный 	2	[{"changed": {"fields": ["\\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430"]}}]	15	5
1325	2025-10-29 10:40:15.942402+00	2f016b91-0b94-4000-bb68-b6fd5be22a0e	KSS_Ala-Gln+AA : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1326	2025-10-29 10:40:38.932883+00	9fe01f07-a489-4eca-8639-403986129de1	KSS_Carnosine(основной продукт)+AA : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1327	2025-10-29 10:41:53.373015+00	4333e45c-09aa-4db5-95b7-82e3500c4376	KSS(His+AA : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1328	2025-10-29 10:42:04.882411+00	4333e45c-09aa-4db5-95b7-82e3500c4376	KSS(His+AA) : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1329	2025-10-29 10:42:34.177453+00	6c07ef7d-b39c-4c57-8c2b-0758a52be082	KSS_His+AA : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1330	2025-10-29 10:45:24.924776+00	9fe01f07-a489-4eca-8639-403986129de1	KSS_Carnosine+AA : основной продукт	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1331	2025-10-29 10:45:53.839849+00	ddbbbef1-5970-4d30-9056-866ae656b91a	Федорова  Елизавета  Николаевна - Sykam 433	1	[{"added": {}}]	18	5
1332	2025-10-29 10:51:09.264594+00	20d1960d-7758-4ca0-9a70-50ad8d901f09	Варламова  Дарья  Олеговна - Shimadzu 6	1	[{"added": {}}]	18	5
1333	2025-10-29 10:54:31.436483+00	0f17ef02-06f8-4e12-8b32-19e37970f7a8	03.11.2025-09.11.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Работает | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430"]}}]	10	5
1334	2025-10-29 11:13:24.399707+00	0f17ef02-06f8-4e12-8b32-19e37970f7a8	03.11.2025-09.11.2025 - Киверо  Александр  Дмитриевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430"]}}]	10	5
1335	2025-10-29 13:17:59.765666+00	57842e9a-041f-4e38-bd7f-abe0603644d1	03.11.2025-09.11.2025 - Санто  Леонид  Павлович | Отпуск | Отпуск | Работает | Работает | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1336	2025-10-29 13:25:39.729214+00	a0caa712-1c9a-4b4b-8dd3-4d309d50319b	03.11.2025-09.11.2025 - Борзенко  Татьяна  Сергеевна | Отпуск | Отпуск | Работает | Работает | Отпуск | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1337	2025-10-29 13:38:05.629832+00	b6c038c1-e9f2-41b5-b946-9f7801a6ad39	10.11.2025-16.11.2025 - Акжигитова  Дарья  Павловна | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1338	2025-10-29 13:38:23.959072+00	cd7e6d33-6dfa-46cf-a4cc-468bbe695826	10.11.2025-16.11.2025 - Новикова  Анна  Евгеньевна | Работает | Работает | Выходной | Выходной | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1339	2025-10-29 13:38:57.508694+00	89e10785-2b23-4cdc-bbdb-10db3dce65fb	10.11.2025-16.11.2025 - Семёнов  Егор  Александрович | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1340	2025-10-29 13:39:15.337113+00	18a16145-4de3-46f7-b03d-de8c63f409bd	10.11.2025-16.11.2025 - Федоров  Антон  Сергеевич | Отпуск | Отпуск | Отпуск | Отпуск | Выходной | Выходной | Выходной 	2	[{"changed": {"fields": ["\\u041f\\u043e\\u043d\\u0435\\u0434\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a", "\\u0412\\u0442\\u043e\\u0440\\u043d\\u0438\\u043a", "\\u0421\\u0440\\u0435\\u0434\\u0430", "\\u0427\\u0435\\u0442\\u0432\\u0435\\u0440\\u0433"]}}]	10	5
1341	2025-10-30 11:41:49.947721+00	e932f75a-1e19-4815-8b0b-bb01c9a1b2b1	GSH,GC : основной продукт - GSH (Ямпольская Татьяна Абрамовна) : Не приоритетный 	1	[{"added": {}}]	17	5
1342	2025-10-30 11:43:21.068001+00	83635efb-56a4-4bff-a8f2-245739f40fc7	GSH,GC : основной продукт - Agilent 1260	2	[{"changed": {"fields": ["\\u041f\\u0440\\u0438\\u0431\\u043e\\u0440"]}}]	19	5
1343	2025-10-31 12:37:32.261332+00	f59ee163-b076-4776-85b3-d0ba4c768838	PFP(AA) : примеси аминокислот	1	[{"added": {}}]	16	5
1344	2025-10-31 12:38:15.98304+00	35ac0b0a-56b7-44b9-bf14-5c3e99e175f1	PFP(AA) : примеси аминокислот - Peptide (Гронский Сергей) : Не приоритетный 	1	[{"added": {}}]	17	5
1345	2025-10-31 12:38:53.50913+00	9ecc8c22-1520-4ec8-99c2-c07ae2169f1e	PFP(AA) : примеси аминокислот - Hitachi 8900	1	[{"added": {}}]	19	5
1346	2025-10-31 12:40:07.480405+00	2232369d-4410-4839-9121-bea4fe8ed9d1	PFP(AA) : примеси аминокислот - Sykam 433	1	[{"added": {}}]	19	5
1347	2025-10-31 12:45:33.334907+00	f7a5b933-2ca1-4f5b-9357-55c34e0bd068	Закрыта период недели: 03.11.2025-09.11.2025	2	[{"changed": {"fields": ["\\u041e\\u0442\\u043a\\u0440\\u044b\\u0442\\u044c \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044e"]}}]	7	5
1348	2025-10-31 12:45:43.08378+00	b52db266-73e5-4b78-ac94-34fa6ad2ab7f	Открыта период недели: 10.11.2025-16.11.2025	1	[{"added": {}}]	7	5
1349	2025-10-31 13:47:58.168299+00	1045bf64-4fb8-4c44-95c2-afe09bffa580	GAA2(цистин) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1350	2025-10-31 13:49:28.557337+00	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	Cys(цистин) : примеси аминокислот	2	[{"changed": {"fields": ["\\u041d\\u0430\\u0437\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0437\\u0430"]}}]	16	5
1351	2025-11-01 07:14:29.326264+00	98815365-3bbe-4d9f-a26d-93034a0c11a3	Lipid ferm (основной продукт) : основной продукт - Shimadzu GC 2010	2	[{"changed": {"fields": ["\\u041f\\u0440\\u0438\\u0431\\u043e\\u0440"]}}]	19	5
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	control_enter	isopenregistration
8	control_enter	openwindowforordering
9	control_enter	workingdayofweek
10	control_enter	workerweekstatus
11	basic_elements	adminstrator
12	basic_elements	analyzetype
13	basic_elements	equipment
14	basic_elements	executor
15	basic_elements	project
16	basic_elements	analyze
17	dependings	projectperanalyze
18	dependings	operatorperequipment
19	dependings	analyzeperequipment
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-05-04 13:09:22.218307+00
2	auth	0001_initial	2025-05-04 13:09:22.294852+00
3	admin	0001_initial	2025-05-04 13:09:22.317887+00
4	admin	0002_logentry_remove_auto_add	2025-05-04 13:09:22.326587+00
5	admin	0003_logentry_add_action_flag_choices	2025-05-04 13:09:22.336136+00
6	contenttypes	0002_remove_content_type_name	2025-05-04 13:09:22.355764+00
7	auth	0002_alter_permission_name_max_length	2025-05-04 13:09:22.365036+00
8	auth	0003_alter_user_email_max_length	2025-05-04 13:09:22.374598+00
9	auth	0004_alter_user_username_opts	2025-05-04 13:09:22.383618+00
10	auth	0005_alter_user_last_login_null	2025-05-04 13:09:22.392945+00
11	auth	0006_require_contenttypes_0002	2025-05-04 13:09:22.396723+00
12	auth	0007_alter_validators_add_error_messages	2025-05-04 13:09:22.405139+00
13	auth	0008_alter_user_username_max_length	2025-05-04 13:09:22.41788+00
14	auth	0009_alter_user_last_name_max_length	2025-05-04 13:09:22.428837+00
15	auth	0010_alter_group_name_max_length	2025-05-04 13:09:22.438618+00
16	auth	0011_update_proxy_permissions	2025-05-04 13:09:22.446236+00
17	auth	0012_alter_user_first_name_max_length	2025-05-04 13:09:22.454814+00
18	basic_elements	0001_initial	2025-05-04 13:09:22.503912+00
19	control_enter	0001_initial	2025-05-04 13:09:22.529558+00
20	dependings	0001_initial	2025-05-04 13:09:22.576243+00
21	sessions	0001_initial	2025-05-04 13:09:22.5918+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
it4hk3h5rc1fr5d2wpoux5h4zt4qy3cx	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uBZ6W:ioOvhYDSdOCVC0LjGJVZiLhG2qrYZSazdqfbhv7-mkU	2025-05-18 13:10:00.829549+00
xl1oyxnjwi5l68a9hzl6pn2z9dzdly93	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uBZAR:FHliexhUkEdV83AvyAS0HafIUBhKPbAMVhnDu1HFV1Q	2025-05-18 13:14:03.831569+00
oer3eoklsaendoc9pdvyyedz1fpvvrw2	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uH5B0:JqlO1KT7wIsHtTiqzgrQquK1oKXiHMe02wYTz11jQAY	2025-06-02 18:25:26.769676+00
nfm154oqvgr679pujnq1lher73ujou9g	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uN7Xb:5ghAbFyz9DTaX3HVUjx9nNPtTCkbMVs76e7vf0qYXmg	2025-06-19 10:09:43.924189+00
3m7h43sow0by2qfxd2sha9g7buz2qu9m	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uH5Ba:J7Ds3KVo1D_uxvq6uRSy13qk3-gHixdgZs59CtKp13c	2025-06-02 18:26:02.79454+00
c5w5hdydv8kgjsjtpwn2c0v3sa6h1zvn	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uH5F3:l0bh_G_qI6KPC2bLiuD_FINtmmgpeRfUhd_1T380CFI	2025-06-02 18:29:37.445585+00
qudjyfehfsd0ic2cx8v7zcwc3cl2m08w	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uHk7H:oAUKE7ZCYnrhJow9yNVfs8z9SEg8h_kLRJOc3QliELs	2025-06-04 14:08:19.026862+00
u7acvwgpzhn96fe8omepcynxjqrdc2xz	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uN7gx:iDWzuVPU86CqNMiDsxP7U7LnB8UteMt07IiRZXmAFTE	2025-06-19 10:19:23.111221+00
az1jrvhjzsf88yrz9saj8bms3vdcawy3	.eJxVjDsOwjAQBe_iGln-xllKes5geb1rHECOFCcV4u4QKQW0b2beS8S0rTVunZc4kTgLK06_G6b84LYDuqd2m2We27pMKHdFHrTL60z8vBzu30FNvX5rHi14cEwMiq3XWTmrvQmAxZMjM5QwABcsJjungZRCg0p7CAWNGrN4fwDUXTd9:1uN8cX:ULyZ_xZOVsbdTLwM2ihfRUC3y-9sciBXs1OQGqiu9kg	2025-06-19 11:18:53.738167+00
6lt0g7f0yiozmz4t87xgixrestrfsxmo	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNUI0:1olbKDpl22W1nZUcO2t0dLhK4linYJmQXgHyrYLPjkM	2025-06-20 10:27:08.775685+00
oenzjsr869bc9g18txl4scnne7d21hm2	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uI5MW:mDV5MBoxJtUT94HVsSHoaU7SN8N58twrNMbKe0_3em4	2025-06-05 12:49:28.015476+00
4a5rdxg3lzoloyzy94iw5wxd73hnjyjw	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNULh:dWWF_YtvMdF_ytvJ4Huc4FrHQFnbzh3Lcd0d4xKzpkY	2025-06-20 10:30:57.818447+00
lkliuwp05s0k8md6hpxz88hbauecxhwv	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0Yh:LMOy1p4ugkOv-iDi7uM6y8I0DgjTtb5--z4LMzuFKgQ	2025-06-13 14:18:07.063964+00
pbntt1ev0mr7mtuuvuzkmmrp12s9oqbc	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0b1:eXPhEadfP5c7V5pHevR4i4ogRi9LhTBlBsQwzQxB9ZI	2025-06-13 14:20:31.871325+00
gx9mk4dtlixf0i54afc4rdhd63ya0cgw	.eJxVjEEOwiAQRe_C2hCgCB2X7nsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwk7gIK06_W8T04LoDumO9NZlaXZc5yl2RB-1yasTP6-H-HRTs5VsP3nNKzqioPTudRksOgLKzTIwGszqTHozLOgLkQUNSSN6SMZCBRhbvD-6jOEg:1uL0ch:iguW7JlQY_QV4Zeu3IgbEEdjII620kcoSqqASw5rP7A	2025-06-13 14:22:15.52872+00
2wx3bf1xi3ha1terfdof3mfmra9mc4qi	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uL0do:9gnaqGIqf3iYjggl5e6JQ5DaYHb6YKfqHC3jprx0AXQ	2025-06-13 14:23:24.132064+00
a1tci9i8zmk8m2e7ljrj3jn6f9owiapc	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uM9rb:1NpzAWZVc-wxWgTUVJRE9PycuppovA6McvRD0jG_1js	2025-06-16 18:26:23.76349+00
s9e8jtfay0uzaze96wrni4se95roufy0	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uNUso:2X3ldefd0w-lyNCGfFvirfQ-V5UfNw59WFm7GkxLFJs	2025-06-20 11:05:10.992219+00
x87954npr9pyvvzqm4pubxbf94b2cno0	.eJxVjEEOwiAQRe_C2hDamQ7g0n3PQIAZpWpoUtqV8e7apAvd_vfef6kQt7WErckSJlZnher0u6WYH1J3wPdYb7POc12XKeld0QdtepxZnpfD_TsosZVv7Xw0QGQsgUVB28Eg8WoTseM-9eLAY5bBezDojaB0xrkEhMSZk4h6fwC63zdd:1uMoH5:0vZGxBeP5O_VFF5Ke-n-R2hZkEyBVV9zPNAXdIUVSt8	2025-06-18 13:35:23.730297+00
2239o245g152tneaejjvmxfigo3q6jg8	.eJxVjDEOwyAQBP9CHSHuDAZSpvcb0AHn4CTCkrGrKH-PLblImi12ZvctAm1rCVvjJUxZXIUWl98uUnpyPUB-UL3PMs11XaYoD0WetMlhzvy6ne7fQaFW9nV0jtUewG5M1viEgBhjBE8aFWNnNZhMNoE1mMkDGM_Yj9z1lEhl8fkC3Ik3xw:1uNV2Z:uk0oJYg2MSvx8TDvI9BoUdvgbcpnPO3GHS9HA4Co1mI	2025-06-20 11:15:15.549904+00
avovjxf5xfcrxr2rxdb04truvvgktuz1	.eJxVjDsOwjAQBe_iGlm2N_5R0nMGy-tdcAA5UpxUiLuTSCmgfTPz3iLldalp7TynkcRZgDj9bpjLk9sO6JHbfZJlass8otwVedAurxPx63K4fwc197rVCqMCY-EG6K3R3np0biDNJg8xYCAVXUCGwNrqqBkRIRazUQKmksXnC7vJN5w:1uOYKx:am4DNcRCPD4tvOvs5_4nFOLls9_nbBMdaRky7xzguKw	2025-06-23 08:58:35.652103+00
x7upvjvt4b6ije2mlyxvdboe9q5gv7ri	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uV8pX:G9TLek3-tsazohJfNKBfZFRbN-OUQlRHHFv4AdYW-WU	2025-07-11 13:09:23.70823+00
uqbr79bbla8ok0ud9grdtryvq64tmy1h	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uYpHy:Djck_Yd-1RbmZMEHOBC1yZbLJpZhn3gIyiaKnY-LQdw	2025-07-21 17:05:58.883239+00
gzt0859btpod36uh4yaocweinj7zzi8i	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1uoeCE:taBj4ozZ8MsERUSxvuFQyqLNlutKh_6a7QMOY61FH5c	2025-09-03 08:29:26.209602+00
7eshwqh16whefoo1pg5ueo7bj7qbui73	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uaD7b:rHAfeP4mSRVyFVc__nGUAxnpBHNdp10aAchOQ8FW92s	2025-07-25 12:44:59.723109+00
hq3wi7hqqbmnja184ingrb5b3gpj3es8	.eJxVjDsOwjAQBe_iGln-sLaXkj5nsHbtNQmgRMqnQtwdIqWA9s3Me6lM29rnbZE5D1VdlI3q9DsylYeMO6l3Gm-TLtO4zgPrXdEHXXQ3VXleD_fvoKel_9YGyBmPkMg2byQAIxfy4Fo1wg5Dgmp9w5igBTHoCa1E1yJbZChn9f4A9nM3sg:1uoJO0:y8wDangEB4kv5G78M6sVavj8_rrNhOf6Za7-YZNkYFc	2025-09-02 10:16:12.54664+00
zaxwgintctr3g2ts094xeu894m4uxpit	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1upAO3:sJd7Oz7pu7tD8dLTlAXOyPfWs8RM-bzpmGZQMV-m-uI	2025-09-04 18:51:47.855452+00
e4qqu825439x34sclblbxd1fzyv0v7h9	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1upTjE:nyWkNYhzSwq5yQufRSV1NvN-1pcWYD8Sy632ThvM2m4	2025-09-05 15:30:56.488637+00
f8ze3p07rwsr7bif4yovi42cl9zjy1rf	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1uxmci:8EDdOchs4MlYxfTRjec0kunpSzk_ZrvuZtDrXXuzwkI	2025-09-28 13:18:32.904248+00
pjidl7lto7ced4gpu8jvx4fheaeavv27	.eJxVjDEOwyAQBP9CHSHuDAZSpvcb0AHn4CTCkrGrKH-PLblImi12ZvctAm1rCVvjJUxZXIUWl98uUnpyPUB-UL3PMs11XaYoD0WetMlhzvy6ne7fQaFW9nV0jtUewG5M1viEgBhjBE8aFWNnNZhMNoE1mMkDGM_Yj9z1lEhl8fkC3Ik3xw:1uzAj8:Z7B5Vb84VgDzzqfI0j3twD4Wkra30F4VEk40TSaCxPo	2025-10-02 09:14:54.736594+00
bmyg6clwold2eod7oresatx2px1x18wq	.eJxVjDsOwjAQBe_iGln-sLaXkj5nsHbtNQmgRMqnQtwdIqWA9s3Me6lM29rnbZE5D1VdlI3q9DsylYeMO6l3Gm-TLtO4zgPrXdEHXXQ3VXleD_fvoKel_9YGyBmPkMg2byQAIxfy4Fo1wg5Dgmp9w5igBTHoCa1E1yJbZChn9f4A9nM3sg:1uzc2M:7r00w7a6bOUwCtYFCAKarQrX45G6VyY8Am_lehg6PVo	2025-10-03 14:24:34.007595+00
2jhf64bxl1cqq9hg7w1k7gw0mognsljh	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1v0g5k:-KcXp_U0FSbnCxKHg7jZA0Y6X5g5tff-6n2KtKNVlqo	2025-10-06 12:56:28.253047+00
zf3uqa2scr80yumr07v2p0hr6hwq5b2b	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1uwghy:l4Wyeb-mG9aAPR4HBvgc5oiScO7B-OOQMQAqH4E2HDc	2025-09-25 12:47:26.030738+00
0h9186vvs4r7mgfz9p5xtptvlahdwapg	.eJxVjEEOwiAQRe_C2hCYQgGX7j0DmYFBqoYmpV0Z765NutDtf-_9l4i4rTVunZc4ZXEWWpx-N8L04LaDfMd2m2Wa27pMJHdFHrTL65z5eTncv4OKvX5rx9o6CuRQkXK50AierU_kyDAUkwcek_FGF5sHAg02gLY6JIcARYF4fwDsazeb:1v3Mbe:SHACrzXKqeo7fBhEOYarH8ID5dJ628xNKLK5dEUvJmU	2025-10-13 22:44:30.037535+00
tbti961ab0o673zlmwlav01y50xrycr8	.eJxVjDsOwjAQBe_iGlnxauMPJT1nsLzrNQ4gR4qTCnF3iJQC2jcz76Vi2tYaty5LnLI6q6BOvxslfkjbQb6ndps1z21dJtK7og_a9XXO8rwc7t9BTb1-a-OCyAjsiXEAIyMGQTJOLACUIokBxIk3xZCx3vJABSAQETpEBPX-AOh1N9E:1vEomK:LHIGQuy8iA7wlowvyND9rfHVCemHvTYoBx6Tli8iJ7U	2025-11-14 13:02:52.524505+00
ge8tdbgetvhvbir3hlh83art96fx9n1r	.eJxVjMsOwiAQRf-FtSHDG1y69xsIM1CpGpqUdmX8dyXpQpO7uufkvFhM-1bj3ssa58zOTAh2-j0x0aO0QfI9tdvCaWnbOiMfCj9o59cll-flcP8CNfU6usZIUxQKIIcZrRLWBK1zkN67kBJq8JDdBEQKNE3gpC9Iyn1nLDj2_gDnDzc9:1vEpPg:de_N59066LYxMihGtQPEKB26Rb1oQ-b8cYfvCVfQDGo	2025-11-14 13:43:32.946261+00
a44vim2rk74lgxxy21j9p6qevlve19q6	.eJxVjDsOwjAQBe_iGlm2N_5R0nMGy-tdcAA5UpxUiLuTSCmgfTPz3iLldalp7TynkcRZgDj9bpjLk9sO6JHbfZJlass8otwVedAurxPx63K4fwc197rVCqMCY-EG6K3R3np0biDNJg8xYCAVXUCGwNrqqBkRIRazUQKmksXnC7vJN5w:1vEpi6:uOPoou_1AzobEg_7K2Bl9q3dmYZw1e45sRg7o7mEjF8	2025-11-14 14:02:34.832781+00
vgcjd45yswbmch03ppzq3s8xne7ff4r7	.eJxVjEEOwiAQRe_C2pBBCqUu3XsGMmVmpGogKe3KeHfbpAvdvvf-f6uI65Lj2niOE6mLMoM6_cIR05PLbuiB5V51qmWZp1HviT5s07dK_Loe7d9Bxpa39dkiOOtSMuIF-94BMFNAGUi6jVsyATzYzkgSIO98EGKwxtjgOQT1-QIMCDfZ:1vBYQF:PHscO5gk7WihMYUG36NooGNNgNtJBIYYPhf_snoo4JA	2025-11-05 12:58:35.298518+00
081h153aavsgdve6k47hot5nvcn9flmi	.eJxVjDsOwjAQBe_iGln-sLaXkj5nsHbtNQmgRMqnQtwdIqWA9s3Me6lM29rnbZE5D1VdlI3q9DsylYeMO6l3Gm-TLtO4zgPrXdEHXXQ3VXleD_fvoKel_9YGyBmPkMg2byQAIxfy4Fo1wg5Dgmp9w5igBTHoCa1E1yJbZChn9f4A9nM3sg:1v7CRP:WX0CiAuvX5CfiEE8JX5XMA8O4O_yewE3R5qOSYGArzE	2025-10-24 12:41:47.694023+00
3k6jq0q4ofo25b3xaasgzfsfdw4g8bgq	.eJxVjEEOwiAQAP_C2ZBuCyx49N43kAUWqZqSlPZk_Lsh6UGvM5N5C0_HXvzRePNLEldhxeWXBYpPXrtID1rvVca67tsSZE_kaZuca-LX7Wz_BoVa6VvkURk9weBydAgWxsFNJlLOIUQEQNaIKQAltpjYkB4zECvjOIAC8fkC0zk34A:1v8eLd:6Um2RptbujEMRSVi7gwTt3OjguSj1ChL2PbB68KVwps	2025-10-28 12:41:49.538752+00
jujvu2o7uoim0c5ef6sjxrchpp5dmb40	.eJxVjDsOwjAQBe_iGln-sLaXkj5nsHbtNQmgRMqnQtwdIqWA9s3Me6lM29rnbZE5D1VdlI3q9DsylYeMO6l3Gm-TLtO4zgPrXdEHXXQ3VXleD_fvoKel_9YGyBmPkMg2byQAIxfy4Fo1wg5Dgmp9w5igBTHoCa1E1yJbZChn9f4A9nM3sg:1vCH8d:bZJjbA4WWUO6xGbtTSZnmhOAN5colatkoif1vx-9qSs	2025-11-07 12:43:23.146585+00
pzdsfzlg3zaowpurvd7xat5e6z4temiu	.eJxVjMsOwiAQRf-FtSGAPF267zeQGRikaiAp7cr479qkC93ec859sQjbWuM2aIlzZhcmNTv9jgjpQW0n-Q7t1nnqbV1m5LvCDzr41DM9r4f7d1Bh1G9NaAMlk3SxzqczeQUKi6MA2tgMZFAISsV6kAZdEeisDARGCrRFZc_eHzQxOP8:1vBUny:1L4Ordtvh2Wf1W5wsUTtg8-QlauBtPZEGzrfkuyEnpE	2025-11-05 09:06:50.453684+00
f59mr1dbxpiarx22q6hbsndmyraomst0	.eJxVjDEOwyAQBP9CHSHuDAZSpvcb0AHn4CTCkrGrKH-PLblImi12ZvctAm1rCVvjJUxZXIUWl98uUnpyPUB-UL3PMs11XaYoD0WetMlhzvy6ne7fQaFW9nV0jtUewG5M1viEgBhjBE8aFWNnNZhMNoE1mMkDGM_Yj9z1lEhl8fkC3Ik3xw:1vE2Pc:JeFbiVSG_SnaKHHRw9jvr9gQk2YJUSjZy45NFlKnSYE	2025-11-12 09:24:12.693288+00
huh8bcbeq3j4eh16o1m61hhnpq025wyo	.eJxVjMsOwiAQRf-FtSGAPF267zeQGRikaiAp7cr479qkC93ec859sQjbWuM2aIlzZhcmNTv9jgjpQW0n-Q7t1nnqbV1m5LvCDzr41DM9r4f7d1Bh1G9NaAMlk3SxzqczeQUKi6MA2tgMZFAISsV6kAZdEeisDARGCrRFZc_eHzQxOP8:1vDJ72:eNHKn4jGsWgjRKfajl7Svoq5IV52IzYuhZpzT5Y7RGs	2025-11-10 09:02:00.737882+00
bs3ujobzzz1zyd4tcu1t7yhszvn760ko	.eJxVjDEOwjAMRe-SGUVxTJPCyM4ZIrt2SAGlUtNOiLtDpQ6w_vfef5lE61LS2nROo5izATSH35FpeGjdiNyp3iY7THWZR7abYnfa7HUSfV529--gUCvf2oNDB4QxEEunOWQQ546CSi4Ii8QcEDx77E9CTnOOyhB7jAgdBzTvDwmlOBg:1vB9Np:F3jVO5u_pq8mas43V67SpLnQaTsXVgeLrWOTxQn4tSU	2025-11-04 10:14:25.075637+00
h96iae13tb8dathvbnbumnk1h5pax8i9	.eJxVjDEOwyAQBP9CHSHuDAZSpvcb0AHn4CTCkrGrKH-PLblImi12ZvctAm1rCVvjJUxZXIUWl98uUnpyPUB-UL3PMs11XaYoD0WetMlhzvy6ne7fQaFW9nV0jtUewG5M1viEgBhjBE8aFWNnNZhMNoE1mMkDGM_Yj9z1lEhl8fkC3Ik3xw:1vE2w9:3Qh3-ensOCYzQqQJGgoR5V4zVCbM31--dO3n_pALkEA	2025-11-12 09:57:49.749611+00
pvwbwbjdf4ey5rvtevw6u2u1i2cuto9i	.eJxVjDsOwjAQBe_iGln-7cahpOcM1tpr4wBypDipEHeHSCmgfTPzXiLQttaw9byEicVZGCVOv2Ok9MhtJ3yndptlmtu6TFHuijxol9eZ8_NyuH8HlXr91loRWDYaMKEGsJgNjnkA55MdsGRAVn40vnjt00jMmm20DimRdqqAeH8A2LM3Sg:1vENcv:bUWHe84LcPfULlUGm0IihblLexYpdQXWX2LTX5IihEs	2025-11-13 08:03:21.388698+00
amyfc7jobb9xmu4knk6q9uowbbh4m02s	.eJxVjDEOAiEQAP9CbQiwgGBp7xsIsIucGkiOu8r4d0NyhbYzk3mzEPethn3QGhZkFyYFO_3CFPOT2jT4iO3eee5tW5fEZ8IPO_itI72uR_s3qHHU-VVFUFKSPGZnwIIWWkSHOZ0tOONkAfTaCaBSClhpFGrUhTJF65Nw7PMF-Rw4CA:1vDfQC:u7_rBuZSs4-PJsTvohmJUAz7Do2Xh-Wh4IwmhWuBVVo	2025-11-11 08:51:16.878018+00
kjda186p0oncv8xcbw3cmtxzuzddsu03	.eJxVjDsOwyAQBe9CHaEFvOBNmd5nsBZYgpMIS_5UUe4eWXKRtG9m3luNvG913FdZximrq7JeXX7HyOkp7SD5we0-6zS3bZmiPhR90lUPc5bX7XT_Diqv9aixK9j3xgc2nIJkiY4QEDxGkkIW0AVBdClHT0DWFiodMCcDXhyozxcAVTes:1vDfpe:fJd_CAPa4Tx3CtV8n3-WXbRMg4HOp7nm8rcBk-zPdsQ	2025-11-11 09:17:34.751834+00
r2pgo7baylixk2qfbmcttx78ugr4wgjz	.eJxVjEEOgjAQRe_StWmgYzvUpXvOQKYzU0FNSSisjHdXEha6_e-9_zIDbes4bFWXYRJzMa03p98xET-07ETuVG6z5bmsy5TsrtiDVtvPos_r4f4djFTHbw2sgQUoSkBEaHPC3AACKkig6LvO-3iGzKCRXaLcKAbARsCRS9iZ9wcLhjfv:1vE3vf:JxIucGImcoajob4uS3fQ3d90Lin8q0BBNZU3QupqGnE	2025-11-12 11:01:23.922781+00
d0lb04s88xqigtqz0y93yyl3y6p4xxld	.eJxVjDkOwjAUBe_iGll2vPChpOcM0V9sHEC2FCcV4u4QKQW0b2beS424LmVce5rHSdRZDV4dfkdCfqS6EbljvTXNrS7zRHpT9E67vjZJz8vu_h0U7OVbQw4ueg6UERKCEyNEfPSALouJAxq22Z88MocYkgCjtcGAo0BWCNT7AyvoOOY:1vERNM:KHTf8xZuKch4_chUh_5lUwFwB-fOL70zp3h0_GpT2Oc	2025-11-13 12:03:32.568184+00
w1ye9ajw5m21do27by9lqn4oyvzfaoyr	.eJxVjDkOwjAUBe_iGll2vPChpOcM0V9sHEC2FCcV4u4QKQW0b2beS424LmVce5rHSdRZDV4dfkdCfqS6EbljvTXNrS7zRHpT9E67vjZJz8vu_h0U7OVbQw4ueg6UERKCEyNEfPSALouJAxq22Z88MocYkgCjtcGAo0BWCNT7AyvoOOY:1vEROt:cgvSO8M2CMvU0p7HUMMiM7QZ1U3JBMwATP02TBq_vPI	2025-11-13 12:05:07.646741+00
5fxk3dyxgybn8euy7vby0ahnqn72c3zk	.eJxVjDkOwjAUBe_iGll2vPChpOcM0V9sHEC2FCcV4u4QKQW0b2beS424LmVce5rHSdRZDV4dfkdCfqS6EbljvTXNrS7zRHpT9E67vjZJz8vu_h0U7OVbQw4ueg6UERKCEyNEfPSALouJAxq22Z88MocYkgCjtcGAo0BWCNT7AyvoOOY:1vERRA:HFxPB3v1E7B-uJSmfDAJomk5pW1m_eJ2B3bFfvZAKNE	2025-11-13 12:07:28.203385+00
iak59je2riukmwl2bekhvqu87xr2ig38	.eJxVjMsOwiAQRf-FtSEM4SEu3fsNZGAGqRpISrtq_Hdt0oVu7znnbiLiutS4Dp7jROIiwInT75gwP7nthB7Y7l3m3pZ5SnJX5EGHvHXi1_Vw_w4qjvqtOZHyAcGQ1dZYhGIyQgBkBUBZFUrO-BIce3aFEJSzWmXwYDzrM4r3BxUXOCA:1vEoYt:mCsVeTzBnf6g9JoTpuwYIL4789cXbY6r9pAleRALp2g	2025-11-14 12:48:59.389384+00
itozp8otcx0vly84d7hqnqtfj83g45mx	.eJxVjEEOgjAQRe_StWmgYzvUpXvOQKYzU0FNSSisjHdXEha6_e-9_zIDbes4bFWXYRJzMa03p98xET-07ETuVG6z5bmsy5TsrtiDVtvPos_r4f4djFTHbw2sgQUoSkBEaHPC3AACKkig6LvO-3iGzKCRXaLcKAbARsCRS9iZ9wcLhjfv:1vF5GQ:zZvsN31_gNdztr2yWkNhzP5vZIV92O5IvuWqWjr3T4M	2025-11-15 06:39:02.65703+00
8vbrkkimog6ecbtlvcd7tpx4b17jddkq	.eJxVjDsOwjAQBe_iGlmsf3Eo6TmDtfaucQDZUpxUiLuTSCmgfTPz3iLgupSwdp7DROIirDj9bhHTk-sO6IH13mRqdZmnKHdFHrTLWyN-XQ_376BgL1sNGTJrtAp8ss4QOAbrtB5SzDgoGI3KdB4js9FWofeWHOIGo-eY0IvPF-JDOI8:1vFANE:2-6piSJsBxyd-xv4sbFoJsvP-EqzVtz6P2_lTyTb-J8	2025-11-15 12:06:24.068245+00
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.equipment (id, created, modified, name, status, count_samples) FROM stdin;
27dc31dd-0a11-452e-ac1e-aeb052f18226	2025-05-29 13:51:03.591829+00	2025-05-29 13:51:03.591843+00	Agilent 7100 CE	active	10
a9bce02e-43b3-44bd-b9dc-0479fe49bd09	2025-05-29 13:53:25.556093+00	2025-06-09 10:28:06.500347+00	Dionex ICS 5000	active	12
a8222354-63a4-4c12-b4ee-00ff34788fa1	2025-05-29 14:01:24.562526+00	2025-06-09 10:28:11.371412+00	Shimadzu GC 2010	active	10
612b7c5b-61b6-4795-8d07-98bc92bc4c51	2025-05-29 13:52:14.690109+00	2025-06-09 10:28:28.663067+00	Methrohm	active	8
60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	2025-05-29 14:04:05.785524+00	2025-06-09 10:28:41.72909+00	Shimadzu LC-MS 8050	active	10
54e28c12-acd4-4c69-a0a6-815a77c4e895	2025-05-29 13:48:21.787475+00	2025-06-09 10:29:50.428774+00	Hitachi 8900	active	6
322bde1c-c844-44d7-8846-a773b9f97679	2025-05-20 12:06:13.703596+00	2025-06-09 10:30:35.800365+00	Waters Alliance New	active	12
0c0b62b6-c1b4-4828-8c87-b90396e2288d	2025-05-29 13:53:45.364815+00	2025-06-09 10:31:24.535922+00	Dionex ICS 5000 2	active	12
e028e32c-581f-4b39-92ae-9a81552b7862	2025-05-29 13:41:39.412583+00	2025-06-10 18:50:23.226704+00	Waters Alliance Old	active	20
555a86cd-0550-42d7-b085-92842c89ee90	2025-05-29 13:59:29.333815+00	2025-06-10 18:51:03.520378+00	Shimadzu 4	active	20
370b51e9-685c-4a6d-bcc5-67bed5d29f48	2025-05-29 13:57:51.863351+00	2025-06-10 18:51:35.05936+00	Aracus	active	6
4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	2025-05-29 13:41:01.554771+00	2025-07-08 12:04:27.328287+00	Agilent 1260	active	12
8bfe7234-ce4a-487c-8728-82b5f1956a71	2025-05-04 13:11:58.697763+00	2025-07-08 12:05:42.939608+00	Agilent 1100	active	12
fb09a7e8-8696-45ab-abc4-baa9e1440da5	2025-05-29 13:37:29.219566+00	2025-07-31 14:06:11.143281+00	Shimadzu 3	active	12
17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	2025-05-29 14:00:14.280359+00	2025-08-04 10:47:40.951911+00	Shimadzu 7	active	12
1fb0d24b-975e-4366-b981-ae320ff1265a	2025-05-29 14:03:05.049354+00	2025-08-07 13:36:53.820483+00	Waters  LC-MS/MS Acquity	active	12
ef5851f3-9428-411b-a8e0-77086b2e9d90	2025-05-29 14:01:51.577863+00	2025-08-29 08:39:44.386452+00	Shimadzu GC 2014	active	30
5bbfe0ce-1c24-443b-8849-834ef90203d3	2025-05-29 13:59:55.45934+00	2025-09-11 10:42:27.956244+00	Shimadzu 5	active	18
62824931-02d2-45a1-9fb1-17050db2b92b	2025-09-12 09:18:16.228096+00	2025-09-12 09:18:16.228111+00	Shimadzu 40	active	12
1de040d3-f437-4e55-a77c-c71c38fe0384	2025-05-20 12:05:59.679623+00	2025-10-22 12:15:08.248754+00	Sykam 433	active	6
db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	2025-05-29 13:49:02.220003+00	2025-10-22 12:48:47.507769+00	Shimadzu 6	active	12
4b3bb52f-df8d-421c-893e-37052e982bcb	2025-05-29 14:01:02.408082+00	2025-10-28 15:03:05.492055+00	Shimadzu 30	active	24
\.


--
-- Data for Name: executor; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.executor (id, created, modified, first_name, last_name, patronymic) FROM stdin;
ad7a9a32-69c3-46c0-b5b9-80f11dc55797	2025-05-28 14:42:32.353012+00	2025-06-09 10:22:29.722011+00	Дарья	Варламова	Олеговна
86bea85e-a62d-4dc0-8c0b-30541fd7782c	2025-05-28 14:39:15.361961+00	2025-06-09 10:23:16.111645+00	Татьяна	Борзенко	Сергеевна
58c12ab6-e451-48b5-917e-26fc1855847a	2025-05-28 14:42:59.554037+00	2025-06-09 10:23:41.986051+00	Антон	Федоров	Сергеевич
1e4fa050-70ba-4031-9201-31d8cbd60b9a	2025-05-28 14:43:27.471935+00	2025-06-09 10:24:03.09071+00	Елизавета	Федорова	Николаевна
09d8307c-2256-4f71-94e1-958c21e6f1bc	2025-05-28 14:40:19.396053+00	2025-06-09 10:24:37.416453+00	Анна	Новикова	Евгеньевна
1a5902da-bf12-4f7e-b055-775956f6adda	2025-05-28 14:40:59.662473+00	2025-08-04 07:34:10.366742+00	Леонид	Санто	Павлович
8afa309b-cec8-4aaa-9031-06fe2b8267bf	2025-05-28 14:41:27.425895+00	2025-08-29 08:23:40.011295+00	Александр	Киверо	Дмитриевич
f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	2025-05-28 14:39:51.190658+00	2025-09-11 12:33:05.239968+00	Дарья	Акжигитова	Павловна
d36c9e4f-2406-492b-b467-de7884e9a2e6	2025-05-29 14:20:22.926911+00	2025-10-28 15:08:55.342519+00	Егор	Семёнов	Александрович
\.


--
-- Data for Name: feedback_task; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.feedback_task (booking_id, question_1, question_2, question_3) FROM stdin;
5	t	t	t
7	f	f	f
9	t	t	t
6	t	t	t
3	t	f	f
11	f	t	t
93	t	t	t
94	t	t	t
90	t	t	t
91	t	t	t
96	t	t	f
98	f	f	f
97	f	f	f
95	f	f	f
106	t	t	t
115	t	t	t
130	t	t	t
142	t	t	f
117	t	t	t
128	t	t	t
129	t	t	t
138	t	t	t
145	t	t	t
160	t	t	t
149	t	t	t
180	t	t	t
169	t	t	t
167	t	t	t
159	t	t	t
164	t	t	t
163	t	t	t
171	t	f	f
186	t	t	t
192	t	t	t
187	t	t	t
188	t	t	t
189	t	t	t
199	t	t	t
200	t	t	t
226	t	t	t
251	t	t	t
232	t	t	t
255	t	t	t
253	t	t	t
254	t	t	t
248	t	t	t
249	t	t	t
250	t	t	t
281	t	t	t
282	t	t	t
283	t	t	t
285	t	t	t
286	t	t	t
300	t	t	t
289	t	t	t
295	t	t	t
296	t	t	t
299	t	t	t
284	t	t	t
298	t	t	t
261	t	t	t
359	t	t	t
350	t	t	t
343	t	t	t
360	t	t	t
351	t	t	t
348	t	t	t
349	t	t	t
355	t	t	t
352	t	t	t
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.project (id, created, modified, project_nick, project_name, is_priority, responsible_person, project_password) FROM stdin;
16bd440d-2799-48da-b879-b1c7975e0ab6	2025-07-08 09:24:47.720625+00	2025-07-08 09:24:47.720639+00	DoroshenkoV1	C12	f	Дорошенко Вера Георгиевна	DoroshenkoV1
806f8ddc-ab22-4e19-9513-953dab466dde	2025-07-08 09:39:14.260478+00	2025-07-08 09:39:14.260494+00	GakEvgeniy1	g-EV	f	Гак Евгений Родионович	GakEvgeniy1
ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-07-10 17:45:29.5397+00	2025-07-10 17:45:29.539717+00	SamsonovViktor1	Serine	f	Самсонов Виктор Васильевич	SamsonovViktor1
17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-04 13:12:51.611859+00	2025-07-10 18:09:37.532151+00	ZiyatdinovM1	Methionine/Cystine	f	Зиятдинов Михаил Харисович	ZiyatdinovM1
a6902413-ff8a-46a6-9b42-9db06927cc30	2025-07-08 09:20:20.994965+00	2025-08-04 10:29:09.184343+00	RostovaJ1	Gr,Hx,GAA-2	f	Ростова Юлия Георгиевна	RostovaJ1
cdf23166-345a-4084-8437-92c51adbbe78	2025-06-05 10:18:06.143127+00	2025-08-04 14:36:08.653452+00	GeraskinaN1	Biostimulant	f	Гераскина Наталия	GeraskinaN1
1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-05-21 14:46:50.712272+00	2025-08-04 15:43:08.422314+00	KiryukhinM1	Arginine	t	Кирюхин Михаил Юрьевич	KiryukhinM1
cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-07-10 18:34:09.119988+00	2025-08-15 12:52:51.979588+00	AltmanIrina1	GAA3	f	Альтман Ирина Борисовна	AltmanIrina1
da96acd3-d31d-447e-9f4e-a805a1fc478c	2025-08-29 12:44:27.955603+00	2025-08-29 12:50:45.214899+00	GolubevaL1	Plasmid production	f	Голубева Любовь Игоревна	GolubevaL1
6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-12 09:15:09.051641+00	2025-09-12 09:15:09.051654+00	Research1	Research	f	Киверо Александр Дмитриевич	Research1
69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0	2025-09-12 09:17:12.275831+00	2025-09-12 09:17:12.275845+00	TechnicalWork1	Технические работы	f	Киверо Александр Дмитриевич	TechnicalWork1
04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-07-10 17:48:57.125723+00	2025-10-21 15:00:45.801213+00	KazievaE1	Глутамин/Аспарагин	f	Казиева Екатерина	KazievaE1
a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-07-31 15:27:30.620046+00	2025-10-22 12:49:15.006296+00	SavrasovaE1	Ile(BCAA)	f	Саврасова Екатерина	SavrasovaE1
eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-07-10 18:12:40.734795+00	2025-10-23 13:23:41.011509+00	MatrosovaE1	Lipid fermentation	f	Матросова Елена	MatrosovaE1
c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-07-08 11:00:43.017681+00	2025-10-23 13:43:54.141448+00	SmirnovS1	a-AP	f	Смирнов Сергей Васильевич	SmirnovS1
26341b8b-cb3e-430b-972c-c37f2b983743	2025-10-23 13:45:45.592668+00	2025-10-23 13:45:45.592683+00	GronskyS1	Peptide	f	Гронский Сергей	GronskyS1
1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	2025-10-23 13:54:29.818283+00	2025-10-23 13:54:29.818298+00	YampolskayaT1	GSH	f	Ямпольская Татьяна Абрамовна	YampolskayaT1
07e8f965-88b7-45c8-8b19-80d2cb688d17	2025-10-23 13:55:54.921114+00	2025-10-23 13:55:54.921128+00	KatashkinaJ1	GAA-1	f	Каташкина Жанна Иосифовна	KatashkinaJ1
e8b5c31f-6da6-4385-adbb-06014c9e6e01	2025-10-23 13:57:47.285856+00	2025-10-23 13:57:47.28587+00	KrylovA1	RNA for biopesticides	f	Крылов Александр	KrylovA1
81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-07-10 18:15:33.825647+00	2025-10-29 10:38:46.415776+00	MinaevaN1	KSS	f	Минаева Наталья	MinaevaN1
\.


--
-- Data for Name: projects_booking; Type: TABLE DATA; Schema: public; Owner: Admin_agri
--

COPY public.projects_booking (id, project_id, date_booking, analyse_id, equipment_id, executor_id, count_analyses, status, is_delete, comment) FROM stdin;
4	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	5	На рассмотрении	t	
1	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-19	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	25	Принято	t	Test
18	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	2	На рассмотрении	t	
7	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	
8	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-22	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	На рассмотрении	t	
17	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	10	Принято	t	
3	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-13	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	комменат
6	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	10	Выполнено	t	
9	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-21	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	10	Выполнено	t	Изменено кол-во
5	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-20	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	20	Выполнено	t	
12	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-29	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	5	На рассмотрении	t	
21	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
11	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	3	Выполнено	t	Изменено кол-во образцов
24	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-12	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
20	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
25	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
29	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-10	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
28	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-09	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
27	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-11	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	86bea85e-a62d-4dc0-8c0b-30541fd7782c	2	На рассмотрении	t	
26	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-10	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	t	
22	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-11	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
32	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-10	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
23	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-12	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	8	На рассмотрении	t	
19	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-10	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
33	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-09	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
31	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
30	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-09	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
34	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-16	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	10	На рассмотрении	t	
35	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-16	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	10	На рассмотрении	t	
36	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-17	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	2	На рассмотрении	t	
37	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-17	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	10	На рассмотрении	t	
38	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-17	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	2	На рассмотрении	t	
39	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-18	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	2	На рассмотрении	t	
40	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-17	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	8	На рассмотрении	t	
41	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-19	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	4	На рассмотрении	t	
42	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
43	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-16	601b7b77-ab12-477c-918e-ca3910a3bb96	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	8	На рассмотрении	t	
47	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
45	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-17	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
48	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
49	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
50	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-17	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
51	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-16	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
52	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-17	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
53	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-18	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
54	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
55	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
56	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
57	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
58	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
59	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
60	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
16	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-27	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Оценить	t	
15	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-26	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Оценить	t	
10	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-26	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	12	Оценить	t	
14	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-29	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	12	На рассмотрении	t	
13	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-28	88bbf7c5-ff0e-49d6-b8de-3a5d7921bd2f	1de040d3-f437-4e55-a77c-c71c38fe0384	b1d920a8-1381-4857-abd7-48ccdb7c16f0	6	Отклонено	t	
61	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
62	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-19	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
66	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
65	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
44	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-16	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
63	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
46	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
64	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
68	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
70	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
67	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
69	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-19	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
74	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-19	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
75	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-16	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
76	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-17	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
77	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-18	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
78	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-19	c0ca9226-15a8-4fa0-adc6-0aca3f6d5627	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
81	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-01	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	t	
82	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-01	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Принято	t	Пробы должны быть готовы к 9 утра
2	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-05-06	dd7560f9-712c-405d-9c82-190ff14317d2	8bfe7234-ce4a-487c-8728-82b5f1956a71	3b62ef9e-48c6-4129-b130-47b56bc69974	25	На рассмотрении	t	
72	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-17	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	t	
71	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-16	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	t	
79	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-06-16	f3f7fdcc-ca70-4429-8e87-69ce7118b14e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	t	
73	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-18	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	t	
80	cdf23166-345a-4084-8437-92c51adbbe78	2025-06-30	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	t	Пробы должны быть к 12.00
83	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-30	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	t	
84	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-06-30	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
86	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-15	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	6	Оценить	f	
98	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-17	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Выполнено	t	
100	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
92	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-07-15	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	8	Оценить	f	
105	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-04	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
104	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-08-04	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
93	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-07	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Выполнено	f	
95	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-17	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Выполнено	t	
90	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-07-14	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Выполнено	f	
91	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-07-14	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Выполнено	f	
94	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-10	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Выполнено	f	
85	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-07-14	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	18	Оценить	f	
87	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-07-14	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	10	Оценить	f	
102	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-04	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
88	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-07-14	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Оценить	f	
89	806f8ddc-ab22-4e19-9513-953dab466dde	2025-07-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Оценить	f	
103	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-05	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
97	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-14	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Выполнено	f	
99	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-14	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	2	На рассмотрении	f	
101	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-07-15	7b74a6a1-d92b-476a-befc-0783a20e9170	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	f	
96	cdf23166-345a-4084-8437-92c51adbbe78	2025-07-16	bdf21f2f-1dff-4a6c-a620-e3cab3f0b98c	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Выполнено	t	
106	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-04	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Выполнено	f	
113	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-07	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	5	Оценить	f	
108	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-07	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Оценить	f	
115	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-04	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
112	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-06	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
114	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-06	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
111	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-06	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
110	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-05	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
116	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-05	a426aa21-8248-4fad-8ed2-f82aa388d1b5	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
126	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-07	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
118	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-05	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
122	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
151	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-08-11	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
117	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-05	1d7b838c-9f35-43e6-9cde-d63c11d9097f	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Выполнено	f	
143	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-13	ca0a4632-47de-4590-b84b-5835604a02c6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Принято	t	
125	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-05	f70dda6c-3b1c-4248-bc15-93aefba973bb	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	Оценить	f	
144	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-13	c42bbfae-2f67-4f80-b3f0-119a0b2aa8cc	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Принято	t	
128	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-06	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
132	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-11	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	t	
133	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-11	00bc93e0-ef32-471d-aade-da29ce6a1660	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Принято	t	
153	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-12	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	12	На рассмотрении	f	
131	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-05	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	3	Оценить	f	
124	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-08-04	e40964e1-8934-428e-a06e-18379a30ebae	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	Оценить	f	
121	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-04	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
120	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-08-04	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Оценить	f	
136	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-12	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	На рассмотрении	t	
154	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-13	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	12	На рассмотрении	f	
134	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-12	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	t	
155	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-14	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	12	На рассмотрении	f	
156	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-13	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	f	
157	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	f	
158	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-08-14	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	4	На рассмотрении	f	
141	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-13	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	t	
130	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-04	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
109	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-05	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
107	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-08-05	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Оценить	f	
137	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-11	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Принято	t	Ирина Борисовна добрый день ,большое спасибо за помощь с программой
161	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-18	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	На рассмотрении	t	
146	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-14	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	Наташа привет, добавила к исполнителям на этот анализ Дашу, если хочешь то измени, но этот анализ придется удалить и сделать новую запись
139	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-12	571c313e-8ec3-4777-bac7-40855117d510	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	t	
135	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-11	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	t	
168	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-19	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
123	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-08-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
147	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-13	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	7	Принято	t	
142	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-06	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	Не больше 12 проб
127	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-07	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
119	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-07	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
145	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-11	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
148	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-13	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
138	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-11	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	12	Выполнено	f	Анализ будет выполнять Санто Леонид
162	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-18	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
165	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-18	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
129	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	8	Выполнено	f	
150	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-08-11	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
140	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-08-19	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	t	
166	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-18	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
149	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-13	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	7	Выполнено	f	
170	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-08-18	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
152	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-08-12	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	09d8307c-2256-4f71-94e1-958c21e6f1bc	6	Оценить	f	
174	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-19	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
175	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-19	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	t	
172	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-18	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
160	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-12	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
169	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-19	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Выполнено	f	
167	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-19	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Выполнено	f	
184	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-28	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	f	
159	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-14	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
164	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-20	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
182	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-27	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
178	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-18	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
179	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-18	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
176	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-18	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
190	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-28	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
173	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-19	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
177	806f8ddc-ab22-4e19-9513-953dab466dde	2025-08-19	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	10	Оценить	f	
181	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-08-19	4d590629-d027-4034-8863-07a0127678be	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
191	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-26	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
180	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-20	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	8	Выполнено	f	
194	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-25	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
195	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-08-26	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
209	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-02	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	8	На рассмотрении	f	
210	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-03	e5ee5b58-9179-459c-a9b2-b019cc3d11f8	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	8	На рассмотрении	f	
211	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	7	На рассмотрении	t	
163	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-21	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
171	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-08-18	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Выполнено	f	
193	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-08-26	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
215	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-03	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	7	На рассмотрении	t	
185	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-27	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	f	
214	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-04	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	8	На рассмотрении	t	
183	cdf23166-345a-4084-8437-92c51adbbe78	2025-08-28	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
186	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-25	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
192	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-26	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	8	Выполнено	f	
187	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-26	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	10	Выполнено	f	
188	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-27	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
189	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-08-28	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
217	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-04	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	15	На рассмотрении	t	
216	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-03	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	15	Оценить	f	
200	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-04	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
202	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-09-03	4d590629-d027-4034-8863-07a0127678be	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
218	da96acd3-d31d-447e-9f4e-a805a1fc478c	2025-09-03	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
221	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-03	e40964e1-8934-428e-a06e-18379a30ebae	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	Оценить	f	
224	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-09-04	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Оценить	f	
212	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-04	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
213	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-04	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
235	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-18	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
219	da96acd3-d31d-447e-9f4e-a805a1fc478c	2025-09-04	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	4	Оценить	f	
199	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-03	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
232	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-15	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
229	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-09-15	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	На рассмотрении	t	
230	cdf23166-345a-4084-8437-92c51adbbe78	2025-09-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
225	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-09-08	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
228	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-09-15	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
201	cdf23166-345a-4084-8437-92c51adbbe78	2025-09-01	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
196	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-09-01	7129f484-2524-4bc2-a857-7a4663b6abbb	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
197	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-09-01	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
205	806f8ddc-ab22-4e19-9513-953dab466dde	2025-09-01	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	9	Оценить	f	
203	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-09-01	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
204	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-09-01	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
207	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-09-01	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
233	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-09-16	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
231	806f8ddc-ab22-4e19-9513-953dab466dde	2025-09-15	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Отклонено	t	Перенесите анализ на вторник
226	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-10	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
227	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-09-15	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
234	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-09-15	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
237	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-17	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
247	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-25	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	t	
241	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-09-22	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
236	cdf23166-345a-4084-8437-92c51adbbe78	2025-09-18	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
242	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-09-22	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	12	Оценить	f	
238	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-09-22	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
246	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-09-22	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
244	806f8ddc-ab22-4e19-9513-953dab466dde	2025-09-25	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	Оценить	f	
243	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-25	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Оценить	f	
198	cdf23166-345a-4084-8437-92c51adbbe78	2025-09-02	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	f	
223	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-02	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	15	Оценить	f	
206	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-09-02	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
208	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-09-02	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
222	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-09-02	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
220	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-02	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	Оценить	f	
239	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-22	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
245	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-24	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
252	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-16	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
272	6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-15	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	На рассмотрении	t	
253	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-16	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
256	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-09-08	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
257	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-08	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	8	Оценить	f	
258	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-09-08	5902477d-a765-4934-a832-4fb9a01cf704	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
259	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-09-08	49334d2e-dc24-4efc-b25a-8054959b1fcb	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
260	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-08	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
264	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-09-09	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
265	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-09	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
266	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-09-09	7da0bd39-87ac-4b74-b152-236e519597e1	1fb0d24b-975e-4366-b981-ae320ff1265a	8afa309b-cec8-4aaa-9031-06fe2b8267bf	12	Оценить	f	
262	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-10	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
263	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-10	261aa121-300a-43d2-bfcf-b4d27630954c	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
248	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-22	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
251	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-15	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
255	cdf23166-345a-4084-8437-92c51adbbe78	2025-09-08	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
288	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
287	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
277	69b4f834-0a0f-4f16-bd9a-9a8a09e8e8d0	2025-09-15	d7b878e3-64f8-4627-b34c-b9acc1cae09e	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	Оценить	f	
270	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-09-16	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
278	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-16	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	Оценить	f	
269	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-09-15	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
267	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-09-15	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
273	6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-15	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	Оценить	f	
268	806f8ddc-ab22-4e19-9513-953dab466dde	2025-09-16	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
274	6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-16	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	Оценить	f	
271	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-09-17	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
279	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-17	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	Оценить	f	
275	6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-17	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	Оценить	f	
280	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-09-18	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	Оценить	f	
276	6ef1e776-af1e-48ba-b443-d26c231b6292	2025-09-18	f2ad7950-00fc-457f-8d6b-aaced7e9e80e	60d4a3a1-a8d2-4d5e-a0b3-2b442956a33b	8afa309b-cec8-4aaa-9031-06fe2b8267bf	1	Оценить	f	
240	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-09-22	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Оценить	f	
290	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-07	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
292	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-09	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	t	
293	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
254	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-17	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
249	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-23	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
250	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-24	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
281	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-24	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
291	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-08	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	t	
294	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	t	
297	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	t	
286	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-09-30	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Выполнено	f	
298	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-07	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
300	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-06	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
282	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-09-30	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
261	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-09-09	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
296	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-08	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
284	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-01	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
299	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-08	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
285	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-09-29	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Выполнено	f	
295	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-07	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
302	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-10-14	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Принято	t	
301	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-10-13	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Принято	t	
283	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-01	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
315	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-14	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	f	
316	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-15	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	f	
321	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	t	
326	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-15	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
327	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-15	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	f	
333	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-23	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
334	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-20	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	f	
335	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-22	b6387178-b0f0-4227-afae-44d21dc68b1e	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	f	
338	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-22	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	f	
340	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-23	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
341	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-22	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	f	
342	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-23	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	f	
322	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-14	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	7	На рассмотрении	t	
329	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-16	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
317	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-13	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
314	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-13	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Оценить	f	
307	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-13	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
313	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-13	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	Оценить	f	
303	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-10-13	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
306	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-10-16	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	t	
305	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-10-16	eecdd0f8-7244-4bf6-8f96-65622901a51d	fb09a7e8-8696-45ab-abc4-baa9e1440da5	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
309	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-10-14	699509be-9a62-464c-b04f-d42efbd2154d	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	7	На рассмотрении	t	
304	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-10-14	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	1	На рассмотрении	t	
311	806f8ddc-ab22-4e19-9513-953dab466dde	2025-10-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
312	806f8ddc-ab22-4e19-9513-953dab466dde	2025-10-14	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	f	
318	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-14	2ae252e7-ff77-4445-9bba-4f12636a2234	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
319	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-10-16	4e1fbb62-07ef-441b-a27b-1956581e9ca8	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	f	
320	753cd7ca-9dcc-4b54-8d30-baedf1296e22	2025-10-16	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	f	
324	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-15	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	f	
325	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-16	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	f	
328	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-16	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	f	
330	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-20	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
331	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-21	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
332	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-22	bcb16827-828e-4e71-b66e-9ed61a8351b9	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
336	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-20	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	На рассмотрении	f	
337	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-21	c5484c5f-6ed9-4743-b796-b668e486b652	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	f	
289	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-06	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
339	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-22	e8f4b841-3dcd-4f8a-bcf2-e923597cdb5b	555a86cd-0550-42d7-b085-92842c89ee90	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	f	
361	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-10-31	71d6bb10-becc-46b9-abfb-a77d4f8d4dc1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Принято	t	
323	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-13	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	6	На рассмотрении	t	
357	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-27	6c07ef7d-b39c-4c57-8c2b-0758a52be082	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
377	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-06	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	1	На рассмотрении	t	
376	1a7ae4d5-2c2e-419e-b36a-2eca4be41641	2025-11-06	0b6e2138-4fc5-4404-b584-6707d4890102	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	12	На рассмотрении	t	
343	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-27	ace768c2-60a5-40f1-b745-63829f6b8d9f	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Выполнено	f	
366	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-29	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	f	
355	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-27	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Выполнено	f	
369	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-29	563ae91e-3338-45f7-aead-c5a3c7a57f63	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
365	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-30	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Оценить	f	
354	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-29	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
371	cdf23166-345a-4084-8437-92c51adbbe78	2025-11-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	На рассмотрении	t	
394	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-11-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	f	
382	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Принято	f	
374	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-11-05	1a901c9f-deb2-4451-a71b-4a059e561058	4b3bb52f-df8d-421c-893e-37052e982bcb	d36c9e4f-2406-492b-b467-de7884e9a2e6	24	Принято	f	
372	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-11-05	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	f	
383	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Принято	f	
387	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-11-06	4e1fbb62-07ef-441b-a27b-1956581e9ca8	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Принято	f	
347	cdf23166-345a-4084-8437-92c51adbbe78	2025-10-31	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	12	Принято	f	
345	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-31	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	f	
364	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-10-31	a426aa21-8248-4fad-8ed2-f82aa388d1b5	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	f	
310	806f8ddc-ab22-4e19-9513-953dab466dde	2025-10-13	87e352df-7694-466a-a100-26aa80ff28e9	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Оценить	f	
373	e8b5c31f-6da6-4385-adbb-06014c9e6e01	2025-11-05	159bcfcd-ecf2-49f9-a33c-8f7f4c551260	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	На рассмотрении	t	
308	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-14	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
358	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-28	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
368	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-27	62608399-2245-470d-a950-4eec08632518	a9bce02e-43b3-44bd-b9dc-0479fe49bd09	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
367	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-27	091e7bb0-f31d-4465-8e6f-130e5f83d454	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
350	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-27	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
380	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
352	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-29	020da433-e3a3-419c-851f-f52102a5fe00	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Выполнено	f	
379	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-05	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	На рассмотрении	t	
359	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-27	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Выполнено	f	
375	16bd440d-2799-48da-b879-b1c7975e0ab6	2025-11-05	7b74a6a1-d92b-476a-befc-0783a20e9170	db8ee35f-2f14-48c9-bab0-d4b2f8bc15cf	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
381	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-11-05	2f016b91-0b94-4000-bb68-b6fd5be22a0e	1de040d3-f437-4e55-a77c-c71c38fe0384	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
378	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-11-06	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	На рассмотрении	t	
400	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-11-10	fb54106f-3070-49c0-8a1e-24cdb1fc2d98	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	12	На рассмотрении	f	
401	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-11-11	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	12	На рассмотрении	f	
349	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-29	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	6	Выполнено	f	
344	cca63e0d-6cd7-4c22-8189-7aad30964b37	2025-10-30	bcb16827-828e-4e71-b66e-9ed61a8351b9	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
363	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-10-30	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Оценить	f	
385	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-06	f76acc0f-710d-4387-8731-dc6d8fd5782c	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
388	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-11-05	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
398	26341b8b-cb3e-430b-972c-c37f2b983743	2025-11-06	f59ee163-b076-4776-85b3-d0ba4c768838	1de040d3-f437-4e55-a77c-c71c38fe0384	1a5902da-bf12-4f7e-b055-775956f6adda	2	Принято	f	
399	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-11-10	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	f	
384	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-05	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	t	
386	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-11-05	571cd566-5150-4b80-9221-233cd3d39b87	54e28c12-acd4-4c69-a0a6-815a77c4e895	1a5902da-bf12-4f7e-b055-775956f6adda	6	Принято	f	
391	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-11-06	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Принято	f	
389	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-11-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	t	
393	1c6cc643-72e7-47c5-8ebc-10cd89f9ea3e	2025-11-05	1d1ec29b-4c2f-45db-94ba-38ee50b0ccf3	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	9	На рассмотрении	t	
395	c051ac7f-3de8-4be8-876f-ac50ab6b7824	2025-11-06	9056a26d-d6ce-41bf-b1c0-c255f6902d6e	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	f	
397	cdf23166-345a-4084-8437-92c51adbbe78	2025-11-06	3893f977-8f70-49be-903b-ed0149e4a505	8bfe7234-ce4a-487c-8728-82b5f1956a71	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	Принято	f	
392	da96acd3-d31d-447e-9f4e-a805a1fc478c	2025-11-06	9d8f453b-f44b-4065-a5a3-e5566c20a6f6	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Принято	f	
370	a4636783-1d55-415b-bbc2-deb27cdcf0f2	2025-10-28	563ae91e-3338-45f7-aead-c5a3c7a57f63	8bfe7234-ce4a-487c-8728-82b5f1956a71	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
356	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-28	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Оценить	f	
353	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-10-28	d6d31c42-7b07-4130-b0d0-fa87dde60a8f	612b7c5b-61b6-4795-8d07-98bc92bc4c51	58c12ab6-e451-48b5-917e-26fc1855847a	6	Оценить	f	
362	04567c72-d2d7-43fc-baa5-d22abe61e00e	2025-10-28	f632dfb7-55a7-4e2b-bccb-74c1ccf7fee6	5bbfe0ce-1c24-443b-8849-834ef90203d3	09d8307c-2256-4f71-94e1-958c21e6f1bc	12	Оценить	f	
346	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-10-29	fdc73d75-74c1-44e9-b276-2b748d35620b	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	12	Оценить	f	
390	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-11-05	eeca97d5-0cb8-4567-9ae5-d3e28c052f61	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	Принято	f	
396	ee16775d-0650-4c3f-b16d-6877ac69afe5	2025-11-05	73129017-ac9d-4a55-9020-7192a2b3150a	5bbfe0ce-1c24-443b-8849-834ef90203d3	f1d1b129-e7ad-49c6-ad16-bf2d3bf61dc3	18	Принято	f	
360	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-28	9fe01f07-a489-4eca-8639-403986129de1	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	d36c9e4f-2406-492b-b467-de7884e9a2e6	12	Выполнено	f	
351	81c6bb75-8c30-404b-904b-5d5afb2b2c47	2025-10-28	16ea24f6-2468-4895-9715-2edadc26b522	fb09a7e8-8696-45ab-abc4-baa9e1440da5	1e4fa050-70ba-4031-9201-31d8cbd60b9a	6	Выполнено	f	
402	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-11-12	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	1a5902da-bf12-4f7e-b055-775956f6adda	6	На рассмотрении	f	
348	a6902413-ff8a-46a6-9b42-9db06927cc30	2025-10-28	5dcb5b48-b6d3-44b4-9e49-9f8db410677d	17eb6ebd-ad98-491e-9e6f-b2bddbe1a16d	58c12ab6-e451-48b5-917e-26fc1855847a	12	Выполнено	f	
404	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-10	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	f	
406	17e997c9-8b23-4847-ac8a-13ce5f4a1ef3	2025-11-11	f546d1c3-036a-47dd-8662-9b37a914408f	370b51e9-685c-4a6d-bcc5-67bed5d29f48	ad7a9a32-69c3-46c0-b5b9-80f11dc55797	6	На рассмотрении	t	
410	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-11	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	f	
411	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-12	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	f	
412	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-13	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	a8222354-63a4-4c12-b4ee-00ff34788fa1	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	f	
407	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-11	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	t	
408	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-12	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	t	
409	eb71ab5f-3f77-4ed0-abd1-b616992094a0	2025-11-13	b64b3c6c-a4d6-46e3-8f09-4f7412a951d1	ef5851f3-9428-411b-a8e0-77086b2e9d90	8afa309b-cec8-4aaa-9031-06fe2b8267bf	6	На рассмотрении	t	
403	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	t	
405	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	6	На рассмотрении	t	
413	806f8ddc-ab22-4e19-9513-953dab466dde	2025-11-11	87e352df-7694-466a-a100-26aa80ff28e9	4b2e3fa7-db1b-402c-9be6-3e9754d7b6c1	86bea85e-a62d-4dc0-8c0b-30541fd7782c	12	На рассмотрении	f	
\.


--
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: Admin_agri
--

SELECT pg_catalog.setval('cron.jobid_seq', 33, true);


--
-- Name: runid_seq; Type: SEQUENCE SET; Schema: cron; Owner: Admin_agri
--

SELECT pg_catalog.setval('cron.runid_seq', 206, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 26, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: block_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.block_booking_id_seq', 1057, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1351, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- Name: projects_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Admin_agri
--

SELECT pg_catalog.setval('public.projects_booking_id_seq', 413, true);


--
-- Name: adminstrator adminstrator_admin_nick_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.adminstrator
    ADD CONSTRAINT adminstrator_admin_nick_key UNIQUE (admin_nick);


--
-- Name: adminstrator adminstrator_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.adminstrator
    ADD CONSTRAINT adminstrator_pkey PRIMARY KEY (id);


--
-- Name: analyze analyze_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public."analyze"
    ADD CONSTRAINT analyze_pkey PRIMARY KEY (id);


--
-- Name: analyze_type analyze_type_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.analyze_type
    ADD CONSTRAINT analyze_type_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: block_booking block_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.block_booking
    ADD CONSTRAINT block_booking_id PRIMARY KEY (id);


--
-- Name: control_enter_isopenregistration control_enter_isopenregistration_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_isopenregistration
    ADD CONSTRAINT control_enter_isopenregistration_pkey PRIMARY KEY (id);


--
-- Name: control_enter_openwindowforordering control_enter_openwindowforordering_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_openwindowforordering
    ADD CONSTRAINT control_enter_openwindowforordering_pkey PRIMARY KEY (id);


--
-- Name: control_enter_workerweekstatus control_enter_workerweekstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workerweekstatus
    ADD CONSTRAINT control_enter_workerweekstatus_pkey PRIMARY KEY (id);


--
-- Name: control_enter_workingdayofweek control_enter_workingdayofweek_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workingdayofweek
    ADD CONSTRAINT control_enter_workingdayofweek_pkey PRIMARY KEY (id);


--
-- Name: dependings_analyzeperequipment dependings_analyzeperequipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzeperequipment_pkey PRIMARY KEY (id);


--
-- Name: dependings_operatorperequipment dependings_operatorperequipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorperequipment_pkey PRIMARY KEY (id);

--
-- Name: dependings_executorperanalyze dependings_executorperanalyze_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_executorperanalyze
    ADD CONSTRAINT dependings_executorperanalyze_pkey PRIMARY KEY (id);

--
-- Name: dependings_projectperanalyze dependings_projectperanalyze_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectperanalyze_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: executor executor_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.executor
    ADD CONSTRAINT executor_pkey PRIMARY KEY (id);


--
-- Name: feedback_task feedback_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.feedback_task
    ADD CONSTRAINT feedback_booking_id PRIMARY KEY (booking_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project project_project_name_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_name_key UNIQUE (project_name);


--
-- Name: project project_project_nick_key; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_project_nick_key UNIQUE (project_nick);


--
-- Name: projects_booking projects_booking_id; Type: CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.projects_booking
    ADD CONSTRAINT projects_booking_id PRIMARY KEY (id);


--
-- Name: adminstrator_admin_nick_50ea001f_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX adminstrator_admin_nick_50ea001f_like ON public.adminstrator USING btree (admin_nick varchar_pattern_ops);


--
-- Name: analyze_analyze_type_id_013e3c35; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX analyze_analyze_type_id_013e3c35 ON public."analyze" USING btree (analyze_type_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: control_enter_workerweekstatus_executor_id_0aece764; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX control_enter_workerweekstatus_executor_id_0aece764 ON public.control_enter_workerweekstatus USING btree (executor_id);


--
-- Name: dependings_analyzeperequipment_analazy_id_3bd0713e; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_analyzeperequipment_analazy_id_3bd0713e ON public.dependings_analyzeperequipment USING btree (analazy_id);


--
-- Name: dependings_analyzeperequipment_equipment_name_id_5149a1e7; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_analyzeperequipment_equipment_name_id_5149a1e7 ON public.dependings_analyzeperequipment USING btree (equipment_name_id);


--
-- Name: dependings_operatorperequipment_equipment_id_94f2408d; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_operatorperequipment_equipment_id_94f2408d ON public.dependings_operatorperequipment USING btree (equipment_id);


--
-- Name: dependings_operatorperequipment_operator_id_6b4f14ed; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_operatorperequipment_operator_id_6b4f14ed ON public.dependings_operatorperequipment USING btree (operator_id);


--
-- Name: dependings_executorperanalyze_analazy_nt_id_ee17cace; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_executorperanalyze_analazy_nt_id_ee17cace ON public.dependings_executorperanalyze USING btree (analazy_nt_id);


--
-- Name: dependings_executorperanalyze_operator_nt_id_8e13d539; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_executorperanalyze_operator_nt_id_8e13d539 ON public.dependings_executorperanalyze USING btree (operator_nt_id);

--
-- Name: dependings_projectperanalyze_analazy_n_id_9d2b088b; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_projectperanalyze_analazy_n_id_9d2b088b ON public.dependings_projectperanalyze USING btree (analazy_n_id);


--
-- Name: dependings_projectperanalyze_project_n_id_810d1380; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX dependings_projectperanalyze_project_n_id_810d1380 ON public.dependings_projectperanalyze USING btree (project_n_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: project_project_name_b03a06d9_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX project_project_name_b03a06d9_like ON public.project USING btree (project_name varchar_pattern_ops);


--
-- Name: project_project_nick_fd1db1e5_like; Type: INDEX; Schema: public; Owner: Admin_agri
--

CREATE INDEX project_project_nick_fd1db1e5_like ON public.project USING btree (project_nick varchar_pattern_ops);


--
-- Name: analyze analyze_analyze_type_id_013e3c35_fk_analyze_type_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public."analyze"
    ADD CONSTRAINT analyze_analyze_type_id_013e3c35_fk_analyze_type_id FOREIGN KEY (analyze_type_id) REFERENCES public.analyze_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: control_enter_workerweekstatus control_enter_worker_executor_id_0aece764_fk_executor_; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.control_enter_workerweekstatus
    ADD CONSTRAINT control_enter_worker_executor_id_0aece764_fk_executor_ FOREIGN KEY (executor_id) REFERENCES public.executor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_analyzeperequipment dependings_analyzepe_analazy_id_3bd0713e_fk_analyze_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzepe_analazy_id_3bd0713e_fk_analyze_i FOREIGN KEY (analazy_id) REFERENCES public."analyze"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_analyzeperequipment dependings_analyzepe_equipment_name_id_5149a1e7_fk_equipment; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_analyzeperequipment
    ADD CONSTRAINT dependings_analyzepe_equipment_name_id_5149a1e7_fk_equipment FOREIGN KEY (equipment_name_id) REFERENCES public.equipment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_operatorperequipment dependings_operatorp_equipment_id_94f2408d_fk_equipment; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorp_equipment_id_94f2408d_fk_equipment FOREIGN KEY (equipment_id) REFERENCES public.equipment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_operatorperequipment dependings_operatorp_operator_id_6b4f14ed_fk_executor_; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_operatorperequipment
    ADD CONSTRAINT dependings_operatorp_operator_id_6b4f14ed_fk_executor_ FOREIGN KEY (operator_id) REFERENCES public.executor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_projectperanalyze dependings_projectpe_analazy_n_id_9d2b088b_fk_analyze_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectpe_analazy_n_id_9d2b088b_fk_analyze_i FOREIGN KEY (analazy_n_id) REFERENCES public."analyze"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dependings_projectperanalyze dependings_projectpe_project_n_id_810d1380_fk_project_i; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.dependings_projectperanalyze
    ADD CONSTRAINT dependings_projectpe_project_n_id_810d1380_fk_project_i FOREIGN KEY (project_n_id) REFERENCES public.project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: Admin_agri
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict H2fzeCoPeGmSZhXi7oR5TSP6DRuM8B3Z7RqWVGebFKENmHupsYm3mzKRiMDGSCZ

